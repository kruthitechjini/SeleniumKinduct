package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminDeviceTransfersPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;

import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;
import static org.testng.Assert.*;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

public class AdminDeviceTransfersTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AdminDeviceTransfersTest.class.getName());

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class DeviceTransferData {
        public String recipient;
        public String groupName;
        public String serialNumber1;
        public String serialNumber2;
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @Test(description = "Transfer new devices", groups = {"admin"})
    public void testNewDeviceTransfer() {

        // TODO: 10/19/18 https://jira.spireon.com/browse/VFM-5221 Time taken to load page “Start new transfer” is more then 2 min
        //change user to micwalshcpa@yahoo.com and get test_data.json from git history

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        AdminDeviceTransfersTest.DeviceTransferData config = null;
        try {
            config = mapper.treeToValue(dataNode, AdminDeviceTransfersTest.DeviceTransferData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = config.userName;
        password = config.password;
        renewalsPage = config.renewalsPage;

        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        // Go to admin form
        AdminLeftBarPage adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Device Transfer page
        AdminDeviceTransfersPage adminDeviceTransfersPage = adminLeftBarPage.clickDeviceTransfersLink();

        //Array list of serial numbers members to transfer
        ArrayList<String> serialNumbersToTransfer = new ArrayList<String>();
        serialNumbersToTransfer.add(config.serialNumber1);
        serialNumbersToTransfer.add(config.serialNumber2);

        // Transfer form data
        String recipient = config.recipient;
        String groupName = config.groupName;

        logger.log(Level.FINE, "recipient name: {}", recipient);
        logger.log(Level.FINE, "group name: {}", groupName);
        logger.log(Level.FINE, "serial number: {}", config.serialNumber1);
        logger.log(Level.FINE, "serial number: {}", config.serialNumber2);

        //Check if transfer is pending for each device.  If yes, cancel the transfer
        for (String serialNumber : serialNumbersToTransfer) {
            Boolean actionPending = adminDeviceTransfersPage.isActionPending(serialNumber);
            if (actionPending) {
                adminDeviceTransfersPage.cancelTransfer(serialNumber);
                waitUntilSpinnerVisibleThenInvisible(driver, 1, 1);
            }
        }

        // TODO: 10/24/18 https://jira.spireon.com/browse/VFM-5229 Device Transfer form doesn’t reset search values
        /* //Fill out the Transfer devices form
        adminDeviceTransfersPage.fillTransferDevicesForm(recipient, groupName, serialNumbersToTransfer);

        //Click close, start a new transfer and verify new form is empty
        adminDeviceTransfersPage.clickCloseBtn();
        adminDeviceTransfersPage.clickStartNewTransferBtn();
        adminDeviceTransfersPage.selectRecipient(recipient);
        assertTrue(adminDeviceTransfersPage.isMultipleSearchInputEmpty(), "Transfer Device form should be empty");*/

        //Transfer devices
        adminDeviceTransfersPage.fillTransferDevicesForm(recipient, groupName, serialNumbersToTransfer);
        adminDeviceTransfersPage.clickTransferNowBtn();

        //Authorize transfer
        adminDeviceTransfersPage.clickTransferAuthorizationBtn();

        //Validate model window is displayed
        assertTrue(adminDeviceTransfersPage.isModelWindowDisplayed());

        //Email sent confirmation.
        adminDeviceTransfersPage.clickEmailSentConfirmation();

        // logout
        navbarHeaderPage.logout();
    }

    @Test(description = "Validate UI Elements of Device Transfer Pop up", groups = {"admin"})
    public void testGSENewDeviceTransfer() {

        // TODO: 10/19/18 https://jira.spireon.com/browse/VFM-5221 Time taken to load page “Start new transfer” is more then 2 min
        //change user to micwalshcpa@yahoo.com and get test_data.json from git history

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        AdminDeviceTransfersTest.DeviceTransferData config = null;
        try {
            config = mapper.treeToValue(dataNode, AdminDeviceTransfersTest.DeviceTransferData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = config.userName;
        password = config.password;
        renewalsPage = config.renewalsPage;

        //login
        MapPage mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Go to admin form
        AdminLeftBarPage adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Device Transfer
        AdminDeviceTransfersPage adminDeviceTransfersPage = adminLeftBarPage.clickDeviceTransfersLink();

        //Click Start New Transfer button
        adminDeviceTransfersPage.clickStartNewTransferBtn();

        //When device transfer pop-up is visible, "From (sender)" dropdown should be shown.
        assertTrue(adminDeviceTransfersPage.getSenderDropDown().isDisplayed());


        //When device transfer pop-up is visible, "From (sender)" dropdown should be enabled.
        assertTrue(adminDeviceTransfersPage.getSenderDropDown().isEnabled());

        //validate the default selection for "From (sender)" dropdown
        assertEquals(adminDeviceTransfersPage.getSenderDropDown()
                .getAttribute("placeholder"), "-- Select A Company --");

        //When device transfer pop-up is visible, "To (recipient)" dropdown should be shown.
        assertTrue(adminDeviceTransfersPage.getRecipientDropDown().isDisplayed());

        //When device transfer pop-up is visible, "To (recipient)" dropdown should be enabled.
        assertTrue(adminDeviceTransfersPage.getRecipientDropDown().isEnabled());

        //validate the default selection for "To (recipient)" dropdown
        assertEquals(adminDeviceTransfersPage.getRecipientDropDown()
                .getAttribute("placeholder"), "-- Select A Company --");

        //When device transfer pop-up is visible, Source group box should be shown.
        assertTrue(adminDeviceTransfersPage.getSourceGroupBox().isDisplayed());

        //When device transfer pop-up is visible, Source group select all check box should be enabled.
        assertTrue(adminDeviceTransfersPage.getSourceGrpSelectAllChkbox().isEnabled());

        //When device transfer pop-up is visible, Source group box heading panel should be shown.
        assertTrue(adminDeviceTransfersPage.getSourceGroupBoxHeadingPanel().isDisplayed());

        //When device transfer pop-up is visible, Source group box body container should be shown.
        assertTrue(adminDeviceTransfersPage.getSourceGroupBoxBodyContainer().isDisplayed());

        //When device transfer pop-up is visible, Source group box footer panel should be shown.
        assertTrue(adminDeviceTransfersPage.getSourceGroupBoxFooterPanel().isDisplayed());

        //When device transfer pop-up is visible, First page btn of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getFirstPageBtnOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Last page btn of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getLastPageBtnOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Previous btn of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getPreviousBtnOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Next btn of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getNextBtnOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Refresh btn of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getRefreshBtnOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Paging status of Source group box footer should be shown.
        assertTrue(adminDeviceTransfersPage.getPagingStatusOfSourceGroupBoxFooter().isDisplayed());

        //When device transfer pop-up is visible, Target group box should be shown.
        assertTrue(adminDeviceTransfersPage.getTargetGroupBox().isDisplayed());

        //When device transfer pop-up is visible, Target group box heading panel should be shown.
        assertTrue(adminDeviceTransfersPage.getTargetGroupBoxHeadingPanel().isDisplayed());

        //When device transfer pop-up is visible, Target group box body container should be shown.
        assertTrue(adminDeviceTransfersPage.getTargetGroupBoxBodyContainer().isDisplayed());

        //When device transfer pop-up is visible, Target group select all check box should be enabled.
        assertTrue(adminDeviceTransfersPage.getTargetGrpSelectAllChkbox().isEnabled());

        //When device transfer pop-up is visible, Add btn should be shown.
        assertTrue(adminDeviceTransfersPage.getAddBtn().isDisplayed());

        //When device transfer pop-up is visible and none of the devices are selected from source panel,
        //Add btn should not be enabled.
        assertFalse(adminDeviceTransfersPage.getAddBtn().isEnabled());

        //When device transfer pop-up is visible, Remove btn should be shown.
        assertTrue(adminDeviceTransfersPage.getRemoveBtn().isDisplayed());

        //When device transfer pop-up is visible and none of the devices are selected from target panel,
        //Remove btn should not be enabled.
        assertFalse(adminDeviceTransfersPage.getRemoveBtn().isEnabled());

        //When device transfer pop-up is visible, Transfer Now btn should be shown.
        assertTrue(adminDeviceTransfersPage.getConfirmYesBtn().isDisplayed());

        //When device transfer pop-up is visible and device selection for transfer is not happened,
        //Transfer Now btn should not be enabled.
        assertFalse(adminDeviceTransfersPage.getConfirmYesBtn().isEnabled());

        //When device transfer pop-up is visible, Close btn should be shown.
        assertTrue(adminDeviceTransfersPage.getConfirmNoBtn().isDisplayed());

        //When device transfer pop-up is visible, Close btn should be enabled.
        assertTrue(adminDeviceTransfersPage.getConfirmNoBtn().isEnabled());

        //Click Close Button
        adminDeviceTransfersPage.clickCloseBtn();

        //logout
        navbarHeaderPage.logout();

    }
}
