package com.procon.vehiclefinance.util;

public class NoMongoDocumentUpdatedException extends Exception {
	public NoMongoDocumentUpdatedException(String message) {
		super(message);
	}
}
