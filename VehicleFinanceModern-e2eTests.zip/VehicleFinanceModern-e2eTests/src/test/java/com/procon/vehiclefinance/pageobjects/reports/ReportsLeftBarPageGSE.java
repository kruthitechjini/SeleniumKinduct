package com.procon.vehiclefinance.pageobjects.reports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportsLeftBarPageGSE extends ReportsLeftBarPage {

    protected static final Logger logger = LoggerFactory.getLogger(ReportsLeftBarPageGSE.class);


    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(1) select")
    private WebElement reportTypeDropdown;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(2) select")
    private WebElement deviceStatusDropdown;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(5) input")
    private WebElement vehiclesInput;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(5) label")
    private WebElement vehiclesLabel;

    @FindBy(css = "section.west div.run > button")
    private WebElement runReportBtn;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(3) select")
    private WebElement dateRangeDropdown;

    public ReportsLeftBarPageGSE(WebDriver driver) {
        super(driver);
    }

    @Override
    public WebElement getDeviceStatusDropdown() {
        return deviceStatusDropdown;
    }

    @Override
    public WebElement getVehiclesInput() {
        return vehiclesInput;
    }

    @Override
    public WebElement getReportTypeDropdown() {
        return reportTypeDropdown;
    }

    @Override
    public void clickRunButton() {
        runReportBtn.click();
    }

    @Override
    public WebElement getDateRangeDropdown() {
        return dateRangeDropdown;
    }

}
