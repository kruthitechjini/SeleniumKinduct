package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Logger;

public class AdminOrderDevicesPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminOrderDevicesPage.class.getName());

    @FindBy(name = "dealer")
    private WebElement dealerDropDown;

    public AdminOrderDevicesPage(WebDriver driver) { super(driver); }

    public WebDriver getDriver() {
        return driver;
    }

    public boolean selectDealerName(String dealerName) {
        //wait till dealer dropdown is populated with dealer names.
        String xpathStr = "//option[text()[contains(.,'" + dealerName + "')]]";

        if (waitTillDropdownIsPoulatedWithData(xpathStr))
        {
            Select dropdown = new Select(dealerDropDown);
            dropdown.selectByVisibleText(dealerName);
            return true;
        }
        else return false;

    }

    public boolean waitTillDropdownIsPoulatedWithData(String xpathStr) {
        try {
            new WebDriverWait(driver, 5).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathStr)));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

}

