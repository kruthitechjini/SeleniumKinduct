package com.procon.vehiclefinance.util;

import com.google.common.collect.Lists;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.error.YAMLException;

import javax.mail.*;
import javax.mail.internet.MimeBodyPart;
import javax.mail.search.SearchTerm;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Email {

    private static final Logger LOGGER = LoggerFactory.getLogger(Email.class);

    private static final String CREDENTIALS_FILE =
            "src/test/resources/credentials.yml";

    private static Email.Credentials creds;

    static class Credentials {
        public String host;
        public String emailId;
        public String password;
    }

    static {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            JsonNode node = mapper.readTree(new File(CREDENTIALS_FILE)).at
                    ("/" + System.getProperty("env") + "/email");
            creds = mapper.treeToValue(node, Email.Credentials.class);
        } catch (IOException e) {
            LOGGER.error("Error reading credentials: {}", e.getLocalizedMessage());
            throw new YAMLException(e.getLocalizedMessage());
        }
    }

    private Store store;

    /**
     * Login to email using Java Mail API
     *
     * @throws MessagingException
     */
    public Email() throws MessagingException {

        Properties properties = System.getProperties();
        properties.setProperty("mail.store.protocol", "imaps");
        Session session = Session.getDefaultInstance(properties, null);

        store = session.getStore("imaps");
        store.connect(creds.host, creds.emailId, creds.password);
    }

    /**
     * Disconnect store
     *
     * @throws MessagingException
     */
    public void close() throws MessagingException {
        store.close();
    }

    /**
     * Get list of messages which matches search term
     *
     * @param folderName
     * @param searchTerm
     * @return
     * @throws MessagingException
     */
    public List<Message> getMessages(String folderName, SearchTerm
            searchTerm) throws MessagingException {

        Folder folder = store.getFolder(folderName);
        folder.open(Folder.READ_WRITE);

        return Arrays.asList(folder.search(searchTerm, folder.getMessages()));
    }

    /**
     * Get list of messages which matches search term with retry policy
     *
     * @param folderName
     * @param searchTerm
     * @return
     * @throws MessagingException
     */
    public List<Message> getMessages(String folderName, SearchTerm
            searchTerm, RetryPolicy retryPolicy) throws MessagingException {

        Folder folder = store.getFolder(folderName);
        folder.open(Folder.READ_WRITE);

        Message[] messages;

        if (retryPolicy == null) {
            messages = folder.search(searchTerm, folder.getMessages());
        } else {
            messages = Failsafe.with(retryPolicy)
                    .onRetry((c, f, ctx) -> {
                        LOGGER.warn("No matching mails found. Most recent mails:");
                        int i = 0;
                        for (Message message : Lists.reverse(Arrays.asList
                                (folder.getMessages()))) {
                            LOGGER.warn("Received Date-" + message.getReceivedDate()
                                    + "\t Subject-" + message.getSubject());
                            if (++i > 1) break;
                        }
                        LOGGER.warn("No mails found#{}. Retrying...", ctx.getExecutions());
                    })
                    .get(() -> folder.search(searchTerm,
                            folder.getMessages()));
        }

        return Arrays.asList(messages);
    }

    /**
     * Get all attachments of a mail
     *
     * @param message
     * @return
     */
    public List<MimeBodyPart> getMessageAttachments(Message message)
            throws MessagingException, IOException {

        if (message == null) {
            return null;
        } else {
            String contentType = message.getContentType();
            List<MimeBodyPart> attachmentList = new ArrayList<>();

            if (contentType.contains("multipart")) {

                //Mail content with attachments
                Multipart multiPart = (Multipart) message.getContent();
                int numberOfParts = multiPart.getCount();

                for (int partCount = 0; partCount < numberOfParts; partCount++) {
                    MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart
                            (partCount);
                    if (Part.ATTACHMENT.equalsIgnoreCase(
                            part.getDisposition())) {
                        attachmentList.add(part);
                    }
                }
            }

            //List of all attachments
            return attachmentList;
        }
    }

    /**
     * Search email with searchTerm and download all the attachments
     *
     * @param searchTerm
     * @param folderName
     * @param downloadPath
     * @return
     * @throws MessagingException
     * @throws IOException
     */

    public static List<File> getEmailAttachments(SearchTerm searchTerm, String
            folderName, String downloadPath) throws MessagingException,
            IOException {

        //Gmail login
        Email email = new Email();

        RetryPolicy retryPolicy = new RetryPolicy()
                .withDelay(10, TimeUnit.SECONDS)
                .withMaxRetries(6)
                .retryIf((Message[] messageList) -> messageList.length == 0);

        //Search for all mails with SearchTerm
        List<Message> messageList = email.getMessages(folderName, searchTerm,
                retryPolicy);

        List<File> fileList = new ArrayList<>();

        if (!messageList.isEmpty()) {

            //Getting list of all attachments
            List<MimeBodyPart> attachmentFileList = email.getMessageAttachments(
                    messageList.get(0));

            if (!attachmentFileList.isEmpty()) {
                for (MimeBodyPart part : attachmentFileList) {
                    File file = new File(downloadPath + File.separator +
                            part.getFileName());
                    part.saveFile(file);
                    fileList.add(file);
                }
            }

            //Mark mail as read
            messageList.get(0).setFlag(Flags.Flag.SEEN, true);
        }

        //Close connection
        email.close();

        return fileList;
    }

    /**
     * Mark all email as read with searchTerm
     *
     * @param searchTerm
     * @param folderName
     * @return
     * @throws MessagingException
     */
    public static void markEmailsAsRead(SearchTerm searchTerm,
            String folderName) throws MessagingException {

        //Gmail login
        Email email = new Email();

        //Search for all mails with SearchTerm
        List<Message> messageList = email.getMessages(folderName, searchTerm);

        if (!messageList.isEmpty()) {
            for (Message message : messageList) {
                message.setFlag(Flags.Flag.SEEN, true);
            }
        }

        //Close connection
        email.close();
    }

    /**
     * Get content of the given message
     *
     * @param message
     * @return
     * @throws MessagingException
     * @throws IOException
     */
    public String getMailContent(Message message)
            throws MessagingException, IOException {

        if (message == null) {
            return null;
        } else {
            return Jsoup.parse(message.getContent().toString()).text();
        }
    }
}
