package com.procon.vehiclefinance.pageobjects.service;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class ServiceRecordsPage extends CommonGrid {

    @FindBy (css= "div[data-e2e=service-records-select]")
    private WebElement serviceRecordListButton;

    @FindBy (css= "div[data-e2e=service-records-select] option[class=ember-view]:nth-of-type(2)")
    private WebElement firstListedRecord;

    public void clickServiceRecordDropdown(){
        serviceRecordListButton.click();
    }

    public void clickFirstListedServiceRecord(){
        firstListedRecord.click();
    }

    /**
     * Default timeout for this class
     */
    private static final int DEFAULT_TIMEOUT = 5;

    private static final Logger logger = Logger
            .getLogger(ServiceRecordsPage.class.getName());


    public ServiceRecordsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    /**
     * Takes the page size select box and selects whichever option is specified by the 'size'.
     * @param size
     */
    public void selectPageSize( int size ) {
        waitUntilSpinnerInvisible(driver);

        Select select = new Select( pageSizeSelect() );
        select.selectByVisibleText( String.valueOf( size ) );

        // This should trigger the spinner to appear.
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Advance pagination to next page.
     */
    public void nextPage() {
        clickNextBtn();
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Move pagination back one page.
     */
    public void previousPage() {
        clickPreviousBtn();
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Advance pagination to last page.
     */
    public void lastPage() {
        clickLastPageBtn();
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Move pagination to first page.
     */
    public void firstPage() {
        clickFirstPageBtn();
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Refresh paginated grid.
     */
    public void refresh() {
        clickRefreshBtn();
        waitUntilSpinnerVisibleThenInvisible( driver, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT );
    }

    /**
     * Select First record from dropdown.
     */
    public void selectFirstService() {
        waitUntilSpinnerInvisible(driver);
        clickServiceRecordDropdown();
        clickFirstListedServiceRecord();
    }
}

