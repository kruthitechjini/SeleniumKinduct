package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.HttpRequest;
import com.procon.vehiclefinance.models.Dashboard;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.DeviceStatusEnum;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.ReportingEnum;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class DashboardService extends ServiceCaller {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardService.class);

    private static String getDashboardUsageReport;
    private static String getDashboardRecentAlerts;
    private static String getDashboardDevices;
    private static String getDashboardRenewals;


    static {
        getDashboardUsageReport = baseUrl + "operation/vfDashboardService/reportUsage.json";
        getDashboardRecentAlerts = baseUrl + "operation/json/deviceAlertRestService/get";
        getDashboardDevices = baseUrl + "operation/vfDashboardService/deviceStatus.json";
        getDashboardRenewals = baseUrl + "operation/vfDashboardService/deviceRenewalStatus.json";
    }

    /**
     * DashboardUsage: Get devices usage report
     */
    public static Dashboard.DashboardUsage getDashboardUsageReport(WebDriver driver, int dayRange, String timeZone)
            throws UnirestException {
        HashMap<String, Object> queryParams = new HashMap<>();

        queryParams.put("dayRange", dayRange);
        queryParams.put("sTz", timeZone.isEmpty() ? "America/Los_Angeles" : timeZone);

        return getDashboardUsageReport(driver, queryParams);
    }

    public static Dashboard.DashboardUsage getDashboardUsageReport(WebDriver driver, HashMap<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Dashboard.DashboardUsage> response = Unirest.get(getDashboardUsageReport)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Dashboard.DashboardUsage.class);

        return response.getBody();
    }

    /**
     * DashboardRecentAlerts: Get devices recent alerts information
     */
    public static Dashboard.DashboardRecentAlerts getDashboardRecentAlerts(WebDriver driver)
            throws UnirestException {

        //generate date pattern 2018-09-23T07:00:00.000Z where date is yesterdays and T07:00:00.000Z is const
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000)) + "T07:00:00.000Z";

        String filters = "[{\"property\":\"alertSpecId\",\"operator\":\"exists\",\"value\":false,\"type\":\"Boolean\"},"
                + "{\"property\":\"acknowledged\",\"operator\":\"ne\",\"value\":true,\"type\":\"Boolean\"},"
                + "{\"property\":\"alertDate\",\"operator\":\"gte\",\"value\":\"" + date + "\","
                + "\"type\":\"Date\"},{\"comparison\":\"in\",\"property\":\"alertTypeId\",\"value\":[112,113,114,115]}]";

        HashMap<String, Object> queryParams = new HashMap<>();

        queryParams.put("filters", filters);

        Dashboard.DashboardRecentAlerts alerts = getDashboardRecentAlerts(driver, queryParams);

        if (!alerts.success) return null;

        //calculate alerts
        for (Dashboard.DashboardRecentAlerts.RecentAlerts a : alerts.data) {
            switch (a.alertTypeId) {
                case 112:
                    alerts.totalLowBattery++;
                    break;
                case 113:
                    alerts.totalBatteryDisconnect++;
                    break;
                case 114:
                    alerts.totalPowerUpWithGps++;
                    break;
                case 115:
                    alerts.totalVehicleAbandonment++;
                    break;
            }
        }

        return alerts;
    }

    public static Dashboard.DashboardRecentAlerts getDashboardRecentAlerts(WebDriver driver, HashMap<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Dashboard.DashboardRecentAlerts> response = Unirest.get(getDashboardRecentAlerts)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Dashboard.DashboardRecentAlerts.class);

        return response.getBody();
    }

    /**
     * DashboardDevices: Get devices report
     */
    public static Dashboard.DashboardDevices getDashboardDevices(WebDriver driver)
            throws UnirestException {
        HttpResponse<Dashboard.DashboardDevices> response = Unirest.get(getDashboardDevices)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Dashboard.DashboardDevices.class);

        //count total number of devices
        Dashboard.DashboardDevices api = response.getBody();

        int totalDevices = 0;
        for (Dashboard.DashboardDevices.DevicesStatus d : api.data) {
            totalDevices += d.totalCount;
        }
        api.total = totalDevices;

        return api;
    }

    /**
     * DashboardRenewals: Get renewals devices report
     */
    public static Dashboard.DashboardRenewals getDashboardRenewals(WebDriver driver)
            throws UnirestException {
        HttpResponse<Dashboard.DashboardRenewals> response = Unirest.get(getDashboardRenewals)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Dashboard.DashboardRenewals.class);

        return response.getBody();
    }
}
