package com.procon.vehiclefinance.pageobjects.vehicles;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * This class defines the objects needed to handle the various response
 * objects from Device service calls
 */
public class DeviceDetails {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Device {
        public int accountId;
        public String accountName;
        public int deviceId;
        public int assetId;
        public String assetName;
        public String serial;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceData {
        public List<Device> data;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CommandResponse {
        public String success;
        public responseData data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class responseData {
        public String commandEventId;
    }
}