package com.procon.vehiclefinance.pageobjects.reports;

import com.procon.vehiclefinance.models.ExportFormat;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

public class ReportsPage extends CommonGrid {

    protected static final Logger logger = LoggerFactory
            .getLogger(ReportsPage.class);

    @FindBy(css = "div.active div.panel-footer [title='First Page']")
    private WebElement firstPageBtn;

    @FindBy(css = "div.active div.panel-footer [title='Previous']")
    private WebElement previousBtn;

    @FindBy(css = "div.active div.panel-footer [title='Next']")
    private WebElement nextBtn;

    @FindBy(css = "div.active div.panel-footer [title='Last Page']")
    private WebElement lastPageBtn;

    @FindBy(css = "div.active div.paging-component select")
    private WebElement selectPageSize;

    @FindBy(css = "div.active div.paging-status.pull-right")
    private WebElement pagingPositionDiv;

    @FindBy(css = "section.east ul.nav-tabs a[href='#report-history']")
    private WebElement reportHistoryTab;

    @FindBy(css = "span.name-tab")
    protected WebElement reportTab;

    //Export link elements
    @FindBy(css = "div.export-dropdown > button")
    protected WebElement exportBtn;

    @FindBy(linkText = "PDF")
    private WebElement pdfLink;

    @FindBy(linkText = "CSV")
    private WebElement csvLink;

    @FindBy(linkText = "XLS")
    private WebElement xlsLink;

    @FindBy(css = "li.report-tab.active")
    protected WebElement activeTab;

    @FindBy(css = "div.modal-body.clearfix select ")
    private WebElement exportTypeSelect;

    @FindBy(css = "button.email-it")
    private WebElement emailBtn;

    @FindBy(css = "div.modal-body.clearfix input")
    private WebElement emailInput;

    private final String emailSendBtn_css = "div.modal button.btn.btn-primary";
    @FindBy(css = emailSendBtn_css)
    private WebElement emailSendBtn;

    @FindBy(css = "div.report-heading-wrapper div.report-heading:nth-of-type(1)")
    private WebElement reportHeaderGroupNameLabel;

    @FindBy(css = "div.report-heading-wrapper div.col-xs-9 div.report-heading:nth-of-type(2)")
    private WebElement reportHeaderReportCreatedLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(1) div.report-heading:nth-of-type(3)")
    private WebElement reportHeaderStartDateLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(1) div.report-heading:nth-of-type(4)")
    private WebElement reportHeaderEndDateLabel;

    @FindBy(css = "div.active div.panel-fill-height div.ember-table-tables-container")
    private WebElement activeReportTable;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(1)")
    private WebElement reportHeaderNumberOfDevicesLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(2)")
    private WebElement reportHeaderOutForRepossessionLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(3)")
    private WebElement reportHeaderInstalledLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(4)")
    private WebElement reportHeaderUninstalledLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(2)")
    private WebElement reportHeaderMileageThresholdLabel;

    @FindBy(css = "div.report-heading-wrapper div.row:nth-of-type(2) div.report-heading:nth-of-type(3)")
    private WebElement reportHeaderCostPerMileLabel;

    @FindBy(css = "i.fa.fa-close")
    private WebElement closeReportBtn;

    @FindBy(css = "button.map-all")
    private WebElement mapAllBtn;

    public WebElement getActiveReportTable() {
        return activeReportTable;
    }

    public ReportsPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getReportHistoryTab() {
        return reportHistoryTab;
    }

    public String getReportTabText() {
        new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(reportTab));
        return reportTab.getText();
    }

    /***
     * Return all report table header column labels as a String Array
     * @return String[] header column names
     */
    public String[] getReportHeaderColumnLabels() {
        String[] headerColumnNames;
        String columnNameText = driver
                .findElements(By.cssSelector("div[class='ember-view ember-table-table-row ember-table-header-row']"))
                .get(1).getAttribute("textContent");
        if (columnNameText != null) {
            headerColumnNames = columnNameText.split("\n");
            //Adding elements to a list and remove empty/enter characters
            List<String> headerColumnList = new ArrayList<>();
            for (String columnName : headerColumnNames) {
                if (!(columnName.trim().equals(null)) && !(columnName.trim().equals(""))) {
                    headerColumnList.add(columnName.trim());
                }
            }
            //Converting List to string array as the current return type is array of strings
            headerColumnNames = new String[headerColumnList.size()];
            int i = 0;
            for (String columnName : headerColumnList) {
                headerColumnNames[i] = columnName;
                i++;
            }
        } else {
            headerColumnNames = new String[]{};
        }

        return headerColumnNames;
    }

    /**
     * Check if a feature on report page is available or not
     *
     * @param reportFeature
     * @return true if present/available, false if not
     */
    public boolean isReportFeaturePresent(String reportFeature) {
        switch (reportFeature.toLowerCase()) {
            case "report history":
                return reportHistoryTab.isDisplayed();
            default:
                return false;
        }
    }

    //click on export button
    public void clickExportBtn() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 2, 30);
        exportBtn.click();
    }

    public WebElement getPdfLink() {
        return pdfLink;
    }

    public WebElement getCsvLink() {
        return csvLink;
    }

    public WebElement getXlsLink() {
        return xlsLink;
    }

    // click on the file extension link to be exported
    public void clickRequiredFileExtension(ExportFormat format) {
        switch (format.getType()) {
            case "pdf":
                pdfLink.click();
                break;
            case "csv":
                csvLink.click();
                break;
            case "xls":
                xlsLink.click();
                break;
            default:
                throw new NoSuchElementException("Invalid Export File Type");
        }
    }

    public String getReportHeaderGroupLabel() {
        return reportHeaderGroupNameLabel.getText().split(":")[1].trim();
    }

    public WebElement getEmailSendBtn() {
        return emailSendBtn;
    }

    public WebElement getEmailInput() {
        return emailInput;
    }

    // Click on email button
    public void clickEmailBtn() {
        new WebDriverWait(driver, 30).until(elementToBeClickable(emailBtn)).click();
    }


    public void sendReportEmail(String reportFormat, String emailId) {
        clickEmailBtn();
        new WebDriverWait(driver, 30).until(visibilityOf(exportTypeSelect));
        exportTypeSelect.sendKeys(reportFormat);
        if (emailInput != null) {
            emailInput.clear();
            emailInput.sendKeys(emailId);
            clickElementAndWaitForInvisibility(driver, emailSendBtn, By.cssSelector(emailSendBtn_css), 10);
        }
    }

    public String getReportHeaderReportCreatedDate() throws ParseException {
        return dateFormat(reportHeaderReportCreatedLabel);
    }

    public String getReportHeaderStartDate() throws ParseException {
        try {
            return dateFormat(reportHeaderStartDateLabel);
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    public String getReportHeaderEndDate() throws ParseException {
        try {
            return dateFormat(reportHeaderEndDateLabel);
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    // Parse the date from the Element. The Element text is of this form:
    // Report Created: 10/19/2017 06:02 PM (CDT)
    private String dateFormat(WebElement dateElement) throws ParseException {
        String text = dateElement.getText();
        // ignore the timezone info for now because of issue that it always
        // displays current DST value, instead of when the report was run.
        String dateString = text.substring(text.indexOf(":") + 1, text
                .indexOf("(")).trim();
        return dateString;

        /*
        SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a '('z')'");
        Date date = inputFormat.parse(dateString);
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        return outputFormat.format(date);
        */
    }

    public String getActiveReportId() {
        WebElement activeTabLink = activeTab.findElement(By.cssSelector("a"));
        String href = activeTabLink.getAttribute("href");

        // check if the active tab is report history tab, in which case there
        // is no report id to return
        if (href.contains("report-history")) {
            return null;
        }
        String marker = "#report-";
        return href.substring(href.indexOf(marker) + marker.length());
    }

    public HashMap<String, String> getTableFirstRow() {
        return getTableFirstRow(activeReportTable);
    }

    public int getReportHeaderNumberOfDevicesLabel() {
        return Integer.parseInt(reportHeaderNumberOfDevicesLabel.getText()
                .split(":")[1].trim());
    }

    public int getReportHeaderOutForRepossessionLabel() {
        return Integer.parseInt(reportHeaderOutForRepossessionLabel.getText()
                .split(":")[1].trim());
    }

    public int getReportHeaderInstalledLabel() {
        return Integer.parseInt(reportHeaderInstalledLabel.getText()
                .split(":")[1].trim());
    }

    public int getReportHeaderUninstalledLabel() {
        return Integer.parseInt(reportHeaderUninstalledLabel.getText()
                .split(":")[1].trim());
    }

    public String getReportHeaderMileageLabel() {
        return reportHeaderMileageThresholdLabel.getText().split(":")[1].trim();
    }

    public String getReportHeaderCostPerMileLabel() {
        return reportHeaderCostPerMileLabel.getText().split(":")[1].trim();
    }

    /**
     * Close all open Report tabs
     *
     * @return
     */
    public void closeReportTab() {
        List<WebElement> reportTabList = driver.findElements(By.cssSelector("li.report-tab"));
        reportTabList.remove(1);
        for (WebElement reportTab : reportTabList) {
            new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(closeReportBtn))
                    .click();
        }
    }

    /**
     * Click on map all button
     */
    public void clickMapAllBtn() {
        new WebDriverWait(driver, 30).until(elementToBeClickable(mapAllBtn)).click();
    }

    public WebElement getPagingPositionDiv() {
        return pagingPositionDiv;
    }

    public WebElement getFirstPageBtn() {
        return firstPageBtn;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getLastPageBtn() {
        return lastPageBtn;
    }

    public WebElement getSelectPageSize() {
        return selectPageSize;
    }
}
