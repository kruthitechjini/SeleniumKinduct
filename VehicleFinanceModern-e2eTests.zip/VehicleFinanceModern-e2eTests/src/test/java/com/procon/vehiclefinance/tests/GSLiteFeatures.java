package com.procon.vehiclefinance.tests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.mail.MessagingException;
import java.io.IOException;
import java.lang.reflect.Method;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class GSLiteFeatures extends BaseTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(GSLiteFeatures.class);

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected VehiclesPage vehiclesPage;
    protected AdminLeftBarPage adminLeftBarPage;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String serialNumber;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickVehicles(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }
        } catch (JsonProcessingException e) {
            fail("Failed to process config values", e);
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Vehicles Page
        vehiclesPage = navbarHeaderPage.clickVehicles();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "GSLite features test ", groups =
            {"features"})
    public void testGSLiteFeatures() throws MessagingException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        navbarHeaderPage.isAlertsPresent();
        //check for main tabs
        assertTrue(!navbarHeaderPage.isAlertsPresent(), "Alerts tab should not be present");
        assertTrue(!navbarHeaderPage.isDashboardPresent(), "Dashboard tab should not be present");
        assertTrue(!navbarHeaderPage.isSalesPresent(), "Sales tab should not be present");
        assertTrue(!navbarHeaderPage.isReportsPresent(), "Reports tab should not be present");
        assertTrue(navbarHeaderPage.isAdminPresent(), "Admin tab should be present");
        assertTrue(navbarHeaderPage.isVehiclesPresent(), "Vehicles tab should be present");

        //Select Serial Number
        vehiclesPage.searchUniqueVehicle(data.serialNumber);
        vehiclesPage.selectAll();

        //validate features in Vehicles tab
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Locate"), "Locate Button is Not present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Starter Enable/Disable"), "Starter Enable/Disable is Not present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("History"), "Vehicle Details tab is Not present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Locate"), "Vehicle History tab is Not present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Notes"), "Notes tab should not be present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Search"), "Search should be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Warning On/Off"), "Warning commands should not be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Group Filter"), "Group Filter");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Advanced Filtering"), "Advanced Filtering is not be present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Device Status"), "Device Status is not be present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Reporting"), "Vehicles,Reporting is not be present");
        assertTrue(vehiclesPage.isVehicleFeaturePresent("Starter Status"), "Starter Status is not be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Warning Status"), "Warning Status should not be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("QuickFence"), "QuickFence should not be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Drive Report"), "Drive Report should not be present");
        assertTrue(!vehiclesPage.isVehicleFeaturePresent("Vehicle Info Print button"), "Vehicle Info Print button should not be present");

        //validate features in Admin tab
        adminLeftBarPage = navbarHeaderPage.clickAdmin();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //following should be present in Admin
        assertTrue(adminLeftBarPage.isAdminFeaturePresent("Devices"), "Devices Menu is not present");
        assertTrue(adminLeftBarPage.isAdminFeaturePresent("Account Management"), "Account Management menu is not present");

        //Following should not be present in Admin section
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("GeoFences"), "GeoFences Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("GeoZones"), "GeoZones Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Impound Lots"), "Impound Lots Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Device Transfers"), "Device Transfers Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Scheduled Commands"), "Scheduled Commands Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Recipients"), "Recipients Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Recovery"), "Recovery Menu should not be present");
        assertTrue(!adminLeftBarPage.isAdminFeaturePresent("Request Installation"), "Request Installation Menu should not be present");
    }
}
