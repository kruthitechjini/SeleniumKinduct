package com.procon.vehiclefinance.pageobjects.reports;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.waitUntilAjaxSpinnerVisibleThenInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;

public abstract class ReportSelectionPanel {

    private WebDriver driver;

    private WebElement reportTypeDropdown;
    private WebElement groupsLabel;
    private WebElement groupsInput;
    private WebElement vehiclesLabel;
    private WebElement vehiclesInput;
    private WebElement dateRangeDropdown;
    private WebElement helpBlockLabel;
    private WebElement customStartDateInput;
    private WebElement customStartTimeDropdown;
    private WebElement customEndDateInput;
    private WebElement customEndTimeDropdown;
    private WebElement mileageThresholdInput;
    private WebElement costPerMileInput;
    private WebElement deviceStatusDropdown;

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getReportTypeDropdown() {
        return reportTypeDropdown;
    }

    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    public WebElement getGroupsInput() {
        return groupsInput;
    }

    public WebElement getVehiclesLabel() {
        return vehiclesLabel;
    }

    public WebElement getVehiclesInput() {
        return vehiclesInput;
    }

    public WebElement getDateRangeDropdown() {
        return dateRangeDropdown;
    }

    public WebElement getHelpBlockLabel() {
        return helpBlockLabel;
    }

    public WebElement getCustomStartDateInput() {
        return customStartDateInput;
    }

    public WebElement getCustomStartTimeDropdown() {
        return customStartTimeDropdown;
    }

    public WebElement getCustomEndDateInput() {
        return customEndDateInput;
    }

    public WebElement getCustomEndTimeDropdown() {
        return customEndTimeDropdown;
    }

    public WebElement getMileageThresholdDropdown() {
        return mileageThresholdInput;
    }

    public WebElement getCostPerMileDropdown() {
        return costPerMileInput;
    }

    public WebElement getDeviceStatusDropdown() { return deviceStatusDropdown; }

    private String browserName = System.getProperty("browser");

    /**
     * Get the list of report types from report type dropdown
     *
     * @return list of report types
     */
    public List<String> getReportTypes() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 1, 10);
        List<String> reportTypes = new ArrayList<>();
        List<WebElement> options = new Select(getReportTypeDropdown())
                .getOptions();
        for (WebElement option : options) {
            reportTypes.add(option.getText());
        }
        return reportTypes;
    }

    public void selectReportType(ReportTypeEnum type) {
        if (type != null) {
            waitUntilSpinnerVisibleThenInvisible(getDriver(), 1, 10);
            new Select(getReportTypeDropdown()).selectByVisibleText(type.getName());
        }
    }

    private static final String GROUP_CHILD_CSS = "ul.list-unstyled > li";

    public List<String> getGroups() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 2, 10);
        WebElement parent = getGroupsInput().findElement(By.xpath(".."));

        List<String> groups = new ArrayList<>();
        for (WebElement elem : parent.findElements(By.cssSelector(GROUP_CHILD_CSS))) {
            // getText doesn't work, so we have to get the overall
            // textContent and remove the span textContent
            String allText = elem.getAttribute("textContent");
            String spanText;
            int beginIndx;
            try {
                spanText = elem.findElement(By.cssSelector("span"))
                        .getAttribute("textContent");
                beginIndx = allText.indexOf(spanText) + spanText.length();
            } catch (NoSuchElementException e) {
                beginIndx = 0;
            }
            int endIndx = allText.indexOf('\n', beginIndx) == -1 ? allText
                    .length() : allText.indexOf('\n', beginIndx);
            groups.add(allText.substring(beginIndx, endIndx));
        }
        return groups;
    }

    public void selectGroup(String groupName) {
        if (groupName != null) {
            WebElement groupsInput = getGroupsInput();
            groupsInput.click();
            groupsInput.sendKeys(groupName);
            if(browserName.equalsIgnoreCase("ff") || browserName.equalsIgnoreCase("firefox")) {
                groupsInput.sendKeys(Keys.ESCAPE);
            }else {
                getGroupsLabel().click();
            }
        }
    }

    public void selectVehicle(String vehicleName) {
        if (vehicleName != null) {
            WebElement vehiclesInput = getVehiclesInput();
            vehiclesInput.click();
            vehiclesInput.sendKeys(vehicleName);
            waitUntilAjaxSpinnerVisibleThenInvisible(getDriver(),2,5);
            if(browserName.equalsIgnoreCase("ff") || browserName.equalsIgnoreCase("firefox")) {
                vehiclesInput.sendKeys(Keys.ESCAPE);
            }else {
                getVehiclesLabel().click();
            }
        }
    }

    public List<String> getDateRanges() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 2, 10);
        List<String> dateRanges = new ArrayList<>();
        List<WebElement> options = new Select(getDateRangeDropdown())
                .getOptions();
        for (WebElement option : options) {
            dateRanges.add(option.getText());
        }
        return dateRanges;
    }

    public void selectDateRange(DateRangeEnum dateRange) {
        if (dateRange != null) {
            WebElement selectBox = getDateRangeDropdown();
            List<WebElement> options = selectBox.findElements(By.tagName("option"));

            for (WebElement option : options) {
                if (option.getText().contains(dateRange.getName())) {
                    option.click();
                    break;
                }
            }
        }
    }

    public void enterReportParams(ReportTypeEnum reportType, String
            groupName, String vehicleName, DateRangeEnum dateRange) {
        selectReportType(reportType);
        selectGroup(groupName);
        selectVehicle(vehicleName);
        selectDateRange(dateRange);
    }

    public void runReport(ReportTypeEnum reportType, String
            groupName, String vehicleName, DateRangeEnum dateRange) {
        enterReportParams(reportType, groupName, vehicleName, dateRange);
        clickRunButton();
    }

    public abstract void clickRunButton();

    public void runReport(ReportTypeEnum reportType, String
            groupName, String vehicleName, DateRangeEnum dateRange, String startDate, String endDate, String startTime, String endTime) {
        enterReportParams(reportType, groupName, vehicleName, dateRange);
        enterCustomDate(startDate, endDate, startTime, endTime);
        clickRunButton();
    }

    public void enterCustomDate(String startDate, String endDate, String startTime, String endTime) {

        if (startDate != null) {
            getCustomStartDateInput().clear();
            getCustomStartDateInput().sendKeys(startDate);
            getCustomStartDateInput().sendKeys(Keys.ESCAPE);
        }

        if (endDate != null) {
            getCustomEndDateInput().clear();
            getCustomEndDateInput().sendKeys(endDate);
            getCustomEndDateInput().sendKeys(Keys.ESCAPE);
        }

        if (startTime != null) {
            new Select(getCustomStartTimeDropdown()).selectByVisibleText(startTime);
        }

        if (endTime != null) {
            new Select(getCustomEndTimeDropdown()).selectByVisibleText(endTime);
        }
    }

    public void runReport(ReportTypeEnum reportType, String
            groupName, String vehicleName, DateRangeEnum dateRange, String
                                  mileageThreshold, String costPerMile) {
        enterReportParams(reportType, groupName, vehicleName, dateRange);
        enterMileageParams(mileageThreshold, costPerMile);
        clickRunButton();
    }

    public void enterMileageParams(String mileageThreshold, String costPerMile) {

        if (mileageThreshold != null) {
            getMileageThresholdDropdown().clear();
            getMileageThresholdDropdown().sendKeys(mileageThreshold);
            getMileageThresholdDropdown().sendKeys(Keys.ESCAPE);
        }

        if (costPerMile != null) {
            getCostPerMileDropdown().clear();
            getCostPerMileDropdown().sendKeys(costPerMile);
            getCostPerMileDropdown().sendKeys(Keys.ESCAPE);
        }
    }

    public void selectDeviceStatus(String deviceStatus) {
        new Select(getDeviceStatusDropdown()).selectByVisibleText(deviceStatus);
    }
}