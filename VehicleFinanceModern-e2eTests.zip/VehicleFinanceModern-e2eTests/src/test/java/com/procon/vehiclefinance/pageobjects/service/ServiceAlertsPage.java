package com.procon.vehiclefinance.pageobjects.service;

import com.procon.vehiclefinance.models.AlertsSpec;
import com.procon.vehiclefinance.models.Recipient;
import com.procon.vehiclefinance.models.Recipients;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class ServiceAlertsPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(ServiceAlertsPage.class.getName());

    @FindBy(css = "[name='addServiceAlert']")
    private WebElement addServiceAlertsBtn;

    @FindBy(css = "[name='name']")
    private WebElement alertNameInput;

    @FindBy(css = "[name='distanceInterval']")
    private WebElement distanceIntervalInput;

    @FindBy(css = "[name='recipientsJSON']")
    private WebElement recipientDropdown;

    @FindBy(css = "[name='addRecipientButton']")
    private WebElement addRecipientBtn;

    private final String cancelBtn_css = "div.modal-footer > button:nth-of-type(1)";
    @FindBy(css = cancelBtn_css)
    private WebElement cancelBtn;

    private final String saveBtn_css = "div.modal-footer > button:nth-of-type(2)";
    @FindBy(css = saveBtn_css)
    private WebElement saveBtn;

    public ServiceAlertsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickAddServiceAlertsBtn() {
        waitUntilSpinnerInvisible(driver);
        addServiceAlertsBtn.click();
        waitUntilSpinnerInvisible(driver);
    }

    public void clickCancelBtn() {
        waitUntilSpinnerInvisible(driver);
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector(cancelBtn_css));
    }

    public void addAlertsSpec(AlertsSpec alertsSpec, Recipients recipients) {
        addEdit(alertsSpec);
        selectRecipients(recipients);
        saveAlert();
    }
    public void cancelAlertsSpec(AlertsSpec alertsSpec, Recipients recipients) {
        addEdit(alertsSpec);
        selectRecipients(recipients);
        clickCancelBtn();
    }

    public void addEdit(AlertsSpec alertsSpec) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);
        enterName(alertsSpec.getAlertName());
        enterDistanceInterval(String.valueOf(alertsSpec.getDistanceInterval()));
    }

    public void saveAlert() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(saveBtn_css));
    }

    public void enterName(String name) {
        if (name != null) {
            enterText(driver, alertNameInput, name);
        }
    }

    public void enterDistanceInterval(String distanceInterval) {
        if (distanceInterval != null) {
            enterText(driver, distanceIntervalInput, distanceInterval);
        }
    }

    public void selectRecipients(Recipients recipients) {
        if (recipients != null) {
            int i = 0;
            for (Recipient recipient : recipients.getRecipients()) {
                selectRecepient(recipient);
                new WebDriverWait(driver, 10).until(
                        elementToBeClickable(addRecipientBtn))
                        .click();
                waitUntilSpinnerInvisible(driver, 5);
                selectDeliveryMethod(recipient.getDeliveryType(), i);
                i++;
            }
        }
    }

    public void selectDeliveryMethod(String s, int i) {
        String format = "//div[@class='fixed-body grid-container']//tr[%s]//select";
        String xpath = String.format(format, i + 1);
        new Select(driver.findElement(By.xpath(xpath))).selectByVisibleText(s);
    }

    public void selectRecepient(Recipient recipient) {
        if (recipient != null) {
            String recipientName = recipient.getName();
            new Select(recipientDropdown).selectByVisibleText(recipientName);
        }
    }

    public boolean isAlertAvailable(String strAlertName) {
        return WebElements.isElementPresent(driver, By.xpath("//label[text()='" + strAlertName + "']"));
    }
}

