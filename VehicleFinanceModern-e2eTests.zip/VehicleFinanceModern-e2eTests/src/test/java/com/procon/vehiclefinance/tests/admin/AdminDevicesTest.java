package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.models.Group;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminDevicesPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.DeviceService.*;
import static com.procon.vehiclefinance.services.GroupService.getGroups;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static com.procon.vehiclefinance.util.WebElements.waitUntilAjaxSpinnerVisibleThenInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminDevicesTest extends BaseTest {

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminDevicesPage adminDevicesPage;

    private static final Logger logger = LoggerFactory.getLogger(AdminDevicesTest.class);

    protected String terminateDeviceName;
    protected String revokeDeviceName;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String terminateDeviceName;
        public String revokeDeviceName;

    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdminDevices(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;
            terminateDeviceName = data.terminateDeviceName;
            revokeDeviceName = data.revokeDeviceName;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Admin
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Devices Page
        adminDevicesPage = adminLeftBarPage.clickDevicesLink();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //Reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Change Group", groups = {"admin", "pipeline", "devices"})
    public void testChangeGroup() throws UnirestException, IOException {

        //Open Change Group form
        adminDevicesPage.clickChangeGroupBtn();

        //Use api call to identify source group and destination group to move
        //devices.
        List<Group.GroupItem> groups = getGroups(driver).data;

        //If number of groups are less than 2 fail the test
        if (groups.size() < 2) {
            fail("At least two groups must be present for this test to run");
        }

        //Identify transfer to and from groups. Make sure transferFrom has
        //at-least one device
        Group.GroupItem transferFromGrp = null, transferToGrp = null;
        List<Device.DeviceDetail> devices = null;
        for (Group.GroupItem grp : groups) {
            devices = getDevices(driver, grp.id, grp.name, false).data;
            if (devices.size() >= 1) {
                transferFromGrp = grp;
                break;
            }
        }

        assertNotNull(transferFromGrp, "Transfer from group not identified, " +
                "at least two devices may not be present in any group");

        //'transfer to' group just needs to be different from 'transfer from' group
        for (Group.GroupItem grp : groups) {
            if (grp.id != transferFromGrp.id) {
                transferToGrp = grp;
                break;
            }
        }

        assertNotNull(transferToGrp, "Transfer to group not identified, at " +
                "least two devices may not be present in any group");

        logger.info("Transfer from Group: {}", transferFromGrp);
        logger.info("Transfer to Group: {}", transferToGrp);
        logger.info("Devices to be transferred: {}", devices);

        List<String> deviceList = new ArrayList<>();
        deviceList.add(devices.get(0).serialNumber);

        //Transfer device through UI. This method also validates that the
        //serial numbers show up in the 'to' group
        adminDevicesPage.changeGroup(transferFromGrp.name, transferToGrp.name,
                false, deviceList);

        //Search the device that has been transferred
        adminDevicesPage.searchVehicle(String.valueOf(deviceList).replaceAll("^\\[|\\]$", ""));
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate that the device has been transferred
        assertEquals(String.valueOf(deviceList).replaceAll("^\\[|\\]$", ""),
                adminDevicesPage.getTableFirstRowSerialNumber().getText());
        assertEquals(transferToGrp.name, adminDevicesPage.getTableFirstRowGroup().getText());

        //Validate that the device has been transferred through api call
        boolean deviceTransferred = false;
        List<Device.DeviceDetail> deviceDetails = getDevices(driver, transferToGrp.id, transferToGrp.name, false).data;
        for (Device.DeviceDetail deviceDetail : deviceDetails) {
            if (deviceDetail.serialNumber.equals(devices.get(0).serialNumber)) {
                deviceTransferred = true;
                break;
            }
        }
        if (!deviceTransferred) {
            fail("Device was not transferred");
        }

        //Transfer devices back to original group using api call
        List<Integer> assetIds = new ArrayList<>();
        assetIds.add(devices.get(0).assetId);
        Device.AssetTransferResponse response = transferAssetGroup(driver, assetIds,
                transferFromGrp.groupId);
        if (!response.success) {
            logger.warn("Asset not transferred back: {}", response);
        }
    }

    @Test(description = "Admin Devices verify page elements", groups = {"admin", "devices"})
    public void testAdminDevicesPageElements() throws UnirestException {

        List<String> devicesColumns = Arrays.asList(
                "Group",
                "Name",
                "Serial",
                "Airtime Status",
                "Inventory Status",
                "Purchase Date",
                "Renewal Date",
                "Actions");
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

        //Verify Title of the page and search box
        assertEquals(adminLeftBarPage.getActiveLeftBarElement(), "Devices");
        assertTrue(adminDevicesPage.getSearchInput().isDisplayed());

        //Verify 'Change group' btn
        assertTrue(adminDevicesPage.getChangeGroupBtn().isDisplayed());

        //Verify Grid Columns.
        assertEquals(adminDevicesPage.getGridColumns(), devicesColumns,
                "Column list does not match expected list for Devices grid");

        //Verify records count
        Device.DeviceData deviceDataAPI = getDevicesAll(driver);
        assertEquals(adminDevicesPage.getTotalRecordCount(), deviceDataAPI.total);

        //Verify first record in grid matches with api response
        HashMap<String, String> tableFirstRow = adminDevicesPage.getTableFirstRow();

        // TODO: 12/7/18 Check with dev team what API return Inventory status

        assertEquals(tableFirstRow.get("Group"), deviceDataAPI.data.get(0).assetGroupName != null ? deviceDataAPI.data.get(0).assetGroupName : "");
        assertEquals(tableFirstRow.get("Name"), deviceDataAPI.data.get(0).assetName);
        assertEquals(tableFirstRow.get("Serial"), deviceDataAPI.data.get(0).serialNumber);
        assertEquals(tableFirstRow.get("Purchase Date"), formatDate(driver,
                deviceDataAPI.data.get(0).networkInstallDate, dateFormat));
        assertEquals(tableFirstRow.get("Renewal Date"), formatDate(driver,
                deviceDataAPI.data.get(0).networkRenewalDate, dateFormat));

        //Verify pagination
        adminDevicesPage.verifyNavigationElementsPresent();
    }

    @Test(description = "Admin Devices - Search, sort, pagination", groups = {"admin", "devices"})
    public void testAdminDevicesSearchSortPagination() {

        // TODO: 9/5/18 after https://jira.spireon.com/browse/VFM-5067 will resolve uncomment next line
        //List<String> devicesColumnsSort = Arrays.asList("Group", "Name", "Serial", "Purchase Date", "Renewal Date");
        List<String> devicesColumnsSort = Arrays.asList("Group", "Name", "Serial");

        //Verify search is case insensitive
        HashMap<String, String> tableFirstRow = adminDevicesPage.getTableFirstRow();
        String searchKey = tableFirstRow.get("Name");

        int count = adminDevicesPage.search(searchKey);
        List<HashMap<String, String>> table = adminDevicesPage.getFixedTable();

        assertEquals(adminDevicesPage.search(searchKey.toLowerCase()), count);
        assertEquals(adminDevicesPage.getFixedTable(), table);

        assertEquals(adminDevicesPage.search(searchKey.toUpperCase()), count);
        assertEquals(adminDevicesPage.getFixedTable(), table);

        //Verify "The user grid should update with the search input, does not require clicking a search icon or hitting enter"
        adminDevicesPage.getSearchInput().clear();
        new Actions(driver).sendKeys(adminDevicesPage.getSearchInput(),
                searchKey.substring(0, searchKey.length() / 3)).perform();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertNotEquals(adminDevicesPage.getTotalRecordCount(), count);

        //Verify 'X' icon
        assertTrue(adminDevicesPage.getSearchInputCancel().isDisplayed());
        adminDevicesPage.getSearchInputCancel().click();
        waitUntilAjaxSpinnerVisibleThenInvisible(driver, 1, 10);

        //Verify when no text is entered in the search box , the background says 'Search'
        assertEquals(adminDevicesPage.getSearchInput().getAttribute("placeholder"), "Search");

        //Verify which columns are sortable
        devicesColumnsSort.forEach(column -> assertTrue(adminDevicesPage.isColumnSortable(column),
                "Sortable Column list does not match expected list for grid"));

        //Click on column and verify sort was performed
        devicesColumnsSort.forEach(column -> adminDevicesPage.verifyColumnSorting(column));

        //Verify pagination
        adminDevicesPage.verifyPagination();
    }

    @Test(description = "Verify Terminate Device and Revoke Dealer Access btn", groups = {"admin", "devices"})
    public void testDeviceTerminateDealerAccess() {

        if(terminateDeviceName.isEmpty() || revokeDeviceName.isEmpty()) {
            throwIllegalStatusException(terminateDeviceName + " and " + revokeDeviceName);
        }

        //we have to change the dimension of the window to load all buttons
        driver.manage().window().setPosition(new Point(0, 0));
        driver.manage().window().setSize(new Dimension(1920, 1080));

        //verify Terminate btn in Devices
        if (adminDevicesPage.search(terminateDeviceName) != 1) {
            throwIllegalStatusException(terminateDeviceName);
        }
        assertTrue(adminDevicesPage.getTerminateBtn().isDisplayed());

        //click Terminate and verify popup
        adminDevicesPage.getTerminateBtn().click();
        assertEquals(adminDevicesPage.getTerminatePopupHeader(), "Terminate Device");
        adminDevicesPage.clickTerminatePopupCancel();

        //verify "Revoke Dealer Access" btn
        if (adminDevicesPage.search(revokeDeviceName) != 1) {
            throwIllegalStatusException(revokeDeviceName);
        }

        //click Revoke Dealer Access and verify popup
        adminDevicesPage.getRevokeBtn().click();
        assertEquals(adminDevicesPage.getRevokePopupHeader(), "Revoke");
        adminDevicesPage.clickRevokePopupCancel();

        //go to Vehicles and verify Terminate and Revoke there
        VehiclesPage vehiclesPage = navbarHeaderPage.clickVehicles();
        vehiclesPage.searchUniqueVehicle(terminateDeviceName);
        vehiclesPage.selectVehicle(1);
        vehiclesPage.clickDetailsTab();
        assertTrue(vehiclesPage.getTerminateBtn().isEnabled(), "Terminate btn isn't clickable");

        vehiclesPage.searchUniqueVehicle(revokeDeviceName);
        vehiclesPage.selectVehicle(1);
        vehiclesPage.clickDetailsTab();
        assertTrue(vehiclesPage.getRevokeBtn().isEnabled(), "Revoke dealer access btn isn't clickable");
    }

    private void throwIllegalStatusException(String deviceName) {
        throw new IllegalStateException("Verify device " + deviceName + " is in correct state");
    }

}
