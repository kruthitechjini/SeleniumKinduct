package com.procon.vehiclefinance.pageobjects.service;

import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.logging.Logger;

public class ServicePage {
    protected WebDriver driver;

    protected static final Logger logger = Logger
            .getLogger(ServicePage.class.getName());

    @FindBy(linkText = "Service Alerts")
    private WebElement serviceAlertsLink;

    @FindBy(linkText = "Service Records")
    private WebElement serviceRecordsLink;

    public ServicePage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public ServiceAlertsPage clickServiceAlerts() {
        serviceAlertsLink.click();
        return PageFactory.initElements(driver, ServiceAlertsPage.class);
    }

    /**
     * Clicks the link for Service Records in the left-hand navigation margin to navigate to the
     * Service Records page.
     *
     * @return
     */
    public ServiceRecordsPage clickServiceRecords() {
        serviceRecordsLink.click();
        return PageFactory.initElements( driver, ServiceRecordsPage.class );
    }

    public boolean isServiceAlertFeaturePresent(String strAlertFeature) {
        return WebElements.isElementPresent(driver, By.partialLinkText(strAlertFeature));
    }
}

