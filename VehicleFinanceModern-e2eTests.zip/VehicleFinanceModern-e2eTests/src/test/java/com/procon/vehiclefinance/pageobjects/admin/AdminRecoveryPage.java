package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;

public class AdminRecoveryPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminRecoveryPage.class.getName());

    public AdminRecoveryPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void expireLink(String linkString) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        String format = "//a[text()='%s']//parent::span/parent::div/parent::div/div[12]/descendant::a";
        String xpath = String.format(format, linkString);
        gridBody.findElement(By.xpath(xpath)).click();
    }

    public String getPageTitle()
    {
        return driver.findElement(By.className("panel-title")).getText();
    }
}
