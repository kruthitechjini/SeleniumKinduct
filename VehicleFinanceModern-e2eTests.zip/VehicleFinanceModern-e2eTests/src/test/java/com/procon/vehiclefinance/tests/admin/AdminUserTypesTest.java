package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.errorprone.annotations.FormatString;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Account;
import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminUserTypesPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminUsersPage;
import com.procon.vehiclefinance.pageobjects.admin.UserPermission;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.services.AccountService.*;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminUserTypesTest extends BaseTest {

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminUserTypesPage adminUserTypesPage;

    private static final Logger logger = Logger
            .getLogger(AdminUserTypesTest.class.getName());

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String serialNumber;
        public List<String> addToGroup;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) throws IOException {

        logger.info("Running test " + method.getName());

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            } else {
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to User Types Link
        adminUserTypesPage = adminLeftBarPage.clickUserTypesLink();

    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Add/Edit/Delete an Admin User Type", groups =
            {"prodsmoke", "admin"})
    public void testAddEditDeleteUserTypes() {

        adminUserTypesPage.clickAddUserTypesBtn();

        // form data
        String adminUserTypeData = "UserType-" + System.currentTimeMillis();
        ArrayList<UserPermission> chkBoxesSelection = new ArrayList<>();

        chkBoxesSelection.add(UserPermission.EDIT_VEHICLE_INFORMATION);
        chkBoxesSelection.add(UserPermission.LOCATE);

        //fill and submit form
        adminUserTypesPage.addUserType(adminUserTypeData, chkBoxesSelection);

        //confirm user type is added and edit user
        ArrayList<UserPermission> chkBoxesSelectionUpdate = new ArrayList<>();
        chkBoxesSelectionUpdate.add(UserPermission.USER_TYPES);

        // modified checkbox selection
        adminUserTypesPage.editUserType(adminUserTypeData, chkBoxesSelectionUpdate);

        // delete user
        mapPage = adminUserTypesPage.deleteUserType(adminUserTypeData);
    }

    @Test(description = "Validate an Admin User Type - User Permissions",
            groups = {"admin"})
    public void testUserTypeUserPermissions() throws UnirestException {

        if(adminUserTypesPage.getTotalRecordCount() > 100)
        {
            fail("Total amount of User Types should be less 100 because UserTypeDropdown in Add/Edit User shows 100 records only");
        }

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Click add button
        adminUserTypesPage.clickAddUserTypesBtn();

        //Form data for user type
        String adminUserTypeData = "User_Type-" + System
                .currentTimeMillis();
        ArrayList<UserPermission> chkBoxesSelection = new ArrayList<>();
        chkBoxesSelection.add(UserPermission.VEHICLES);
        chkBoxesSelection.add(UserPermission.EDIT_VEHICLE_INFORMATION);
        chkBoxesSelection.add(UserPermission.HISTORY);
        chkBoxesSelection.add(UserPermission.LOCATE);
        chkBoxesSelection.add(UserPermission.STARTER_ENABLE);
        chkBoxesSelection.add(UserPermission.STARTER_DISABLE);
        chkBoxesSelection.add(UserPermission.ALERTS);
        chkBoxesSelection.add(UserPermission.REPORTS);
        chkBoxesSelection.add(UserPermission.GEOZONE);
        chkBoxesSelection.add(UserPermission.DEVICE_TRANSERS);
        chkBoxesSelection.add(UserPermission.USER_TYPES);
        chkBoxesSelection.add(UserPermission.USERS);

        //Fill and submit form
        waitUntilSpinnerVisibleThenInvisible(driver, 3, 10);
        adminUserTypesPage.addUserType(adminUserTypeData, chkBoxesSelection);

        //Open user modal form
        AdminUsersPage adminUsersPage = adminLeftBarPage.clickUserLink();
        adminUsersPage.clickAddUserBtn();

        //Form data for user
        String username = "autotest-" + System.currentTimeMillis();

        Person person = new Person.PersonBuilder()
                .firstName("Automated")
                .lastName("Test")
                .username(username)
                .userType(adminUserTypeData)
                .email("automationtests05@gmail.com")
                .phone("5555555555")
                .build();

        //Create new user who is part of new user type created
        adminUsersPage.addEditUser(person, "password", "password", false,
                data.addToGroup, null, "Automated Test " +
                        "User", null, false);
        waitUntilSpinnerInvisible(driver, 30);

        //Logout
        navbarHeaderPage.logout();

        //Login with the new user created
        userName = username;
        password = "password";
        renewalsPage = "N";
        login();

        //Validate selected tabs
        assertTrue(navbarHeaderPage.isVehiclesPresent());
        assertTrue(navbarHeaderPage.isReportsPresent());
        assertTrue(navbarHeaderPage.isAlertsPresent());
        assertTrue(navbarHeaderPage.isAdminPresent());

        //Validate unselected tabs
        assertFalse(navbarHeaderPage.isSalesPresent());

        //Navigate to Vehicles screen
        VehiclesPage vehiclesPage = navbarHeaderPage.clickVehicles();

        vehiclesPage.searchVehicle(data.serialNumber);
        assertTrue(vehiclesPage.isQuickEditBtnPresent());

        vehiclesPage.selectVehicle(1);

        //Validate selected permissions in vehicles page
        assertTrue(vehiclesPage.isEditBtnPresent());
        assertTrue(vehiclesPage.isHistoryTabPresent());

        //Validate unselected permissions in vehicles page
        assertFalse(vehiclesPage.isNotesTabPresent());
        assertFalse(vehiclesPage.isProfileChangesTabPresent());
        assertFalse(vehiclesPage.isRecoveryTabPresent());

        //Navigate to Admin screen
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Validate selected permissions in admin page
        assertTrue(adminLeftBarPage.isGeoZonesLinkPresent());
        assertTrue(adminLeftBarPage.isDeviceTransfersLinkPresent());
        assertTrue(adminLeftBarPage.isUsersLinkPresent());
        assertTrue(adminLeftBarPage.isUserTypesLinkPresent());

        //Validate unselected permissions in admin page
        assertFalse(adminLeftBarPage.isGeoFencesLinkPresent());
        assertFalse(adminLeftBarPage.isScheduledCommandsLinkPresent());
        assertFalse(adminLeftBarPage.isImpoundLotsLinkPresent());
        assertFalse(adminLeftBarPage.isAccountManagementLinkPresent());
        assertFalse(adminLeftBarPage.isGroupsLinkPresent());
        assertFalse(adminLeftBarPage.isDevicesLinkPresent());
        assertFalse(adminLeftBarPage.isRequestInstallationLinkPresent());

        //Logout
        navbarHeaderPage.logout();

        LoginData loginData = null;
        try {
            loginData = mapper.treeToValue(dataNode, LoginData.class);
            userName = loginData.userName;
            password = loginData.password;
            renewalsPage = loginData.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            } else {
            }

        } catch (JsonProcessingException e) {
        }

        //Login with the default user
        login();

        //Delete created user
        assertEquals(deleteUser(driver, getUsers(driver, username).data.get(0).id).msg, "Account user deleted");

        //Delete created user type
        assertEquals(deleteUserType(driver, getUserTypes(driver, adminUserTypeData).data.get(0).id).msg, "Data deleted");
    }

    @Test(description = "Validate an Admin UserType - Paginate", groups = {"admin"})
    public void testUserTypePaginate() throws UnirestException {

        Account.AccountFilterResults userTypesAPI = getUserTypes(driver);

        //Verify records count
        assertEquals(adminUserTypesPage.getTotalRecordCount(), userTypesAPI.total);

        //Verify first record in grid matches with api response
        assertEquals(adminUserTypesPage.getTableFirstRow().get("User Type"), userTypesAPI.data.get(0).name);
        assertEquals(adminUserTypesPage.getTableFirstRow().get("Scope").equals("Account") ? "false" : null,
                userTypesAPI.data.get(0).noAdmin);
        assertEquals(Integer.parseInt(adminUserTypesPage.getTableFirstRow().get("Number of Users")),
                userTypesAPI.data.get(0).accountUserCount);

        //Verify Page Size Selection
        adminUserTypesPage.verifyPageSizeSelection();

        //Verify navigation buttons
        adminUserTypesPage.verifyNavigationElementsPresent();
        adminUserTypesPage.verifyNavigationBtns();
        adminUserTypesPage.verifyNavigationBtnsTooptip();

        //Verify pagination display "startIndex-showEntries of userCount"
        adminUserTypesPage.verifyPaginationBoundsDisplay();
    }

    @Test(description = "Validate Default user types are already present for GSE", groups = {"admin"})
    public void testDefaultUserTypeGSE() {
        String[] userTypes = {"Admin", "Collector", "Locate Only", "Manager", "Repo", "User - No Admin"};
        List<String> defaultUserTypes = new ArrayList<>(Arrays.asList(userTypes));

       adminUserTypesPage.getFixedTable().forEach(r -> {
          if(defaultUserTypes.contains(r.get("User Type"))) {
              defaultUserTypes.remove(r.get("User Type"));
              assertFalse(adminUserTypesPage.isDeleteBtnEnabled());
           }
       });

       assertEquals(defaultUserTypes.size(), 0, "Default user type(s) not found: " + defaultUserTypes.toString());
    }
}
