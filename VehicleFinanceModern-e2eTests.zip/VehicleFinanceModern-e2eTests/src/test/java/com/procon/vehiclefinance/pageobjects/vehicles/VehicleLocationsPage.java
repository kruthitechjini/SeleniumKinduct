package com.procon.vehiclefinance.pageobjects.vehicles;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VehicleLocationsPage extends CommonGrid {

    protected static final Logger LOGGER = Logger
            .getLogger(VehicleLocationsPage.class.getName());

    @FindBy(css = "div.ember-table-table-row:nth-of-type(1) button.gridButton")
    private WebElement detailsButton;

    @FindBy(css = "a[title='Filter']")
    private WebElement filterButton;

    @FindBy(css = "div.top-address")
    private WebElement dateRange;

    private static final String filter_window_css="div.trends-filter";

    @FindBy(css = "select.date-range-select")
    private WebElement dateRangeSelect;

    @FindBy(css = "div.trends-filter[style*='display: block'] button:nth-of-type(1)")
    private WebElement filterClearButton;

    @FindBy(css = "div.trends-filter[style*='display: block'] button:nth-of-type(2)")
    private WebElement filterApplyButton;

    @FindBy(css = "#mostVisitedAddress-tab div.ember-table-tables-container")
    private WebElement locationsTable;

    public VehicleLocationsPage(WebDriver driver) {
      super(driver);
    }
    
    public void waitForLocationDetailsButton() {
    	new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(detailsButton));
    }

    public VehicleLocationDetailsPage clickLocationDetails(){
    	waitForLocationDetailsButton();
    	detailsButton.click();
    	return PageFactory.initElements(driver, VehicleLocationDetailsPage.class);
    }

    public void setFilterDateRange(String range) {
    	new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(filterButton)).click();
    	new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(dateRangeSelect));
    	Select rangeSelect = new Select(dateRangeSelect);
    	String currentRange = rangeSelect.getFirstSelectedOption().getText();
    	if (currentRange.equals(range)) {
    	  LOGGER.fine("Range is the same: " + range + " Clicking filter.");
    	  filterButton.click();
    	  return;
    	}
    	rangeSelect.selectByVisibleText(range);
    	LOGGER.fine("New Range: " + range + " Clicking filter Apply.");
    	filterApplyButton.click();

    	// Waiting for filter window disappear
    	new WebDriverWait(driver, 10).until(
    			ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(filter_window_css)));

    	// Waiting for locationsTable to redraw
    	waitUntilSpinnerVisibleThenInvisible(driver, 2, 1);
    }

    private static String[] getDate(String desc) {
    	int count=0;
    	String[] allMatches = new String[2];
    	Matcher m = Pattern.compile("(\\d{2}/\\d{2}/\\d{4})").matcher(desc);
    	while (m.find()) {
    		allMatches[count] = m.group();
    		count++;
    		}
    	return allMatches;
    }

    public String[] getDateRange() {
        try {
          waitForLocationDetailsButton();
        } catch (org.openqa.selenium.TimeoutException e) {
        }
        return getDate(dateRange.getText());
    }

}
