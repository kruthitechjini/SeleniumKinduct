package com.procon.vehiclefinance.tests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.pageobjects.*;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertManagementPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsPage;
import com.procon.vehiclefinance.pageobjects.dashboard.DashboardPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsLeftBarPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsPage;
import com.procon.vehiclefinance.pageobjects.sales.SalesPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.testng.Assert.fail;
import static org.testng.AssertJUnit.assertTrue;

public class FeaturesTest extends BaseTest {

    private static final String CSV_MODULE_HEADER = "module";
    private static final String CSV_FEATURE_HEADER = "feature";
    private static final String CSV_FEATURE_SET_PREFIX = "set_";
    private static final String CSV_DATA_FILE =
            "src/test/resources/features/features.csv";
    private static final String FEATURE_CONFIG_FILE =
            "src/test/resources/features/features_config.json";

    class Feature {
        String module;
        String name;
        String enabled;

        public Feature(String module, String name, String enabled) {
            this.module = module;
            this.name = name;
            this.enabled = enabled;
        }
    }

    // this class needs to be static for Jackson to be able to databind to it
    static class EnvConfig {
        public String userName;
        public String password;
        public String displayName;
        public String serialNumber;
        public String quickFenceIsSet;
        public String renewalsPage;
    }

    class FeatureSet {
        private String name;
        private List<Feature> features;

        public FeatureSet(String name) {
            this(name, new ArrayList<>());
        }

        public FeatureSet(String name, List<Feature> features) {
            this.name = name;
            this.features = features;
        }

        public void addFeature(Feature feature) {
            features.add(feature);
        }

        public List<Feature> getFeatures() {
            return features;
        }

    }

    @DataProvider(name = "features")
    private Iterator<FeatureSet> getCSVData() throws IOException {

        Reader in = new FileReader(CSV_DATA_FILE);
        CSVParser parser = CSVFormat.RFC4180.withHeader()
                .withIgnoreEmptyLines().parse(in);

        // read header names and create Feature Sets for each column that
        // starts with CSV_FEATURE_SET_PREFIX
        Map<String, FeatureSet> featureSetMap = new HashMap<>();
        for (String key : parser.getHeaderMap().keySet()) {
            if (key.startsWith(CSV_FEATURE_SET_PREFIX)) {
                String name = key.substring(CSV_FEATURE_SET_PREFIX.length());
                featureSetMap.put(name, new FeatureSet(name));
            }
        }

        // for each CSV record, add the feature in the appropriate feature set
        Set<String> setNames = featureSetMap.keySet();
        for (CSVRecord record : parser) {
            String module = record.get(CSV_MODULE_HEADER);
            String featureName = record.get(CSV_FEATURE_HEADER);
            for (String setName : setNames) {
                FeatureSet set = featureSetMap.get(setName);
                set.addFeature(new Feature(module, featureName, record.get
                        (CSV_FEATURE_SET_PREFIX + setName)));
            }
        }
        return featureSetMap.values().iterator();
    }

    @BeforeClass(alwaysRun = true)
    public void testSetup() throws IOException {
        JsonNode doc = mapper.readTree(new File(FEATURE_CONFIG_FILE));
        envNode = doc.at("/" + env);
    }

    enum Module {
        DASHBOARD("dashboard"),
        VEHICLES("vehicles"),
        REPORTS("reports"),
        REPORTS_TAB("reports"),
        ALERTS("management"),
        ALERTS_MENU("alerts"),
        ADMIN("admin"),
        SALES_PORTAL("sales_portal");

        private String url;

        Module(String url) {
            this.url = url;
        }

        public String getUrl() {
            return url;
        }
    }

    @Test(dataProvider = "features", groups = {"features"})
    public void testFeatures(FeatureSet featureSet) {
        final Logger logger = Logger
                .getLogger(FeaturesTest.class.getName());

        //time out is set for this test
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

        AlertsPage alertsPage;
        AlertManagementPage alertManagementPage = null;

        ReportsPage reportsPage;
        ReportsLeftBarPage reportsLeftBarPage;
        VehiclesPage vehiclesPage;
        DashboardPage dashboardPage;
        SalesPage salesPage;

        logger.log(Level.FINE, "feature set: {0}", featureSet.name);
        JsonNode configNode = envNode.at("/" + featureSet.name);

        EnvConfig config = null;
        try {
            config = mapper.treeToValue(configNode, EnvConfig.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process config values", e);
        }

        renewalsPage = config.renewalsPage;
        userName = config.userName;
        password = config.password;
        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);
        List<String> errors = new ArrayList<>();

        // list of available reports in Reports page
        List<String> availableReports = new ArrayList<>();

        logger.log(Level.FINE, "username: {0}, serial: {1}", new
                Object[]{config.userName, config.serialNumber});

        // check if login is successful. If not, logout so further iterations
        // can continue
        String displayName = navbarHeaderPage.getDisplayName();
        if (!displayName.equalsIgnoreCase(config.displayName)) {
            navbarHeaderPage.logout();
            fail(String.format("Logged in user '%s' doesn't match expected " +
                    "user '%s'", displayName, config.displayName));
        }

        for (Feature feature : featureSet.getFeatures()) {
            String currentUrl = driver.getCurrentUrl();

            boolean actual;
            boolean expected = feature.enabled.equalsIgnoreCase("y");

            if (!feature.module.equalsIgnoreCase("Alerts") && currentUrl
                    .contains("management")) {
                alertManagementPage.clickCancelBtn();
            }

            switch (feature.module.toLowerCase()) {
                case "dashboard":
                    if (!currentUrl.contains(Module.DASHBOARD.getUrl())) {
                        try {
                            driver.findElement(By.linkText("Dashboard")).click();
                        } catch (NoSuchElementException e) {
                            actual = false;
                            break;
                        }
                    }
                    dashboardPage = PageFactory.initElements(driver,
                            DashboardPage.class);
                    actual = dashboardPage.findIffeatureIsAccessible(feature.name);
                    break;

                case "admin":
                    if (!currentUrl.contains(Module.ADMIN.getUrl())) {
                        try {
                            waitUntilSpinnerVisible(driver, 30);
                        } catch (TimeoutException e) {
                        }

                        driver.findElement(By.linkText("Admin")).click();
                        waitUntilSpinnerInvisible(driver, 30);
                    }

                    AdminLeftBarPage adminLeftBarPage = PageFactory.initElements(driver,
                            AdminLeftBarPage.class);

                    actual = adminLeftBarPage.isAdminFeaturePresent(feature.name);
                    break;

                case "alerts_menu":
                    if (!currentUrl.contains(Module.ALERTS_MENU.getUrl())) {
                        driver.findElement(By.linkText("Alerts")).click();
                    }

                    alertsPage = PageFactory.initElements(driver,
                            AlertsPage.class);
                    actual = alertsPage.isAlertFeaturePresent(feature.name);

                    break;

                case "alerts":

                    if (!currentUrl.contains(Module.ALERTS.getUrl())) {
                        driver.findElement(By.linkText("Alerts")).click();

                        // Click alerts management
                        driver.findElement(By.linkText("Alert Management")).click();

                        //open alerts management page
                        driver.findElement(By.cssSelector(".btn.btn-primary.pull-right")).click();
                    }

                    alertManagementPage = PageFactory.initElements(driver,
                            AlertManagementPage.class);
                    actual = alertManagementPage.isAlertAvailable(feature.name);

                    break;

                case "vehicles":
                    vehiclesPage = PageFactory.initElements(driver,
                            VehiclesPage.class);

                    if (!currentUrl.contains(Module.VEHICLES.getUrl())) {
                        //
                        driver.findElement(By.linkText("Vehicles")).click();
                        vehiclesPage = PageFactory.initElements(driver,
                                VehiclesPage.class);
                    }
                    if (!vehiclesPage.isDeviceSelected()) {
                        //search device
                        vehiclesPage.searchUniqueVehicle(config.serialNumber);

                        //select searched device
                        vehiclesPage.selectAll();
                        waitUntilSpinnerInvisible(driver, 30);
                    }

                    actual = vehiclesPage.isVehicleFeaturePresent(feature.name);

                    break;

                // TODO open issue: https://jira.spireon.com/browse/VFM-4281
                case "reports":
                    if (!currentUrl.contains(Module.REPORTS.getUrl())) {
                        driver.findElement(By.linkText("Reports")).click();
                        waitUntilSpinnerInvisible(driver, 30);
                    }
                    reportsLeftBarPage = PageFactory.initElements(driver,
                            ReportsLeftBarPage.class);

                    //get list of reports in the application that are
                    // visible, but only if it hasn't been retrieved already.
                    // There's no need to get it again for the same user
                    if (availableReports.isEmpty()) {
                        availableReports = reportsLeftBarPage.getReportTypes();
                    }
                    actual = availableReports.contains(feature.name.trim());

                    break;

                case "saved_reports":
                    if (!currentUrl.contains(Module.REPORTS.getUrl())) {
                        driver.findElement(By.linkText("Reports")).click();
                        waitUntilSpinnerInvisible(driver, 30);
                    }
                    reportsLeftBarPage = PageFactory.initElements(driver,
                            ReportsLeftBarPage.class);

                    actual = reportsLeftBarPage
                            .isSavedReportHeaderLinkDisplayed(feature.name.trim());

                    break;

                case "reports_tab":
                    reportsPage = PageFactory.initElements(driver,
                            ReportsPage.class);

                    if (!currentUrl.contains(Module.REPORTS_TAB.getUrl())) {
                        driver.findElement(By.linkText("Reports")).click();
                    }

                    actual = reportsPage.isReportFeaturePresent(feature.name);

                    break;

                case "sales_portal":
                    if (!isElementPresent(driver, By.linkText("Connect"))) {
                        actual = false;
                        break;
                    }
                    if (!currentUrl.contains(Module.SALES_PORTAL.getUrl())) {
                        driver.findElement(By.linkText("Connect")).click();
                    }

                    salesPage = PageFactory.initElements(driver,
                            SalesPage.class);
                    actual = salesPage.isSalesFeaturePresent(feature.name);

                    break;

                default:
                    errors.add(String.format("Unknown feature: %s, %s, %s %s",
                            featureSet.name, feature.module, feature.name,
                            expected));
                    continue;
            }

            String outputLogStr = String.format("For feature set: %s, Module: %s, " +
                            "feature: %s, expected %s, actual %s",
                    featureSet.name, feature.module, feature.name,
                    expected, actual);

            if (actual != expected) {
                logger.log(Level.WARNING, outputLogStr);
                errors.add(outputLogStr + System.lineSeparator());
            }
        }

        // logout
        navbarHeaderPage.logout();
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);
        assertTrue(loginPage.getUsernameField().isDisplayed());

        //check if any expected and actual mismatches present
        if (!errors.isEmpty()) {
            fail(errors.toString());
        }
    }
}


