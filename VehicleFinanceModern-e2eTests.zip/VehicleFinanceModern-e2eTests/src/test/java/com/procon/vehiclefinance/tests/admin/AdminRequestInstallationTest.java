package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Dealer;
import com.procon.vehiclefinance.models.Vehicle;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRequestInstallationPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;
import static org.testng.Assert.*;

public class AdminRequestInstallationTest extends BaseTest {

    static class TestData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String dealerName;
        public String vinNumber;
        public String vehicleMake;
        public String vehicleModel;
        public String vehicleYear;
    }

    @Test(testName = "Request Installation", groups = {"gse", "admin"})
    public void testRequestInstallation() throws IOException {
        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;
        String dealerName = data.dealerName;

        MapPage mapPage = login();

        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        AdminLeftBarPage adminLeftBarPage = navbarHeaderPage.clickAdmin();

        AdminRequestInstallationPage adminRequestInstallationPage = adminLeftBarPage.clickRequestInstallationLink();
        waitUntilSpinnerInvisible(driver, 10);
        Assert.assertTrue(driver.getCurrentUrl().contains("admin/request-installation-enterprise"));

        WebElement requestInstallHeader = adminRequestInstallationPage.getRequestInstallHeader();
        Assert.assertTrue(requestInstallHeader.getText().contains("Request Installation"));

        String sectionText = adminRequestInstallationPage.getSectionText();
        Assert.assertTrue(sectionText.contains("VEHICLE INFORMATION"));
        Assert.assertTrue(sectionText.contains("CUSTOMER INFORMATION"));

        String billTo = "Lender";
        String stockNumber = "123123";

        //populate address
        Address address = new Address.AddressBuilder()
                .street("16802 Aston Street")
                .city("Irvine")
                .state("CA")
                .postalCode("92606")
                .country("USA")
                .build();

        //Populate dealer details
        Dealer dealer = new Dealer.DealerBuilder()
                // .dealerId(getRandomDealerId())
                .dealerName(dealerName)
                .firstName("George")
                .lastName("Washington")
                .email("email@test.com")
                .password("password")
                .confirmPassword("password")
                .address(address)
                .phone("1111111111")
                .phoneSecondary("3333333333")
                .fax("12222222222")
                .build();

        Vehicle vehicle = new Vehicle(data.vinNumber, data.vehicleMake, data.vehicleModel, data.vehicleYear);
        String notes = "Please install the device";

/*      following changes are commented out as VIN less than 17 characters can be saved
        adminRequestInstallationPage.fillRequestInstallationFormAndSubmit(dealer, vehicle, billTo, stockNumber, notes);
        waitUntilSpinnerInvisible(driver, 5);

        String sectionTextWithInvalidVIN = driver.findElement(By.className("lender-body")).getText();
        Assert.assertTrue(sectionTextWithInvalidVIN.contains("VIN must be 17 characters long"), "Verify invalid VIN");
*/

        //Enter details with wrong vin number
        adminRequestInstallationPage.enterVinNumber("ABCD");
        adminRequestInstallationPage.clickDecodeVIN();
        assertEquals(adminRequestInstallationPage.getinvalidVinPopUp().getText(), "VIN must be 17 characters long");
        adminRequestInstallationPage.clickOk();

        //Enter details with correct vin number
        adminRequestInstallationPage.enterVinNumber(data.vinNumber);
        adminRequestInstallationPage.clickDecodeVIN();

        //Verify Make/Model/year
        assertTrue(adminRequestInstallationPage.verifyVehicleMakeTxt(data.vehicleMake));
        assertTrue(adminRequestInstallationPage.verifyVehicleModelTxt(data.vehicleModel));
        assertTrue(adminRequestInstallationPage.verifyVehicleYearTxt(data.vehicleYear));

        adminRequestInstallationPage.fillRequestInstallationFormAndSubmit(dealer, vehicle, billTo, stockNumber, notes);

        waitUntilSpinnerInvisible(driver, 5);

        String message = adminRequestInstallationPage.getConfirmationText();

        Assert.assertTrue(message.contains("Request Installation submitted successfully"), "Message: " + message);

        // logout
        navbarHeaderPage.logout();
    }

    @Test(testName = "Request Installation fields and validations", groups = {"gse", "admin"})
    public void testRequestInstallationFields() throws IOException {

        List<String> requiredFields = Arrays.asList(
                "Dealer",
                "Bill To",
                "Stock Number",
                "VIN",
                "Make",
                "Model",
                "Year",
                "First Name",
                "Last Name",
                "Address",
                "City",
                "State",
                "Postal Code",
                "Operator Phone (Primary)");

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        AdminRequestInstallationTest.TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, AdminRequestInstallationTest.TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        login();

        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        AdminLeftBarPage adminLeftBarPage = navbarHeaderPage.clickAdmin();

        AdminRequestInstallationPage adminRequestInstallationPage = adminLeftBarPage.clickRequestInstallationLink();
        waitUntilSpinnerInvisible(driver, 10);
        assertTrue(driver.getCurrentUrl().contains("admin/request-installation-enterprise"),
                "Current user " + userName + " isn't enterprise");

        //Verify section VEHICLE INFORMATION
        String sectionText = adminRequestInstallationPage.getSectionText();
        assertTrue(sectionText.contains("VEHICLE INFORMATION"),
                "Wrong section name is " + sectionText);

        //Verify fields are visible
        assertTrue(adminRequestInstallationPage.getLenderName().isDisplayed());
        assertTrue(adminRequestInstallationPage.getDealerDropDown().isDisplayed());
        assertTrue(adminRequestInstallationPage.getBillTo().isDisplayed());
        assertTrue(adminRequestInstallationPage.getStockNumberInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getVinInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getMakeInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getModelInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getYearInput().isDisplayed());

        //Verify section CUSTOMER INFORMATION
        Assert.assertTrue(sectionText.contains("CUSTOMER INFORMATION"),
                "Wrong section name is " + sectionText);

        //Verify fields are visible
        assertTrue(adminRequestInstallationPage.getOperatorFirstNameInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorLastNameInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorAddressInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorCityInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorStateInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorZipInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorPhonePrimaryInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getOperatorPhoneSecondaryInput().isDisplayed());

        //Verify bottom
        assertTrue(adminRequestInstallationPage.getNotesInput().isDisplayed());
        assertTrue(adminRequestInstallationPage.getCustomerHasSignedDisclosureInput().isDisplayed());

        //Verify Customer has signed disclosure unchecked and Submit is disabled
        assertFalse(adminRequestInstallationPage.getCustomerHasSignedDisclosureInput().isSelected());
        assertFalse(adminRequestInstallationPage.getSubmitBtn().isEnabled());

        //Submit clean form
        adminRequestInstallationPage.getCustomerHasSignedDisclosureInput().click();
        adminRequestInstallationPage.getSubmitBtn().click();

        //Verify required fields
        assertEquals(adminRequestInstallationPage.getRequiredFields(), requiredFields);

        // logout
        navbarHeaderPage.logout();
    }
}
