package com.procon.vehiclefinance.tests.alerts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.*;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertManagementPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

import static com.procon.vehiclefinance.services.AlertService.deleteSavedAlert;
import static com.procon.vehiclefinance.services.AlertService.getSavedAlerts;
import static com.procon.vehiclefinance.services.ContactService.createContact;
import static com.procon.vehiclefinance.services.ContactService.deleteContact;
import static com.procon.vehiclefinance.services.DeviceService.getDevices;
import static com.procon.vehiclefinance.services.GroupService.getGroups;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AlertsAlertManagementTest extends BaseTest {

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AlertsPage alertsPage;
    protected AlertManagementPage alertManagementPage;

    protected List<Integer> alertIdList;
    protected List<Integer> recipientIdList;

    private static final Logger logger = LoggerFactory.getLogger(AlertsAlertManagementTest.class);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String groupName;
        public String vehicleName;
        public List<RecipientData> recipients;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class RecipientData {
        public String name;
        public String deliveryType;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAlertManagement(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Click alerts menu
        alertsPage = navbarHeaderPage.clickAlerts();
        alertManagementPage = alertsPage.clickAlertManagement();

        alertIdList = new ArrayList<>();
        recipientIdList = new ArrayList<>();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Delete created recipients
        if (!recipientIdList.isEmpty()) {
            for (Integer recipientId : recipientIdList) {
                assertEquals(deleteContact(driver, recipientId).msg, "Data deleted");
            }
        }

        //Delete created alerts
        if (!alertIdList.isEmpty()) {
            for (Integer alertId : alertIdList) {
                assertEquals(deleteSavedAlert(driver, alertId).msg, "Data deleted");
            }
        }

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Add/Edit/Delete/Cancel alerts", groups = {"bvt", "prodsmoke", "alerts"})
    public void testAddEditDeleteCancelAlerts() {

        //Fetch data from test_data.json
        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        //Object to JSON in String
        String jsonInString = null;
        try {
            jsonInString = mapper.writeValueAsString(dataNode);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        Recipients recipients = null;
        try {
            recipients = mapper.readValue(jsonInString, Recipients.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Alerts test data
        ArrayList<AlertType> includedAlerts = new ArrayList<>();
        includedAlerts.add(AlertType.GEOFENCES);

        //Form Data
        String alertName = "Test Name_" + System.currentTimeMillis();
        AlertsSpec alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .scope("Global (All Vehicles)")
                .selectAllAlerts(false)
                .includeAlerts(includedAlerts)
                .build();

        //Open user modal form
        alertManagementPage.clickAddAlertsBtn();

        //Add alerts data
        alertManagementPage.addAlertsSpec(alertsSpec, recipients);
        assertEquals(alertManagementPage.search(alertName), 1);

        //Modify alert name data
        String editedAlertName = alertName + "_edited";

        //Search for the newly added alert and edit name
        alertManagementPage.editSearchedRecord(alertsSpec.getAlertName());
        alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(editedAlertName)
                .build();
        alertManagementPage.addEdit(alertsSpec);
        alertManagementPage.saveAlert();
        assertEquals(alertManagementPage.search(editedAlertName), 1);

        //Test cancel
        String cancelAlertName = editedAlertName + "_cancel";

        //Search for edited alert name
        alertManagementPage.editSearchedRecord(alertsSpec.getAlertName());
        alertManagementPage.enterName(cancelAlertName);
        alertManagementPage.clickCancelBtn();
        assertEquals(alertManagementPage.search(cancelAlertName), 0);

        //Delete alert.
        alertManagementPage.deleteSearchedRecord(editedAlertName);
        assertEquals(alertManagementPage.search(editedAlertName), 0);
    }

    @Test(description = "Alert - Alert Management - Modal- Verify Page Elements",
            groups = {"alerts"})
    public void testAlertManagementModalPageElements() {

        //Open alerts modal form
        alertManagementPage.clickAddAlertsBtn();

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Check if name field is present
        assertTrue(alertManagementPage.isAlertNameInputDisplayed(), "alertNameInput is missing");

        //Check if scope field is present
        assertTrue(alertManagementPage.isScopeDropdownDisplayed(), "scopeDropdown is missing");

        //Check if "Select All" Alert types is present
        assertTrue(alertManagementPage.isSelectAllChkboxDisplayed(), " Select All checkbox is missing");

        //Check if expected alert types are present
        String[] alertNames = {"Auto Report", "Battery Disconnect", "Drive Report", "GeoFences", "GeoZone Alert", "Impound Lot", "Low Battery Voltage",
                "Max Speed", "Power Up with GPS", "Stop Report", "Tow Alert", "Vehicle Abandonment"};
        for (String alertName : alertNames) {
            assertTrue(alertManagementPage.isAlertAvailable(alertName), alertName + " -- checkbox is missing");
        }

        //Check if All Days check box is present
        assertTrue(alertManagementPage.isAllDaysChkBoxDisplayed(), " All Days checkbox is missing");

        //Check if Mon-Fri check box is present
        assertTrue(alertManagementPage.isMonToFriChkboxDisplayed(), " Mon-Fri checkbox is missing");

        //Check if Mon to Sun checkboxes are present
        String[] validDays = {"validMonday", "validTuesday", "validWednesday", "validThursday", "validFriday", "validSaturday", "validSunday"};
        for (String validDay : validDays) {
            assertTrue(alertManagementPage.isValidDayAvailable(validDay), validDay + " -- checkbox is missing");
        }

        //Check Anytime check box is present
        assertTrue(alertManagementPage.isAnyTimeChkBoxDisplayed(), " Anytime checkbox is missing");

        //From time dropdowns is present
        assertTrue(alertManagementPage.isStartTimeDropdownDisplayed(), " From time dropdown is missing");

        //Check if recipients dropdown is present
        assertTrue(alertManagementPage.isRecipientDropdownDisplayed(), " Recipient dropdown is missing");

        //Close Alerts Modal form
        alertManagementPage.clickCancelBtn();
    }


    @Test(description = "Alert - Alert Management - Modal- Field validations",
            groups = {"alerts"})
    public void testAlertManagementFieldValidations() throws UnirestException, IOException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData testData = null;
        try {
            testData = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Create recipients using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);

        Recipient recipientObj = new Recipient();
        recipientObj.setName(recipient.fullName);
        recipientObj.setDeliveryType("Email");

        ArrayList<Recipient> recipientList = new ArrayList<>();
        recipientList.add(recipientObj);

        Recipients recipients = new Recipients();
        recipients.setRecipients(recipientList);

        long testGrpId = 0;

        //Open alerts modal form
        alertManagementPage.clickAddAlertsBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Check if 3 input areas Name/Scope, Type/Range, Recipients
        assertTrue(alertManagementPage.isAlertTypesLblDisplayed(), "Alert Type section is missing");
        assertTrue(alertManagementPage.isAlertNotificationsLblDisplayed(), "Alert Notification section is missing");
        assertTrue(alertManagementPage.isAlertRecipientsLblDisplayed(), "Alert Recipients section is missing");

        //Check if name field is present
        assertTrue(alertManagementPage.isAlertNameInputDisplayed(), "alertNameInput is missing");

        //Verify if the field 'Scope' is a dropdown and values are Global, Group, Vehicle. Default to (All Vehicle)
        final List<String> SCOPE_VALUES = Arrays.asList("Global (All Vehicles)", "Group", "Vehicle");
        assertEquals(alertManagementPage.getScopeItems(), SCOPE_VALUES, "Scope values are not as expected");

        //Check first record is Defaulted to Global(All Vehicle)
        assertEquals(alertManagementPage.getFirstSelectedScopeOption(), "Global (All Vehicles)");

        //Get the groups for the user making api call
        List<Group.GroupItem> grps = getGroups(driver).data;
        List<String> grpNamesUsingApi = new ArrayList<String>(); // create list of group names

        //Get groupId for test group
        for (Group.GroupItem grp : grps) {
            grpNamesUsingApi.add(grp.name);
            if (grp.name.equalsIgnoreCase(testData.groupName)) {
                testGrpId = grp.id;
            }
        }

        //Get devices for the group
        List<Device.DeviceDetail> devices = getDevices(driver, testGrpId, testData.groupName, true).data;

        //Select group scope
        alertManagementPage.selectScope("Group");

        //Get groups from groups dropdown
        List<String> grpsInDropdown = alertManagementPage.getGroupItems();
        grpsInDropdown.remove(0); // remove blank group in the top

        //Verify Group (dropdown) - only displayed if scope is Group or Vehicle.
        // Contains all the vehicle groups the user has access to.
        assertEquals(grpsInDropdown, grpNamesUsingApi,
                "Group names do not match between UI and API for the user");

        //Select Vehicles scope
        alertManagementPage.selectScope("Vehicle");
        alertManagementPage.selectGroup(testData.groupName);

        //Validate devices counts in UI and api
        //TODO:Following counts are not matching. Opened defect: https://jira.spireon.com/browse/VFM-4846
        int countOfVehiclesInDropdown = alertManagementPage.getCountInVehiclesDropdown();
        /*assertEquals(countOfVehiclesInDropdown, devices.size(),
                "Vehicles count do not match between UI and API for the group");*/

        //Make sure validity period checkboxes are available
        assertTrue(alertManagementPage.isCheckboxDisplayed("validAllDays"), "All Days checkbox is missing");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validWeekDays"), "MON - FRI checkbox is missing");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validMonday"), "Monday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validTuesday"), "Tuesday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validWednesday"), "Wednesday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validThursday"), "Thursday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validFriday"), "Friday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validSaturday"), "Saturday checkbox is missing ");
        assertTrue(alertManagementPage.isCheckboxDisplayed("validSunday"), "Sunday checkbox is missing ");

        //Validate check boxes are disabled
        assertTrue(alertManagementPage.isCheckboxDisabled("validMonday"), "Monday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validTuesday"), "Tuesday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validWednesday"), "Wednesday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validThursday"), "Thursday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validFriday"), "Friday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validSaturday"), "Saturday box should be disabled");
        assertTrue(alertManagementPage.isCheckboxDisabled("validSunday"), "Sunday box should be disabled");

        //Uncheck All Days checkbox
        alertManagementPage.updateCheckbox("validAllDays", false);

        //Validate check boxes are enabled
        assertTrue(!alertManagementPage.isCheckboxDisabled("validMonday"), "Monday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validTuesday"), "Tuesday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validWednesday"), "Wednesday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validThursday"), "Thursday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validFriday"), "Friday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validSaturday"), "Saturday box should be enabled");
        assertTrue(!alertManagementPage.isCheckboxDisabled("validSunday"), "Sunday box should be enabled");

        //Check Anytime checkbox
        alertManagementPage.updateCheckbox("validAnyTime", true);
        assertTrue(!alertManagementPage.isStartTimeDropdownEnabled(), "StartTimeDropdown should be disabled");
        assertTrue(!alertManagementPage.isEndTimeDropdownEnabled(), "EndTimeDropdown should be disabled");

        //Uncheck Anytime checkbox
        alertManagementPage.updateCheckbox("validAnyTime", false);
        assertTrue(alertManagementPage.isStartTimeDropdownEnabled(), "StartTimeDropdown should be enabled");
        assertTrue(alertManagementPage.isEndTimeDropdownEnabled(), "EndTimeDropdown should be enabled");

        //Add Recipient
        alertManagementPage.selectRecipients(recipients);

        //If I try to add same recipient again I should not find it
        try {
            alertManagementPage.selectRecipients(recipients);
        } catch (NoSuchElementException e) {
            logger.warn("Validating recipient that has been added shouldn't show up in the dropdown list anymore "
                    + e.getLocalizedMessage());
        }

        //Check if delete link is present
        assertTrue(alertManagementPage.isRecipientDeleteLinkDisplayed(), "Delete Recipient link is missing");

        //Delete added Recipient from grid
        alertManagementPage.deleteFirstRecipientFromGrid();

        //Select the same deleted recipient again. Recipient should be available in recipient dropdown
        try {
            alertManagementPage.selectRecipients(recipients);
        } catch (NoSuchElementException e) {
            logger.error(e.getLocalizedMessage());
            fail("Recipient is not visible ", e);
        }

        //Close Alerts Modal form
        alertManagementPage.clickCancelBtn();
    }

    @Test(description = "Alert - Alert Management - Modal- Input validations",
            groups = {"alerts"})
    public void testAlertManagementInputValidations() throws UnirestException, IOException {

        //Open alerts modal form
        alertManagementPage.clickAddAlertsBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Select Global scope, but do not select any vehicle
        alertManagementPage.selectScope("Global (All Vehicles)");

        //Uncheck "All Days" checkbox
        alertManagementPage.updateCheckbox("validAllDays", false);

        //Uncheck "Mon" through "Sat" checkboxes
        alertManagementPage.updateCheckbox("validMonday", false);
        alertManagementPage.updateCheckbox("validTuesday", false);
        alertManagementPage.updateCheckbox("validAllDays", false);
        alertManagementPage.updateCheckbox("validWednesday", false);
        alertManagementPage.updateCheckbox("validThursday", false);
        alertManagementPage.updateCheckbox("validFriday", false);
        alertManagementPage.updateCheckbox("validSaturday", false);
        alertManagementPage.updateCheckbox("validSunday", false);

        //Uncheck "Any time" checkbox
        alertManagementPage.updateCheckbox("validAnyTime", false);

        //Click Save button and make sure you get to see all validation messages
        alertManagementPage.clickSaveBtn();

        //Validate validation errors
        assertTrue(alertManagementPage.isNameValidationMsgDisplayed(), "Name validation message does not show");
        assertTrue(!alertManagementPage.isVehicleDropdownValidationMsgPresent(), "Vehicle dropdown validation should not Show");
        assertTrue(!alertManagementPage.isGroupdropdownValidationMsgPresent(), "Group dropdown validation should not Show");
        assertTrue(alertManagementPage.isAlertTypesValidationMsgDisplayed(), "Alert types validation message does not show");
        assertTrue(alertManagementPage.isDayValidationMsgDisplayed(), "Day validation message does not show");
        assertTrue(alertManagementPage.isTimeValidationMsgDisplayed(), "Time validation message does not show");
        assertTrue(alertManagementPage.isRecipientsValidationMsgDisplayed(), "Recipient validation message does not show");

        //Select group scope
        alertManagementPage.selectScope("Group");

        //Click Save button and make sure you get to see all validation messages
        alertManagementPage.clickSaveBtn();

        //Validate validation errors
        assertTrue(alertManagementPage.isNameValidationMsgDisplayed(), "Name validation message does not show");
        assertTrue(alertManagementPage.isGroupDropdownValidationMsgDisplayed(), "Group dropdown validation message does not show");
        assertTrue(!alertManagementPage.isVehicleDropdownValidationMsgPresent(), "Vehicle dropdown validation should not Show");
        assertTrue(alertManagementPage.isAlertTypesValidationMsgDisplayed(), "Alert types validation message does not show");
        assertTrue(alertManagementPage.isDayValidationMsgDisplayed(), "Day validation message does not show");
        assertTrue(alertManagementPage.isTimeValidationMsgDisplayed(), "Time validation message does not show");
        assertTrue(alertManagementPage.isRecipientsValidationMsgDisplayed(), "Recipient validation message does not show");

        //Select Vehicles scope, but do not select any vehicle
        alertManagementPage.selectScope("Vehicle");

        //Click Save button and make sure you get to see all validation messages
        alertManagementPage.clickSaveBtn();

        //Validate validation errors
        assertTrue(alertManagementPage.isNameValidationMsgDisplayed(), "Name validation message does not show");
        assertTrue(alertManagementPage.isVehicleValidationMsgDisplayed(), "Vehicle dropdown validation message does not show");
        assertTrue(alertManagementPage.isAlertTypesValidationMsgDisplayed(), "Alert types validation message does not show");
        //TODO:Group name remains blank even when vehicle is selected. There is an outstanding Jira ticket for the issue.  https://jira.spireon.com/browse/VFM-13
        assertTrue(alertManagementPage.isDayValidationMsgDisplayed(), "Day validation message does not show");
        assertTrue(alertManagementPage.isTimeValidationMsgDisplayed(), "Time validation message does not show");
        assertTrue(alertManagementPage.isRecipientsValidationMsgDisplayed(), "Recipient validation message does not show");

        //Close Alerts Modal form
        alertManagementPage.clickCancelBtn();
    }

    @Test(description = "Alert Management - Verify page elements", groups = {"alerts"})
    public void testVerifyAlertManagementPageElements() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        final List<String> GRID_COLUMNS = Arrays.asList("Name", "Scope", "Alert Types", "Actions");

        //Validate title
        assertEquals(alertManagementPage.getTitle().getText(), "Alert Management");

        //Validate grid displayed
        assertTrue(alertManagementPage.gridBody().isDisplayed());

        Alert.AlertResults alertResults = getSavedAlerts(driver);

        //Validate total record counts in UI and API
        assertEquals(alertManagementPage.getTotalRecordCount(), alertResults.total);

        //Validate first row of UI and API
        assertEquals(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()),
                alertManagementPage.getApiFirstRecord(alertResults.data));

        //Validate Grid Columns.
        assertEquals(alertManagementPage.getGridColumns(), GRID_COLUMNS,
                "Columns list is not matching");

        //Alerts test data
        ArrayList<AlertType> includedAlerts = new ArrayList<>();
        includedAlerts.add(AlertType.GEOFENCES);

        //Form Data
        String alertName = "Alert Name_" + System.currentTimeMillis();
        AlertsSpec alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .scope("Global (All Vehicles)")
                .selectAllAlerts(false)
                .includeAlerts(includedAlerts)
                .build();

        //Create recipients using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);

        Recipient recipientObj = new Recipient();
        recipientObj.setName(recipient.fullName);
        recipientObj.setDeliveryType("Email");

        ArrayList<Recipient> recipientList = new ArrayList<>();
        recipientList.add(recipientObj);

        Recipients recipients = new Recipients();
        recipients.setRecipients(recipientList);

        //Open alert modal form
        alertManagementPage.clickAddAlertsBtn();

        //Add alerts data
        alertManagementPage.addAlertsSpec(alertsSpec, recipients);
        assertEquals(alertManagementPage.search(alertName), 1);

        for (Alert.AlertSpecData alert : getSavedAlerts(driver).data) {
            if (alert.name.equals(alertName)) {
                alertIdList.add(alert.id);
                break;
            }
        }

        //Validate scope for Global
        assertEquals(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()).get("Scope"), "Global");

        //Search for the newly added alert and edit scope
        alertManagementPage.editSearchedRecord(alertsSpec.getAlertName());
        alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .scope("Group")
                .group(data.groupName)
                .build();
        alertManagementPage.addEdit(alertsSpec);
        alertManagementPage.saveAlert();

        //Validate scope for Group
        assertEquals(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()).get("Scope"),
                "Group (" + data.groupName + ")");

        //Search for the newly added alert and edit scope
        alertManagementPage.editSearchedRecord(alertsSpec.getAlertName());
        alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .scope("Vehicle")
                .group(data.groupName)
                .vehicle(data.vehicleName)
                .build();
        alertManagementPage.addEdit(alertsSpec);
        alertManagementPage.saveAlert();

        //Validate scope for Vehicle
        assertEquals(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()).get("Scope"),
                "Vehicle (" + data.vehicleName + ")");

        //Search for the newly added alert and edit alerts
        alertManagementPage.editSearchedRecord(alertsSpec.getAlertName());
        alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .selectAllAlerts(true)
                .build();
        alertManagementPage.addEdit(alertsSpec);
        alertManagementPage.saveAlert();

        List<String> gridAlertTypes = Arrays.asList(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody())
                .get("Alert Types").split(","));
        Collections.sort(gridAlertTypes);

        List<String> allAlertTypes = AlertType.getValues();
        Collections.sort(allAlertTypes);

        //Validate Alert Types
        assertEquals(gridAlertTypes, allAlertTypes);

        //Validate mousing over the Alert Types cell, a popup should appear showing all the Alert Types in a more readable form
        assertEquals(alertManagementPage.getFirstRowScope().getAttribute("title"),
                alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()).get("Alert Types").replaceAll(",", "\n"));

        //Validate Add, Edit, Delete buttons are active
        assertTrue(alertManagementPage.getAddAlertsBtn().isEnabled());
        assertTrue(alertManagementPage.getEditLink().isEnabled());
        assertTrue(alertManagementPage.getDeleteLink().isEnabled());

        //Clear search
        alertManagementPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate Page Navigation bar and Show dropdown
        alertManagementPage.verifyNavigationElementsPresent();
    }

    @Test(description = "Alert Management - Verify Search, Sort and Paginate", groups = {"alerts"})
    public void testVerifyAlertManagementSearchSortPaginate() throws UnirestException {

        //Alerts test data
        ArrayList<AlertType> includedAlerts = new ArrayList<>();
        includedAlerts.add(AlertType.GEOFENCES);

        //Form Data
        String alertName = "Alert Name_" + System.currentTimeMillis();
        AlertsSpec alertsSpec = new AlertsSpec.AlertsSpecBuilder()
                .alertName(alertName)
                .scope("Global (All Vehicles)")
                .selectAllAlerts(false)
                .includeAlerts(includedAlerts)
                .build();

        //Create recipients using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);

        Recipient recipientObj = new Recipient();
        recipientObj.setName(recipient.fullName);
        recipientObj.setDeliveryType("Email");

        ArrayList<Recipient> recipientList = new ArrayList<>();
        recipientList.add(recipientObj);

        Recipients recipients = new Recipients();
        recipients.setRecipients(recipientList);

        //Open alert modal form
        alertManagementPage.clickAddAlertsBtn();

        //Add alerts data
        alertManagementPage.addAlertsSpec(alertsSpec, recipients);

        for (Alert.AlertSpecData alert : getSavedAlerts(driver).data) {
            if (alert.name.equals(alertName)) {
                alertIdList.add(alert.id);
                break;
            }
        }

        //Verify search giving a substring
        searchAndValidateResults("Alert Name_");

        //Verify search giving a full string
        searchAndValidateResults(alertName);

        //Clear search
        alertManagementPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate sort on each column
        for (String column : alertManagementPage.getGridColumns()) {
            if (column.equals("Name"))
                assertTrue(alertManagementPage.isColumnSortable(column));
        }

        int totalSavedAlerts = getSavedAlerts(driver).total;

        String paginationInfo = alertManagementPage.getPagingPositionDiv().getText();

        //Validate pagination display info
        if (totalSavedAlerts > alertManagementPage.getPageSizeSelection()) {

            assertEquals(paginationInfo,
                    "1 - " + alertManagementPage.getPageSizeSelection()
                            + " of " + totalSavedAlerts);
        } else {
            assertEquals(paginationInfo,
                    "1 - " + totalSavedAlerts + " of " + totalSavedAlerts);
        }

        //Validate select page size values
        assertEquals(alertManagementPage.getSelectPageSizeValues(), CommonGrid.SelectPageSizesEnum.getValues());

        //Validate default selected option should be 50
        assertEquals(alertManagementPage.getPageSizeSelection(), 50);

        //When the user changes the value in the Show dropdown, the # of alerts displayed in the grid
        //should automatically update to that number
        alertManagementPage.selectPageSizeValue(CommonGrid.SelectPageSizesEnum.TWENTY_FIVE.getName());

        if (alertManagementPage.getTotalRecordCount() >= 25) {
            assertEquals(alertManagementPage.getPageUpperBound(), 25);
        } else {
            assertEquals(alertManagementPage.getPageUpperBound(), alertManagementPage.getTotalRecordCount());
        }

        //Validate grid navigation control buttons
        alertManagementPage.verifyNavigationBtns();

        //Validate tooltip of navigation controls
        alertManagementPage.verifyNavigationBtnsTooptip();
    }

    /**
     * Search given string and validate results
     *
     * @param searchString
     * @throws UnirestException
     */
    private void searchAndValidateResults(String searchString) throws UnirestException {

        alertManagementPage.search(searchString);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        Alert.AlertResults alertResults = getSavedAlerts(driver, searchString);

        //Validate total record counts in UI and API
        assertEquals(alertManagementPage.getTotalRecordCount(), alertResults.total);

        //Validate first row of UI and API
        assertEquals(alertManagementPage.getTableFirstRow(alertManagementPage.gridBody()),
                alertManagementPage.getApiFirstRecord(alertResults.data));
    }
}