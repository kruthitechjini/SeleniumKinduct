package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.openqa.selenium.support.ui.ExpectedConditions
        .elementToBeClickable;

public class VehicleGeoFencePage extends CommonGrid {

    private static final Logger logger = LoggerFactory
            .getLogger(VehicleGeoFencePage.class);

    @FindBy(css = "div#geofence-tab div:nth-child(1) > div > div:nth-child(2) > span > select")
    private WebElement firstRowGeoFenceDropdown;

    @FindBy(css = "div#geofence-tab div:nth-child(1) > div > div:nth-child(3) > span > select")
    private WebElement firstRowGeoFenceTypeDropdown;

    @FindBy(css = "div#geofence-tab div:nth-child(1) > div > div:nth-child(4)" +
            " > span > a:nth-child(1)")
    private WebElement firstRowViewLink;

    @FindBy(css = "div#geofence-tab div:nth-child(1) > div > div:nth-child(4)" +
            " > span > a:nth-child(2)")
    private WebElement firstRowClearLink;

    @FindBy(css = "div#geofence-tab div:nth-child(1) > div > div:nth-child(4)" +
            " > span > a:nth-child(3)")
    private WebElement firstRowSaveLink;

    @FindBy(css = "div.leaflet-marker-pane img")
    private WebElement geoFenceViewMarker;

    @FindBy(css = "div.modern-bubble-headline-title.ellipsis")
    private WebElement geoFenceViewLinkBubbleHeader;

    @FindBy(css = "a.status-close")
    private WebElement closeBtn;

    @FindBy(css = "button.btn.btn-cancel")
    private WebElement bulkGeoFencePopupCancelBtn;

    @FindBy(css = "div.modal-footer > button.btn.btn-primary")
    private WebElement bulkGeoFencePopupSaveBtn;

    @FindBy(css = "div.modal-body > div.form div:nth-child(1) > div > span")
    private WebElement geoFenceSelectValidationMsg;

    @FindBy(css = "div.modal-body > div.form div:nth-child(2) > div > span")
    private WebElement geoFenceSelectTypeValidationMsg;

    @FindBy(css = "div.modal-body > div > div:nth-child(2) > div:nth-child(1) select")
    private WebElement geoFenceSelectBulkDropdown;

    @FindBy(css = "[class='modal-body'] > div >  div:nth-child(2)  > div:nth-child(2) select")
    private WebElement geoFenceTypeSelectBulkDropdown;

    @FindBy(css = "[class='modal-body'] label:not([for])")
    private WebElement mainTextOnBulkGeoFencePopupLbl;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header > h4.modal-title")
    private WebElement modalWindowTitle;

    public VehicleGeoFencePage(WebDriver driver) {
        super(driver);
    }

    public String getMainTextFromBulkGeoFencePopup() {
        return mainTextOnBulkGeoFencePopupLbl.getText();
    }

    public WebElement getFirstRowViewLink() {
        return firstRowViewLink;
    }

    public WebElement getFirstRowClearLink() {
        return firstRowClearLink;
    }

    public WebElement getFirstRowSaveLink() {
        return firstRowSaveLink;
    }

    public WebElement getGeoFenceViewLinkBubbleHeader() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions
                .visibilityOf(geoFenceViewLinkBubbleHeader));
    }

    public boolean isGeoFenceSelectValidationMsgDisplayed() {
        return geoFenceSelectValidationMsg.isDisplayed();
    }

    public boolean isGeoFenceTypeValidationMsgDisplayed() {
        return geoFenceSelectTypeValidationMsg.isDisplayed();
    }

    public boolean isGeoFenceBulkDropdownIsDisplayed() {
        return geoFenceSelectBulkDropdown.isDisplayed();
    }

    public boolean isGeoFenceTypeBulkDropdownIsDisplayed() {
        return geoFenceTypeSelectBulkDropdown.isDisplayed();
    }

    public boolean isGeoFenceBulkCancelBtnIsDisplayed() {
        return bulkGeoFencePopupCancelBtn.isDisplayed();
    }

    public boolean isGeoFenceBulkSaveBtnIsDisplayed() {
        return bulkGeoFencePopupSaveBtn.isDisplayed();
    }

    public void bulkGeoFencePopupSave() {
        bulkGeoFencePopupSaveBtn.click();
    }

    public void bulkGeoFencePopupCancel() {
        bulkGeoFencePopupCancelBtn.click();
    }

    public enum GeoFenceTypeEnum {
        ENTER_EXIT("Enter/Exit"),
        ENTER("Enter"),
        EXIT("Exit");

        private String name;

        GeoFenceTypeEnum(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public static HashSet<String> getValues() {
            HashSet<String> values = new HashSet<>();
            for (GeoFenceTypeEnum geoFenceType : GeoFenceTypeEnum.values()) {
                values.add(geoFenceType.getName());
            }
            return values;
        }
    }

    /**
     * Get GeoFence List
     *
     * @return
     */
    public List<String> getGeoFenceList() {

        List<String> geoFenceList = new ArrayList<>();
        List<WebElement> options = new Select(firstRowGeoFenceDropdown).getOptions();
        options.forEach(option -> geoFenceList.add(option.getText()));

        return geoFenceList;
    }

    /**
     * Get GeoFence Type List
     *
     * @return
     */
    public List<String> getGeoFenceTypeList() {

        List<String> geoFenceTypeList = new ArrayList<>();
        List<WebElement> options = new Select(firstRowGeoFenceTypeDropdown).getOptions();
        options.forEach(option -> geoFenceTypeList.add(option.getText()));

        return geoFenceTypeList;
    }

    /**
     * Select a GeoFence
     *
     * @param geoFenceName
     */
    public void selectGeoFence(String geoFenceName) {
        if (geoFenceName != null) {
            new Select(firstRowGeoFenceDropdown).selectByVisibleText(
                    geoFenceName);
        }
    }

    public void selectGeoFenceBulk(String geoFenceName) {
        if (geoFenceName != null) {
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
            new Select(geoFenceSelectBulkDropdown).selectByVisibleText(
                    geoFenceName);
        }
    }

    public void selectGeoFenceTypeBulk(String geoFenceType) {
        if (geoFenceType != null) {
            new Select(geoFenceTypeSelectBulkDropdown).selectByVisibleText(
                    geoFenceType);
        }
    }

    /**
     * Select GeoFence type
     *
     * @param geoFenceType
     */
    public void selectGeoFenceType(GeoFenceTypeEnum geoFenceType) {
        if (geoFenceType != null) {
            List<WebElement> options = new Select(firstRowGeoFenceTypeDropdown).getOptions();

            for (WebElement option : options) {
                if (option.getText().contains(geoFenceType.getName())) {
                    option.click();
                    break;
                }
            }
        }
    }

    /**
     * Select and save a GeoFence
     *
     * @param geoFenceName
     */
    public void selectAndSaveGeoFence(String geoFenceName, GeoFenceTypeEnum
            geoFenceType) {
        selectGeoFence(geoFenceName);
        selectGeoFenceType(geoFenceType);
        clickSaveLink();
    }

    public void saveGeofenceBulk() {
        bulkGeoFencePopupSaveBtn.click();
    }

    /**
     * Click on view marker
     */
    public void clickGeoFenceViewMarker() {
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(geoFenceViewMarker)).click();
    }

    public void clickCloseBtn() {
        closeBtn.click();
    }

    public void clickSaveLink() {
        firstRowSaveLink.click();
    }

    public void clickViewLink() {
        firstRowViewLink.click();
    }

    public void clickClearLink() {
        firstRowClearLink.click();
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }
}
