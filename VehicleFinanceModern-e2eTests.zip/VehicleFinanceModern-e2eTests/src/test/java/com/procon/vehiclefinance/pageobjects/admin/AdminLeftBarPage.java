package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.isElementPresent;

public class AdminLeftBarPage {
    WebDriver driver;
    protected static final Logger logger = Logger
            .getLogger(AdminLeftBarPage.class.getName());

    @FindBy(css = "div.search-bar")
    private WebElement searchInput;

    // define elements in left bar
    @FindBy(linkText = "Users")
    private WebElement usersLink;

    @FindBy(linkText = "User Types")
    private WebElement userTypesLink;

    @FindBy(linkText = "Groups")
    private WebElement groupsLink;

    @FindBy(linkText = "GeoFences")
    private WebElement geoFencesLink;

    @FindBy(linkText = "GeoZones")
    private WebElement geoZonesLink;

    @FindBy(linkText = "Devices")
    private WebElement devicesLink;

    @FindBy(linkText = "Device Transfers")
    private WebElement deviceTransfersLink;

    @FindBy(linkText = "Scheduled Commands")
    private WebElement scheduledCommandsLink;

    @FindBy(linkText = "Account Management")
    private WebElement accountManagementLink;

    private static final String ACCOUNT_MANAGEMENT_LINK_ACTIVE = "div.admin-nav-panel > ul.admin-nav > li.active > a ";
    @FindBy(css = ACCOUNT_MANAGEMENT_LINK_ACTIVE)
    private WebElement accountManagementLinkActive;

    @FindBy(linkText = "Recipients")
    private WebElement recipientsLink;

    @FindBy(linkText = "Dealer Management")
    private WebElement dealerManagement;

    @FindBy(linkText = "Recovery")
    private WebElement recoveryLink;

    @FindBy(linkText = "Lots")
    private WebElement lotsLink;

    @FindBy(linkText = "Impound Lots")
    private WebElement impoundLotsLink;

    @FindBy(linkText = "Request Installation")
    private WebElement requestInstallationLink;

    @FindBy(linkText = "Order Devices")
    private WebElement orderDevices;

    public AdminLeftBarPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getSearchInput() {
        return searchInput;
    }

    public WebElement getAccountManagementLinkActive() {

        return accountManagementLinkActive;
    }

    public Boolean isAccountManagementLinkEnabled() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(By.cssSelector(ACCOUNT_MANAGEMENT_LINK_ACTIVE)));
        return accountManagementLinkActive.isEnabled();
    }

    public void goToAdminUser() throws InterruptedException {
        //goToAdmin();
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Users")));
        wait.until(ExpectedConditions.elementToBeClickable
                (usersLink)).click();
    }

    public AdminUsersPage clickUserLink() {
        usersLink.click();
        return PageFactory.initElements(driver, AdminUsersPage.class);
    }

    public AdminScheduledCommandsPage clickScheduledCommandsLink() {
        scheduledCommandsLink.click();
        return PageFactory.initElements(driver, AdminScheduledCommandsPage.class);
    }

    public AdminDevicesPage clickDevicesLink() {
        devicesLink.click();
        return PageFactory.initElements(driver, AdminDevicesPage.class);
    }

    public AdminGeoBoundsPage clickGeoFencesLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(geoFencesLink)).click();
        return PageFactory.initElements(driver, AdminGeoBoundsPage.class);
    }

    public AdminGeoBoundsPage clickGeoZonesLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(geoZonesLink)).click();
        return PageFactory.initElements(driver, AdminGeoBoundsPage.class);
    }

    public AdminUserTypesPage clickUserTypesLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(userTypesLink)).click();
        return PageFactory.initElements(driver, AdminUserTypesPage.class);
    }

    public AdminGroupsPage clickGroupsLink() {
        groupsLink.click();
        return PageFactory.initElements(driver, AdminGroupsPage.class);
    }

    public AdminDeviceTransfersPage clickDeviceTransfersLink() {
        deviceTransfersLink.click();
        return PageFactory.initElements(driver, AdminDeviceTransfersPage.class);
    }

    public AdminRecipientsPage clickRecipientsLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(recipientsLink)).click();
        return PageFactory.initElements(driver, AdminRecipientsPage.class);
    }

    public AdminRecoveryPage clickRecoveryLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(recoveryLink)).click();
        return PageFactory.initElements(driver, AdminRecoveryPage.class);
    }

    public boolean isAdminFeaturePresent(String StrAdminFeature) {
        boolean featureIsAvailable = WebElements.isElementPresent(driver, By.linkText(StrAdminFeature));
        return featureIsAvailable;
    }

    public AdminAccountManagementPage clickAccountManagementLink() {
        accountManagementLink.click();
        return PageFactory.initElements(driver, AdminAccountManagementPage.class);
    }

    public AdminDealerManagementPage clickDealerManagementLink() {
        dealerManagement.click();
        return PageFactory.initElements(driver, AdminDealerManagementPage.class);
    }

    public AdminOrderDevicesPage clickOrderDevicesLink() {
        orderDevices.click();
        return PageFactory.initElements(driver, AdminOrderDevicesPage.class);
    }


    public Boolean isUsersLinkPresent () {
        return isElementPresent(driver, By.linkText("Users"));
    }

    public Boolean isUserTypesLinkPresent () {
        return isElementPresent(driver, By.linkText("User Types"));
    }

    public Boolean isGeoFencesLinkPresent () {
        return isElementPresent(driver, By.linkText("GeoFences"));
    }

    public Boolean isGeoZonesLinkPresent () {
        return isElementPresent(driver, By.linkText("GeoZones"));
    }

    public Boolean isScheduledCommandsLinkPresent () {
        return isElementPresent(driver, By.linkText("Scheduled Commands"));
    }

    public Boolean isImpoundLotsLinkPresent () {
        return isElementPresent(driver, By.linkText("Impound Lots"));
    }

    public Boolean isAccountManagementLinkPresent () {
        return isElementPresent(driver, By.linkText("Account Management"));
    }

    public Boolean isGroupsLinkPresent () {
        return isElementPresent(driver, By.linkText("Groups"));
    }

    public Boolean isDevicesLinkPresent () {
        return isElementPresent(driver, By.linkText("Devices"));
    }

    public Boolean isDeviceTransfersLinkPresent () {
        return isElementPresent(driver, By.linkText("Device Transfers"));
    }

    public Boolean isRequestInstallationLinkPresent () {
        return isElementPresent(driver, By.linkText("Request Installation"));
    }

    public AdminImpoundLotsPage clickImpoundLotsLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(impoundLotsLink)).click();
        return PageFactory.initElements(driver, AdminImpoundLotsPage.class);
    }

    public AdminRequestInstallationPage clickRequestInstallationLink() {
        requestInstallationLink.click();
        return PageFactory.initElements(driver, AdminRequestInstallationPage.class);
    }

    public String getActiveLeftBarElement() {
        return driver.findElement(By.cssSelector("div.admin-nav-panel li.active")).getText();
    }
}
