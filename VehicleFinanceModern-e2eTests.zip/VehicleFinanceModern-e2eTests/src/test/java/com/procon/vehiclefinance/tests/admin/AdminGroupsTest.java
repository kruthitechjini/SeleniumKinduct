package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminGroupsPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static org.testng.Assert.*;

public class AdminGroupsTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AdminGroupsTest.class.getName());

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminGroupsPage adminGroupsPage;

    protected LoginData data;

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class GroupsData {
        public String roleFilter;
        public List<String> groupMembers;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String searchKey;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdminGroups(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            } else {
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Groups page
        adminGroupsPage = adminLeftBarPage.clickGroupsLink();

    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Add/Edit/Delete an Admin Group", groups =
            {"bvt", "prodsmoke", "admin"})
    public void testAddEditDeleteGroup() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        GroupsData config = null;
        try {
            config = mapper.treeToValue(dataNode, GroupsData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        // Open Groups modal form
        adminGroupsPage.clickAddGroupBtn();

        // form data
        String groupName = "TestGroup" + System.currentTimeMillis();
        String roleFilter = config.roleFilter;
        String comments = "This is a test comment";

        logger.log(Level.FINE, "group name: {0}", groupName);

        //test add group functionality
        adminGroupsPage.createGroup(groupName, roleFilter, false,
                config.groupMembers, comments);

        //Data for updating group
        String groupNameNew = groupName + "-New";
        comments = "This is a new test comment";

        // update Group, this also confirms that it was added previously,
        // and that cancel step worked as expected
        waitUntilSpinnerInvisible(driver, 20);
        adminGroupsPage.editSearchedRecord(groupName);
        adminGroupsPage.updateGroup(groupNameNew, null, false,
                null, false, null, comments);

        // delete group
        adminGroupsPage.deleteGroup(groupNameNew);
    }

    @Test(description = "AdminGroup - paginate, search, sort", groups = {"admin"})
    public void testAdminGroupPaginate() {
        final List<String> GRID_COLUMNS = Arrays.asList("Group Name", "Comments", "Actions");
        final List<String> GRID_COLUMNS_SORTABLE = Arrays.asList("Group Name", "Comments");

        adminGroupsPage.waitForTable();

        //Verify page elements are available
        assertTrue(adminGroupsPage.getAddGroupBtn().isEnabled());
        assertTrue(adminGroupsPage.getSearchInput().isDisplayed());
        assertTrue(adminGroupsPage.getEditLink().isDisplayed());
        assertTrue(adminGroupsPage.getDeleteLink().isDisplayed());
        adminGroupsPage.verifyNavigationElementsPresent();
        adminGroupsPage.verifyGridVerticalScrollbar();

        //Verify columns
        assertEquals(adminGroupsPage.getGridColumns(), GRID_COLUMNS,
                "Column list does not match expected list for grid");

        //Verify which columns are sortable
        GRID_COLUMNS_SORTABLE.forEach(column -> assertTrue(adminGroupsPage.isColumnSortable(column),
                "Sortable Column list does not match expected list for grid"));

        //Click on column and verify sort was performed
        GRID_COLUMNS_SORTABLE.forEach(column -> {
            //Check if column not active sorting then click to activate sorting
            if (!adminGroupsPage.isColumnSortedAscending(column)) adminGroupsPage.clickHeaderColumn(column);
            HashMap<String, String> table = adminGroupsPage.getTableFirstRow();
            adminGroupsPage.clickHeaderColumn(column);
            assertNotEquals(adminGroupsPage.getTableFirstRow(), table);
            adminGroupsPage.clickHeaderColumn(column);
            assertEquals(adminGroupsPage.getTableFirstRow(), table);
        });

        //Verify pagination controls
        adminGroupsPage.verifyPageSizeSelection();
        adminGroupsPage.verifyNavigationBtns();
        adminGroupsPage.verifyNavigationBtnsTooptip();
        adminGroupsPage.verifyPaginationBoundsDisplay();

        //Verify if the Search bar is located on the topleft of the Group grid in the LayoutTest.testAdminPageDesktop

        //Verify search is case insensitive
        int count = adminGroupsPage.search(data.searchKey);
        List<HashMap<String, String>> table = adminGroupsPage.getFixedTable();

        assertEquals(adminGroupsPage.search(data.searchKey.toLowerCase()), count);
        assertEquals(adminGroupsPage.getFixedTable(), table);

        assertEquals(adminGroupsPage.search(data.searchKey.toUpperCase()), count);
        assertEquals(adminGroupsPage.getFixedTable(), table);

        //Verify 'X' icon
        assertTrue(adminGroupsPage.getSearchInputCancel().isDisplayed());
        adminGroupsPage.getSearchInputCancel().click();

        //Verify when no text is entered in the search box , the background says 'Search'
        assertEquals(adminGroupsPage.getSearchInput().getAttribute("placeholder"), "Search");

        //Verify search by comment column
        String commentSearch = adminGroupsPage.getTableFirstRow().get("Comments");
        assertTrue(adminGroupsPage.search(commentSearch) > 0);

    }
}