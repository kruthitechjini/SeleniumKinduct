package com.procon.vehiclefinance.pageobjects.gseDealer;

import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRequestInstallationPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.logging.Logger;

public class DevicesLeftBarPage {

    WebDriver driver;
    protected static final Logger logger = Logger
            .getLogger(AdminLeftBarPage.class.getName());

    @FindBy(linkText = "Active Devices")
    private WebElement activeDevices;

    @FindBy(linkText = "Inventory Devices")
    private WebElement inventoryDevices;

    @FindBy(linkText = "Order Devices")
    private WebElement orderDevices;

    @FindBy(linkText = "Request Installation")
    private WebElement requestInstallation;

    @FindBy(linkText = "Installation Support")
    private WebElement installationSupport;

    @FindBy(linkText = "FAQ")
    private WebElement faq;

    public DevicesLeftBarPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickActiveDevices() {
        activeDevices.click();
    }

    public void clickInventoryDevices() {
        inventoryDevices.click();
    }

    public void clickOrderDevices() {

        orderDevices.click();
    }

    public AdminRequestInstallationPage clickRequestInstallation() {
        requestInstallation.click();

        //using the AdminRequestInstallationPage to create a Installation request
        return PageFactory.initElements(driver, AdminRequestInstallationPage.class);
    }

    public DevicesInstallationSupportPage clickInstallationSupport() {
        installationSupport.click();
        return PageFactory.initElements(driver, DevicesInstallationSupportPage.class);
    }

    public DevicesFaqPage clickFaq() {
        faq.click();
        return PageFactory.initElements(driver, DevicesFaqPage.class);

    }
}
