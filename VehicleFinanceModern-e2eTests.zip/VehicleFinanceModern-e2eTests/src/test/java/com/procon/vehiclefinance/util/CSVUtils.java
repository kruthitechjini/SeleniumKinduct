package com.procon.vehiclefinance.util;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CSVUtils {

    /**
     * Get list of records of csv data
     *
     * @param file
     * @return
     * @throws IOException
     */
    public static List<HashMap<String, String>> getCsvRecordList(File file) throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));
        String row;

        List<HashMap<String, String>> recordList = new ArrayList<>();
        HashMap<String, String> csvRecord = new HashMap<>();
        String[] csvHeaders = br.readLine().split("\",\"");

        while ((row = br.readLine()) != null) {
            String[] rowContent = row.split("\",\"");
            for (int i = 0; i < csvHeaders.length; i++) {
                csvRecord.put(csvHeaders[i].replace("\"", ""),
                        rowContent[i].replace("\"", "").trim());
            }
            recordList.add(csvRecord);
        }

        return recordList;
    }

    /**
     * Get CSV first row
     *
     * @param file
     * @return
     * @throws IOException
     */
    public static HashMap<String, String> getCsvFirstRow(File file) throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));
        String headers = br.readLine();
        String firstRowContent = br.readLine();

        if (firstRowContent.startsWith(",")) {
            firstRowContent = firstRowContent.replaceFirst(",", "\"\",");
        }
        if (firstRowContent.endsWith(",")) {
            firstRowContent = firstRowContent.substring(0, firstRowContent.length() - 1) + ",\"\"";
        }
        if (firstRowContent.contains(",,")) {
            firstRowContent = firstRowContent.replaceAll(",,", ",\"\",");
        }

        String[] csvHeaders = headers.split("\",\"");
        String[] csvFirstRowContent = firstRowContent.split("\",\"");

        //Get the first row from exported csv file
        HashMap<String, String> csvFirstRecord = new HashMap<>();

        for (int i = 0; i < csvHeaders.length; i++) {
            csvFirstRecord.put(csvHeaders[i].replace("\"", ""),
                    csvFirstRowContent[i].replace("\"", "").trim());
        }

        return csvFirstRecord;
    }

    /**
     * Get number of records of csv data
     *
     * @param file
     * @param isHeaderPresent
     * @return
     * @throws IOException
     */
    public static int getCsvNumberOfRecords(File file, Boolean isHeaderPresent) throws IOException {

        LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(file));

        lineNumberReader.skip(Long.MAX_VALUE);
        int totalRecords = lineNumberReader.getLineNumber();
        lineNumberReader.close();

        return isHeaderPresent ? totalRecords - 1 : totalRecords;
    }
}