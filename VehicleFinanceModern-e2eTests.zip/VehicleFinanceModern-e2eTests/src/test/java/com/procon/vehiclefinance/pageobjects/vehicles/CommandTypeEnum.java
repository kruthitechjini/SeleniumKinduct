package com.procon.vehiclefinance.pageobjects.vehicles;

public enum CommandTypeEnum {
	SET_GEOFENCE("setGeofence"),
	LOCATE("locate"),
	QUICK_FENCE("setGeofenceHere"),
	STARTER_DISABLE("starterDisable"),
	STARTER_ENABLE("starterEnable"),
	WARNING_OFF("warningOff"),
	WARNING_ON("warningOn"),
	MAX_SPEED("maxSpeedset");

	private String name;

	CommandTypeEnum(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
