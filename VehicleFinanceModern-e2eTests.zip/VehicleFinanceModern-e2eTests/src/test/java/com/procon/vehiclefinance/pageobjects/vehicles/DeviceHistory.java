package com.procon.vehiclefinance.pageobjects.vehicles;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;
import java.util.HashMap;

/**
 * This class defines the objects needed to handle the various response
 * objects from DeviceHistory service calls
 */
public class DeviceHistory {
	
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertListItem {
        public String _id;
        public int alertTypeId;
        public String alertTypeName;
        // optional 
        public int alertSpecId;
    }

    /**
     * This is the metadata that is returned when user 
     * clicks on Details link in Vehicle Locations tab
     * can be retrieved using getDeviceHistory
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceHistoryOutput {
        public int accountId;
        public String address;
        public List<AlertListItem> alertList;
        public boolean arOn;
        public long arOnStart;
        public double assetDistance;
        public double assetDistanceSum;
        public int assetGroupId;
        public String assetGroupName;
        public int assetId;
        public String assetName;
        public String assetVfStockNumber;
        public int avgAr;
        public int avgMv;
        public boolean cargoLoaded;
        public boolean cargoOn;
        public String city;
        public boolean commOn;
        public long commOnStart;
        public boolean containerSensorOn;
        public String dateCreated;
        public String daystamp;
        public int deviceId;
        public boolean deviceReset;
        public int deviceTypeId;
        public double distance;
        public boolean doorOpenOn;
        public long doorOpenOnStart;
        public boolean doorUnlock;
        public boolean drOn;
        public long drOnStart;
        public String endDate;
        public int engineTime;
        public String event;
        public String eventDate;
        public String eventId;
        public String eventTypeCode;
        public int eventTypeId;
        public int eventTypeMapId;
        public String eventTypeName;
        public int extVolts;
        public String fixDate;
        public String fixStatus;
        public int fixStatusQuality;
        public String formattedStartDate;
        public int formattedTotalCost;
        public boolean fridgeOn;
        public long fridgeOnStart;
        public String fullAddress;
        public boolean garmin;
        public boolean garminOn;
        public long garminOnStart;
        public long garminStart;
        public int gpio;
        public long gpsLostLockTime;
        public boolean gpsOn;
        public long gpsOnStart;
        public int gpsStatus;
        public boolean harshAccel;
        public boolean harshBreaking;
        public boolean harshCorner;
        public int heading;
        public boolean heaterOn;
        public long heaterOnStart;
        public int hourOfDay;
        public String id;
        public boolean idle;
        public long idleStart;
        public boolean ignitionOn;
        public long ignitionOnStart;
        public String imei;
        public boolean input1High;
        public boolean input1On;
        public boolean input2High;
        public boolean input3High;
        public boolean input3On;
        public boolean input4High;
        public boolean input5High;
        public long input5HighStart;
        public boolean input6High;
        public long input6HighStart;
        public String inputMap;
        public int inputStatus;
        public boolean landmarkOn;
        public long landmarkOnStart;
        public long lastAr;
        public String lastVisibleEventDate;
        public String lastVisibleEventTypeName;
        public double lat;
        public int listenerId;
        public double lng;
        public boolean lowBattery;
        public long lowBatteryStart;
        public boolean lowInternalBattery;
        public long lowInternalBatteryStart;
        public String matchId;
        public double maxOdometer;
        public String mongoId;
        public boolean movingOn;
        public long movingOnStart;
        public boolean newLoc;
        public double odometer;
        public int oldLoc;
        public String operatorExternalId;
        public String operatorFirstName;
        public int operatorId;
        public String operatorInternalId;
        public String operatorLastName;
        public String operatorNickname;
        public int parserId;
        public String payloadKey;
        public boolean powerConnected;
        public long powerConnectedStart;
        public boolean powerSaveOn;
        public long powerSaveOnStart;
        public boolean processed;
        public int rssi;
        public int satellites;
        public boolean seatbeltOn;
        public long seatbeltOnStart;
        public int sequence;
        public String serial;
        public String serialNumber;
        public String serverId;
        public List<String> setFields;
        public boolean sleepModeOn;
        public long sleepModeOnStart;
        public String softwareRev;
        public int speed;
        public boolean srOn;
        public long srOnStart;
        public String srcType;
        public String startDate;
        public double startOdometer;
        public boolean starterOn;
        public long starterOnStart;
        public String state;
        public String status;
        public boolean stop;
        public long stopStart;
        public long timeCreated;
        public int totalCost;
        public double totalDistance;
        public boolean towAlertOn;
        public long towAlertOnStart;
        public boolean towOn;
        public long towOnStart;
        public boolean tripOn;
        public boolean unauthMove;
        public String user;
        public long userAck;
        public boolean validLocation;
        public String vehicleBatteryStatus;
        public boolean vinOn;
        public long vinOnStart;
        public boolean visible;
        public int voltage;
        public boolean warningOn;
        public long warningOnStart;
        public String zip;
        public String _class;
    }

    /**
     * The list of all device history that is shown when
     * navigating to Vehicle Locations tab Details page
     */
    public static class DeviceHistoryResults {
        public List<DeviceHistoryOutput> data;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }
    
    /**
     * This is the metadata that is returned when user 
     * clicks on Vehicle Locations tab
     * can be retrieved using getDeviceTopAddresses
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceTopAddressesOutput {
        public String address;
        public String city;
        public long count;
        public List<Long> hourlyCounts;
        public double lat;
        public double lng;
        public String state;
        public List<String> stateIds;
        public String zip;
    }
    
    /**
     * The list of all device top addresses that is shown when
     * navigating to Vehicle Locations
     */
    public static class DeviceTopAddressesResults {
    	public int count;
    	public List<Long> dailyTotals;
        public List<DeviceTopAddressesOutput> data;
        public HashMap<String, String> dateParams;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }
}
