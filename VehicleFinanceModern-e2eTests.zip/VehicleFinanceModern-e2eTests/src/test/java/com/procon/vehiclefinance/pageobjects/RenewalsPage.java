package com.procon.vehiclefinance.pageobjects;

import com.procon.vehiclefinance.pageobjects.LoginPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;


public class RenewalsPage {

    //protected WebDriver driver;
    private WebDriver driver;

    @FindBy(css = "a[href='/?renew=1']")
    private WebElement continueAndRenewLaterLink;

    @FindBy(css = "a[href='/?expiring=true&amp;renew=1#renew']")
    private WebElement renewNowExpiringDevicesLink;

    @FindBy(css = "a[href='/?suspended=true&amp;renew=1#renew']")
    private WebElement renewNowSuspendedDevicesLink;

    @FindBy(css = "a[href='/session/signout']")
    private WebElement signOutLink;

    public RenewalsPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }


    public MapPage continueAndRenewLater() {
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(continueAndRenewLaterLink))
                .click();
        return PageFactory.initElements(driver, MapPage.class);
    }

    public void renewalPageIsInvisible() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("a[href='/?renew=1']")));
    }

    public LoginPage logout() {
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(signOutLink))
                .click();
        return PageFactory.initElements(driver, LoginPage.class);
    }
}
