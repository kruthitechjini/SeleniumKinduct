package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Group;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GroupService extends ServiceCaller {

    // get existing groups
    private static String getGroupsEndpoint;

    static {
        getGroupsEndpoint = baseUrl + "rest/json/vehicleFinanceUserGroup";
    }

    /**
     * Get asset groups
     *
     * @param driver      WebDriver object
     * @param queryParams a Map of query parameters
     * @return Group Data with a list of groups
     * @throws UnirestException
     */
    public static Group.GroupData getGroups(WebDriver driver, Map<String,
            Object> queryParams) throws UnirestException {
        HttpResponse<Group.GroupData> response = Unirest.get
                (getGroupsEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Group.GroupData.class);
        return response.getBody();
    }

    /**
     * Get asset groups for the currently logged in user account
     *
     * @param driver WebDriver object
     * @return Group Data with a list of groups
     * @throws UnirestException
     * @throws IOException
     */
    public static Group.GroupData getGroups(WebDriver driver) throws
            UnirestException, IOException {
        // create the default query params with currently logged in account Id
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 1000);
        queryParams.put("accountUserId", getUserSettings(driver).accountUserId);
        queryParams.put("minimal", true);
        queryParams.put("filterOperator", "or");
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getGroups(driver, queryParams);
    }

}
