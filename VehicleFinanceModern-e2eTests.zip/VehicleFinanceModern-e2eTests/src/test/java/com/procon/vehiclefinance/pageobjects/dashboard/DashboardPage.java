package com.procon.vehiclefinance.pageobjects.dashboard;

import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;


public class DashboardPage {
    WebDriver driver;
    protected static final Logger logger = Logger
            .getLogger(DashboardPage.class.getName());

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    @FindBy(css = "#renewals-dashboard > div.ember-view > div.panel-dashboard > div.panel-heading")
    protected WebElement renewals;

    @FindBy(css = "a[href='#/admin/account-management']")
    protected WebElement renewDevices;

    @FindBy(css = "#renewal-chart g.nvd3.nv-legend >g > g:nth-of-type(1)")
    protected WebElement activeDevices;

    @FindBy(css = "#renewal-chart g.nvd3.nv-legend >g > g:nth-of-type(2)")
    protected WebElement eligibleForRenewal;

    @FindBy(css = "#renewal-chart g.nvd3.nv-legend >g > g:nth-of-type(3)")
    protected WebElement expiredDevices;

    @FindBy(css = "#renewal-chart .nv-groups > g:nth-child(1) text")
    protected WebElement activeDevicesValue;

    @FindBy(css = "#renewal-chart .nv-groups > g:nth-child(2) text")
    protected WebElement eligibleForRenewalValue;

    @FindBy(css = "#renewal-chart .nv-groups > g:nth-child(3) text")
    protected WebElement expiredDevicesValue;

    @FindBy(css = "#renewal-chart g.nvd3 > g > g.nv-groups > g.nv-series-0 > g > rect")
    protected WebElement activeBar;

    @FindBy(css = "#renewal-chart g.nvd3 > g > g.nv-groups > g.nv-series-1 > g > rect")
    protected WebElement eligibleBar;

    @FindBy(css = "#renewal-chart g.nvd3 > g > g.nv-groups > g.nv-series-2 > g > rect")
    protected WebElement expiredBar;

    @FindBy(css = "#devices-dashboard > div.ember-view > div.panel-dashboard > div.panel-heading")
    protected WebElement devices;

    @FindBy(css = "#devices-dashboard small")
    protected WebElement devicesSubTitle;

    @FindBy(css = "#devices-dashboard > div > div > div.panel-body > div.device-total-wrapper > span.device-total")
    protected WebElement totalDevices;

    @FindBy(css = "#devices-dashboard > div > div > div.panel-body > div.device-total-wrapper > span.device-label")
    protected WebElement totalDevicesLabel;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-legendWrap > g > g > g:nth-child(1) > text")
    protected WebElement devicesLegend1;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-legendWrap > g > g > g:nth-child(2) > text")
    protected WebElement devicesLegend2;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-legendWrap > g > g > g:nth-child(3) > text")
    protected WebElement devicesLegend3;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-pieWrap > g > g > g.nv-pie > g:nth-child(1) > path")
    protected WebElement devicesPieSlice1;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-pieWrap > g > g > g.nv-pie > g:nth-child(2) > path")
    protected WebElement devicesPieSlice2;

    @FindBy(css = "#device-chart > svg > g > g > g.nv-pieWrap > g > g > g.nv-pie > g:nth-child(3) > path")
    protected WebElement devicesPieSlice3;

    @FindBy(css = "#devices-dashboard .nv-label > text")
    protected List<WebElement> devicesPieValues;

    @FindBy(xpath = "//a[text()='View Reports'][@class='clickable']")
    protected WebElement viewUsageReport;

    @FindBy(css = "ul.nav-pills > li")
    protected List<WebElement> usageReportPeriod;

    @FindBy(css = "ul.nav-pills > li.active")
    protected WebElement activeUsageReportPeriod;

    @FindBy(css = "ul.dash-usage > li")
    protected List<WebElement> usageEvents;

    @FindBy(xpath = "//a[text()=\"View Today's Alerts\"][@class='clickable']")
    protected WebElement viewTodayAlerts;

    @FindBy(css = "div#outstanding-chart svg > g")
    protected WebElement recentAlertChart;

    @FindBy(css = "div#outstanding-chart svg g.nv-axis.nv-x g.tick text")
    protected List<WebElement> recentAlertBarsLabels;

    @FindBy(css = "div#outstanding-chart svg g.nv-multibarHorizontal text")
    protected List<WebElement> recentAlertBarsValues;

    @FindBy(css = "div.settings-container > select")
    protected WebElement groupsDropdown;

    @FindBy(css = "div.settings-container > a")
    protected WebElement refreshBtn;


    public String getRenewalsText() {
        return renewals.getText();
    }

    public String getRenewDevicesText() {
        return renewDevices.getText();
    }

    public String getActiveDevicesText() {
        new WebDriverWait(driver, 10).until(visibilityOf(activeDevices));
        return activeDevices.getText();
    }

    public String getEligibleForRenewalText() {
        return eligibleForRenewal.getText();
    }

    public String getExpiredDevicesText() {
        return expiredDevices.getText();
    }

    public Boolean isActiveBarDisplayed() {
        return activeBar.isDisplayed();
    }

    public Boolean isEligibleBarDisplayed() {
        return eligibleBar.isDisplayed();
    }

    public Boolean isExpiredBarDisplayed() {
        return expiredBar.isDisplayed();
    }

    public AdminLeftBarPage clickRenewDevices() {
        renewDevices.click();
        return PageFactory.initElements(driver, AdminLeftBarPage.class);
    }

    public boolean findIffeatureIsAccessible(String featureName) {
        boolean dashboardFeaturePresent = false;

        if (featureName.equals("Devices Widget")) {
            //dashboardFeaturePresent = webElements.isElementPresent1(By.cssSelector(devicesDashboardBy,driver));
            dashboardFeaturePresent = WebElements.isElementPresent(driver, By.cssSelector("#devices-dashboard"));
        }

        if (featureName.equals("Renewals Widget")) {
            dashboardFeaturePresent = WebElements.isElementPresent(driver, By.cssSelector("#renewals-dashboard"));
        }

        if (featureName.equals("Usage")) {
            dashboardFeaturePresent = WebElements.isElementPresent(driver, By.cssSelector(".dash-usage"));
        }

        if (featureName.equals("Recent Alerts")) {
            dashboardFeaturePresent = WebElements.isElementPresent(driver, By.cssSelector("#outstanding-chart"));
        }

        if (featureName.equals("Top Device Usage")) {
            dashboardFeaturePresent = WebElements.isElementPresent(driver, By.cssSelector("div.widget-content-dashboard"));
        }

        return dashboardFeaturePresent;
    }

    public String getDevicesText() {
        return devices.getText();
    }

    public int getTotalDevices() {
        new WebDriverWait(driver, 10).until(visibilityOf(devicesLegend1));
        try {
            return Integer.parseInt(totalDevices.getText());
        } catch (NumberFormatException exp) {
            return 0;
        }
    }

    public String getDevicesLegend1Text() {
        new WebDriverWait(driver, 20).until(visibilityOf(devicesLegend1));
        return devicesLegend1.getText();
    }

    public String getDevicesLegend2Text() {
        return devicesLegend2.getText();
    }

    public String getDevicesLegend3Text() {
        return devicesLegend3.getText();
    }

    public boolean isDevicesPieSlice1Displayed() {
        return devicesPieSlice1.isDisplayed();
    }

    public void clickDevicesPieSlice1() {
        devicesPieSlice1.click();
    }

    public boolean isDevicesPieSlice2Displayed() {
        return devicesPieSlice2.isDisplayed();
    }

    public void clickDevicesPieSlice2() {
        devicesPieSlice2.click();
    }

    public boolean isDevicesPieSlice3Displayed() {
        return devicesPieSlice3.isDisplayed();
    }

    public VehiclesPage clickDevicesLegend1() {
        devicesLegend1.click();
        return PageFactory.initElements(driver, VehiclesPage.class);
    }

    public void clickDevicesLegend2() {
        devicesLegend2.click();
    }

    public String getDevicesSubTitleText() {
        return devicesSubTitle.getText();
    }

    public String getTotalDevicesLabel() {
        return totalDevicesLabel.getText();
    }

    public String getViewUsageReportText() {
        return viewUsageReport.getText();
    }

    public String getViewTodayAlertsText() {
        return viewTodayAlerts.getText();
    }

    public List<WebElement> getUsageReportPeriod() {
        return usageReportPeriod;
    }

    public ReportsPage clickViewTodayAlerts() {
        viewTodayAlerts.click();
        waitUntilSpinnerVisibleThenInvisible(driver, 3, 20);
        return new PageFactory().initElements(driver, ReportsPage.class);
    }

    public List<HashMap<String, WebElement>> getUsageDashboardElements() {
        List<HashMap<String, WebElement>> d = new ArrayList<HashMap<String, WebElement>>();

        for (int i = 0; i < usageEvents.size(); i++) {
            HashMap<String, WebElement> h = new HashMap<>();
            h.put("icon", usageEvents.get(i).findElement(By.cssSelector("span.dash-icon")));
            h.put("metric", usageEvents.get(i).findElement(By.cssSelector("span.metric")));
            d.add(h);
        }
        return d;
    }


    public int getUsageTotalAlerts() {
        return Integer.parseInt(getUsageDashboardElements().get(0).get("metric").getText());
    }

    public int getUsageUserLocates() {
        return Integer.parseInt(getUsageDashboardElements().get(1).get("metric").getText());
    }

    public int getUsageStopDrive() {
        return Integer.parseInt(getUsageDashboardElements().get(2).get("metric").getText());
    }

    public int getUsageStarter() {
        return Integer.parseInt(getUsageDashboardElements().get(3).get("metric").getText());
    }

    public List<WebElement> getUsageEvents() {
        return usageEvents;
    }

    public List<WebElement> getRecentAlertBarsLabels() {
        waitForRecentAlertsWidget();
        return recentAlertBarsLabels;
    }

    public List<WebElement> getRecentAlertBarsValues() {
        waitForRecentAlertsWidget();
        return recentAlertBarsValues;
    }

    public void waitForRecentAlertsWidget() {
        new WebDriverWait(driver, 20).until(visibilityOf(recentAlertChart));
    }

    public boolean isGroupsDropdownDisplayed() {
        return groupsDropdown.isDisplayed();
    }

    public boolean isRefreshBtnDisplayed() {
        return refreshBtn.isDisplayed();
    }

    public int getActiveUsageReportPeriod() {
        return Integer.parseInt(activeUsageReportPeriod.getText().split(" ")[0]);
    }

    public List<Integer> getDevicesPieValues() {
        List<Integer> values = new ArrayList();

        for (WebElement w : devicesPieValues) {
            String s = w.getText().replace("%", "");
            if (s.isEmpty()) s = "0";
            values.add(Integer.parseInt(s));
        }

        return values;
    }

    public int getActiveDevicesValue() {
        return Integer.parseInt(activeDevicesValue.getText());
    }

    public int getEligibleForRenewalValue() {
        return Integer.parseInt(eligibleForRenewalValue.getText());
    }

    public int getExpiredDevicesValue() {
        return Integer.parseInt(expiredDevicesValue.getText());
    }

    public List<String> getGroupsDropdownList() {
        List<String> list = new ArrayList<>();

        new Select(groupsDropdown).getOptions().forEach(w -> list.add(w.getText()));

        return list;
    }
}

