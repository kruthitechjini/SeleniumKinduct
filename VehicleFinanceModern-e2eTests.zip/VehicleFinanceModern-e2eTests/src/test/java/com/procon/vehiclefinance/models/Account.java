package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;
import java.util.List;

public class Account {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AccountData {
        public long id;
        public String name;
        public int accountUserCount;
        public String noAdmin;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AccountFilterResults {
        public String errors;
        public String msg;
        public int total;
        public int offset;
        public boolean success;
        public int max;
        public List<AccountData> data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ItemData{
        public String deviceSerialNumber;
        public double unitPrice;
        public double tax;
        public int renewalProductId;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OrderData {
        public String externalOrderId;
        public String status;
        public double orderTotal;
        public String dateSubmitted;
        public  List<ItemData> items;
    }

    public static class OrdersList{
        public String msg;
        public int total;
        public int offset;
        public boolean success;
        public int max;
        public List<OrderData> data;

    }

    public static class RenewalDevices {
        public String msg;
        public int total;
        public int offset;
        public boolean success;
        public int max;
        public List<RenewalData> data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RenewalData {
        public String assetGroupName;
        public String assetName;
        public String assetVin;
        public Date networkRenewalDate;
        public Date renewalDeadline;
        public String serialNumber;
        public String eventTypeName;
        public String maxEventDateFormat;
        public List<RenewalOptions> renewalOptions;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RenewalOptions {
        public String price;
        public String termInMonths;
        public String termInYears;
    }
}
