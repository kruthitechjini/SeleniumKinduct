package com.procon.vehiclefinance.models;

public class Recipient
{
    private String name;

    private String deliveryType;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getDeliveryType ()
    {
        return deliveryType;
    }

    public void setDeliveryType (String deliveryType)
    {
        this.deliveryType = deliveryType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [person = "+name+", deliveryType = "+deliveryType+"]";
    }
}
