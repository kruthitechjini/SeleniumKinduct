package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static com.procon.vehiclefinance.util.WebElements.enterText;

public class AdminRecipientsPage extends CommonGrid {

    @FindBy(css = "div.panel-heading > button.btn-primary")
    private WebElement addRecipientBtn;

    @FindBy(css = "input[name='firstName']")
    private WebElement firstNameInput;

    @FindBy(css = "input[name='lastName']")
    private WebElement lastNameInput;

    @FindBy(css = "input[name='email']")
    private WebElement emailInput;

    @FindBy(css = "input[name='phoneNumber']")
    private WebElement phoneNumberInput;

    private static final String SAVE_BTN_CSS = "div.modal-footer > button" +
            ".btn-primary";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    private static final String CANCEL_BTN_CSS = "div.modal-footer > button" +
            ".btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    @FindBy(css = ".panel-title")
    private WebElement pageTitle;

    @FindBy(css = "a[title='Edit']")
    private WebElement editAction;

    @FindBy(css = "a[title='Delete']")
    private WebElement deleteAction;

    public AdminRecipientsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickAddRecipientBtn() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(addRecipientBtn)).click();
    }

    /**
     * Add/edit a recipient
     *
     * @param firstName   first name
     * @param lastName    last name
     * @param email       email
     * @param phoneNumber phone number
     */
    public void addEditRecipient(String firstName, String lastName, String email,
                                 String phoneNumber) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterEmail(email);
        enterPhoneNumber(phoneNumber);
        submitForm();
    }

    public void enterFirstName(String firstName) {
        enterText(driver, firstNameInput, firstName, 20);
    }

    public void enterLastName(String lastName) {
        enterText(driver, lastNameInput, lastName);
    }

    public void enterEmail(String email) {
        enterText(driver, emailInput, email, 10);
    }

    public void enterPhoneNumber(String phoneNumber) {
        enterText(driver, phoneNumberInput, phoneNumber);
    }

    public void submitForm() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector
                (SAVE_BTN_CSS));
    }

    public void cancelForm() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector
                (CANCEL_BTN_CSS));
    }

    public String getPageTitle() {
        return pageTitle.getText();
    }

    public WebElement getEditAction() {
        return editAction;
    }

    public WebElement getDeleteAction() {
        return deleteAction;
    }
}
