package com.procon.vehiclefinance.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.mongodb.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateOptions;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.vehicles.CommandTypeEnum;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.error.YAMLException;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class MongoUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MongoUtils.class);

    private static final String CREDENTIALS_FILE =
            "src/test/resources/credentials.yml";
    private static Credentials creds;

    static class Credentials {
        public String host;
        public String userName;
        public String database;
        public String password;
    }

    static {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            JsonNode node = mapper.readTree(new File(CREDENTIALS_FILE)).at
                    ("/" + System.getProperty("env") + "/mongo");
            creds = mapper.treeToValue(node, Credentials.class);
        } catch (IOException e) {
            LOGGER.error("Error reading credentials: {}", e.getLocalizedMessage());
            throw new YAMLException(e.getLocalizedMessage());
        }
    }

    /**
     * Insert alerts in Mongo deviceAlert.deviceAlert collection
     *
     * @param deviceAlerts
     */
    public static void insertAlert(List<Device.DeviceAlert> deviceAlerts) {
        CodecRegistry pojoCodecRegistry = fromRegistries(MongoClient.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()));

        MongoCredential credential = MongoCredential.createCredential
                (creds.userName, creds.database, creds.password.toCharArray());
        ServerAddress server = new ServerAddress(creds.host);
        MongoClient mongoClient = new MongoClient(server, credential,
                MongoClientOptions.builder().codecRegistry(pojoCodecRegistry)
                        .build());

        MongoDatabase database = mongoClient.getDatabase("deviceAlert");
        MongoCollection<Device.DeviceAlert> collection = database
                .getCollection("deviceAlert", Device.DeviceAlert.class);
        collection.insertMany(deviceAlerts);
    }

    /**
     * Get device details from Mongo
     *
     * @param bson
     * @return
     */
    public static FindIterable<Device.DeviceDetail> getDeviceDetail(Bson bson) {
        CodecRegistry pojoCodecRegistry = fromRegistries(MongoClient.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()));

        MongoCredential credential = MongoCredential.createCredential
                (creds.userName, creds.database, creds.password.toCharArray());
        ServerAddress server = new ServerAddress(creds.host);
        MongoClient mongoClient = new MongoClient(server, credential,
                MongoClientOptions.builder().codecRegistry(pojoCodecRegistry)
                        .build());
        MongoDatabase database = mongoClient.getDatabase("device");
        MongoCollection<Device.DeviceDetail> deviceDetailColl = database.getCollection
                ("deviceDetail", Device.DeviceDetail.class);

        FindIterable<Device.DeviceDetail> deviceDetails = deviceDetailColl.find(bson);

        return deviceDetails;
    }


    /**
     * Update CommandEventCollection to simulate command success
     *
     * @param accountId
     * @param deviceId
     * @param bson the fields to be updated
     * @return the boolean value indicating if the update meets the expectation
     */
    public static void simulateCommandSuccess(int accountId, int deviceId, Bson bson, CommandTypeEnum commandType)
            throws MongoException, NoMongoDocumentUpdatedException {
        CodecRegistry pojoCodecRegistry = fromRegistries(MongoClient.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()));

        MongoCredential credential = MongoCredential.createCredential
                (creds.userName, creds.database, creds.password.toCharArray());
        ServerAddress server = new ServerAddress(creds.host);
        MongoClient mongoClient = new MongoClient(server, credential,
                MongoClientOptions.builder().codecRegistry(pojoCodecRegistry)
                        .build());

        MongoDatabase database = mongoClient.getDatabase("deviceCommand");
        MongoCollection<Document> collection = database
                .getCollection("deviceCommandEvent");

        // run the mongo query with retry policy
        RetryPolicy retryPolicy = new RetryPolicy()
                .withDelay(2, TimeUnit.SECONDS)
                .withMaxRetries(3)
                .retryIf((Long recordCount) -> recordCount == 0);

        long modifiedDocCount = Failsafe.with(retryPolicy)
                .onRetry((c, f, ctx) -> {
                    LOGGER.warn("mongodb updated document count is 0. Retrying...");
                    LOGGER.warn("Retry #{}...", ctx.getExecutions());
                })
                .get(() ->
                        collection.updateMany(
                                and(eq("accountId", accountId),
                                        eq("deviceId", deviceId),
                                        eq("code", commandType.getName()),
                                        // update all documents matching the command type with dateCreated gte 90 secs ago
                                        gte("dateCreated", new Date(System.currentTimeMillis() - 90 * 1000)))
                                , bson
                                , new UpdateOptions().upsert(false).bypassDocumentValidation(true)).getModifiedCount()
                );

        LOGGER.info("# of documents updated: " + modifiedDocCount);

        if (modifiedDocCount == 0) {
            throw new NoMongoDocumentUpdatedException("No documents updated by this query!");
        }
    }
}
