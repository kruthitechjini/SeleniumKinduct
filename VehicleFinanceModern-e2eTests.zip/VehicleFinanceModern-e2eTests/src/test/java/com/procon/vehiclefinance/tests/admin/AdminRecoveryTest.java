package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRecoveryPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class AdminRecoveryTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AdminRecoveryTest.class.getName());
    protected MapPage mapPage;
    protected VehiclesPage vehiclesPage;
    protected NavbarHeaderPage navbarHeaderPage;

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class deviceData {
        public String serialNumber;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickVehicles(Method method) throws IOException {

        JsonNode dataNode = envNode.at("/" + method.getName());

        deviceData data = null;
        try {
            data = mapper.treeToValue(dataNode, deviceData.class);
            serialNumber = data.serialNumber;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            logger.info("Failed to process data values. Using system data");
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Vehicles Page
        vehiclesPage = navbarHeaderPage.clickVehicles();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Expire Recovery Link", groups = {"admin"})
    public void testExpireRecoveryLink() {
        //Re-size screen display area
        Dimension dimension = new Dimension(1400, 1200);
        driver.manage().window().setSize(dimension);

        //Click Recovery tab
        vehiclesPage.searchAndClickRecoveryLinkForSerial(serialNumber);

        //Create Recovery link
        String linkText = vehiclesPage.createRecoveryLink("TestCompany", "John", "Doe",
                "automationtests05@gmail.com");

        //Switch to Admin > Recovery tab
        AdminLeftBarPage adminLeftBarPage = navbarHeaderPage.clickAdmin();
        AdminRecoveryPage adminRecoveryPage = adminLeftBarPage.clickRecoveryLink();

        //Expire Recovery link
        adminRecoveryPage.expireLink(linkText);
    }

    @Test(description = "Recovery tab UI elements Search/sort", groups = {"admin"})
    public void testAdminRecoveryTabUI() throws ParseException {
        final List<String> GRID_COLUMNS = Arrays.asList(
                "Display Name",
                "Serial Number",
                "Link",
                "Expiration",
                "Repo Company",
                "First Name",
                "Last Name",
                "Email",
                "SMS",
                "Views",
                "Access Log",
                "Actions");

        final List<String> GRID_COLUMNS_SORTABLE = Arrays.asList(
                "Display Name",
                "Serial Number",
                "Expiration",
                "Repo Company",
                "First Name",
                "Last Name",
                "Email",
                "SMS",
                "Views",
                "Access Log");


        //Go to Admin recovery page
        AdminRecoveryPage adminRecoveryLink = navbarHeaderPage.clickAdmin().clickRecoveryLink();
        adminRecoveryLink.waitForTable();

        //Verify title
        assertEquals(adminRecoveryLink.getPageTitle(), "Recovery");

        //Verify columns
        assertEquals(adminRecoveryLink.getGridColumns(), GRID_COLUMNS,
                "Column list does not match expected list for grid");

        //Verify which columns are sortable
        GRID_COLUMNS_SORTABLE.forEach(column -> assertTrue(adminRecoveryLink.isColumnSortable(column),
                "Sortable Column list does not match expected list for grid"));

        //Click on column and verify sort was performed
        GRID_COLUMNS_SORTABLE.forEach(c -> {
            assertTrue(adminRecoveryLink.isColumnSortable(c),
                    "Column " + c + " is not sortable");
            adminRecoveryLink.verifyColumnSorting(c);
        });

        //Verify pagination controls
        adminRecoveryLink.verifyPageSizeSelection();
        adminRecoveryLink.verifyNavigationBtns();
        adminRecoveryLink.verifyNavigationBtnsTooptip();
        adminRecoveryLink.verifyPaginationBoundsDisplay();

        //Verify Recovery tab shows recovery links for the last six months
        String column = "Expiration";
        adminRecoveryLink.clickHeaderColumn(column);
        if (adminRecoveryLink.isColumnSortedAscending(column)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            Period diff = Period.between(LocalDate.parse(adminRecoveryLink.getTableFirstRow().get(column), formatter),
                    LocalDate.now());
            assertTrue(diff.getMonths() <= 6,
                    "Recovery link shows more then the last 6 month");
        }
    }

    @Test(description = "Access log should display last five (5) instances data is shown", groups = {"admin"})
    public void testAdminRecoveryTabAccessLog() {

        //Go to Admin recovery page
        AdminRecoveryPage adminRecoveryLink = navbarHeaderPage.clickAdmin().clickRecoveryLink();
        adminRecoveryLink.waitForTable();

        //Sort by filed Views
        String viewsCol = "Views";
        adminRecoveryLink.clickHeaderColumn(viewsCol);
        if (adminRecoveryLink.isColumnSortedAscending(viewsCol)) {
            adminRecoveryLink.clickHeaderColumn(viewsCol);
        }

        //Get table first row
        HashMap<String, String> table = adminRecoveryLink.getTableFirstRow();

        // Get AccessLog from first row and verify number of instances
        String[] accessLogs = table.get("Access Log").split(",");
        int views = Integer.parseInt(table.get("Views"));

        //if number of views more then 5 then last 5 instances should display
        if (views >= 5) {
            assertEquals(accessLogs.length, 5);
        }
        //else number of views == number of instances
        else
        {
            assertEquals(accessLogs.length, views);
        }

    }
}
