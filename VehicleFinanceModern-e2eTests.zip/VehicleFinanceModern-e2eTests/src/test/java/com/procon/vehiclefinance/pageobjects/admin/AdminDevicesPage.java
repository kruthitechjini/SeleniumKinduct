package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class AdminDevicesPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminDevicesPage.class.getName());

    @FindBy(css = "div.col-xs-4.device-filter-section > button:nth-of-type(1)")
    private WebElement changeGroupBtn;

    @FindBy(css = "div.form > div.row > div:nth-child(1) > div:nth-child(3) .lazy-list-container")
    private WebElement fromGroupBox;

    @FindBy(css = "div.form > div.row > div:nth-child(3) div.ember-table-content-selectable")
    private WebElement toGroupBox;

    private String allRowsInGroupsDropdownCssLocator_css = "[name='selectedLeftGroup'] option";

    private String devicesTransferredMsg_css = "div.bootbox.modal.fade.in";

    //used to get rows count
    private String allRowsCssLocator_css = "div.form > div.row > div:nth-child(1) > div:nth-child(3) .lazy-list-container > div";

    @FindBy(css = ".form > .row  > div:nth-child(1) select")
    private WebElement fromGroupDropDown;

    @FindBy(css = "[name='selectedRightGroup']")
    private WebElement toGroupDropDown;

    @FindBy(css = ".row  > div:nth-child(1) > div:nth-child(3)  div.fixed-body.list-container .ember-table-header-container input")
    private WebElement fromGrpSelectAllChkbox;

    @FindBy(css = ".btn.btn-block.btn-primary.add")
    private WebElement transferBtn;

    final String closeBtnCssStr = ".modal-footer button";
    @FindBy(css = closeBtnCssStr)
    private WebElement closeBtn;

    @FindBy(css = "div:nth-child(1) > div > div:nth-child(3) > span")
    private WebElement tableFirstRowSerialNumber;

    @FindBy(css = "div.ember-view.ember-table-table-row.ember-table-last-row.ember-table-odd-row > div > div:nth-child(1) > span")
    private WebElement tableFirstRowGroup;

    @FindBy(css = "input[type='search']")
    private WebElement searchInput;

    @FindBy(css = "a[title='Terminate']")
    private WebElement terminateBtn;

    @FindBy(css = "div.modal-dialog")
    private WebElement terminatePopup;

    @FindBy(css = "div.modal-header h4.modal-title")
    private WebElement terminatePopupHeader;

    @FindBy(css = "div.modal-footer button[data-bb-handler='cancel']")
    private WebElement terminatePopupCancel;

    @FindBy(css = "a[title='Revoke']")
    private WebElement revokeBtn;

    public AdminDevicesPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickChangeGroupBtn() {
        try {
            waitUntilSpinnerVisible(driver, 1);
        } catch (TimeoutException e) {
        }

        //wait till page is loaded
        waitUntilSpinnerInvisible(driver, 10);

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(changeGroupBtn)).click();
    }

    /**
     * @param fromGroup
     * @param toGroup
     * @param selectAll
     * @param serialNumbers
     */
    public void changeGroup(String fromGroup, String toGroup, Boolean selectAll, List<String> serialNumbers) {
        new WebDriverWait(driver, 15).until(
                elementToBeClickable(fromGroupDropDown));
        Select select = new Select(fromGroupDropDown);
        select.selectByVisibleText(fromGroup);

        Select selectTo = new Select(toGroupDropDown);
        selectTo.selectByVisibleText(toGroup);

        // need to catch the exception because there can be valid test
        // scenarios which have no available devices. In that case, we log a
        // warning and continue instead of failing
        try {
            new WebDriverWait(driver, 20).until(ExpectedConditions
                    .visibilityOfNestedElementsLocatedBy(fromGroupBox, By
                            .cssSelector("div.ember-table-cell")));
        } catch (TimeoutException e) {
            logger.log(Level.WARNING, "Available list has 0 devices");
        }

        if (selectAll) {
            fromGrpSelectAllChkbox.click();
        }

        if (serialNumbers != null) {
            selectSerialNumbers(fromGroupBox, serialNumbers);
        }

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(transferBtn)).click();

        //message box comes up after some time
        try {
            new WebDriverWait(driver, 2)
                    .until(visibilityOfElementLocated(By.cssSelector(devicesTransferredMsg_css)));
        } catch (TimeoutException e) {
        }

        //wait till message box is invisible
        try {
            new WebDriverWait(driver, 5)
                    .until(invisibilityOfElementLocated(By.cssSelector(devicesTransferredMsg_css)));
        } catch (TimeoutException e) {
        }

        //Make sure all selected devices are transferred
        waitUntilSerialNumbersTransferred(toGroupBox, serialNumbers);

        clickCloseBtn();
    }

    private void selectSerialNumbers(WebElement listElement, List<String> serialNumbers) {
        String format = "//span[text()='%s']/parent::div/parent::div/descendant::input";
        waitUntilSpinnerInvisible(driver);
        for (String serialNumber : serialNumbers) {
            String xpath = String.format(format, serialNumber);

            new WebDriverWait(driver, 10)
                    .until(elementToBeClickable(listElement.findElement(By.xpath(xpath)))).click();
        }
    }

    private void waitUntilSerialNumbersTransferred(WebElement listElement, List<String> serialNumbers) {
        String format = "//span[text()='%s']";
        waitUntilSpinnerInvisible(driver);
        for (String serialNumber : serialNumbers) {
            String xpath = String.format(format, serialNumber);

            new WebDriverWait(driver, 10)
                    .until(presenceOfNestedElementLocatedBy(listElement, By
                                    .xpath(xpath)));
        }
    }

    public void clickCloseBtn() {
        clickElementAndWaitForInvisibility(driver, closeBtn, By.cssSelector(closeBtnCssStr), 10);
    }

    /**
     * @deprecated this method relies on UI elements and is no longer
     * recommended. To get a list of groups for currently logged in account,
     * use
     * {@link com.procon.vehiclefinance.services.GroupService.getGroups()}
     * which makes use of API calls instead.
     */
    @Deprecated
    public List<String> getGroups() {
        new WebDriverWait(driver, 10)
                .until(elementToBeClickable(By.cssSelector(allRowsInGroupsDropdownCssLocator_css)));

        List<WebElement> options = driver.findElements(
                By.cssSelector(allRowsInGroupsDropdownCssLocator_css));

        ArrayList<String> listAccessibleGroups = new ArrayList<>();
        for (int i = 0; i < options.size(); i++) {
            listAccessibleGroups.add(options.get(i).getText());
        }
        return listAccessibleGroups;
    }

    /**
     * @deprecated this method relies on UI elements and is no longer
     * recommended. To get a list of devices in an asset group, use {@link com
     * .procon.vehiclefinance.services.DeviceService.getDevicesByGroup()}
     * which makes use of API calls instead.
     */
    @Deprecated
    public ArrayList<String> getGroupMembers(String group) {
        Select select = new Select(fromGroupDropDown);
        select.selectByVisibleText(group);

        waitUntilSpinnerInvisible(driver, 10);
        ArrayList<String> groupMembers = new ArrayList<String>();

        try {
            new WebDriverWait(driver, 1).until(ExpectedConditions
                    .visibilityOfNestedElementsLocatedBy(fromGroupBox, By
                            .cssSelector("div.ember-table-cell")));
        } catch (TimeoutException e) {
            logger.log(Level.WARNING, "Available list has 0 devices");
        }

        int rowCount = driver.findElements(By.cssSelector(allRowsCssLocator_css)).size() - 2;
        int i = 1;
        while (i <= rowCount) {
            WebElement elementText = fromGroupBox.findElement(By.xpath("div[" + i + "]/div/div[3]"));
            groupMembers.add(elementText.getText());
            i++;
        }
        return groupMembers;
    }

    public WebElement getTableFirstRowSerialNumber() {
        return tableFirstRowSerialNumber;
    }

    public WebElement getSearchInput() { return searchInput; }

    public WebElement getTableFirstRowGroup() { return tableFirstRowGroup; }

    public void searchVehicle(String searchString) {
        waitUntilSpinnerInvisible(driver);
        searchInput.clear();
        waitUntilSpinnerInvisible(driver);
        searchInput.sendKeys(searchString);
    }

    public WebElement getChangeGroupBtn() {
        return changeGroupBtn;
    }

    public WebElement getTerminateBtn() {
        return terminateBtn;
    }

    public WebElement getTerminatePopup() {
        return terminatePopup;
    }

    public String getTerminatePopupHeader() {
        return new WebDriverWait(driver, 3).until(visibilityOf(terminatePopupHeader)).getText();
    }

    public void clickTerminatePopupCancel() {
        new WebDriverWait(driver, 3).until(elementToBeClickable(terminatePopupCancel)).click();
        try {
            new WebDriverWait(driver, 2).until(invisibilityOf(terminatePopup));
        }
        catch (TimeoutException e) { }
    }

    public WebElement getRevokeBtn() {
        return revokeBtn;
    }

    public WebElement getRevokePopup() {
        return terminatePopup;
    }

    public String getRevokePopupHeader() {
        return new WebDriverWait(driver, 3).until(visibilityOf(terminatePopupHeader)).getText();
    }

    public void clickRevokePopupCancel() {
        new WebDriverWait(driver, 3).until(elementToBeClickable(terminatePopupCancel)).click();
        try {
            new WebDriverWait(driver, 2).until(invisibilityOf(terminatePopup));
        }
        catch (TimeoutException e) { }
    }
}
