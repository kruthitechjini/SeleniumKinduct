package com.procon.vehiclefinance.tests.vehicles;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mongodb.MongoException;
import com.procon.vehiclefinance.models.Device.DeviceGeoFencesData;
import com.procon.vehiclefinance.models.PlatformObject;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.CommandTypeEnum;
import com.procon.vehiclefinance.pageobjects.vehicles.VehicleGeoFencePage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.NoMongoDocumentUpdatedException;
import com.procon.vehiclefinance.util.PlatformApiUtils;
import com.spireon.platform.utils.model.RabbitmqEvent;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.bson.conversions.Bson;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.mongodb.client.model.Updates.combine;
import static com.mongodb.client.model.Updates.set;
import static com.mongodb.client.model.Updates.unset;
import static com.procon.vehiclefinance.services.DeviceService.getDevices;
import static com.procon.vehiclefinance.services.DeviceService.getGeoFences;
import static com.procon.vehiclefinance.services.DeviceService.getUserSettings;
import static com.procon.vehiclefinance.util.MongoUtils.simulateCommandSuccess;
import static com.procon.vehiclefinance.util.PlatformApiUtils.deleteDevice;
import static com.procon.vehiclefinance.util.PlatformApiUtils.deleteVehicle;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static com.spireon.platform.utils.RabbitMQEventPublisher.sendEvent;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class CommandsTest extends BaseTest {
    protected MapPage mapPage;
    protected VehiclesPage vehiclesPage;
    protected NavbarHeaderPage navbarHeaderPage;

    private String token = "";

    private static final Logger LOGGER = LoggerFactory.getLogger(CommandsTest.class);

    RetryPolicy commandResponsetryPolicy = new RetryPolicy()
            .retryOn(TimeoutException.class)
            .withDelay(2, TimeUnit.SECONDS)
            .withMaxRetries(3);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String apiUserName;
        public String apiPassword;
        public String appToken;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String geoFenceName;
        public String serialNumber;
    }

    @BeforeClass(alwaysRun = true)
    protected void setupDevicesAndVehicles() {
        JsonNode dataNode = envNode.at("/" + this.getClass().getSimpleName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            LOGGER.warn("Json data reading failure from test_resource.json!");
        }

        // get token
        token = PlatformApiUtils.getToken(data.apiUserName, data.apiPassword, data.appToken);
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickVehicles() {

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Vehicles Page
        vehiclesPage = navbarHeaderPage.clickVehicles();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }
    }

    @Test(description = "Test Locate command using fake devices", groups =
            {"vehicles", "command"})
    public void testLocateCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getLocateBtn(), "Locate", 1, CommandTypeEnum.LOCATE);
    }

    @Test(description = "Test Locate command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testLocateCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getLocateCommandBtn(), "Locate", 2, CommandTypeEnum.LOCATE);
    }

    @Test(description = "Test Warning On command using a fake device", groups =
            {"vehicles", "command"})
    public void testWarningOnCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getWarningOnLink(), "Warning On", 1, CommandTypeEnum.WARNING_ON);
    }

    @Test(description = "Test Warning On command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testWarningOnCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getWarningOnLink(), "Warning On", 2, CommandTypeEnum.WARNING_ON);
    }

    @Test(description = "Test Warning Off command using a fake device", groups =
            {"vehicles", "command"})
    public void testWarningOffCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getWarningOffLink(), "Warning Off", 1, CommandTypeEnum.WARNING_OFF);
    }

    @Test(description = "Test Warning Off command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testWarningOffCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getWarningOffLink(), "Warning Off", 2, CommandTypeEnum.WARNING_OFF);
    }

    @Test(description = "Test Starter Enable command using a fake device", groups =
            {"vehicles", "command"})
    public void testStarterEnableCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getStarterEnableLink(), "Starter Enable", 1, CommandTypeEnum.STARTER_ENABLE);
    }

    @Test(description = "Test Starter Disable command using a fake device", groups =
            {"vehicles", "command"})
    public void testStarterDisableCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getStarterDisableLink(), "Starter Disable", 1, CommandTypeEnum.STARTER_DISABLE);
    }

    @Test(description = "Test Starter Enable command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testStarterEnableCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getStarterEnableLink(), "Starter Enable", 2, CommandTypeEnum.STARTER_ENABLE);
    }

    @Test(description = "Test Starter Disable command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testStarterDisableCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getStarterDisableLink(), "Starter Disable", 2, CommandTypeEnum.STARTER_DISABLE);
    }

    @Test(description = "Test Quick Fence command using a fake device", groups =
            {"vehicles", "command"})
    public void testQuickFenceCommand() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getSetQuickFenceBtn(), "QuickFence", 1, CommandTypeEnum.QUICK_FENCE);
    }

    @Test(description = "Test Quick Fence command using multiple fake devices", groups =
            {"vehicles", "command"})
    public void testQuickFenceCommandBulk() throws IOException, UnirestException, InterruptedException {

        sendAndValidateCommands(vehiclesPage.getSetQuickFenceBulkBtn(), "QuickFence", 2, CommandTypeEnum.QUICK_FENCE);
    }

    @Test(description = "Test set geofence command using fake devices", groups = {"vehicles", "command"})
    public void testGeoFenceCommand() throws IOException, UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }
        serialNumber = data.serialNumber;

        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);
        vehiclesPage.waitForLocateCommandBtnVisible(); // wait for command buttons to show up

        //Click on GeoFence tab
        VehicleGeoFencePage vehicleGeoFencePage = vehiclesPage.clickGeoFenceTab();

        //Validate Geo-Fence Tab grid is displayed
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(vehicleGeoFencePage.columnHeader().isDisplayed());

        //Select and save a GeoFence
        vehicleGeoFencePage.selectAndSaveGeoFence(data.geoFenceName,
                VehicleGeoFencePage.GeoFenceTypeEnum.ENTER_EXIT);

        String rawResponse = "OK,A100003C5F0E51,AT+IONGF=6,3,33.64579,33.64528,-117.98951,-117.98902,60\r\n";

        Bson deviceCommandEvent = setupBsonObjForGeoFence(rawResponse);

        //get Ids for account, device and asset
        Map<Integer, String> deviceIdAndSerialNumMap = new HashMap<>();
        User.UserSettings userSettings = getUserSettings(driver);
        int accountId = userSettings.accountId;
        int deviceId = getDevices(driver, serialNumber).data.get(0).deviceId;
        deviceIdAndSerialNumMap.put(deviceId, serialNumber);
        LOGGER.info("accountId: " + accountId + "\n" + "serial#: " + serialNumber + "\n" + "deviceId: " + deviceId);

        //simulate command geofence set by inserting data in Mongodb
        updateMongoDocuments(CommandTypeEnum.SET_GEOFENCE, accountId, deviceId, deviceCommandEvent);

        //Validate Save GeoFence Bubble
        validateCommandBubbles(CommandTypeEnum.SET_GEOFENCE, accountId, deviceIdAndSerialNumMap, deviceCommandEvent);

        assertEquals(vehiclesPage.getBubbleSuccessIcon()
                .getAttribute("title"), "Successful");
        assertEquals(vehiclesPage.getBubbleTitle()
                .getAttribute("title"), "Set GeoFence - " + vehiclesPage
                .getVehicleName().getText());

        DeviceGeoFencesData geoFencesSetData = getGeoFences(driver,
                deviceId);

        List<String> geoFenceNameList = new ArrayList<>();

        geoFencesSetData.data.forEach(geoFencesDetail -> geoFenceNameList.add(geoFencesDetail.name.split(" - ")[0]));

        //Validate Saved GeoFence with service call
        assertTrue(geoFenceNameList.contains(data.geoFenceName));

        //Click view link
        vehicleGeoFencePage.clickViewLink();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 20);

        //Validate GeoFence view link is clickable
        vehicleGeoFencePage.clickGeoFenceViewMarker();

        //Validate GeoFence view link bubble
        assertEquals(vehicleGeoFencePage.getGeoFenceViewLinkBubbleHeader().getText(), data.geoFenceName);

        vehicleGeoFencePage.clickCloseBtn();

        //Click clear link
        vehicleGeoFencePage.clickClearLink();

        rawResponse = "OK,A100003C5F0E51,AT+IONGF=1,0,0,0,0,0,60\n";
        deviceCommandEvent = setupBsonObjForGeoFence(rawResponse);

        //simulate command geofence clear by inserting data in Mongodb
        updateMongoDocuments(CommandTypeEnum.SET_GEOFENCE, accountId, deviceId, deviceCommandEvent);

        //Validate Clear GeoFence Bubble
        validateCommandBubbles(CommandTypeEnum.SET_GEOFENCE, accountId, deviceIdAndSerialNumMap, deviceCommandEvent);

        assertEquals(vehiclesPage.getBubbleSuccessIcon()
                .getAttribute("title"), "Successful");
        assertEquals(vehiclesPage.getBubbleTitle()
                .getAttribute("title"), "Clear GeoFence - " + vehiclesPage
                .getVehicleName().getText());
    }

    private void sendAndValidateCommands(WebElement commandElement, String commandText, int numOfVehicles, CommandTypeEnum commandType)
            throws IOException, UnirestException, InterruptedException {
        List<String> serialNumberList = new ArrayList<>();
        List<String> deviceGlobaldList = new ArrayList<>();
        List<String> assetGlobalIdList = new ArrayList<>();

        // this vehicleNameBase is used for searching in the UI
        // so that all vehicles with the same base name will return in the search
        String vehicleNameBase = Long.toString(System.currentTimeMillis());

        // create multiple vehicle names using the base name above
        // also create fake devices & vehicles within this loop
        for (int i = 0; i < numOfVehicles; i++) {
            String vehicleName = new StringBuffer().append(vehicleNameBase).append(i).toString();

            // create device & vehicle
            PlatformObject platformObject = PlatformApiUtils.createDeviceAndAsset(vehicleName, token);

            String serialNumber = platformObject.deviceDto.getSerialNumber();
            serialNumberList.add(serialNumber);

            deviceGlobaldList.add(platformObject.deviceDto.getId());
            assetGlobalIdList.add(platformObject.assetDto.getId());
        }

        //Clear filter button
        vehiclesPage.clearFilter();

        // once a device is created there is some lag before it shows in the UI.  Following code
        // retries till intended vehicles show in UI
        vehiclesPage.searchVehicle(vehicleNameBase);

        RetryPolicy retryPolicy = new RetryPolicy()
                .retryIf((Boolean flag) -> flag == false)
                .withDelay(2, TimeUnit.SECONDS)
                .withMaxRetries(5);

        // Run with retries
        Failsafe.with(retryPolicy).onRetry((c, f, ctx) -> {
            vehiclesPage.clickRefreshBtn();
            LOGGER.warn("Vehicle with prefix {} still not visible refreshing UI..", vehicleNameBase);
        }).get(() -> {
            for (int i = 0; i < serialNumberList.size(); i++) {
                if (!vehiclesPage.isVehicleVisible(i + 1)) {
                    return false;
                }
            }
            return true;
        });

        //select all vehicles
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 3);
        for (int i = 0; i < serialNumberList.size(); i++) {
            vehiclesPage.selectVehicle(i + 1);
        }
        vehiclesPage.waitForLocateCommandBtnVisible(); // wait for command buttons to show up

        //get Ids for account and devices
        User.UserSettings userSettings = getUserSettings(driver);
        int accountId = userSettings.accountId;

        //get a list of device IDs based on serial numbers and add device ID & Serial Number into a map
        Map<Integer, String> deviceIdAndSerialNumMap = new HashMap<>();
        for (String serialNumber : serialNumberList) {
            int deviceId = getDevices(driver, serialNumber).data.get(0).deviceId;
            deviceIdAndSerialNumMap.put(deviceId, serialNumber);
            LOGGER.info("accountId: " + accountId + "\n" + "serial#: " + serialNumber + "\n" + "deviceId: " + deviceId);
        }

        //Click on Command button for bulk command
        commandElement.click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        // if it's Starter Disable command for a single device, an extra step of clicking on the Send button is required
        if (commandText.equals("Starter Disable") && deviceIdAndSerialNumMap.size() == 1) {
            vehiclesPage.getStarterDisableSendButton().click();
        }
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Create Bson object to pass
        Bson deviceCommandEvent = setupBsonObj();

        //simulate command success by sending command response or inserting data in Mongodb
        for (Map.Entry<Integer, String> entry : deviceIdAndSerialNumMap.entrySet()) {
            simulateCommandResponse(commandType, accountId, entry.getKey(), entry.getValue(), deviceCommandEvent);
        }

        //Validate Command Bubbles for all vehicles
        try {
            validateCommandBubbles(commandType, accountId, deviceIdAndSerialNumMap, deviceCommandEvent);
        } catch (TimeoutException e) {
            fail("Test Failed - not all spinning bubbles turned into successful bubbles.");
        }

        List<String> bubbleTitles = vehiclesPage.getBubbleTitlesText();
        List<String> vehicleNameTextList = vehiclesPage.getVehicleNameText();

        // verify that the bubble count matches the vehicle counts
        assertEquals(bubbleTitles.size(), vehicleNameTextList.size());

        // verify the vehicle names are showing in the bubbles
        for (String vehicleNameText : vehicleNameTextList) {
            assertTrue(bubbleTitles.contains(commandText + " - " + vehicleNameText));
        }

        //delete asset after command is successful
        for (String assetGlobalId : assetGlobalIdList) {
            if (!deleteVehicle(assetGlobalId, token)) {
                LOGGER.warn("AssetGlobalID -> {} could not be deleted ", assetGlobalId);
            }
        }

        // delete device after command is successful
        for (String deviceGlobalId : deviceGlobaldList) {
            if (!deleteDevice(deviceGlobalId, token)) {
                LOGGER.warn("deviceGlobalId -> {} could not be deleted ", deviceGlobalId);
            }
        }
    }

    private Bson setupBsonObj() {
        Bson deviceCommandEvent =
                combine(set("totalCost", 0)
                        , set("sendCost", 0)
                        , set("landmarkName", "Spireon")
                        , set("totalDistance", 1.090451217893368E8)
                        , set("answered", true)
                        , set("sendSuccess", true)
                        , set("status", "Success")
                        , set("rawResponse", "")
                        , set("receiveDate", new Date())
                        , set("lat", 33.69935)
                        , set("lng", -117.84335)
                        , set("address", "16793 Aston")
                        , set("city", "Irvine")
                        , set("zip", "92606")
                        , set("state", "CA")
                        , set("speed", 0)
                        , set("heading", 0)
                        , set("newLoc", 1)
                        , set("satellites", 11)
                        , set("softwareRev", 22)
                        , set("rssi", 28)
                        , set("extVolts", 13.6)
                        , set("commandResponse", null)
                        , set("totalDistance", 1.090451217893368E8)
                        , set("assetDistance", 2.137241529032097E7)
                        , set("updatedBy", "commandService")
                        , set("landmarkId", 444403)
                        , set("landmarkName", "Spireon")
                        , set("message", "timeout")
                        , set("error", false)
                );
        return deviceCommandEvent;
    }

    /**
     * Create Bson object to pass for setting and clearing geofence
     *
     * @return
     */
    private Bson setupBsonObjForGeoFence(String rawResponse) {
        Bson deviceCommandEvent =
                combine(unset("pending")
                        , set("answered", true)
                        , set("totalCost", 1)
                        , set("status", "Success")
                        , set("rawResponse", rawResponse)
                        , set("receiveDate", new Date())
                        , set("lat", null)
                        , set("lng", null)
                        , set("address", null)
                        , set("city", null)
                        , set("zip", null)
                        , set("state", null)
                        , set("speed", null)
                        , set("heading", null)
                        , set("newLoc", null)
                        , set("satellites", null)
                        , set("softwareRev", null)
                        , set("rssi", null)
                        , set("extVolts", null)
                        , set("commandResponse", "AT+IONGF=1")
                        , set("totalDistance", 8408825.001488645)
                        , set("assetDistance", 949513.2537565972)
                        , set("updatedBy", "commandService"));
        return deviceCommandEvent;
    }

	/**
	 * Retry MongoDB query to update the command - for both single & bulk commands
	 *
	 * @param commandType
	 * @param accountId
	 * @param deviceIdAndSerialMap
	 * @param commandBson
	 */
    private void validateCommandBubbles(CommandTypeEnum commandType, int accountId, Map<Integer, String> deviceIdAndSerialMap, Bson commandBson) {
        Failsafe.with(commandResponsetryPolicy)
                .onRetry((c, f, ctx) -> {
                    LOGGER.warn("Retry #{} commandType: " + commandType.getName(), ctx.getExecutions());

                    // Go through mongoDB update during retry only for QuickFence & SetGeoFence commands
                    // For other commands' responses, simulation is done through event generator
                    for (Map.Entry<Integer, String> entry : deviceIdAndSerialMap.entrySet()) {
                        if (commandType == CommandTypeEnum.QUICK_FENCE || commandType == CommandTypeEnum.SET_GEOFENCE) {
                            LOGGER.warn("retry via MongoDB udpates...");
                            try {
                                simulateCommandSuccess(accountId, entry.getKey(), commandBson, commandType);
                            } catch (MongoException me) {
                                LOGGER.error("Failed to update data in Mongo Database: {}", me.getLocalizedMessage());
                                fail("Failed to update data in Mongo Database");
                            }
                        } else {
                            LOGGER.warn("retry via command response from event generator...");
                            simulateCommandResponseViaEventGenerator(commandType, entry.getValue());
                        }
                    }
                })
                .run(() ->
                            vehiclesPage.waitForSuccessfulBubbles(deviceIdAndSerialMap.size())
                );
    }

    /**
     * simulate command response using different approchaes based on different command types
     * for locate, warning on/off, starter enable/disable - event generator is used to simulate command response
     * quick fence & geo fence - mongoDB document was dupcated directly to mimic successful command response
     *
     * @param commandType
     * @param accountId
     * @param deviceId
     * @param deviceSerial
     * @param commandBson
     * @throws UnirestException
     * @throws InterruptedException
     */
    private void simulateCommandResponse(CommandTypeEnum commandType, int accountId, int deviceId, String deviceSerial, Bson commandBson)
        throws UnirestException, InterruptedException {
        switch (commandType) {
            case LOCATE:
            case WARNING_ON:
            case WARNING_OFF:
            case STARTER_ENABLE:
            case STARTER_DISABLE:
                simulateCommandResponseViaEventGenerator(commandType, deviceSerial);
                break;
            default:
                updateMongoDocuments(commandType, accountId, deviceId, commandBson);
                break;
        }
    }

    /**
     * simulate command response using event generator through RabbitMQ
     *
     * @param commandType
     * @param deviceSerial
     * @throws UnirestException
     * @throws InterruptedException
     */
    private void simulateCommandResponseViaEventGenerator(CommandTypeEnum commandType, String deviceSerial)
        throws UnirestException, InterruptedException {
        int deviceTypeId = 17; // 17 for Montage device by default

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));


        RabbitmqEvent.RabbitmqEventBuilder rmqEventBuilder = RabbitmqEvent.RabbitmqEventBuilder.aRabbitmqEvent()
                .withEventDate(formatter.format(System.currentTimeMillis()))
                .withLat(33.684566)
                .withLng(-117.826508)
                .withSerial(deviceSerial);

        switch (commandType) {
            case LOCATE:
                rmqEventBuilder.withEventTypeCode("USER_LOC");
                break;
            case WARNING_ON:
                rmqEventBuilder.withEventTypeCode("WARNBUZZ_SET");
                rmqEventBuilder.withRawResponse("OK," + deviceSerial + ",AT+IONBZ=1");
                break;
            case WARNING_OFF:
                rmqEventBuilder.withEventTypeCode("WARNBUZZ_SET");
                rmqEventBuilder.withRawResponse("OK," + deviceSerial + ",AT+IONBZ=0");
                break;
            case STARTER_ENABLE:
                rmqEventBuilder.withEventTypeCode("STARTER_TOGGLE");
                rmqEventBuilder.withSrcType("VEHICLE_STARTER_WAS_ENABLED");
                break;
            case STARTER_DISABLE:
                rmqEventBuilder.withEventTypeCode("STARTER_TOGGLE");
                rmqEventBuilder.withSrcType("VEHICLE_STARTER_WAS_DISABLED");
                break;
        }

        RabbitmqEvent rmqEvent = rmqEventBuilder.build();

        LinkedList<RabbitmqEvent> rmqEventList = new LinkedList<>();
        rmqEventList.add(rmqEvent);

        RetryPolicy rmqRetryPolicy = new RetryPolicy()
                .retryOn(AmqpException.class)
                .withDelay(5, TimeUnit.SECONDS)
                .withMaxRetries(2);

        Failsafe.with(rmqRetryPolicy)
                .onRetry((c, f, ctx) -> {
                    LOGGER.warn("AMQP exception. Retry #{}... ", ctx.getExecutions());
                })
                .onFailure(failure -> {
                    fail("case failed due to AMQP exception after 2 retries..." + failure);
                })
                .run(() -> sendEvent(rmqEventList, deviceTypeId)
                );
    }

	/**
	 * update mongo DB documents for devices
	 *
	 * @param commandType
	 * @param accountId
	 * @param deviceId
	 * @param commandBson
	 * @return
	 */
    private void updateMongoDocuments(CommandTypeEnum commandType, int accountId, int deviceId, Bson commandBson) {
		try {
			LOGGER.info("commandType: " + commandType.getName());
			simulateCommandSuccess(accountId, deviceId, commandBson, commandType);
		} catch (MongoException me) {
			LOGGER.error("Failed to update data in Mongo Database: {}", me.getLocalizedMessage());
			fail("Failed to update data in Mongo Database");
		} catch (NoMongoDocumentUpdatedException e) {
		    LOGGER.error(e.getMessage());
		    fail(e.getMessage());
		}
	}
}

