package com.procon.vehiclefinance.models;

public class GeoCoord {
    private Double lat;
    private Double lng;

    private GeoCoord(Double lat, Double lng) {
        this.lat = lat;
        this.lng = lng;
    }

    public Double getLatitude() {
        return lat;
    }

    public Double getLongitude() {
        return lng;
    }

    public static class GeoCoordBuilder {
        private Double lat;
        private Double lng;

        public GeoCoordBuilder lat(Double lat) {
            this.lat = lat;
            return this;
        }

        public GeoCoordBuilder lng(Double lng) {
            this.lng = lng;
            return this;
        }

        public GeoCoord build() {
            return new GeoCoord(lat, lng);
        }
    }
}
