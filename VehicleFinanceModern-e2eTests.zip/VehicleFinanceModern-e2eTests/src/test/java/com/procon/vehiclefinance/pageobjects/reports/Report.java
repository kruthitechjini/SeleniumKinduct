package com.procon.vehiclefinance.pageobjects.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * This class defines the objects needed to handle the various response
 * objects from Reports service calls
 */
public class Report {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ReportItem {
        public String assetName;
        public String assetModel;
        public String assetMake;
        public String eventDate;
        public String alertTypeName;
        public String speed;
        public String assetVin;
        public String serialNumber;
        public String address;
        public String type;
        public String username;
        public String requestBy;
        public String command;
        public String response;
        public String geozone;
        public String eventTypeName;
        public String scheduledName;
        public String status;
        public String id;

        // Inventory Status report fields
        public String inventoryStatus;
        public String installDate;
        public String installStatus;

        // Vehicle information report fields
        public String make;
        public String model;
        public Object year;
        public String color;
        public String licensePlate;
        public String licenseState;
        public double odometer;
        public String assetGroupName;
        public String inventory;

        // Mileage report fields
        public double drivenMiles;
        public String stockNumber;
        public String vin;
        public String group;
        public double excessMiles;
        public double cost;
        public double initialOdometer;

        // Reference Verification report fields
        public String reference;
        public String verified;
        public String visits;
        public String visitThreshold;

        // Impound Status report fields
        public String duration;
        public String date;
        public String landmarkName;

        // Installation Request History report fields
        public String requestedBy;
        public long orderNumber;
        public String dealerName;
        public String appId;
        public String dateCreated;
        public String customerName;
    }

    /**
     * Report data. This is the response to the display report call which
     * retrieves all the data contained in a report.
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ReportData {
        public JsonNode summary;
        public List<String> selectedColumns;
        public JsonNode columns;
        public JsonNode config;
        public String eventType;
        public JsonNode filters;

        /*
        Alert History
        Auto Report History
        All Device History
        Daily Device History
        GeoFence Violations
        GeoZone Violations
         */
        public List<ReportItem> alertList;

        /*
        Drive Report
        Response History
        Stipulation Report
        Stop Report
         */
        public List<ReportItem> eventList;

        /*
        Exceptions
         */
        public List<ReportItem> deviceList;

        /*
        Excessive Mileage Report
        Inventory Status
        Mileage Summary Report
        Sales Report
        Starter Status
        Vehicle Information
        */
        public List<ReportItem> assetList;
        public JsonNode starterDisablePermission;
        public JsonNode starterEnablePermission;
        public String startDate;
        public String endDate;

        /*
        Reference Verification
         */
        public List<ReportItem> stipList;

        /*
        Scheduled History
         */
        public List<ReportItem> commandList;
    }

    /**
     * This is the report metadata that is returned in both the Report
     * History Results, as well as the response to when a new report is run.
     * This response object doesn't contain actual data of the report, which
     * can be retrieved using getDisplayReport
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ReportOutput {
        public int accountId;
        public String executionEnd;
        public String executionStart;
        public String id;
        public String reportName;
        public boolean reportSaved;
        public int reportSpecId;
        public int reportTypeId;
        public String reportTypeName;
        public String reportTypeVersion;
        public int requestedByAccountUserId;
        public String nextRunDate;
        public String reportViewed;
    }

    /**
     * The list of all reports that have been previously run that is shown when
     * navigating to reports page in the 'Report History' tab
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ReportHistoryResults {
        public int count;
        public List<ReportOutput> data;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SavedReport {
        public int accountId;
        public String accountLabel;
        public boolean active;
        public boolean async;
        public String config;
        public String cronSpec;
        public int id;
        public String lastRunId;
        public int reportTypeId;
        public String reportTypeLabel;
        public String reportTypeName;
        public int requestedById;
        public String requestedByLabel;
        public String timezone;
        public String type;
        public String userName;
        public boolean userSaved;

    }

    public static class SavedReportResults {
        public List<SavedReport> data;
        public String errors;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }
}
