package com.procon.vehiclefinance.pageobjects.alerts;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;

public class AlertsNotificationHistoryPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AlertsNotificationHistoryPage.class.getName());

    private final String panelTitle_css = "span.panel-title";
    @FindBy(css = panelTitle_css)
    private WebElement panelTitle;

    @FindBy(css = "[placeholder='Search']")
    private WebElement searchBox;

    @FindBy(css = "select.ember-select.form-control")
    private WebElement selectAlertTypeBox;

    @FindBy(css = "div.ember-table-tables-container.ember-table-content-selectable")
    private WebElement grid;

    @FindBy(css = "div.ember-table-tables-container.ember-table-content-selectable div.lazy-list-container > div:nth-of-type(1)>div > div:nth-of-type(7)>span>div")
    private WebElement recipient;

    @FindBy(css = "div.ember-table-tables-container.ember-table-content-selectable div.lazy-list-container > div:nth-of-type(1)>div  span.glyphicon-eye-open")
    private WebElement viewNotificationButton;

    @FindBy(css = "div.ember-table-tables-container.ember-table-content-selectable div.lazy-list-container > div:nth-of-type(1)>div span.glyphicon.glyphicon-map-marker")
    private WebElement notificationHistoryMap;

    @FindBy(css = "i.glyphicon-step-backward")
    private WebElement firstPage;

    @FindBy(css = "i.fa-caret-left")
    private WebElement previousPage;

    @FindBy(css = "i.fa-caret-right")
    private WebElement nextPage;

    @FindBy(css = "i.glyphicon-step-forward")
    private WebElement lastPage;

    @FindBy(css = "i.fa-refresh")
    private WebElement refreshPage;

    @FindBy(css = "div.panel-footer button:nth-of-type(1)")
    private WebElement clearSelectedBtn;

    @FindBy(css = "div.panel-footer button:nth-of-type(2)")
    private WebElement clearAllBtn;

    @FindBy(css = "div.paging-status")
    private WebElement pagingStatusLabel;

    //below elements are for notificationModal
    @FindBy(xpath = "//h4[text()='ALERT INFO']")
    private WebElement notificationModalAlertInfoLabel;

    @FindBy(xpath = "//h4[text()='LOCATION INFO']")
    private WebElement notificationModalLocationInfoLabel;

    @FindBy(xpath = "//h4[text()='Recipients']")
    private WebElement notificationModalRecipientsLabel;

    @FindBy(css = "div.panel-footer button:nth-of-type(2)")
    private WebElement notificationModalRecipient;

    private final String notificationModalCancelBtn_css = "button.btn.btn-cancel";
    @FindBy(css = notificationModalCancelBtn_css)
    private WebElement notificationModalCancelBtn;

    //below elements are for notificationMapModal
    @FindBy(css = "button.btn.btn-cancel")
    private WebElement notificationMapModalCancelBtn;

    @FindBy(css = "h4.modal-title")
    private WebElement notificationMapModalLabel;

    @FindBy(css = "tr> td:nth-of-type(1)")
    private List<WebElement> notificationMapModalRecipientList;

    public AlertsNotificationHistoryPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }


    public String getPanelTitleText() {
        return panelTitle.getText();
    }

    public String getSearchPlaceHolderText() {
        return searchBox.getAttribute("Placeholder");
    }

    public String getAlertsDropdownPlaceHolderText() {
        return selectAlertTypeBox.getText();
    }

    public boolean isPanelTitlePresent() {
        return WebElements.isElementPresent(driver, By.cssSelector(panelTitle_css));
    }

    public boolean isGridDisplayed() {
        return grid.isDisplayed();
    }

    public boolean navigationControlFirstPageIsDisplayed() {
        return firstPage.isDisplayed();
    }

    public boolean navigationControlNextPageIsDisplayed() {
        return nextPage.isDisplayed();
    }

    public boolean navigationControlLastPageIsDisplayed() {
        return lastPage.isDisplayed();
    }

    public boolean navigationControlRefreshPageIsDisplayed() {
        return refreshPage.isDisplayed();
    }

    public boolean navigationControlPreviousPageIsDisplayed() {
        return previousPage.isDisplayed();
    }

    public boolean isClearSelectedBtnDisplayed() {
        return clearSelectedBtn.isDisplayed();
    }

    public boolean isclearAllBtnDisplayed() {
        return clearAllBtn.isDisplayed();
    }

    public String isPagingStatusDisplayed() {
        return pagingStatusLabel.getText();
    }

    public void clickViewNotificationButton() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        viewNotificationButton.click();
    }

    public String getNotificationModalAlertInfoLabelText() {
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
        return notificationModalAlertInfoLabel.getText();
    }

    public String getNotificationModalLocationInfoLabelText() {
        return notificationModalLocationInfoLabel.getText();
    }

    public String getNotificationModalRecipientsLabelText() {
        return notificationModalRecipientsLabel.getText();
    }

    public void clickNotificationModalCancelBtn() {
        clickElementAndWaitForInvisibility(driver, notificationModalCancelBtn, By.cssSelector(notificationModalCancelBtn_css));
    }

    public void clickNotificationMapModalBtn() {
        notificationHistoryMap.click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
    }

    public String getNotificationMapModalLabelText() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        return notificationMapModalLabel.getText();
    }

    public void clickNotificationMapModalCancelBtn() {
        clickElementAndWaitForInvisibility(driver, notificationMapModalCancelBtn, By.cssSelector(notificationModalCancelBtn_css));
    }

    public String getRecipietText() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        return recipient.getText();
    }

    /**
     * Get all recipients in notificationModal
     * @return
     */
    public List<String> getNotificationModalRecipients() {
        List<String> recipientList = new ArrayList<>();

        for (WebElement notificationMapModalRecipient: notificationMapModalRecipientList) {
            recipientList.add(notificationMapModalRecipient.getText());
        }

        return recipientList;
    }
}

