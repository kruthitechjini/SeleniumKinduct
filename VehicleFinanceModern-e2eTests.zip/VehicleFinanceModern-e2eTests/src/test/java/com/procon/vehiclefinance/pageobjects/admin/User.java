package com.procon.vehiclefinance.pageobjects.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class User {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UserSettings {
        public String username;
        public String email;
        public String phone;
        public int userId;
        public String userTz;
        public String lName;
        public String fName;
        public int accountId;
        public String accountName;
        public int accountUserId;
        public boolean masterUser;
        public DefaultVehiclesView defaultVehiclesView;
    }

    public static class DefaultVehiclesView {
        public String name;
        public String value;
        public String valueType;
        public String tags;
        public String category;
        public boolean visible;
        public boolean editable;
    }
}
