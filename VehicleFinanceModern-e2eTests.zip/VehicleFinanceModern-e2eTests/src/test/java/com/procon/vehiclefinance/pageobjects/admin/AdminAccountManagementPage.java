package com.procon.vehiclefinance.pageobjects.admin;


import static com.procon.vehiclefinance.services.AccountService.getRenewals;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static com.procon.vehiclefinance.util.WebElements.enterText;
import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Account;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.*;

public class AdminAccountManagementPage extends CommonGrid {

    private static final Logger logger = LoggerFactory.getLogger(AdminAccountManagementPage.class);

    @FindBy(css = "#adminManageTab a[href='#renew-tab']")
    protected WebElement renewTab;

    @FindBy(css = "#adminManageTab a[href='#orders-tab']")
    protected WebElement ordersTab;

    @FindBy(css = "#adminManageTab li.active a")
    protected WebElement activeTabLink;

    @FindBy(css = "#renew-tab > div.loading-mask > img")
    protected List<WebElement> loadingMaskImage;

    @FindBy(css = "#renew-tab > div")
    protected List<WebElement> renevalDivs;

    @FindBy(css = "div.renew-devices div.ember-table-tables-container")
    protected WebElement selectDevicesTable;

    @FindBy(css = "div.ember-table-table-row:nth-of-type(1) input[name='isSelected']")
    protected WebElement firstCheckbox;

    @FindBy(css = "button.btn-sm")
    protected WebElement addToOrderButton;

    @FindBy(css = "div.renew-button-continue > button")
    protected WebElement continueRenewButton;

    @FindBy(css = "#modal[style='display: block;']")
    protected WebElement modalWindow;

    @FindBy(css = "#modal[style='display: block;'] input[name='shippingAddress']")
    protected WebElement shippingAddressInput;

    @FindBy(name = "shippingCity")
    protected WebElement shippingCityInput;

    @FindBy(name = "shippingState")
    protected WebElement shippingStateSelect;

    @FindBy(name = "shippingZip")
    protected WebElement shippingZipInput;

    @FindBy(name = "shippingCountry")
    protected WebElement shippingCountrySelect;

    @FindBy(css = "div.modal-footer button.btn-primary")
    protected WebElement calculateButton;

    @FindBy(css = "input.search")
    protected WebElement searchInput;

    private static final String MODAL_WINDOW_LOCATOR = "#modal[style='display: block;']";

    @FindBy(css = "div.section-footer.clearfix [title='First Page']")
    private WebElement firstPageBtn;

    @FindBy(css = "div.section-footer.clearfix [title='Previous']")
    private WebElement previousBtn;

    @FindBy(css = "div.section-footer.clearfix [title='Next']")
    private WebElement nextBtn;

    @FindBy(css = "div.section-footer.clearfix [title='Last Page']")
    private WebElement lastPageBtn;

    @FindBy(css = "button.btn.btn-primary.btn-sm")
    private WebElement addToRenewalOrderCmdBtn;

    @FindBy(css = "table.table.table-striped tr")
    protected WebElement renewalOrderColumnHeader;

    @FindBy(css = "div.items")
    private WebElement renewalOrderTable;

    @FindBy(css = "div.panel-body.clearfix > a")
    protected WebElement removeAllLink;

    @FindBy(css = "div.panel-body.clearfix > div.pull-right.total > div")
    protected WebElement subTotal;

    @FindBy(css = "div.panel-body.clearfix > div.pull-right.total > strong")
    protected WebElement total;

    @FindBy(css = "div.pull-right.renew-button-continue")
    protected WebElement continueBtn;

    @FindBy(css = "div.text-center.footerNotice")
    protected WebElement noticeText;

    @FindBy(css = "input[name='isSelected']")
    private List<WebElement> checkboxList;

    @FindBy(css = "select[name='renewalStatus']")
    private WebElement renewalStatusDropdown;

    @FindBy(css = "td.remove button")
    private WebElement removeBtn;

    @FindBy(css = "button[data-bb-handler='remove']")
    private WebElement removeDevicesConfirmationYesBtn;

    @FindBy(css = "div.export-dropdown button")
    private WebElement exportBtn;

    @FindBy(css = "div.export-dropdown.open li:nth-child(1) > div > span")
    private WebElement exportCSVLink;

    @FindBy(css = "div.export-dropdown.open li:nth-child(2) > div > span")
    private WebElement exportPDFLink;

    @FindBy(css = "div.export-dropdown.open li:nth-child(3) > div > span")
    private WebElement exportXLSLink;

    public AdminAccountManagementPage(WebDriver driver) {
        super(driver);
    }

    public AdminAMOrdersPage openOrdersTab() {
        if (activeTabLink.getAttribute("href").contains("renew-tab")) {
            waitWhileLoading();
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(ordersTab)).click();
        }
        return PageFactory.initElements(driver, AdminAMOrdersPage.class);
    }

    public void calculateTax(Address address) {

        // Calculate Tax Modal popup
        enterText(driver, shippingAddressInput, address.getStreet());
        shippingCityInput.sendKeys(address.getCity());
        new Select(shippingStateSelect).selectByVisibleText(address.getState());
        shippingZipInput.sendKeys(address.getPostalCode());
        new Select(shippingCountrySelect).selectByVisibleText(address.getCountry());
        clickElementAndWaitForInvisibility(driver, calculateButton, By.id("modal"), 30);
        waitWhileLoading();
    }

    public String getFirstSerial() {
        return getTableFirstRow(selectDevicesTable).get("Serial");
    }

    public AdminAMBillingPage addFirstDeviceToRenewOrder(Address address) {

        firstCheckbox.click();
        addToOrderButton.click();

        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(continueRenewButton)).click();

        // When there is no address needed to calculate tax billing page will be next.
        try {
            new WebDriverWait(driver, 3).until(ExpectedConditions
                    .elementToBeClickable(shippingAddressInput));
            calculateTax(address);

            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(continueRenewButton)).click();
        } catch (org.openqa.selenium.TimeoutException e) {
        }

        return PageFactory.initElements(driver, AdminAMBillingPage.class);
    }

    public void selectFirstDevice() {
        firstCheckbox.click();
    }

    public void clickAddToRenewalOrderBtn() {
        addToOrderButton.click();
    }

    public AdminAMBillingPage clickContinueBtn() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(continueRenewButton)).click();
        return PageFactory.initElements(driver, AdminAMBillingPage.class);
    }

    /**
     * When loading second div.loading-mask added to #renew-tab
     * Waiting while it is gone
     */
    public void waitWhileLoading() {
        new WebDriverWait(driver, 300).until(d -> renevalDivs.size() == 1);
    }

    public void searchDevice(String text) {
        enterText(driver, searchInput, text);
        searchInput.sendKeys(Keys.ENTER);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 120);
    }

    public WebElement getFirstPageBtn() {
        return firstPageBtn;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getLastPageBtn() {
        return lastPageBtn;
    }

    public WebElement getContinueBtn() {
        return continueBtn;
    }

    public WebElement getSubTotal() {
        return subTotal;
    }

    public WebElement getTotal() {
        return total;
    }

    public WebElement getRemoveAllLink() {
        return removeAllLink;
    }

    public WebElement getAddToRenewalOrderCmdBtn() {
        return addToRenewalOrderCmdBtn;
    }

    public WebElement getNoticeText() {
        return noticeText;
    }

    public WebElement getRenewalOrderTable() {
        return renewalOrderTable;
    }

    public List<String> getRenewalOrderGridColumns() {

        List<String> columns = new ArrayList<>();
        List<WebElement> elements = renewalOrderColumnHeader.findElements(By.cssSelector("th"));

        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getExportCSVLink() {
        return exportCSVLink;
    }

    public WebElement getExportPDFLink() {
        return exportPDFLink;
    }

    public WebElement getExportXLSLink() {
        return exportXLSLink;
    }

    public WebElement getExportBtn() {
        return exportBtn;
    }


    public void clickRemoveBtn() {
        new Actions(driver).moveToElement(removeBtn).perform();
        removeBtn.click();
    }

    public void removeAllDevices() {
        removeAllLink.click();
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(removeDevicesConfirmationYesBtn)).click();
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
    }

    public void clickCheckbox(int rowNumber) {
        checkboxList.get(rowNumber - 1).click();
    }

    public void selectRenewalStatus(String renewalStatus) {
        if (renewalStatus != null)
            new Select(renewalStatusDropdown).selectByVisibleText(renewalStatus);
    }

    public HashMap<String, String> getRenewalOrderTableFirstRow() {
        return getTable(renewalOrderTable, "table.table.table-striped th",
                "table.table.table-striped td").get(0);
    }

    public List<HashMap<String, String>> getRenewalOrderTableContent() {
        return getTable(renewalOrderTable, "table.table.table-striped th",
                "table.table.table-striped td");
    }

    @Override
    public HashMap<String, String> getTableFirstRow() {

        HashMap<String, String> gridFirstRecord = super.getTableFirstRow();
        gridFirstRecord.remove("");

        return gridFirstRecord;
    }

    /**
     * Get First Record from API
     *
     * @param renewalData
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<Account.RenewalData> renewalData, DateFormat DATE_FORMAT) {

        HashMap<String, String> apiFirstRecord = new HashMap<>();

        apiFirstRecord.put("Serial", renewalData.get(0).serialNumber);
        apiFirstRecord.put("Description", renewalData.get(0).assetName.trim());
        apiFirstRecord.put("Group", renewalData.get(0).assetGroupName);

        if (renewalData.get(0).assetVin != null) {
            apiFirstRecord.put("VIN", renewalData.get(0).assetVin);
        } else {
            apiFirstRecord.put("VIN", "");
        }

        apiFirstRecord.put("Expiration", formatDate(driver, renewalData.get(0).networkRenewalDate, DATE_FORMAT));
        apiFirstRecord.put("Renewable Until", formatDate(driver, renewalData.get(0).renewalDeadline, DATE_FORMAT));

        if (renewalData.get(0).eventTypeName != null) {
            apiFirstRecord.put("Last Event", renewalData.get(0).eventTypeName);
        } else {
            apiFirstRecord.put("Last Event", "");
        }

        if (renewalData.get(0).maxEventDateFormat != null) {
            apiFirstRecord.put("Date & Time", renewalData.get(0).maxEventDateFormat);
        } else {
            apiFirstRecord.put("Date & Time", "Invalid date");
        }

        return apiFirstRecord;
    }

}
