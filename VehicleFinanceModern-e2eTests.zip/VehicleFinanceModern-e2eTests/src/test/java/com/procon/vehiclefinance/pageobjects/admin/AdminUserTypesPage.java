package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class AdminUserTypesPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminUserTypesPage.class.getName());

    @FindBy(css = "button.pull-right.btn.btn-sm.btn-primary.gridButton")
    private WebElement addUserTypesBtn;

    @FindBy(xpath = "//*[@name='name']")
    private WebElement userTypesName;

    @FindBy(css = "div.col-xs-4 select.ember-view.ember-select.form-control")
    private WebElement startFromDropdown;

    @FindBy(css = "input[name='Edit Vehicle Information']")
    private WebElement editVehicleInformation;

    @FindBy(css = "input[name=Locate]")
    private WebElement locate;

    @FindBy(css = "input[name='User Types']")
    private WebElement userTypes;

    @FindBy(css = "div.modal-footer > button:nth-of-type(1)")
    private WebElement cancelBtn;

    private static final String SAVE_BTN_CSS = "div.modal-footer > button:nth-of-type(2)";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "input[name='Vehicles']")
    private WebElement vehicles;

    @FindBy(css = "input[name='History']")
    private WebElement history;

    @FindBy(css = "input[name='Enable']")
    private WebElement starterEnable;

    @FindBy(css = "input[name='Disable']")
    private WebElement starterDisable;

    @FindBy(css = "input[name='Alerts']")
    private WebElement alerts;

    @FindBy(css = "input[name='Reports']")
    private WebElement reports;

    @FindBy(css = "input[name='GeoZone']")
    private WebElement geoZone;

    @FindBy(css = "input[name='Device Transfers']")
    private WebElement deviceTransfers;

    @FindBy(css = "input[name='Vehicle Notes']")
    private WebElement vehicleNotes;

    @FindBy(css = "input[name='Profile Changes']")
    private WebElement profileChanges;

    @FindBy(css = "input[name='Recovery']")
    private WebElement recovery;

    @FindBy(css = "input[name='Drive Report']")
    private WebElement driveReport;

    @FindBy(css = "input[name='Stop Report']")
    private WebElement stopReport;

    @FindBy(css = "input[name='Auto Report']")
    private WebElement autoReport;

    @FindBy(css = "input[name='GeoFence']")
    private WebElement geoFence;

    @FindBy(css = "input[name='QuickFence']")
    private WebElement quickFence;

    @FindBy(css = "input[name='Warning ON/OFF']")
    private WebElement warningOnOff;

    @FindBy(css = "input[name='Max Speed']")
    private WebElement maxSpeed;

    @FindBy(css = "input[name='Reference Verification']")
    private WebElement referenceVerification;

    @FindBy(css = "input[name='Ignition ON/OFF']")
    private WebElement ignitionOnOff;

    @FindBy(css = "input[name='Accelerations/Dec']")
    private WebElement accelerationsDec;

    @FindBy(css = "input[name='Door UnLock']")
    private WebElement doorUnLock;

    @FindBy(css = "input[name='Tow Alert']")
    private WebElement towAlert;

    @FindBy(css = "input[name='Sales Portal']")
    private WebElement salesPortal;

    @FindBy(css = "input[name='Users']")
    private WebElement users;

    @FindBy(css = "input[name='GeoFences']")
    private WebElement geoFences;

    @FindBy(css = "input[name='Scheduled Commands']")
    private WebElement scheduledCommands;

    @FindBy(css = "input[name='ImpoundLots']")
    private WebElement impoundLots;

    @FindBy(css = "input[name='Account Management']")
    private WebElement accountManagement;

    @FindBy(css = "input[name='Groups']")
    private WebElement groups;

    @FindBy(css = "input[name='Devices']")
    private WebElement devices;

    @FindBy(css = "input[name='Request Installation']")
    private WebElement requestInstallation;

    @FindBy(css = "div.ember-view.ember-table-tables-container.ember-table-content-selectable")
    private WebElement table;

    @FindBy(css = "a.btn[title=Delete]")
    private WebElement deleteBtn;

    public boolean isCheckBoxSelected(String chkBoxName) {
        return driver.findElement(By.cssSelector("input[name='" +chkBoxName+ "']")).isSelected();
    }

    public void clickCancel() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector
                (SAVE_BTN_CSS), 10);
    }

    public void selectStartFrom(String userType) {
        //wait till page is loaded
        waitUntilSpinnerInvisible(driver, 5);

        //click Start From Dropdown
        startFromDropdown.click();

        //Select by Usertype text
        new Select(startFromDropdown).selectByVisibleText(userType);
    }

    private EnumMap<UserPermission, WebElement> permissionsMap = new EnumMap<>(UserPermission.class);

    public AdminUserTypesPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }


    public void addUserType(String userTypesNameParam, ArrayList<UserPermission> checkBoxesToBeSelected) {

        //wait till page is loaded
        waitUntilSpinnerVisibleThenInvisible(driver, 2,5);

        //Enter form data
        userTypesName.sendKeys(userTypesNameParam);

        updateCheckBoxesAndSave(checkBoxesToBeSelected);
    }

    public void editUserType(String userTypesNameParam, ArrayList<UserPermission> checkBoxesToBeSelected) {

        super.editSearchedRecord(userTypesNameParam);

        //wait till page is loaded
        waitUntilSpinnerInvisible(driver, 10);

        updateCheckBoxesAndSave(checkBoxesToBeSelected);
    }

    private void updateCheckBoxesAndSave(ArrayList<UserPermission> checkBoxesToBeSelected) {
        loadCheckBoxesMap();
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 5);

        for (UserPermission p : checkBoxesToBeSelected) {
            permissionsMap.get(p).click();
        }
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector
                (SAVE_BTN_CSS), 10);
    }

    public void clickAddUserTypesBtn() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(addUserTypesBtn)).click();
    }

    public MapPage deleteUserType(String strSearch) {
        super.deleteSearchedRecord(strSearch);
        return PageFactory.initElements(driver, MapPage.class);
    }

    private void loadCheckBoxesMap() {
        //Load map with checkbox text and corresponding checkbox locators
        permissionsMap.put(UserPermission.EDIT_VEHICLE_INFORMATION, editVehicleInformation);
        permissionsMap.put(UserPermission.LOCATE, locate);
        permissionsMap.put(UserPermission.USER_TYPES, userTypes);
        permissionsMap.put(UserPermission.VEHICLES, vehicles);
        permissionsMap.put(UserPermission.HISTORY, history);
        permissionsMap.put(UserPermission.STARTER_ENABLE, starterEnable);
        permissionsMap.put(UserPermission.STARTER_DISABLE, starterDisable);
        permissionsMap.put(UserPermission.ALERTS, alerts);
        permissionsMap.put(UserPermission.REPORTS, reports);
        permissionsMap.put(UserPermission.GEOZONE, geoZone);
        permissionsMap.put(UserPermission.DEVICE_TRANSERS, deviceTransfers);
        permissionsMap.put(UserPermission.VEHICLE_NOTES, vehicleNotes);
        permissionsMap.put(UserPermission.PROFILE_CHANGES, profileChanges);
        permissionsMap.put(UserPermission.RECOVERY, recovery);
        permissionsMap.put(UserPermission.DRIVE_REPORT, driveReport);
        permissionsMap.put(UserPermission.STOP_REPORT, stopReport);
        permissionsMap.put(UserPermission.AUTO_REPORT, autoReport);
        permissionsMap.put(UserPermission.GEOFENCE, geoFence);
        permissionsMap.put(UserPermission.QUICKFENCE, quickFence);
        permissionsMap.put(UserPermission.WARNING_ON_OFF, warningOnOff);
        permissionsMap.put(UserPermission.MAX_SPEED, maxSpeed);
        permissionsMap.put(UserPermission.REFERENCE_VERIFICATION, referenceVerification);
        permissionsMap.put(UserPermission.IGNITION_ON_OFF, ignitionOnOff);
        permissionsMap.put(UserPermission.ACCELERATIONS_DEC, accelerationsDec);
        permissionsMap.put(UserPermission.DOOR_UNLOCK, doorUnLock);
        permissionsMap.put(UserPermission.TOW_ALERT, towAlert);
        permissionsMap.put(UserPermission.SALES_PORTAL, salesPortal);
        permissionsMap.put(UserPermission.USERS, users);
        permissionsMap.put(UserPermission.GEOFENCES, geoFences);
        permissionsMap.put(UserPermission.SCHEDULED_COMMANDS, scheduledCommands);
        permissionsMap.put(UserPermission.IMPOUND_LOTS, impoundLots);
        permissionsMap.put(UserPermission.ACCOUNT_MANAGEMENT, accountManagement);
        permissionsMap.put(UserPermission.GROUPS, groups);
        permissionsMap.put(UserPermission.DEVICES, devices);
        permissionsMap.put(UserPermission.REQUEST_INSTALLATION, requestInstallation);
    }

    public HashMap<String, String> getTableFirstRow()
    {
       return getTableFirstRow(table);
    }

    public boolean isDeleteBtnEnabled() {
        return !deleteBtn.getAttribute("class").contains("disabled");
    }
}
