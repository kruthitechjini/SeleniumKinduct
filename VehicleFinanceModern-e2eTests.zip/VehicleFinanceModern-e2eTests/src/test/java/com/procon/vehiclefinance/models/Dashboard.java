package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.procon.vehiclefinance.pageobjects.admin.User;
import org.bson.BsonDateTime;

import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * This class defines the objects needed to handle the various response
 * objects from Dashboard service calls
 */
public class Dashboard {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DashboardDevices {
        public List<DevicesStatus> data;
        public String msg;
        public boolean success;
        public int total;

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class DevicesStatus {
            public assetVfDeviceStatus _id;
            public int totalCount;

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class assetVfDeviceStatus {
                public String assetVfDeviceStatus;
            }
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DashboardRenewals {
        public List<RenewalsDetails> data;
        public String msg;
        public boolean success;

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class RenewalsDetails {
            public String label;
            public int value;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DashboardUsage {
        public UsageReport data;
        public String msg;
        public boolean success;

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class UsageReport {
            public int locateTotal;
            public int reportTotal;
            public int starterTotal;
            public int totalAlerts;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DashboardRecentAlerts {
        public List<RecentAlerts> data;
        public String msg;
        public boolean success;
        public int totalPowerUpWithGps;
        public int totalLowBattery;
        public int totalVehicleAbandonment;
        public int totalBatteryDisconnect;

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class RecentAlerts {
            public int alertTypeId;
            public String alertTypeName;
            public String serialNumber;
        }
    }
}
