package com.procon.vehiclefinance.models;

public class Dealer {
    private String dealerId;
    private String dealerName;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String confirmPassword;
    private Address address;
    private String phone;
    private String phoneSecondary;
    private String fax;
    private boolean enableRequestInstallation;
    private boolean enableDeviceOrdering;

    public Dealer(String dealerId, String dealerName, String firstName, String lastName,
                  String email, String password, String confirmPassword, Address address, String phone,
                  String phoneSecondary, String fax,
                  boolean enableRequestInstallation, boolean enableDeviceOrdering) {

        this.dealerId = dealerId;
        this.dealerName = dealerName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.address = address;
        this.phone = phone;
        this.phoneSecondary = phoneSecondary;
        this.fax = fax;
        this.enableRequestInstallation = enableRequestInstallation;
        this.enableDeviceOrdering = enableDeviceOrdering;
    }

    public String getDealerId() {
        return this.dealerId;
    }

    public void setDealerId(String dealerId) {
        this.dealerId = dealerId;
    }

    public String getDealerName() {
        return this.dealerName;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public String getConfirmPassword() {
        return this.confirmPassword;
    }

    public Address getAddress() {
        return this.address;
    }

    public String getPhone() {
        return this.phone;
    }

    public String getFax() {
        return this.fax;
    }

    public String getPhoneSecondary() {
        return this.phoneSecondary;
    }

    public boolean getEnableRequestInstallation() { return this.enableRequestInstallation; }

    public boolean getEnableDeviceOrdering() { return this.enableDeviceOrdering; }

    public static class DealerBuilder {
        private String dealerId;
        private String dealerName;
        private String firstName;
        private String lastName;
        private String email;
        private String password;
        private String confirmPassword;
        private Address address;
        private String phone;
        private String phoneSecondary;
        private String fax;
        private boolean enableRequestInstallation;
        private boolean enableDeviceOrdering;

        public DealerBuilder dealerId(String dealerId) {
            this.dealerId = dealerId;
            return this;
        }

        public DealerBuilder dealerName(String dealerName) {
            this.dealerName = dealerName;
            return this;
        }

        public DealerBuilder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public DealerBuilder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public DealerBuilder email(String email) {
            this.email = email;
            return this;
        }

        public DealerBuilder password(String password) {
            this.password = password;
            return this;
        }

        public DealerBuilder confirmPassword(String confirmPassword) {
            this.confirmPassword = confirmPassword;
            return this;
        }

        public DealerBuilder address(Address address) {
            this.address = address;
            return this;
        }

        public DealerBuilder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public DealerBuilder phoneSecondary(String phoneSecondary) {
            this.phoneSecondary = phoneSecondary;
            return this;
        }

        public DealerBuilder fax(String fax) {
            this.fax = fax;
            return this;
        }

        public DealerBuilder enableRequestInstallation(boolean enableRequestInstallation) {
            this.enableRequestInstallation = enableRequestInstallation;
            return this;
        }

        public DealerBuilder enableDeviceOrdering(boolean enableDeviceOrdering) {
            this.enableDeviceOrdering = enableDeviceOrdering;
            return this;
        }

        public Dealer build() {
            return new Dealer(dealerId, dealerName, firstName, lastName, email, password,
                    confirmPassword,address, phone,phoneSecondary,fax, enableRequestInstallation, enableDeviceOrdering);

        }
    }
}