package com.procon.vehiclefinance.pageobjects.alerts;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class AlertsOutstandingAlertsPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AlertsOutstandingAlertsPage.class.getName());

    @FindBy(css = "div.panel-footer  div.paging-status.pull-right")
    protected WebElement pagingStatusOfActiveTab;

    private final String grid_css = "[class='ember-view lazy-list-container ember-table-table-block ember-table-right-table-block']";
    @FindBy(css = grid_css)
    private WebElement grid;

    private final String table_css = "[class='ember-view ember-table-tables-container ember-table-content-selectable']";
    @FindBy(css = table_css)
    public WebElement table;

    public final String header_css = "div.ember-table-header-container span";
    @FindBy(css = header_css)
    public WebElement header;

    public final String cell_css = "div.ember-table-body-container div:nth-of-type(1) > div > div > div > div>div>span";
    @FindBy(css = cell_css)
    public WebElement cell;

    private final String gridRows_css = "[class='ember-view lazy-list-container ember-table-table-block ember-table-right-table-block']>div";
    @FindBy(css = gridRows_css)
    private WebElement gridRows;

    @FindBy(css = "select")
    private WebElement showRecordsPerPageDropdown;

    @FindBy(css = "button.btn.btn-primary.btn-sm.pull-right")
    private WebElement filterBtn;

    @FindBy(css = "div.paging-status")
    private WebElement pagingStatus;

    private final String firstRowDateTime_css = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block > div:nth-of-type(1) > div > div:nth-of-type(2) div";
    @FindBy(css = firstRowDateTime_css)
    private WebElement firstRowDateTime;

    private final String firstRowCheckBox_css = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block > div:nth-of-type(1) > div > div:nth-of-type(1) input";
    @FindBy(css = firstRowCheckBox_css)
    private WebElement firstRowCheckBox;

    private final String firstRowAlertType_css = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block > div:nth-of-type(1) > div > div:nth-of-type(5) span";
    @FindBy(css = firstRowAlertType_css)
    private WebElement firstRowAlertType;

    private final String CHK_BOX_SELECT_ALL_CSS = "[name='alertTypesAllSelected']";
    @FindBy(css = CHK_BOX_SELECT_ALL_CSS)
    private WebElement chkBoxSelectAll;

    @FindBy(css = "div.panel-footer button:nth-of-type(1)")
    private WebElement clearSelectedBtn;

    @FindBy(css = "div.panel-footer button:nth-of-type(2)")
    private WebElement clearAllBtn;

    @FindBy(css = "div.filter-outstanding div.selections input[type=checkbox]")
    private List<WebElement> alertChkBoxes;

    private static final String CONFIRM_DELETE_BTN_CSS = "div.modal-footer > " +
            "button.btn-danger[data-bb-handler=delete]";
    @FindBy(css = CONFIRM_DELETE_BTN_CSS)
    private WebElement confirmDeleteBtn;

    public AlertsOutstandingAlertsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public String getDateTimeOfFirstRow() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        return firstRowDateTime.getText();
    }

    public void selectFirstRow() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        firstRowCheckBox.click();
    }

    public void clickBtnClearSelected() {
        clearSelectedBtn.click();
    }

    public void clickClearAllBtn() {
        clearAllBtn.click();
        clickElementAndWaitForInvisibility(driver, confirmDeleteBtn, By
                .cssSelector(CONFIRM_DELETE_BTN_CSS), 10);
    }

    public void selectAlertType(int AlertTypeId) {
        String format = "[name='%s']";
        String css_str = String.format(format, AlertTypeId);
        updateCheckBox(driver, driver.findElement(By.cssSelector(css_str)), true);
    }

    public void selectAllAlertTypes() {
        updateCheckBox(driver, driver.findElement(By.cssSelector(CHK_BOX_SELECT_ALL_CSS)), true);
    }

    public void unSelectAllAlertTypes() {
        updateCheckBox(driver, driver.findElement(By.cssSelector(CHK_BOX_SELECT_ALL_CSS)), false);
    }

    public void unSelectAlertType(int AlertTypeId) {
        String format = "[name='%s']";
        String css_str = String.format(format, AlertTypeId);
        updateCheckBox(driver, driver.findElement(By.cssSelector(css_str)), false);
    }

    public int getAlertTypeId(String AlertType) {
        String getAlertTypeIdStr;
        String format = "//label[text()[contains(.,'%s')]]/input";
        String xpath_str = String.format(format, AlertType);
        getAlertTypeIdStr = driver.findElement(By.xpath(xpath_str)).getAttribute("name");
        return Integer.parseInt(getAlertTypeIdStr);
    }

    public List<HashMap<String, String>> getAlertListInGrid() {
        List<HashMap<String, String>> tmpList = getTable(table, header_css, cell_css);
        return tmpList.subList(0, tmpList.size() - 2);
    }

    public int getNumberOfRowsInGrid() {
        //get records in the grid
        return getTable(table, header_css, cell_css).size() - 2;
    }

    public void clickFilterBtn() {
        filterBtn.click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
    }

    public List<Integer> getAvailableAlertTypeIds() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .visibilityOfAllElements(alertChkBoxes));
        List<Integer> alertIds = new ArrayList<>();
        for (WebElement element : alertChkBoxes) {
            if (!element.getAttribute("name").equals("alertTypesAllSelected")) {
                alertIds.add(Integer.parseInt(element.getAttribute("name")));
            }
        }
        return alertIds;
    }
}

