package com.procon.vehiclefinance.pageobjects;

import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsPage;
import com.procon.vehiclefinance.pageobjects.dashboard.DashboardPage;
import com.procon.vehiclefinance.pageobjects.gseDealer.DevicesLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsPage;
import com.procon.vehiclefinance.pageobjects.sales.SalesPage;
import com.procon.vehiclefinance.pageobjects.service.ServicePage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.procon.vehiclefinance.util.WebElements.*;

public class NavbarHeaderPage {

    private static final Logger LOGGER = LoggerFactory.getLogger(NavbarHeaderPage.class);

    protected WebDriver driver;

    @FindBy(css = "li.dropdown a.account-btn")
    //@FindBy(linkText = "Admin")
    private WebElement accountDropdown;

    @FindBy(linkText = "Settings")
    private WebElement settingsDropdownMenuItem;

    @FindBy(linkText = "Feedback")
    private WebElement feedbackDropdownMenuItem;

    @FindBy(linkText = "Logout")
    private WebElement logoutDropdownMenuItem;

    @FindBy(linkText = "Admin")
    private WebElement adminBtn;

    @FindBy(linkText = "Alerts")
    private WebElement alertsBtn;

    @FindBy(linkText = "Reports")
    private WebElement reportsBtn;

    @FindBy(linkText = "Vehicles")
    private WebElement vehiclesBtn;

    @FindBy(linkText = "Dashboard")
    private WebElement dashboardBtn;

    @FindBy(linkText = "Service")
    private WebElement serviceAlertsBtn;

    @FindBy(linkText = "Connect")
    private WebElement salesBtn;

    @FindBy(linkText = "Map")
    private WebElement mapBtn;

    @FindBy(linkText = "Devices")
    private WebElement devicesBtn;

    @FindBy(css = "a.navbar-logo > img")
    protected WebElement brandLogo;

    @FindBy(css = "input[name='firstName']")
    protected WebElement firstNameInput;

    @FindBy(css = "input[name='lastName']")
    protected WebElement lastNameInput;

    @FindBy(css = "input[name='phone']")
    protected WebElement phoneNumberInput;

    @FindBy(css = "button[name='modalSave']")
    protected WebElement modalSaveBtn;

    @FindBy(css = "label[for='defaultMapAll'] + select")
    protected WebElement mapAllDevicesOnLogin;

    @FindBy(name = "modalCancel")
    protected WebElement modalCancelBtn;

    public NavbarHeaderPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public LoginPage logout() {
        try {
            //wait till bootbox fades away
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .invisibilityOfElementLocated(By.cssSelector("div.bootbox.modal.fade")));

            //wait till modal is visible
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .invisibilityOfElementLocated(By.cssSelector("div#modal")));

            // wait for spinner to disappear, otherwise it can block the logout
            waitUntilSpinnerInvisible(driver, 120);
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(accountDropdown)).click();

            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(logoutDropdownMenuItem)).click();
        } catch (TimeoutException te) {
            LOGGER.warn("Failed to logout possibly because of " +
                    "other elements blocking the logout link: {0}", te.getLocalizedMessage());
        }
        return PageFactory.initElements(driver, LoginPage.class);
    }

    public AdminLeftBarPage clickAdmin() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(adminBtn)).click();
        return PageFactory.initElements(driver, AdminLeftBarPage.class);
    }

    public AlertsPage clickAlerts() {
        alertsBtn.click();
        return PageFactory.initElements(driver, AlertsPage.class);
    }

    public ServicePage clickService() {
        serviceAlertsBtn.click();
        return PageFactory.initElements(driver, ServicePage.class);
    }

    public ReportsPage clickReports() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(reportsBtn)).click();
        return PageFactory.initElements(driver, ReportsPage.class);
    }

    public VehiclesPage clickVehicles() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(vehiclesBtn)).click();
        return PageFactory.initElements(driver, VehiclesPage.class);
    }

    public DashboardPage clickDashboard() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(dashboardBtn)).click();
        return PageFactory.initElements(driver, DashboardPage.class);
    }

    public SalesPage clickSales() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(salesBtn)).click();
        return PageFactory.initElements(driver, SalesPage.class);
    }

    public MapPage clickMap() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.
                elementToBeClickable(mapBtn)).click();
        return PageFactory.initElements(driver, MapPage.class);
    }

    public DevicesLeftBarPage clickDevices() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.
                elementToBeClickable(devicesBtn)).click();
        return PageFactory.initElements(driver, DevicesLeftBarPage.class);
    }



    public boolean isBtnVisible(String btnText) {
        return isElementPresent(driver, By.linkText(btnText));
    }

    public boolean isLogoutMenuClickable() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 2);
            wait.until(ExpectedConditions.elementToBeClickable(logoutDropdownMenuItem));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getDisplayName() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 10).until(d -> !accountDropdown.getText().isEmpty());
        return accountDropdown.getText();
    }

    public Boolean isAdminPresent() {
        return isElementPresent(driver, By.linkText("Admin"));
    }

    public Boolean isDashboardPresent() {
        return isElementPresent(driver, By.linkText("Dashboard"));
    }

    public Boolean isReportsPresent() {
        return isElementPresent(driver, By.linkText("Reports"));
    }

    public Boolean isMapPresent() {
        return isElementPresent(driver, By.linkText("Map"));
    }

    public Boolean isVehiclesPresent() {
        return isElementPresent(driver, By.linkText("Vehicles"));
    }

    public Boolean isDevicesPresent() {
        return isElementPresent(driver, By.linkText("Devices"));
    }

    public Boolean isAlertsPresent() {
        return isElementPresent(driver, By.linkText("Alerts"));
    }

    public Boolean isSalesPresent() {
        return isElementPresent(driver, By.linkText("Sales"));
    }

    public String getBrandLogoSrc() {
        return brandLogo.getAttribute("src");
    }

    //Navigate to User Settings page by clicking on 'Account' drop down
    public void clickSettingsDropdownMenuItem() {
        getAccountDropdown().click();
        getSettingsDropdownMenuItem().click();
    }

    public WebElement getAccountDropdown() {
        return accountDropdown;
    }

    public WebElement getSettingsDropdownMenuItem() {
        return settingsDropdownMenuItem;
    }

    public WebElement getFirstNameInput() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(firstNameInput));
    }

    public WebElement getLastNameInput() {
        return lastNameInput;
    }

    public WebElement getPhoneNumberInput() {
        return phoneNumberInput;
    }

    public void enterFirstName(String firstName) {
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(firstNameInput));
        firstNameInput.clear();
        firstNameInput.sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        lastNameInput.clear();
        lastNameInput.sendKeys(lastName);
    }

    public void enterPhoneNumber(String phoneNumber) {
        phoneNumberInput.clear();
        phoneNumberInput.sendKeys(phoneNumber);
    }

    public void enterUserInfo(String firstName, String lastName, String phoneNumber) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterPhoneNumber(phoneNumber);
        modalSaveBtn.click();
    }

    private Select getMapAllDevicesOnLogin() {
        return new Select(mapAllDevicesOnLogin);
    }

    public String getMapAllDevicesOnLoginState() {
        return getMapAllDevicesOnLogin().getFirstSelectedOption().getText();
    }

    public void setMapAllDevicesOnLoginState(String state) {
        getMapAllDevicesOnLogin().selectByVisibleText(state);
    }

    public void waitForUserSettingsWindow() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(mapAllDevicesOnLogin));
    }

    public void clickModalCancelBtn() {
        clickElementAndWaitForInvisibility(driver, modalCancelBtn, By.id("modal"));
    }

    public void clickModalSaveBtn() {
        clickElementAndWaitForInvisibility(driver, modalSaveBtn, By.id("modal"));
    }

}
