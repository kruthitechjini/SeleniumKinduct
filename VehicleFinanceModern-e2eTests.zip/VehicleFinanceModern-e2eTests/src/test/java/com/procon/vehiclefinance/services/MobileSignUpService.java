package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.HttpRequest;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.spireon.platform.cdm.v1.dto.InvitationDto;

import java.util.HashMap;

public class MobileSignUpService extends ServiceCaller {

    private static final Logger logger = LoggerFactory.getLogger(MobileSignUpService.class);

    private static String mobileSignUpEndpoint;

    static {
        mobileSignUpEndpoint = System.getProperty("platformSvcUrl") + "/invitations";
    }

    /**
     * Activate account using given pin number and emailId
     *
     * @param pin
     * @param emailId
     * @return
     * @throws UnirestException
     */
    public static InvitationDto activateAccount(String pin, String emailId)
            throws UnirestException {

        HttpResponse<InvitationDto[]> response = Unirest.get
                (mobileSignUpEndpoint)
                .queryString("userSecret", pin)
                .queryString("challenge", emailId)
                .asObject(InvitationDto[].class);

        return response.getBody()[0];
    }

    /**
     * Set username & password using given id, token, username and password
     *
     * @param id
     * @param dealerAppToken
     * @param basicUserName
     * @param basicPassword
     * @return
     * @throws UnirestException
     */
    public static InvitationDto setUsernamePassword(String id, String dealerAppToken, String basicUserName,
            String basicPassword) throws UnirestException {

        HashMap<String, String> headerMap = new HashMap<>();
        headerMap.put("X-Nspire-AppToken", dealerAppToken);
        headerMap.put("Content-Type", "application/json");

        String basicAuthStr = Base64.encodeBase64String((basicUserName + ":" + basicPassword).getBytes());
        headerMap.put("Authorization", "Basic " + basicAuthStr);

        HttpResponse<InvitationDto> response = Unirest.put
                (mobileSignUpEndpoint + "/{id}")
                .headers(headerMap)
                .routeParam("id", id)
                .asObject(InvitationDto.class);

        return response.getBody();
    }
}