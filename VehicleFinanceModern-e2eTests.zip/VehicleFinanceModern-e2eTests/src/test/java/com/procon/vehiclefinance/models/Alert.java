package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

public class Alert {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertData {
        public String alertDate;
        public String serialNumber;
        public String assetName;
        public String alertTypeName;
        public String eventTypeName;
        public String formattedAddress;
        public String globalId;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertFilterResults {
        public String msg;
        public int total;
        public int offset;
        public boolean success;
        public int max;
        public List<AlertData> data;
    }


    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertType {
        public Object accountId;
        public Object accountLabel;
        public Boolean active;
        public String alertVersion;
        public String assetMode;
        public Object brandId;
        public Object brandLabel;
        public String category;
        public Object checkInterval;
        public String code;
        public Object context;
        public Object defaultMethod;
        public Boolean defaultRepeatNotification;
        public Integer defaultRepeatNotificationMinutes;
        public String description;
        public String detailTemplate;
        public Boolean deviceAlert;
        public Boolean doAcknowledge;
        public String emailTemplate;
        public Integer executionOrder;
        public String executionType;
        public Integer id;
        public String inputTemplate;
        public String inputTemplateType;
        public String inputValidationScript;
        public String landmarkMode;
        public String name;
        public String outputTemplate;
        public String outputTemplateType;
        public Integer repeatDelay;
        public String script;
        public String smsTemplate;
        public Integer systemId;
        public String systemLabel;
        public Boolean useAlertFactory;
        public Integer version;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertTypeResults {
        public List<Alert.AlertType> data;
        public String errors;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertResults {
        public String msg;
        public int total;
        public int offset;
        public boolean success;
        public int max;
        public List<AlertSpecData> data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertSpecData {
        public int id;
        public String name;
        public String objectId;
        public String objectType;
        public String objectLabel;
        public List<String> alertTypeNames;
        public boolean active;
        public List<String> alertTypeIds;
        public String config;
        public String recipientsJSON;
        public boolean validAllDays;
        public boolean validAnyTime;
        public boolean validFriday;
        public boolean validMonday;
        public boolean validSaturday;
        public boolean validSunday;
        public boolean validThursday;
        public boolean validTuesday;
        public boolean validWednesday;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AlertResponseData {
        public String msg;
        public int total;
        public boolean success;
        public AlertSpecData data;
    }
}
