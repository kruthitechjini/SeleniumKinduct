package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.CreditCard;
import com.procon.vehiclefinance.models.Person;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static com.procon.vehiclefinance.util.WebElements.enterText;
import static org.testng.Assert.assertTrue;

public class AdminAMBillingPage {

    protected WebDriver driver;

    private static final Logger logger = LoggerFactory.getLogger(AdminAMBillingPage.class);

    @FindBy(name = "cardNumber")
    protected WebElement cardNumberInput;

    @FindBy(name = "expirationMo")
    protected WebElement expirationMonthInput;

    @FindBy(name = "expirationYr")
    protected WebElement expirationYearInput;

    @FindBy(name = "cvv")
    protected WebElement cvvInput;

    @FindBy(name = "cardFirstName")
    protected WebElement cardFirstNameInput;

    @FindBy(name = "cardLastName")
    protected WebElement cardLastNameInput;

    @FindBy(name = "billingAddress")
    protected WebElement billingAddressInput;

    @FindBy(name = "billingAddress2")
    private WebElement billingAddress2Input;

    @FindBy(name = "billingCity")
    protected WebElement billingCityInput;

    @FindBy(name = "billingState")
    protected WebElement billingStateSelect;

    @FindBy(name = "billingZip")
    protected WebElement billingZipInput;

    @FindBy(name = "billingCountry")
    protected WebElement billingCountrySelect;

    @FindBy(name = "billingPhone")
    protected WebElement billingPhoneInput;

    @FindBy(name = "bilingEmail")
    protected WebElement bilingEmailInput;

    @FindBy(css = "div.total button.btn-primary")
    protected WebElement reviewOrderButton;

    @FindBy(css = "div.total button.btn-secondary")
    protected WebElement billingCancelButton;

    public String getCountryDropdownValue() {
        return new Select(billingCountrySelect).getFirstSelectedOption().getText();
    }

    public AdminAMBillingPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    /**
     * Enter Payment Information and click REVIEW ORDER button
     *
     * @param address
     * @param creditCard
     * @param person
     * @return
     */
    public AdminAMReviewOrderPage payWithCreditCard(Address address, CreditCard creditCard, Person person) {

        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(cardNumberInput));
        // Master Card test number: 5555555555554444
        // Visa test number:  4111111111111111
        enterText(driver, cardNumberInput, creditCard.getNumber());
        enterText(driver, expirationMonthInput, creditCard.getMonth());
        //Integer.toString(Calendar.getInstance().get(Calendar.YEAR) + 3)
        enterText(driver, expirationYearInput, creditCard.getYear());
        enterText(driver, cvvInput, creditCard.getCvv());
        enterText(driver, cardFirstNameInput, person.getFirstName());
        enterText(driver, cardLastNameInput, person.getLastName());
        enterText(driver, billingAddressInput, address.getStreet());
        enterText(driver, billingCityInput, address.getCity());
        new Select(billingStateSelect).selectByVisibleText(address.getState());
        enterText(driver, billingZipInput, address.getPostalCode());
        new Select(billingCountrySelect).selectByVisibleText(address.getCountry());
        enterText(driver, billingPhoneInput, person.getPhone());
        enterText(driver, bilingEmailInput, person.getEmail());
        reviewOrderButton.click();

        return PageFactory.initElements(driver, AdminAMReviewOrderPage.class);
    }

    public void validateCreditCardBillingInformationUIElements() {

        assertTrue(cardNumberInput.isDisplayed());
        assertTrue(expirationMonthInput.isDisplayed());
        assertTrue(expirationYearInput.isDisplayed());
        assertTrue(cvvInput.isDisplayed());
        assertTrue(cardFirstNameInput.isDisplayed());
        assertTrue(cardLastNameInput.isDisplayed());
        assertTrue(billingAddressInput.isDisplayed());
        assertTrue(billingAddress2Input.isDisplayed());
        assertTrue(billingStateSelect.isDisplayed());
        assertTrue(billingCityInput.isDisplayed());
        assertTrue(billingZipInput.isDisplayed());
        assertTrue(billingCountrySelect.isDisplayed());
        assertTrue(bilingEmailInput.isDisplayed());
        assertTrue(billingPhoneInput.isDisplayed());
        assertTrue(reviewOrderButton.isDisplayed());
        assertTrue(billingCancelButton.isDisplayed());
    }
}