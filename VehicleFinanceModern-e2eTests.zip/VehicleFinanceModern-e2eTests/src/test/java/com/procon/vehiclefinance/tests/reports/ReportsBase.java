package com.procon.vehiclefinance.tests.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.reports.*;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.procon.vehiclefinance.services.ContactService.deleteContact;
import static com.procon.vehiclefinance.services.DeviceService.mapAllReport;
import static com.procon.vehiclefinance.services.ReportService.getDisplayReport;
import static com.procon.vehiclefinance.services.ReportService.getSavedReports;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static com.procon.vehiclefinance.util.DateTimeUtils.getCurrentBrowserDate;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

public class ReportsBase extends BaseTest {

    private final DecimalFormat Decimal_Format = new DecimalFormat(
            "0.###########");

    protected List<Integer> recipientIdList;

    protected NavbarHeaderPage navbarHeaderPage;
    protected ReportsPage reportsPage;
    protected ReportsLeftBarPage reportsLeftBarPage;
    protected String curDate = null;

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickReport(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
                login();
            } else {
                login();
            }

        } catch (JsonProcessingException e) {
            login();
        }

        //Navigate to reports Page
        clickReportsTab(driver);
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Delete added recipients
        if (!recipientIdList.isEmpty()) {
            for (Integer recipientId : recipientIdList) {
                assertEquals(deleteContact(driver, recipientId).msg, "Data deleted");
            }
        }

        //Logout
        if (navbarHeaderPage != null) {
            // press escape key to dismiss advanced reports page if present
            new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
        serialNumber = System.getProperty("serialNumber");

    }

    /**
     * Navigate to reports page
     *
     * @param driver
     */
    private void clickReportsTab(WebDriver driver) {

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage
                .class);

        // Open the Reports Page and instantiate the ReportsPage object for use
        reportsPage = navbarHeaderPage.clickReports();
        reportsLeftBarPage = PageFactory.initElements(driver,
                ReportsLeftBarPage.class);

        recipientIdList = new ArrayList<>();
    }

    /**
     * To Validate Report content UI with API
     *
     * @param startDate
     * @param endDate
     * @param apiFirstRecord
     * @param recordCount
     * @throws ParseException
     */
    protected void verifyReportUIWithAPI(String startDate, String endDate, String[] expectedColumns,
                                         HashMap<String, String> apiFirstRecord, int recordCount)
            throws ParseException {
/*
temporarily remove date checks in headers and data because of VFM-5289 PDT/PST time issue
        //Validate Header Info: start date
        if (reportsPage.getReportHeaderStartDate() != null) {
            assertEquals(reportsPage.getReportHeaderStartDate(), startDate);
        }

        //Validate Header Info: end date
        if (reportsPage.getReportHeaderEndDate() != null) {
            assertEquals(reportsPage.getReportHeaderEndDate(), endDate);
        }

        //Validate Header labels.
        assertEquals(reportsPage.getReportHeaderColumnLabels(),
                expectedColumns);

        //Validate first row of the Report with api response.
        reportsPage.getTableFirstRow().forEach((k, v) ->
        {
            assertTrue(apiFirstRecord.containsKey(k));
            assertTrue(apiFirstRecord.containsValue(v));
        });

        //Validate records in report should match record count in api response.
        assertEquals(reportsPage.getTotalRecordCount(reportsPage.getPagingPositionDiv()), recordCount);
*/
    }

    /**
     * Get Active Report Data using report Id
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    protected Report.ReportData getActiveReportData(WebDriver driver)
            throws UnirestException {

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("name", "reportOutput");

        String reportId = reportsPage.getActiveReportId();
        return getDisplayReport(driver, reportId, queryParams, Report
                .ReportData.class);
    }

    /**
     * Get Report Data using report SpecId
     *
     * @param driver
     * @param reportSpecId
     * @return
     * @throws UnirestException
     */
    protected Report.ReportData getActiveReportData(WebDriver driver, int reportSpecId)
            throws UnirestException {

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("name", "reportOutput");
        queryParams.put("reportSpecId", reportSpecId);

        return getDisplayReport(driver, Integer.toString(reportSpecId),
                queryParams, Report.ReportData.class);
    }

    /**
     * Run and Validate Report through UI
     *
     * @param driver
     * @param reportType
     * @param groupName
     * @param vehicleName
     * @param dateRange
     * @param startDate
     * @param endDate
     * @param startTime
     * @param endTime
     * @param reportHeading
     * @param timeout
     * @param UI_DATE_FORMAT
     * @throws ParseException
     */
    protected void runAndVerifyReportHeaderInfo(WebDriver driver, ReportTypeEnum reportType, String groupName,
                                                String vehicleName, DateRangeEnum dateRange, String startDate,
                                                String endDate, String startTime, String endTime,
                                                String reportHeading, int timeout, DateFormat UI_DATE_FORMAT)
            throws ParseException {

        reportsLeftBarPage.runReport(reportType, groupName, vehicleName,
                dateRange,
                startDate, endDate, startTime, endTime);

        waitUntilSpinnerInvisible(driver, timeout);

        verifyReportHeaderInfo(driver, reportType, reportHeading,
                UI_DATE_FORMAT);
    }

    /**
     * Run and Validate Report through UI
     *
     * @param driver
     * @param reportType
     * @param groupName
     * @param vehicleName
     * @param dateRange
     * @param mileageThreshold
     * @param costPerMile
     * @param reportHeading
     * @param timeout
     * @param UI_DATE_FORMAT
     * @throws ParseException
     */
    protected void runAndVerifyReportHeaderInfo(WebDriver driver, ReportTypeEnum reportType, String groupName,
                                                String vehicleName, DateRangeEnum dateRange, String mileageThreshold,
                                                String costPerMile, String reportHeading, int timeout,
                                                DateFormat UI_DATE_FORMAT)
            throws ParseException {

        reportsLeftBarPage.runReport(reportType, groupName, vehicleName,
                dateRange, mileageThreshold, costPerMile);

        waitUntilSpinnerInvisible(driver, timeout);

        verifyReportHeaderInfo(driver, reportType, reportHeading,
                UI_DATE_FORMAT);

        //Validate Header Info:Number of devices, Mileage Threshold and Cost
        //Per Mile.
        assertEquals(reportsPage.getReportHeaderNumberOfDevicesLabel(),
                reportsPage.getTotalRecordCount(reportsPage.getPagingPositionDiv()));

        assertEquals(reportsPage.getReportHeaderMileageLabel(),
                mileageThreshold);

        assertEquals(reportsPage.getReportHeaderCostPerMileLabel(),
                Decimal_Format.format(Double.valueOf(costPerMile)));
    }

    /**
     * Validate Header Info:Active tab name, Groups, Report created date
     *
     * @param driver
     * @param reportType
     * @param reportHeading
     * @param UI_DATE_FORMAT
     * @throws ParseException
     */
    protected void verifyReportHeaderInfo(WebDriver driver, ReportTypeEnum reportType, String reportHeading,
                                          DateFormat UI_DATE_FORMAT) throws ParseException {

        //01/04/2018 10:08 AM
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        Long maxDiff = 60000L; // max difference of 60 seconds

        curDate = getCurrentBrowserDate(driver, UI_DATE_FORMAT);
        long curDateMillis = format.parse(curDate).getTime();

        //Validate active Tab name
        assertEquals(reportsPage.getReportTabText(), reportType.getName());

        //Validate Header Info:Groups.
        assertEquals(reportsPage.getReportHeaderGroupLabel(), reportHeading);

        //Validate Report created date and add 1 minute to UI date if there is 1 minute difference
        String uiReportCreatedDate = reportsPage
                .getReportHeaderReportCreatedDate();
        long uiReportCreatedDateMillis = format.parse(uiReportCreatedDate)
                .getTime();
        assertTrue(Math.abs(uiReportCreatedDateMillis - curDateMillis) <=
                maxDiff, String.format("Report Created Date: %s doesn't match" +
                        " current date: %s within 1 minute.", uiReportCreatedDate,
                curDate));
    }

    /**
     * Get First Record from API
     *
     * @param driver
     * @param reportData
     * @param reportDataList
     * @param inputDateFormat
     * @param CELL_DATE_FORMAT
     * @return
     * @throws ParseException
     */
    protected HashMap<String, String> getApiFirstRecord(WebDriver driver, Report.ReportData reportData,
                                                        List<Report.ReportItem> reportDataList,
                                                        DateFormat inputDateFormat, DateFormat CELL_DATE_FORMAT)
            throws ParseException {

        HashMap<String, String> apiFirstRecord = new LinkedHashMap<>();

        //Get selectedColumns from API Response
        List<String> selectedColumns = reportData.selectedColumns;

        //Get columns from API Response
        JsonNode columnDetails = reportData.columns;

        //Map the first record from API Response
        JsonNode firstRowMapper = new ObjectMapper().valueToTree
                (reportDataList.get(0));

        for (String columnName : selectedColumns) {
            JsonNode columnNode = columnDetails.get(columnName);

            //Get the key name from API Response
            String columnHeader = columnNode.get("name").asText();

            //Get the key colName from API Response
            String mappingColumn = columnNode.path("colName").isMissingNode() ?
                    columnName : columnNode.get("colName").asText(columnName);

            //Get the key type from API Response
            String columnDataType = columnNode.get("type").asText();

            if (columnDataType.equals("date") || columnDataType.equals("dateTime")) {
                String dateTime = firstRowMapper.get(mappingColumn).asText();
                if ((dateTime == null) || (dateTime.equals("null")) ||
                        (dateTime.equals(""))) {
                    apiFirstRecord.put(columnHeader, "Unknown");
                } else if (dateTime.contains("Z")) {
                    apiFirstRecord.put(columnHeader, formatDate(driver, dateTime.replaceAll("Z", "+0000"), inputDateFormat, CELL_DATE_FORMAT));
                } else {
                    apiFirstRecord.put(columnHeader, formatDate(driver, dateTime, inputDateFormat, CELL_DATE_FORMAT));
                }
            } else if (columnDataType.equals("number")) {
                apiFirstRecord.put(columnHeader, firstRowMapper.get
                        (mappingColumn) != null ? Decimal_Format.format(
                        firstRowMapper.get(mappingColumn).doubleValue()) : "");
            } else if (mappingColumn.equals("address")) {
                apiFirstRecord.put(columnHeader, (firstRowMapper.get
                        (mappingColumn).asText("")
                        .replace("<br/>", "\n")).trim());
            } else {
                apiFirstRecord.put(columnHeader, firstRowMapper.get
                        (mappingColumn).asText("").trim().replaceAll("\\s+", " "));
            }
        }
        return apiFirstRecord;
    }

    /**
     * Validate Daily Device History Report
     *
     * @param advancedReportsPage
     * @param reportName
     * @param addRecipientList
     * @param changeRecipientList
     * @param UI_DATE_FORMAT
     * @param API_DATE_FORMAT
     * @param CELL_DATE_FORMAT
     * @throws IOException
     * @throws UnirestException
     * @throws ParseException
     */
    protected void validateDailyDeviceHistory(AdvancedReportsPage advancedReportsPage, String reportName,
                                              List<String> addRecipientList, List<String> changeRecipientList,
                                              DateFormat UI_DATE_FORMAT, DateFormat API_DATE_FORMAT,
                                              DateFormat CELL_DATE_FORMAT)
            throws IOException, UnirestException, ParseException {

        //Validate the report executed
        assertEquals(reportsPage.getReportTabText(), ReportTypeEnum.DAILY_DEVICE_HISTORY.getName());

        //Edit report and change the recipient
        reportsLeftBarPage.editSavedReport(reportName);
        assertTrue(advancedReportsPage.getModalWindow().isDisplayed());
        advancedReportsPage.editRecipients(changeRecipientList, addRecipientList, "PDF");
        advancedReportsPage.clickRunButton();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate Recipient of the report is changed
        reportsLeftBarPage.editSavedReport(reportName);
        assertTrue(advancedReportsPage.getModalWindow().isDisplayed());
        advancedReportsPage.clickSaveConfigTabLink();
        assertTrue(changeRecipientList.equals(advancedReportsPage.getAddedRecipientsList()));
        advancedReportsPage.clickCancelButton();

        //Close all report tabs
        reportsPage.closeReportTab();

        //Click Run Report
        reportsLeftBarPage.runSavedReport(reportName);

        //Wait until the grid data loaded
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Wait until the saved reports refreshed
        waitUntilSpinnerVisibleThenInvisible(driver, 10, 5);

        //Validate Header Info:Active tab name, Groups, Report created date.
        verifyReportHeaderInfo(driver, ReportTypeEnum.DAILY_DEVICE_HISTORY, "All Groups",
                UI_DATE_FORMAT);

        //Get the Daily Device History report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Daily Device History report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Header Info: start date, end date
        //TODO open issue: https://jira.spireon.com/browse/VFM-3638
        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData.config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());

        //Get all records id and add to a list
        List<String> deviceIdList = new ArrayList<>();
        alertData.forEach(deviceId -> deviceIdList.add(deviceId.id));

        //Validate response of map service call
        //mapAllReport service call has a request line limit. We must break request into a parts
        int offset = 150;
        for (int i = 0; i < deviceIdList.size(); i = i + offset) {
            assertEquals(mapAllReport(driver,
                    deviceIdList.subList(i, i + offset <= deviceIdList.size() ? i + offset : deviceIdList.size())), 200);
        }

        //Delete Report
        reportsLeftBarPage.deleteSavedReport(reportName);

        //Get saved reports data through service call to validate that the
        // report was deleted
        Report.SavedReportResults savedReportsResponse = getSavedReports(driver);

        List<String> savedReportList = new ArrayList<>();
        savedReportsResponse.data.forEach(savedReport -> savedReportList.add(savedReport.userName));

        assertFalse(savedReportList.contains(reportName));
    }
}
