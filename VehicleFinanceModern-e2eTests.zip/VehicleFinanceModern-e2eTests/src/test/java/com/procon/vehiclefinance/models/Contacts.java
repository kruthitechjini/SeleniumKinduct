package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

public class Contacts {
    /**
     * Contacts in report which is pulled up in the Advanced Reports section
     * as recipients for saved reports. These may be similar to Account so
     * can be combined in future with an 'Account' object
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Contact {
        public int accountId;
        public String accountLabel;
        public String billingAddressId;
        public String billingAddressLabel;
        public String email;
        public String faxNumber;
        public String firstName;
        public String fullName;
        public String globalId;
        public int id;
        public String lastName;
        public String middleName;
        public String mobileNumber;
        public String phoneNumber;
        public String type;
        public String version;
        public String workNumber;
        public String alertSpecCount;
    }

    public static class ContactList {
        public List<Contact> data;
        public String errors;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    public static class ContactResponseData {
        public Contact data;
        public String errors;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }
}
