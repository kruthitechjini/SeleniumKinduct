package com.procon.vehiclefinance.pageobjects.alerts;

import com.procon.vehiclefinance.models.*;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class AlertManagementPage extends CommonGrid {

    private static final Logger logger = LoggerFactory.getLogger(AlertManagementPage.class);

    // @FindBy(xpath = "//span[@class=\"glyphicon glyphicon-plus\"]")  "[name='name']"
    @FindBy(css = ".btn.btn-primary.pull-right")
    private WebElement addAlertsBtn;

    @FindBy(css = "[name='name']")
    private WebElement alertNameInput;

    @FindBy(css = "[class='help-block'][for='name']")
    private WebElement alertNameInputValidationMsg;

    @FindBy(css = "[name='alertTypesAllSelected']")
    private WebElement selectAllAertsChkBox;

    @FindBy(css = "[name='validAllDays']")
    private WebElement allDaysChkBox;

    @FindBy(css = "[name='validWeekDays']")
    private WebElement monToFriChkBox;

    @FindBy(css = "[name='validMonday']")
    private WebElement monChkBox;

    @FindBy(css = "[name='validTuesday']")
    private WebElement tueChkBox;

    @FindBy(css = "[name='validWednesday']")
    private WebElement wedChkBox;

    @FindBy(css = "[name='validThursday']")
    private WebElement thuChkBox;

    @FindBy(css = "[name='validFriday']")
    private WebElement friChkBox;

    @FindBy(css = "[name='validSaturday']")
    private WebElement satChkBox;

    @FindBy(css = "[name='validSunday']")
    private WebElement sunChkBox;

    @FindBy(css = "[name='validAnyTime']")
    private WebElement anyTimeChkBox;

    @FindBy(id = "startTimeSelect")
    private WebElement startTimeDropdownBox;

    @FindBy(id = "[propertyname='validTime'] div:nth-of-type(5) select:nth-of-type(1)")
    private WebElement endTimeDropdownBox;

    private final String SCOPE_DROP_DOWN_CSS = "div.modal-body div.form-group:nth-of-type(2) > select.ember-select";
    @FindBy(css = SCOPE_DROP_DOWN_CSS)
    private WebElement scopeDropdown;

    @FindBy(css = "div.modal-body div.form-group:nth-of-type(3) > select.ember-select")
    private WebElement groupDropdown;

    @FindBy(css = "div.modal-body div.form-group:nth-of-type(3) > select.ember-select")
    private WebElement dealerNameDropdown;

    @FindBy(css = "[for='selectedGroup']")
    private WebElement groupsLabel;

    @FindBy(css = "[for='selectedDealer']")
    private WebElement dealerNameLabel;

    @FindBy(css = "[class='help-block'][for='selectedGroup']")
    private WebElement groupsDropdownValidationMsg;

    @FindBy(css = "div.modal-body div.form-group > div > div > input")
    private WebElement vehicleDropdown;

    @FindBy(css = "[class='help-block'][for='selectedVehicle']")
    private WebElement vehicleDropdownValidationMsg;

    @FindBy(css = "[class='help-block'][for='validDay']")
    private WebElement validDayValidationMsg;

    @FindBy(css = "[class='help-block'][for='validTime']")
    private WebElement validTimeValidationMsg;

    @FindBy(css = "[class='ember-view typeahead'] > div > ul> li")
    private WebElement vehicleList;

    @FindBy(xpath = "//label[text()='Auto Report']")
    private WebElement autoReport;

    @FindBy(xpath = "//label[text()='Battery Disconnect']")
    private WebElement batteryDisconnectReport;

    @FindBy(xpath = "//label[text()='Drive Report']")
    private WebElement driveReport;

    @FindBy(css = "div.form-group.row > div.col-md-3 select")
    private WebElement recipientDropdown;

    @FindBy(css = "div.alert-management-add-button-width .btn.btn-primary")
    private WebElement addRecipientBtn;

    private final String CANCEL_BTN_CSS = "div.modal-footer > button:nth-of-type(1)";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    private final String SAVE_BTN_CSS = "div.modal-footer > button:nth-of-type(2)";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "span.panel-title")
    private WebElement title;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "div.panel-footer [title='First Page']")
    private WebElement firstPageBtn;

    @FindBy(css = "div.panel-footer [title='Previous']")
    private WebElement previousBtn;

    @FindBy(css = "div.panel-footer [title='Next']")
    private WebElement nextBtn;

    @FindBy(css = "div.panel-footer [title='Last Page']")
    private WebElement lastPageBtn;

    @FindBy(css = "div.paging-component select")
    private WebElement selectPageSize;

    @FindBy(css = "div:nth-child(1) > div > div:nth-child(3) > span > div")
    private WebElement firstRowScope;

    @FindBy(css = "div.col-md-2.alert-types-heading > h4")
    private WebElement alertTypesLbl;

    @FindBy(css = "[class='help-block'][for='alertTypeIds']")
    private WebElement alertTypesValidationMsg;

    @FindBy(css = "div.col-md-3.alert-notifications-heading > h4")
    private WebElement alertNotificationsLbl;

    @FindBy(xpath = "//h4[text()='Recipients']")
    private WebElement alertRecipientsLbl;

    @FindBy(css = "[class='help-block'][for='recipientsJSON']")
    private WebElement alertRecipientsValidationMsg;

    @FindBy(css = "div.grid-body.alert-recipient-grid-body span.glyphicon.glyphicon-trash")
    private WebElement recipientsFirstDeleteLink;

    @FindBy(css = "div.typeahead-input-wrapper > ul > li:nth-of-type(2)")
    private WebElement secondVehicleInVehicleList;

    @FindBy(css = "label[for='selectedVehicle']")
    private WebElement vehicleLabel;

    //div.grid-body.alert-recipient-grid-body span.glyphicon.glyphicon-trash

    public AlertManagementPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Get the list of options in scope dropdown
     *
     * @return list of options types
     */
    public List<String> getScopeItems() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 1, 10);
        List<String> scopeTypes = new ArrayList<>();
        List<WebElement> options = new Select(scopeDropdown).getOptions();
        for (WebElement option : options) {
            scopeTypes.add(option.getText());
        }
        return scopeTypes;
    }

    public String getFirstSelectedScopeOption() {
        Select select = new Select(driver.findElement(By.cssSelector(SCOPE_DROP_DOWN_CSS)));
        WebElement option = select.getFirstSelectedOption();
        String defaultItem = option.getText();
        return defaultItem;
    }

    public List<String> getGroupItems() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 1, 10);
        List<String> groups = new ArrayList<>();
        List<WebElement> options = new Select(groupDropdown).getOptions();
        for (WebElement option : options) {
            groups.add(option.getText());
        }
        return groups;
    }

    public List<String> getDevices() {
        waitUntilSpinnerVisibleThenInvisible(getDriver(), 1, 10);
        List<String> devices = new ArrayList<>();
        List<WebElement> options = new Select(vehicleDropdown).getOptions();
        for (WebElement option : options) {
            devices.add(option.getText());
        }
        return devices;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getAddAlertsBtn() {
        return addAlertsBtn;
    }

    public void clickAddAlertsBtn() {
        addAlertsBtn.click();
        waitUntilSpinnerVisible(driver);
    }

    public void clickCancelBtn() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector(CANCEL_BTN_CSS));
    }

    public void addAlertsSpec(AlertsSpec alertsSpec, Recipients recipients) {
        addEdit(alertsSpec);
        selectRecipients(recipients);
        saveAlert();
    }

    public boolean isNameValidationMsgDisplayed() {
        return alertNameInputValidationMsg.isDisplayed();
    }

    public boolean isGroupDropdownValidationMsgDisplayed() {
        return groupsDropdownValidationMsg.isDisplayed();
    }

    public boolean isVehicleValidationMsgDisplayed() {
        return vehicleDropdownValidationMsg.isDisplayed();
    }

    public boolean isVehicleDropdownValidationMsgPresent() {
        return isElementPresent(driver, By.cssSelector("[class='help-block'][for='selectedVehicle']"));
    }

    public boolean isGroupdropdownValidationMsgPresent() {
        return isElementPresent(driver, By.cssSelector("[class='help-block'][for='selectedGroup']"));
    }

    public boolean isAlertTypesValidationMsgDisplayed() {
        return alertTypesValidationMsg.isDisplayed();
    }

    public boolean isRecipientsValidationMsgDisplayed() {
        return alertRecipientsValidationMsg.isDisplayed();
    }

    public boolean isTimeValidationMsgDisplayed() {
        return validTimeValidationMsg.isDisplayed();
    }

    public boolean isDayValidationMsgDisplayed() {
        return validDayValidationMsg.isDisplayed();
    }

    public boolean isAlertTypesLblDisplayed() {
        return alertTypesLbl.isDisplayed();
    }

    public boolean isAlertNotificationsLblDisplayed() {
        return alertNotificationsLbl.isDisplayed();
    }

    public boolean isAlertRecipientsLblDisplayed() {
        return alertRecipientsLbl.isDisplayed();
    }

    public boolean isAlertNameInputDisplayed() {
        return alertNameInput.isDisplayed();
    }

    public boolean isScopeDropdownDisplayed() {
        return scopeDropdown.isDisplayed();
    }

    public boolean isAllDaysChkBoxDisplayed() {
        return allDaysChkBox.isDisplayed();
    }

    public boolean isSelectAllChkboxDisplayed() {
        return selectAllAertsChkBox.isDisplayed();
    }

    public boolean isMonToFriChkboxDisplayed() {
        return monToFriChkBox.isDisplayed();
    }

    public boolean isCheckboxDisplayed(String chkboxName) {
        return driver.findElement(By.cssSelector("input[name='" + chkboxName + "']")).isDisplayed();
    }

    public boolean isAnyTimeChkBoxDisplayed() {
        return anyTimeChkBox.isDisplayed();
    }

    public boolean isStartTimeDropdownDisplayed() {
        return startTimeDropdownBox.isDisplayed();
    }

    public boolean isRecipientDropdownDisplayed() {
        return recipientDropdown.isDisplayed();
    }

    public boolean isRecipientDeleteLinkDisplayed() {
        return recipientsFirstDeleteLink.isDisplayed();
    }

    public void deleteFirstRecipientFromGrid() {
        recipientsFirstDeleteLink.click();
    }

    public boolean isCheckboxDisabled(String chkboxName) {
        return isAttribituePresent(driver.findElement(By.cssSelector("input[name='" + chkboxName + "']")), "disabled");
    }

    public boolean isStartTimeDropdownEnabled() {
        if (startTimeDropdownBox.isEnabled()) {
            return true;
        } else
            return false;
    }

    public boolean isEndTimeDropdownEnabled() {
        if (startTimeDropdownBox.isEnabled()) {
            return true;
        } else
            return false;
    }


    public void updateCheckbox(String chkBoxName, boolean select) {
        WebElement chkBox = driver.findElement(By.cssSelector("input[name='" + chkBoxName + "']"));
        updateCheckBox(driver, chkBox, select);
    }

    private boolean isAttribituePresent(WebElement element, String attribute) {
        Boolean result = false;
        try {
            String value = element.getAttribute(attribute);
            if (value != null) {
                result = true;
            }
        } catch (Exception e) {
        }

        return result;
    }


    public void addEdit(AlertsSpec alertsSpec) {
        waitUntilSpinnerVisibleThenInvisible(driver, 3, 5);
        enterName(alertsSpec.getAlertName());
        selectScope(alertsSpec.getScope());
        selectGroup(alertsSpec.getGroup());
        selectVehicle(alertsSpec.getVehicle());
        selectAllAlertsType(alertsSpec.getSelectAllAlerts());
        unSelectAlerts(alertsSpec.getRemoveAlerts());
        selectAlerts(alertsSpec.getIncludeAlerts());
    }

    public void saveAlert() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(SAVE_BTN_CSS));
    }

    public void clickSaveBtn() {
        saveBtn.click();
    }

    public void enterName(String name) {
        if (name != null) {
            enterText(driver, alertNameInput, name);
        }
    }

    public void selectScope(String scope) {
        if (scope != null) {
            new Select(scopeDropdown).selectByVisibleText(scope);
        }
    }

    public void selectGroup(String groupName) {
        if (groupName != null) {
            new Select(groupDropdown).selectByVisibleText(groupName);
        }
    }

    public void selectDealerName(String dealerName) {
        if (dealerName != null) {
            new Select(dealerNameDropdown).selectByVisibleText(dealerName);
            getDealerNameLabel().click();
        }
    }

    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    public WebElement getDealerNameLabel() {
        return dealerNameLabel;
    }

    public void selectVehicle(String vehicle) {
        if (vehicle != null) {
            vehicleDropdown.sendKeys(vehicle);
            waitUntilAjaxSpinnerVisibleThenInvisible(driver, 1, 15);
            clickOnNthElementInVehicleList(1);
        }
    }

    public void clickOnNthElementInVehicleList(int n) {
        String format = "[class='ember-view typeahead'] > div > ul> li:nth-of-type(%s)";
        String cssStr = String.format(format, n + 1);  //first element starts from 2nd row
        driver.findElement(By.cssSelector(cssStr)).click();
    }

    public List<String> getVehiclesInDropdown() {
        List<String> vehiclesList = new ArrayList<>();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        String format = "div.typeahead-input-wrapper > ul > li:nth-of-type(%s)";
        int rowCount = getCountInVehiclesDropdown();
        for (int i = 2; i <= rowCount; i++) {
            String cssStr = String.format(format, i);
            vehiclesList.add(driver.findElement(By.cssSelector(cssStr)).getText());
        }
        return vehiclesList;
    }

    public int getCountInVehiclesDropdown() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        return (driver.findElements(By.cssSelector("div.typeahead-input-wrapper > ul > li")).size());

    }

    public void selectAlerts(ArrayList<AlertType> alertNames) {
        if (alertNames != null) {
            for (AlertType alertName : alertNames) {
                selectAlert(alertName);
            }
        }
    }

    public void unSelectAlerts(ArrayList<AlertType> alertNames) {
        if (alertNames != null) {
            for (AlertType alertName : alertNames) {
                selectAlert(alertName);
            }
        }
    }

    public boolean alertSelected(AlertType alertType) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        String format = "//label[text()= '%s']/input";
        String xpath = String.format(format, alertType.getAlertType());
        boolean alertSelected = driver.findElement(By.xpath(xpath)).isSelected();
        return alertSelected;
    }

    public void selectAllAlertsType(Boolean selectAllAlerts) {
        if (selectAllAlerts != null) {
            updateCheckBox(driver, selectAllAertsChkBox, selectAllAlerts);
        }
    }

    public void selectAlertsType(Boolean selectAllAlerts) {
        if (selectAllAlerts != null) {
            updateCheckBox(driver, selectAllAertsChkBox, selectAllAlerts);
        }
    }

    public void selectRecipients(Recipients recipients) {
        if (recipients != null) {
            int i = 0;
            for (Recipient recipient : recipients.getRecipients()) {
                selectRecepient(recipient);
                new WebDriverWait(driver, 10).until(
                        elementToBeClickable(addRecipientBtn))
                        .click();
                waitUntilSpinnerInvisible(driver, 5);
                selectDeliveryMethod(recipient.getDeliveryType(), i);
                i++;
            }
        }
    }

    public void selectDeliveryMethod(String s, int i) {
        String format = "//div[@class='grid-body alert-recipient-grid-body']//tr[%s]//select";
        String xpath = String.format(format, i + 1);
        new Select(driver.findElement(By.xpath(xpath))).selectByVisibleText(s);
    }

    public void selectRecepient(Recipient recipient) {
        if (recipient != null) {
            String recipientName = recipient.getName();
            new Select(recipientDropdown).selectByVisibleText(recipientName);
        }
    }

    public void selectAlert(AlertType alertType) {
        String format = "//label[text()= '%s']";
        String xpath = String.format(format, alertType.getAlertType());
        updateCheckBox(driver, driver.findElement(By.xpath(xpath)), true);
    }

    public void unSelectAlert(String alertType) {
        String format = "//label[text()= '%s']";
        String xpath = String.format(format, alertType);
        updateCheckBox(driver, driver.findElement(By.xpath(xpath)), false);
    }

    public boolean isAlertAvailable(String strAlertName) {
        //Assumption: Cancel button is clickable after all alert labels are loaded.
        //This fix should handle Auto Report label that was being ignored
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(cancelBtn));
        return WebElements.isElementPresent(driver, By.xpath("//label[text()='" + strAlertName + "']"));
    }

    public boolean isValidDayAvailable(String validDay) {
        String format = "[name='%s']";
        String css_str = String.format(format, validDay);
        return WebElements.isElementPresent(driver, By.cssSelector(css_str));
    }

    public WebElement getTitle() {
        return title;
    }

    /**
     * Get header column names of grid.
     *
     * @return
     */
    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getFirstRowScope() {
        return firstRowScope;
    }

    /**
     * Get First Record from API
     *
     * @param alertsData
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<Alert.AlertSpecData> alertsData) {

        HashMap<String, String> apiFirstRecord = new HashMap<>();

        apiFirstRecord.put("Name", alertsData.get(0).name);

        if (alertsData.get(0).objectId == null) {
            apiFirstRecord.put("Scope", "Global");
        } else {
            if (alertsData.get(0).objectType.equals("AssetGroup")) {
                apiFirstRecord.put("Scope", "Group (" + alertsData.get(0).objectLabel + ")");
            } else if (alertsData.get(0).objectType.equals("Asset")) {
                apiFirstRecord.put("Scope", "Vehicle (" + alertsData.get(0).objectLabel + ")");
            }
        }

        apiFirstRecord.put("Alert Types", alertsData.get(0).alertTypeNames.toString().replaceAll("\\[|\\]", "")
                .replaceAll(", ", ","));

        apiFirstRecord.put("Actions", "");

        return apiFirstRecord;
    }

    public WebElement getVehicleDropdown() {
        return vehicleDropdown;
    }

    public WebElement getSecondVehicleInVehicleList() {
        return secondVehicleInVehicleList; //first vehicle starts from 2nd row
    }

    public WebElement getVehicleLabel() {
        return vehicleLabel;
    }
}
