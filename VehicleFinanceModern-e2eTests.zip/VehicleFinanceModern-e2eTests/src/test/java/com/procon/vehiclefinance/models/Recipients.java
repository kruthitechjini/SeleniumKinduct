package com.procon.vehiclefinance.models;

import java.util.ArrayList;

public class Recipients {
    public Recipients() {

    }

    private ArrayList<Recipient> recipients = new ArrayList<Recipient>();

    public ArrayList<Recipient> getRecipients() {
        return recipients;
    }

    public void setRecipients(ArrayList<Recipient> recipients) {
        this.recipients = recipients;
    }

    @Override
    public String toString() {
        return "Recipients [recipients = " + recipients + "]";
    }
}
