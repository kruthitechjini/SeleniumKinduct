package com.procon.vehiclefinance.tests;

import com.procon.vehiclefinance.pageobjects.LoginPage;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.RenewalsPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

import static org.testng.Assert.*;

public class LoginTest extends BaseTest {


    @Test(description = "Login with valid credentials and renew later", groups = {"login"})
    public void testValidLoginAndRenewLater() throws InterruptedException {
        driver.get(baseUrl);
        LoginPage loginPage = PageFactory.initElements(driver,
                LoginPage.class);

        // verify page elements
        assertEquals(loginPage.getLogoImgSrc().endsWith(logoSrc), true,
                "Logo source image doesn't match");
        assertEquals(loginPage.getPrivacyPolicyLink().isDisplayed(), true,
                "Privacy policy link not displayed");
        assertEquals(loginPage.getTermsAndConditionsLink().isDisplayed(),
                true, "T&C link not displayed");

        MapPage mapPage = null;

        if (renewalsPage.equals("Y")) {
            RenewalsPage renewalsPage = loginPage.loginWithRenewals(userName, password);
            mapPage = renewalsPage.continueAndRenewLater();
        } else {
            mapPage = loginPage.loginWithNoRenewals(userName, password);
        }

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        assertTrue(mapPage.getSearchInput().isDisplayed());

        // logout
        navbarHeaderPage.logout();
    }

    @Test(description = "Verify Customer support text", groups = {"login", "ExcludeFromFB"})
    public void testCustomerSupportText() {

        driver.get(baseUrl);
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        //Assert customer support text.  Logging in not necessary
        assertEquals(loginPage.getSupportText(), envNode.get("customerSupportContactText").textValue());
    }

    @Test(description = "Login with invalid credentials", groups = {"login",
            "prodsmoke", "pipeline"})
    public void testInvalidLogin() {
        driver.get(baseUrl);
        LoginPage loginPage = PageFactory.initElements(driver,
                LoginPage.class);

        MapPage mapPage = null;

        if (renewalsPage.equals("Y")) {
            RenewalsPage renewalsPage = loginPage.loginWithRenewals(userName, "invalidpwd");
        } else {
            mapPage = loginPage.loginWithNoRenewals(userName, "invalidpwd");
        }
        assertEquals(loginPage.getAlertText(), invalidLoginTest);
    }

    @Test(description = "Login - Verify Session Expiration Date", groups = {"login"})
    public void testVerifySessionExpDate() throws ParseException {

        final List<String> COOKIE_NAMES = Arrays.asList(
                "X-Nspire-UserToken",
                "proconGoldStarAuth"
        );
        final int SESSION_DURATION_HOURS = 4;

        login();

        Set<Cookie> cookies = driver.manage().getCookies();

        Calendar expectedDateTime = Calendar.getInstance();
        int expectedHour = expectedDateTime.get(Calendar.HOUR_OF_DAY) + SESSION_DURATION_HOURS;

        cookies.forEach(c -> {
            if(COOKIE_NAMES.contains(c.getName())) {
                Calendar actualHour = Calendar.getInstance();
                actualHour.setTime(c.getExpiry());
                assertEquals(actualHour.get(Calendar.HOUR_OF_DAY), expectedHour);
            }
        });

    }

    @Test(description = "Login - verify Terms and Privacy statement links", groups = {"login"})
    public void testVerifyTermsPrivacyLinks() {
        String[] windows;

        driver.get(baseUrl);
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        //verify Privacy Policy page
        loginPage.getPrivacyPolicyLink().click();
        windows = driver.getWindowHandles().toArray(new String[2]);
        driver.switchTo().window(windows[1]);
        assertTrue(driver.getCurrentUrl().contains("policy/privacy"));
        assertTrue(driver.getPageSource().toUpperCase().contains("PRIVACY STATEMENT"));
        driver.close();
        driver.switchTo().window(windows[0]);

        //verify Terms and Conditions
        loginPage.getTermsAndConditionsLink().click();
        windows = driver.getWindowHandles().toArray(new String[2]);
        driver.switchTo().window(windows[1]);
        assertTrue(driver.getCurrentUrl().contains("policy/termsOfUse"));
        assertTrue(driver.getPageSource().toUpperCase().contains("TERMS OF USE"));
    }

    @Test(description = "Login - verify marketing content rotation", groups = {"login"})
    public void testVerifyMarketingContentRotation() {
        driver.get(baseUrl);
        LoginPage loginPage = PageFactory.initElements(driver, LoginPage.class);

        String src = loginPage.getLoginAdvSectionSrc();
        driver.navigate().refresh();

        assertNotEquals(src, loginPage.getLoginAdvSectionSrc());
    }
}
