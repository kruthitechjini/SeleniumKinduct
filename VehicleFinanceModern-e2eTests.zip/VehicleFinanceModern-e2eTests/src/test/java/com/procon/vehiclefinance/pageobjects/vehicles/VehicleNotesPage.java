package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Arrays;
import java.util.List;
import java.util.HashMap;

import static com.procon.vehiclefinance.util.WebElements.*;

public class VehicleNotesPage extends CommonGrid {

    @FindBy(css = "a[title='Add'")
    private WebElement addNoteLink;

    @FindBy(css = "div.modal-body textarea")
    private WebElement noteTextarea;

    private static final String SAVE_BTN_CSS = "div.modal-footer > button.btn-primary";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    private static final String CANCEL_BTN_CSS = "div.modal-footer > button.btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;
    
    @FindBy(css = "div.fixed-body.notes")
    private WebElement notesTable;
    
    private static final List<String> GRID_COLUMNS = Arrays.asList("Date", "Comment", "Created By", "Actions");

    public VehicleNotesPage(WebDriver driver) {
        super(driver);
    }

    public void clickAddNoteLink() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(addNoteLink)).click();
    }

    /**
     * Add/edit a note
     *
     * @param note        note
     */
    public void addEditNote(String note) {
    	new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(noteTextarea));
    	enterText(driver, noteTextarea, note);
        submitForm();
    }

    public void submitForm() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(SAVE_BTN_CSS));
    }

    public void cancelForm() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector(CANCEL_BTN_CSS));
    }
    
    public Boolean isNotePresent(String note) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        String format = "//span[text()='%s']";
        String xpath = String.format(format, note);
        return isElementPresent(driver, By.xpath(xpath));   	
    }
    
    public List<String> getExpectedColumns() {
    	return GRID_COLUMNS;
    }

    public HashMap<String, String> getFirstNote(){
    	return getTableFirstRow(notesTable);
    }
    
    public void waitForNewNote(HashMap<String, String> oldNote, Integer timeout) {
        Integer sleepTime = 500;
        Integer timeSpent = 0;

        while (timeSpent < (timeout * 1000)) {
            if (!oldNote.equals(getTableFirstRow(notesTable))) {
                break;
            }
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException ie) {
            }
            timeSpent = timeSpent + sleepTime;
        }
    }
}