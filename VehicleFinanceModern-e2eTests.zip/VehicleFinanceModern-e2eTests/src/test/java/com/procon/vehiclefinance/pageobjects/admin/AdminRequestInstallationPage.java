package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Dealer;
import com.procon.vehiclefinance.models.Vehicle;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.collections.Lists;

import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class AdminRequestInstallationPage extends CommonGrid {

    /*
    This class using with dealer and lender account. Some of the locators were made by not optimal way
    to meet compatibility between those two accounts type
     */

    @FindBy(css = "span.panel-title")
    private WebElement panelTitle;

    @FindBy(name = "lenderName")
    private WebElement lenderName;

    @FindBy(css = "*[name^='dealer']")
    private WebElement dealerDropDown;

    @FindBy(css = "select")
    private List<WebElement> dropDownsBillToYearState;

    @FindBy(css = "input[placeholder='Stock Number']")
    private WebElement stockNumberInput;

    @FindBy(css = "[title='Decode VIN']")
    private WebElement vehicleDecodeVinTxtBox;

    @FindBy(css = "[placeholder='VIN']")
    private WebElement vehicleVinNumberTxtBox;

    @FindBy(css = "div.bootbox.modal.fade.bootbox-alert.in > div > div > div.modal-body>div")
    private WebElement invalidVinPopup;

    @FindBy(css = "div.modal-footer > button[type='button']")
    private WebElement vinModelOkBtn;

    @FindBy(name = "make")
    private WebElement makeInput;

    @FindBy(name = "model")
    private WebElement modelInput;

    @FindBy(name = "operatorFirstName")
    private WebElement operatorFirstNameInput;

    @FindBy(name = "operatorLastName")
    private WebElement operatorLastNameInput;

    @FindBy(css = "input[placeholder='Address']")
    private WebElement operatorAddressInput;

    @FindBy(css = "input[placeholder='City']")
    private WebElement operatorCityInput;

    @FindBy(css = "input[placeholder='Zip']")
    private WebElement operatorZipInput;

    @FindBy(css = "input[name^='operatorPhone']")
    private List<WebElement> operatorPhonesInput;

    @FindBy(name = "notes")
    private WebElement notesInput;

    @FindBy(name = "customerHasSignedDisclosure")
    private WebElement customerHasSignedDisclosureInput;

    @FindBy(css = "div.panel-footer > .btn-primary")
    private WebElement submitBtn;

    @FindBy(css = "div.bootbox-body")
    protected WebElement bootboxBody;

    @FindBy(css = "div.modal-footer button.btn-primary")
    protected WebElement okButton;

    @FindBy(css = "div.has-error > span.help-block")
    private List<WebElement> requiredFields;

    public AdminRequestInstallationPage(WebDriver driver) {
        super(driver);
    }

    public WebElement getRequestInstallHeader() {
        return panelTitle;
    }

    public void fillRequestInstallationFormAndSubmit(Dealer dealer, Vehicle vehicle, String billTo, String stockNumber, String notes) {

        if (dealer.getDealerName() != null && !dealer.getDealerName().isEmpty() && !getDealerDropDown().getTagName().equals("input")) {
            //wait till dealer dropdown is populated with dealer names.
            String xpathStr = "//option[text()[contains(.,'" + dealer.getDealerName().substring(0, 15) + "')]]";
            new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathStr)));

            getDealerDropDown().sendKeys(dealer.getDealerName());
        }

        if (billTo != null && !billTo.isEmpty()) {
            new Select(getBillTo()).selectByValue(billTo);
        }

        getStockNumberInput().sendKeys(stockNumber);
        enterTextAndConfirmEntry(driver, getVinInput(), vehicle.getVin());
        clickDecodeVIN();

        new Select(getYearInput()).selectByValue(vehicle.getYear());

        enterText(driver, getOperatorFirstNameInput(), dealer.getFirstName());
        enterText(driver, getOperatorLastNameInput(), dealer.getLastName());
        enterText(driver, getOperatorAddressInput(), dealer.getAddress().getStreet());
        enterText(driver, getOperatorCityInput(), dealer.getAddress().getCity());


        Select drpState = new Select(getOperatorStateInput());
        drpState.selectByValue(dealer.getAddress().getState());

        enterText(driver, getOperatorZipInput(), dealer.getAddress().getPostalCode());
        enterText(driver, getOperatorPhonePrimaryInput(), dealer.getPhone());
        enterText(driver, getOperatorPhoneSecondaryInput(), dealer.getPhoneSecondary());
        enterText(driver, getNotesInput(), notes);

        //make sure check box is visible
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getCustomerHasSignedDisclosureInput());
        WebElements.updateCheckBox(driver, getCustomerHasSignedDisclosureInput(), true);
        new WebDriverWait(driver, 10).until(elementToBeClickable(getSubmitBtn())).click();
    }

    public boolean waitTillDropdownIsPoulatedWithData(String xpathStr) {
        try {
            new WebDriverWait(driver, 5).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathStr)));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getConfirmationText() {
        waitUntilSpinnerInvisible(driver, 30);

        // Wait for alert box, get alert message
        new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(bootboxBody));

        String alertMessage = bootboxBody.getText();

        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(okButton)).click();
        waitUntilSpinnerInvisible(driver);

        return alertMessage;
    }

    public boolean selectDealerName(String dealerName) {
        //wait till dealer dropdown is populated with dealer names.
        String xpathStr = "//option[text()[contains(.,'" + dealerName + "')]]";

        if (waitTillDropdownIsPoulatedWithData(xpathStr)) {
            Select dropdown = new Select(dealerDropDown);
            dropdown.selectByVisibleText(dealerName);
            return true;
        } else return false;

    }

    public WebElement getLenderName() {
        return lenderName;
    }

    public WebElement getDealerDropDown() {
        return dealerDropDown;
    }

    public WebElement getBillTo() {
        if(getDealerDropDown().getTagName().equals("select")) return dropDownsBillToYearState.get(1);
        if(getDealerDropDown().getTagName().equals("input")) return dropDownsBillToYearState.get(0);

        return null;
    }

    public WebElement getStockNumberInput() {
        return stockNumberInput;
    }

    public WebElement getVinInput() {
        return vehicleVinNumberTxtBox;
    }

    public WebElement getMakeInput() {
        return makeInput;
    }

    public WebElement getModelInput() {
        return modelInput;
    }

    public WebElement getYearInput() {
        if(getDealerDropDown().getTagName().equals("select")) return dropDownsBillToYearState.get(2);
        if(getDealerDropDown().getTagName().equals("input")) return dropDownsBillToYearState.get(2);

        return null;
    }

    public WebElement getOperatorFirstNameInput() {
        return operatorFirstNameInput;
    }

    public WebElement getOperatorLastNameInput() {
        return operatorLastNameInput;
    }

    public WebElement getOperatorAddressInput() {
        return operatorAddressInput;
    }

    public WebElement getOperatorCityInput() {
        return operatorCityInput;
    }

    public WebElement getOperatorStateInput() {
        if(getDealerDropDown().getTagName().equals("select")) return dropDownsBillToYearState.get(3);
        if(getDealerDropDown().getTagName().equals("input")) return dropDownsBillToYearState.get(1);

        return null;
    }

    public WebElement getOperatorZipInput() {
        return operatorZipInput;
    }

    public WebElement getOperatorPhonePrimaryInput() {
        return operatorPhonesInput.get(0);
    }

    public WebElement getOperatorPhoneSecondaryInput() {
        return operatorPhonesInput.get(1);
    }

    public WebElement getNotesInput() {
        return notesInput;
    }

    public WebElement getCustomerHasSignedDisclosureInput() {
        return customerHasSignedDisclosureInput;
    }

    public WebElement getSubmitBtn() {
        return submitBtn;
    }

    public List<String> getRequiredFields() {
        List<String> required = Lists.newArrayList();

        for (WebElement field : requiredFields) {
            String r = field.getText();
            //Trim text to get Fields name only, because in DOM there are in pattern "Please select Bill To" etc
            r = r.replace("Please select ", "");
            r = r.replace("a ", "");
            r = r.replace(" is required", "");
            r = r.replace(" is invalid", "");
            required.add(r);
        }

        return required;
    }

    public String getSectionText() {
        return driver.findElement(By.className("lender-body")).getText();
    }

    public void enterVinNumber(String vinNumber) {
        new WebDriverWait(driver, 2).until(
                visibilityOf(vehicleVinNumberTxtBox));

        vehicleVinNumberTxtBox.clear();
        enterText(driver, vehicleVinNumberTxtBox, vinNumber);
    }

    public void clickDecodeVIN() {
        new WebDriverWait(driver, 2).until(
                elementToBeClickable(vehicleDecodeVinTxtBox)).click();
    }

    public Boolean verifyVehicleMakeTxt(String make) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(makeInput, make));
    }

    public Boolean verifyVehicleModelTxt(String model) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(modelInput, model));
    }

    public Boolean verifyVehicleYearTxt(String year) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(getYearInput(), year));
    }

    public WebElement getinvalidVinPopUp() {
        return new WebDriverWait(driver, 2).until(
                visibilityOf(invalidVinPopup));
    }

    public void clickOk() {
        clickElementAndWaitForInvisibility(driver, vinModelOkBtn);
    }
}
