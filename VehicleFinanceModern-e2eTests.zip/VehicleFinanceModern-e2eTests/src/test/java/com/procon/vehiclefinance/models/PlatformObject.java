package com.procon.vehiclefinance.models;

import com.spireon.platform.cdm.v1.dto.AssetDto;
import com.spireon.platform.cdm.v1.dto.DeviceDto;
import com.spireon.platform.cdm.v1.dto.OperatorDto;

public class PlatformObject {
    public DeviceDto deviceDto;
    public AssetDto assetDto;
    public boolean result;
}