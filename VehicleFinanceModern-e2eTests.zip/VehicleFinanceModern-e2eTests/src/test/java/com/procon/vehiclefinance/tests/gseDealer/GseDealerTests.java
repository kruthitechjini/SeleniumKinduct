package com.procon.vehiclefinance.tests.gseDealer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Dealer;
import com.procon.vehiclefinance.models.Vehicle;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRequestInstallationPage;
import com.procon.vehiclefinance.pageobjects.gseDealer.DevicesFaqPage;
import com.procon.vehiclefinance.pageobjects.gseDealer.DevicesInstallationSupportPage;
import com.procon.vehiclefinance.pageobjects.gseDealer.DevicesLeftBarPage;
import com.procon.vehiclefinance.pageobjects.reports.*;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import static com.procon.vehiclefinance.services.ServiceCaller.getUserSettings;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class GseDealerTests extends BaseTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(GseDealerTests.class);
    private NavbarHeaderPage navbarHeaderPage;
    private DevicesLeftBarPage devicesLeftBar;
    private AdminLeftBarPage adminLeftBar;
    private AdminRequestInstallationPage adminReqInstallPage;
    private ReportsPage reportPage;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class testData {
        public String dealerUserName;
        public String dealerPassword;
        public String lenderUserName;
        public String lenderPassword;
        public String renewalsPage;
        public String dealerName;
        public String vinNumber;
        public String vehicleMake;
        public String vehicleModel;
        public String vehicleYear;
        public String billTo;
        public String stockNumber;
    }

    private testData data = null;
    final static int reportTimeout = 100;
    private Vehicle vehicle;
    private Dealer dealer;
    private Address address;

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickDevicesTab(Method method) throws IOException {

        JsonNode dataNode = envNode.at("/" + getClass().getSimpleName());

        try {
            data = mapper.treeToValue(dataNode, testData.class);
        } catch (JsonProcessingException e) {
            LOGGER.info("Failed to process data values. Using system data");
        }
    }


    @Test(description = "Verify Installation Support and FAQ", groups = {"gse"})
    public void testDevicesSupportFAQ() {

        userName = data.dealerUserName;
        password = data.dealerPassword;
        renewalsPage = data.renewalsPage;

        //Login
        login();

        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);
        devicesLeftBar = navbarHeaderPage.clickDevices();

        List<String> filesList = Arrays.asList(
                "Talon Device Installation Guide",
                "GoldStar GPS Talon Installation Best Practices",
                "Pass Through Cable Installation Guide",
                "Decoy GPS tracking device Installation Guide",
                "Spireon GPS Edge LTE Installation Best Practices",
                "Edge LTE GPS Device Installation Guide",
                "Edge LTE GPS Device Installation Guide - CDMA",
                "GoldStar Edge GPS Device Installation Guide",
                "GoldStar Edge LTE GPS Device Installation Guide");

        List<String> videosTitlesList = Arrays.asList(
                "OBDII Y-Harness Installation - English",
                "OBDII Y-Harness Installation - Spanish",
                "3 WIRE INSTALL-ENGLISH",
                "3 WIRE INSTALL-SPANISH",
                "3 WIRE UNDER HOOD-ENGLISH",
                "3 WIRE UNDER HOOD-SPANISH",
                "2 WIRE INSTALLATION - ENGLISH");

        //Navigate to Installation Page
        DevicesInstallationSupportPage devicesInstallationSupportPage = devicesLeftBar.clickInstallationSupport();

        //Verify Header is "Installation Support"
        assertEquals(devicesInstallationSupportPage.getPanelTitleText(), "Installation Support");

        //Verify links to files are presented
        filesList.forEach(file -> assertTrue(devicesInstallationSupportPage.isFileLinkShown(file),
                "File " + file + " not found"));

        //Verify Page has list of 7 videos
        devicesInstallationSupportPage.getVideosTitles().forEach(t -> assertTrue(videosTitlesList.contains(t.getText())));

        List<String> list = devicesInstallationSupportPage.getInnerVideosTitlesText();
        videosTitlesList.forEach(e -> {
            boolean found = false;
            for (String s : list) {
                if (s.contains(e)) {
                    found = true;
                }
            }
            assertTrue(found, "Video Title " + e + " not found");
        });

        //Navigate to Frequently Asked Questions Page
        DevicesFaqPage devicesFaqPage = devicesLeftBar.clickFaq();

        //Verify Header is "Frequently Asked Questions"
        assertEquals(devicesFaqPage.getPanelTitleText(), "Frequently Asked Questions");

        //Verify FAQ
        assertTrue(devicesFaqPage.getDevicesFaq().isDisplayed());
        assertTrue(!devicesFaqPage.getDevicesFaq().getText().isEmpty());

    }

    @Test(description = "Verify Dealer Installation Request becomes visible in Dealer and Lender Installation Request Reports", groups = {"gse"})
    public void testDealerRequestInstallation() throws IOException, UnirestException {

        //login under Dealer
        userName = data.dealerUserName;
        password = data.dealerPassword;
        renewalsPage = data.renewalsPage;
        login();

        //go to Request installation for Dealer interface
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        devicesLeftBar = navbarHeaderPage.clickDevices();
        adminReqInstallPage = devicesLeftBar.clickRequestInstallation();

        createInstallationRequest("Dealer");

        generateDealerReport();

        //Verify userName in report match with Dealer userName
        String reportUserName = getUserSettings(driver).fName + " " + getUserSettings(driver).lName;
        assertEquals(reportPage.getTableFirstRow().get("User Name"), reportUserName);

        //Comment: Verifying Installation Request Report content details in Reports test

        //Login under Lender account
        logout();
        userName = data.lenderUserName;
        password = data.lenderPassword;
        renewalsPage = data.renewalsPage;
        login();

        generateLenderReport();

        //Verify userName in report match with Dealer userName
        assertEquals(reportPage.getTableFirstRow().get("User Name"), reportUserName);
    }

    @Test(description = "Verify Lender Installation Request becomes visible in Dealer and Lender Installation Request Reports", groups = {"gse"})
    public void testLenderRequestInstallation() throws IOException, UnirestException {

        //login under Lender
        userName = data.lenderUserName;
        password = data.lenderPassword;
        renewalsPage = data.renewalsPage;
        login();

        //go to Request installation in Lender interface
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        adminLeftBar = navbarHeaderPage.clickAdmin();
        adminReqInstallPage = adminLeftBar.clickRequestInstallationLink();

        createInstallationRequest("Lender");

        generateLenderReport();

        //Verify userName in report match with Dealer userName
        String reportUserName = getUserSettings(driver).fName + " " + getUserSettings(driver).lName;
        assertEquals(reportPage.getTableFirstRow().get("User Name"), reportUserName);

        //login under Dealer
        logout();
        userName = data.dealerUserName;
        password = data.dealerPassword;
        renewalsPage = data.renewalsPage;
        login();

        generateDealerReport();

        //Verify userName in report match with Dealer userName
        assertEquals(reportPage.getTableFirstRow().get("User Name"), reportUserName);
    }

    private void generateDealerReport() {
        //Generate Installation Request report under Dealer account
        reportPage = navbarHeaderPage.clickReports();
        ReportsLeftBarPageGSE reportsLeftBarPageGSE = PageFactory.initElements(driver, ReportsLeftBarPageGSE.class);

        reportsLeftBarPageGSE.runReport(ReportTypeEnum.INSTALLATION_REQUEST_HISTORY, null, null, DateRangeEnum.TODAY);
        waitUntilSpinnerInvisible(driver, reportTimeout);
    }

    private void generateLenderReport() {
        //Generate Installation Request report under Lender account and verify Dealer's request is visible
        reportPage = navbarHeaderPage.clickReports();
        ReportsLeftBarPage reportsLeftBarPage = PageFactory.initElements(driver, ReportsLeftBarPage.class);

        reportsLeftBarPage.runReport(ReportTypeEnum.INSTALLATION_REQUEST_HISTORY, null, null, DateRangeEnum.TODAY);
        waitUntilSpinnerInvisible(driver, reportTimeout);
    }

    private void createInstallationRequest(String dealerLender) {

        //verify header
        assertEquals(adminReqInstallPage.getRequestInstallHeader().getText(), "Request Installation");

        populateTestData("Dealer");

        //Create Installation request
        adminReqInstallPage.fillRequestInstallationFormAndSubmit(dealer, vehicle, data.billTo, data.stockNumber, "Automation test");
        waitUntilSpinnerInvisible(driver, 5);
        assertEquals(adminReqInstallPage.getConfirmationText(), "Request Installation submitted successfully.");
        adminReqInstallPage.clickOk();

    }

    private void populateTestData(String dealerLender) {
        //populate address
        address = new Address.AddressBuilder()
                .street("16802 Aston Street")
                .city("Irvine")
                .state("CA")
                .postalCode("92606")
                .country("USA")
                .build();

        //Populate dealer details
        dealer = new Dealer.DealerBuilder()
                .dealerName(data.dealerName)
                .firstName(dealerLender)
                .lastName("Washington")
                .email("email@test.com")
                .password("password")
                .confirmPassword("password")
                .address(address)
                .phone("1111111111")
                .phoneSecondary("3333333333")
                .fax("12222222222")
                .build();

        vehicle = new Vehicle(data.vinNumber, data.vehicleMake, data.vehicleModel, data.vehicleYear);
    }

    @AfterMethod(alwaysRun = true)
    protected void logout() throws IOException {

        //Logout
        if (navbarHeaderPage != null) {

            //Press escape key to dismiss popup if present
            new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
            navbarHeaderPage.logout();
        }

        //reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

}
