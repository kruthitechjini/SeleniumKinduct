package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Account;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class AccountService extends ServiceCaller {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountService.class);

    //Retrieve admin users
    private static String adminUserEndpoint;

    //Retrieve admin user types
    private static String adminUserTypeEndpoint;

    //Download users data
    private static String exportUsersEndpoint;

    //Retrieve renewal devices
    private static String deviceRenewalEndpoint;

    //Download renewal devices data
    private static String exportRenewalDevicesEndpoint;

    //Orders data
    private static String ordersEndpoint;

    static {
        adminUserEndpoint = baseUrl + "rest/json/accountUser";
        adminUserTypeEndpoint = baseUrl + "rest/json/accountRole";
        exportUsersEndpoint = baseUrl + "rest/{fileType}/vehicleFinanceAccountUser";
        ordersEndpoint = baseUrl + "operation/vfDeviceRenewalService/orders.json";
        deviceRenewalEndpoint = baseUrl + "rest/json/vfDeviceRenewal";
        exportRenewalDevicesEndpoint = baseUrl + "operation/vfDeviceRenewalService/show.{fileType}";
    }

    /**
     * Get list of users.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUsers(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Account.AccountFilterResults> response = Unirest.get
                (adminUserEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Account.AccountFilterResults.class);
        return response.getBody();
    }

    /**
     * Get list of users with default parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUsers(WebDriver driver) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("filters", "[]");
        queryParams.put("sorts", "[{\"property\":\"user.firstName\",\"direction\":\"ASC\"}," +
                "{\"property\":\"user.lastName\",\"direction\":\"ASC\"}]");

        return getUsers(driver, queryParams);
    }

    /**
     * Search users using given search key.
     *
     * @param driver
     * @param searchKey
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUsers(WebDriver driver, String searchKey)
            throws UnirestException {

        String firstName;
        String lastName;

        if (searchKey.indexOf(" ") > 0) {
            firstName = searchKey.split(" ")[0];
            lastName = searchKey.split(" ")[1];
        } else {
            firstName = searchKey;
            lastName = searchKey;
        }

        String filterStrFormat = "[{\"property\":\"user.firstName\"," +
                "\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"user.username\",\"comparison\":\"ilike\"," +
                "\"value\":\"%3$s\"},{\"property\":\"user.lastName\"," +
                "\"comparison\":\"ilike\",\"value\":\"%2$s\"}," +
                "{\"property\":\"user.email\",\"comparison\":\"ilike\"," +
                "\"value\":\"%3$s\"},{\"property\":\"user.phone\"," +
                "\"comparison\":\"ilike\",\"value\":\"%3$s\"}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("filterOperator", "or");
        queryParams.put("filters", String.format(filterStrFormat, firstName, lastName, searchKey));
        queryParams.put("sorts", "[{\"property\":\"user.firstName\"," +
                "\"direction\":\"ASC\"},{\"property\":\"user.lastName\"," +
                "\"direction\":\"ASC\"}]");

        return getUsers(driver, queryParams);
    }

    /**
     * Delete user using user id
     *
     * @param driver
     * @param id
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults deleteUser(WebDriver driver, long id)
            throws UnirestException {

        HttpResponse<Account.AccountFilterResults> response = Unirest.delete
                (adminUserEndpoint + "/{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", String.valueOf(id))
                .asObject(Account.AccountFilterResults.class);
        return response.getBody();
    }

    /**
     * Get list of user types.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUserTypes(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Account.AccountFilterResults> response = Unirest.get
                (adminUserTypeEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Account.AccountFilterResults.class);
        return response.getBody();
    }

    /**
     * Search user type using given search key.
     *
     * @param driver
     * @param searchKey
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUserTypes(WebDriver driver, String searchKey)
            throws UnirestException {

        String filterStrFormat = "[{\"property\":\"name\"," +
                "\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"description\",\"comparison\":\"ilike\"," +
                "\"value\":\"%1$s\"}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("filters", String.format(filterStrFormat, searchKey));
        queryParams.put("sorts", "[{\"property\":\"name\"," +
                "\"direction\":\"ASC\"}]");

        return getUserTypes(driver, queryParams);
    }

    /**
     * Get list of users type
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults getUserTypes(WebDriver driver) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("sorts", "[{\"property\":\"name\"," +
                "\"direction\":\"ASC\"}]");

        return getUserTypes(driver, queryParams);
    }

    /**
     * Delete user type using user type id.
     *
     * @param driver
     * @param id
     * @return
     * @throws UnirestException
     */
    public static Account.AccountFilterResults deleteUserType(WebDriver driver, long id)
            throws UnirestException {

        HttpResponse<Account.AccountFilterResults> response = Unirest.delete
                (adminUserTypeEndpoint + "/{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", String.valueOf(id))
                .asObject(Account.AccountFilterResults.class);
        return response.getBody();
    }

    /**
     * Download Users data.
     * Accepted FileTypes = csv/pdf/excel
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static InputStream exportUsers(WebDriver driver, Map<String, Object> queryParams, String fileType)
            throws UnirestException {

        HttpResponse<InputStream> response = Unirest.get
                (exportUsersEndpoint)
                .routeParam("fileType", fileType)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Download all Users
     * Accepted FileTypes = csv/pdf/excel
     */
    public static InputStream exportUsers(WebDriver driver, String fileName, String fileType)
            throws UnirestException {

        String sortStr = "[{\"property\":\"user.firstName\",\"direction\":\"ASC\"}," +
                "{\"property\":\"user.lastName\",\"direction\":\"ASC\"}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("fileName", fileName);
        queryParams.put("sorts", sortStr);
        queryParams.put("max", "25000");
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);

        return exportUsers(driver, queryParams, fileType);
    }

    /**
     * Download Users using given search key
     * Accepted FileTypes = csv/pdf/excel
     */
    // TODO: 8/30/18 API call defect https://jira.spireon.com/browse/VFM-5055
/*
    public static InputStream exportUsers(WebDriver driver, String searchKey, String fileName, String fileType)
            throws UnirestException    {

        String sortStr = "[{\"property\":\"user.firstName\",\"direction\":\"ASC\"}," +
                "{\"property\":\"user.lastName\",\"direction\":\"ASC\"}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("fileName", fileName);
        queryParams.put("sorts", sortStr);
        queryParams.put("max", "25000");
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);

        return exportUsers(driver,queryParams , fileType);
    }
*/

    /**
     * Get list of renewals.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Account.RenewalDevices getRenewals(WebDriver driver, HashMap<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Account.RenewalDevices> response = Unirest.get
                (deviceRenewalEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Account.RenewalDevices.class);
        return response.getBody();
    }

    /**
     * Search renewals using given search key.
     *
     * @param driver
     * @param searchKey
     * @return
     * @throws UnirestException
     */
    public static Account.RenewalDevices getRenewals(WebDriver driver, String searchKey)
            throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("offset", 0);

        if (searchKey != (null)) {
            queryParams.put("phrase", searchKey);
        }

        return getRenewals(driver, queryParams);
    }

    /**
     * Filter renewals with given renewal status
     * Accepted value : Suspended = false and Expiring = true
     *
     * @param driver
     * @param renewalStatus
     * @return
     * @throws UnirestException
     */
    public static Account.RenewalDevices getRenewals(WebDriver driver, boolean renewalStatus)
            throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("offset", 0);

        if (!renewalStatus) {
            queryParams.put("suspended", "true");
            queryParams.put("order", "desc");
        } else {
            queryParams.put("expiring", "true");
            queryParams.put("order", "desc");
        }

        return getRenewals(driver, queryParams);
    }

    /**
     * Download renewal devices data.
     * Accepted FileTypes = csv/pdf/excel
     *
     * @param driver
     * @param queryParams
     * @param fileType
     * @return
     * @throws UnirestException
     */
    public static InputStream exportRenewals(WebDriver driver, Map<String, Object> queryParams, String fileType)
            throws UnirestException {

        HttpResponse<InputStream> response = Unirest.get
                (exportRenewalDevicesEndpoint)
                .routeParam("fileType", fileType)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Download renewal devices data with given default parameters
     *
     * @param driver
     * @param fileType
     * @return
     * @throws UnirestException
     */
    public static InputStream exportRenewals(WebDriver driver, String fileType) throws UnirestException {

        String fields = "[\"serialNumber\",\"assetName\",\"assetGroupName\",\"assetVin\"" +
                ",\"renewalDate\",\"renewalDeadlineFormat\",\"eventTypeName\"," + "\"maxEventDateFormat\"]";
        String labels = "{\"serialNumber\":\"Serial\",\"assetName\":\"Description\"," +
                "\"assetGroupName\":\"Group\",\"assetVin\":\"VIN\",\"renewalDate\":\"Expiration\"," +
                "\"renewalDeadlineFormat\":\"Renewable Until\",\"eventTypeName\":\"Last Event\"," +
                "\"maxEventDateFormat\":\"Date and Time\"}";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("labels", labels);
        queryParams.put("fields", fields);
        queryParams.put("export", true);
        queryParams.put("all", true);

        if (fileType.equals("xls")) {
            fileType = "excel";
        }

        return exportRenewals(driver, queryParams, fileType);
    }

    /**
     * Get list of orders.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Account.OrdersList getOrders(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Account.OrdersList> response = Unirest.get
                (ordersEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Account.OrdersList.class);
        return response.getBody();
    }

    /**
     * Get list of orders with default parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Account.OrdersList getOrders(WebDriver driver) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "100");
        queryParams.put("offset", 0);

        return getOrders(driver, queryParams);
    }
}
