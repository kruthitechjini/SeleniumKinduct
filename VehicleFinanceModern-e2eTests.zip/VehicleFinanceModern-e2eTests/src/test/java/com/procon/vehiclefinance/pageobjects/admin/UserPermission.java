package com.procon.vehiclefinance.pageobjects.admin;

public enum UserPermission {
    VEHICLES("Vehicles"),
    MAP("Map"),
    EDIT_VEHICLE_INFORMATION("Edit Vehicle Information"),
    HISTORY("History"),
    LOCATE("Locate"),
    GEOFENCE("GeoFence"),
    MAX_SPEED("Max Speed"),
    ALERTS("Alerts"),
    REPORTS("Reports"),
    SALES_PORTAL("Sales Portal"),
    SERVICE("Service"),
    USERS("Users"),
    USER_TYPES("User Types"),
    GEOFENCES("GeoFences"),
    ACCOUNT_MANAGEMENT("Account Management"),
    GROUPS("Groups"),
    LOTS("Lots"),
    DEVICES("Devices"),
    DEVICE_TRANSERS("Device Transfers"),
    STARTER_ENABLE("Enable"),
    STARTER_DISABLE("Disable"),
    GEOZONES("Geozones"),
    VEHICLE_NOTES("Vehicle Notes"),
    PROFILE_CHANGES("Profile Changes"),
    RECOVERY("Recovery"),
    DRIVE_REPORT("Drive Report"),
    STOP_REPORT("Stop Report"),
    AUTO_REPORT("Auto Report"),
    QUICKFENCE("QuickFence"),
    WARNING_ON_OFF("Warning ON/OFF"),
    REFERENCE_VERIFICATION("Reference Verification"),
    IGNITION_ON_OFF("Ignition ON/OFF"),
    ACCELERATIONS_DEC("Accelerations/Dec"),
    DOOR_UNLOCK("Door UnLock"),
    TOW_ALERT("Tow Alert"),
    GEOZONE("GeoZone"),
    SCHEDULED_COMMANDS("Scheduled Commands"),
    IMPOUND_LOTS("ImpoundLots"),
    REQUEST_INSTALLATION("Request Installation");


    private String text;

    UserPermission(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
