package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminImpoundLotsPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.DeviceService.getImpoundLots;
import static com.procon.vehiclefinance.util.WebElements
        .waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class AdminImpoundLotsTest extends BaseTest {
    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminImpoundLotsPage adminImpoundLotsPage;

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminImpoundLotsTest.class);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String searchText;
        public String searchImpoundLotName;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Impound Lots Link
        adminImpoundLotsPage = adminLeftBarPage.clickImpoundLotsLink();

    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Validate Impound Lots", groups = {"admin"})
    public void testVerifyImpoundLots() throws UnirestException {

        final List<String> GRID_COLUMNS = Arrays.asList("Name", "City", "State");

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Validate Search Input
        assertTrue(adminImpoundLotsPage.getSearchInput().isDisplayed());

        //Validate Grid Columns.
        assertEquals(adminImpoundLotsPage.getGridColumns(), GRID_COLUMNS,
                "Column list does not match expected list for Impound lots grid");

        int totalRecords = adminImpoundLotsPage.getTotalRecordCount();

        //Search a text
        adminImpoundLotsPage.enterSearchText(data.searchText);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        Device.LandmarkData landmarkData = getImpoundLots(driver, data.searchText);

        //Validate records in Impound Lots grid should match record count in api response.
        assertEquals(adminImpoundLotsPage.getTotalRecordCount(), landmarkData.total);

        //Validate first row of the Impound Lots with api first record.
        assertEquals(adminImpoundLotsPage.getTableRow(1),
                adminImpoundLotsPage.getApiFirstRecord(landmarkData.content));

        //Validate total records in grid and total map pins should be same
        assertEquals(adminImpoundLotsPage.getPageUpperBound(), adminImpoundLotsPage.getNumberOfMapPins());

        //Click on clear button
        adminImpoundLotsPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Verify Grid should show back all the records and the filter that is
        // entered is removed.
        assertEquals(totalRecords, adminImpoundLotsPage.getTotalRecordCount());
        assertEquals(adminImpoundLotsPage.getSearchInput().getAttribute
                ("placeholder"), "Search");

        //Validate Grid Navigation control elements
        adminImpoundLotsPage.verifyNavigationBtns();

        //Search an impound lot
        adminImpoundLotsPage.enterSearchText(data.searchImpoundLotName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Wait until one map pin displayed
        adminImpoundLotsPage.validateNumberOfMapPins(1);

        //Click on first map pin
        adminImpoundLotsPage.clickMapPin(1);

        HashMap<String, String> firstRowData = adminImpoundLotsPage.getTableRow(1);

        //Validate popup should show Name, City and State.
        validateGridDataWithMapPin(firstRowData);

        //Click on clear button
        adminImpoundLotsPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Click on first row
        adminImpoundLotsPage.clickRow(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate location of the impound lot is zoomed
        assertEquals(adminImpoundLotsPage.getNumberOfMapPins(), 1);

        //Validate popup should show Name, City and State.
        validateGridDataWithMapPin(firstRowData);

        //Verify Ability to sort in ascending & descending when click on 'Name', 'City' and 'State' columns
        GRID_COLUMNS.forEach(column -> adminImpoundLotsPage.verifyColumnSorting(column));
    }


    @Test(description = "Validate Impound Lots", groups = {"admin"})
    public void testReportMissingImpoundLots() {

        //Click Did we miss an impound lot? Suggest one here (link)
        adminImpoundLotsPage.clickReportMissingImpoundLotLink();

        //Make sure validation error messages are present
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);
        adminImpoundLotsPage.clickSend();

        // TODO: 11/6/18 Use the Batch Asserter functionality once will available
        assertTrue(adminImpoundLotsPage.getLotNameValidationTextMsg().equals("Lot Name is required"));
        assertTrue(adminImpoundLotsPage.getStreetAddressValidationMsg().equals("Address is required"));
        assertTrue(adminImpoundLotsPage.getCityValidationMsg().equals("City is required"));
        assertTrue(adminImpoundLotsPage.getStateValidationMsg().equals("State is required"));
        assertTrue(adminImpoundLotsPage.getZipValidationMsg().equals("Postal Code is required"));

        //Correctly fill out the form without a phone and website and cancel form
        adminImpoundLotsPage.fillImpoundLotForm("Test Lot", "123 Test Ave.", "Irvine", "California",
                "92617", "", "");
        adminImpoundLotsPage.clickCancel();

        //Make sure modal is no longer visible
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);
        assertTrue(adminImpoundLotsPage.isImpoundLotEntryFormHidden());

        //Open the form again
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);
        adminImpoundLotsPage.clickReportMissingImpoundLotLink();

        //Correctly fill out the form and submit form data
        adminImpoundLotsPage.fillImpoundLotForm("Test Lot", "123 Test Ave.", "Irvine", "California",
                "92617", "", "");
        adminImpoundLotsPage.clickSend();

        //Wait for email popup to send then click "OK"
        adminImpoundLotsPage.clickOk();
        assertTrue(adminImpoundLotsPage.getimpoundDetailsSubmissionDialogText().equals("The impound details have been submitted. Thank you."));
    }

    /**
     * Validate Map Bubble data with grid row data.
     *
     * @param firstRowData
     */
    private void validateGridDataWithMapPin(HashMap<String, String> firstRowData) {
        assertEquals(adminImpoundLotsPage.getMapBubbleHeadline().getText(),
                firstRowData.get("Name"));

        assertEquals(adminImpoundLotsPage.getMapBubbleContent().getText(),
                firstRowData.get("City") + ", " + firstRowData.get("State"));
    }
}
