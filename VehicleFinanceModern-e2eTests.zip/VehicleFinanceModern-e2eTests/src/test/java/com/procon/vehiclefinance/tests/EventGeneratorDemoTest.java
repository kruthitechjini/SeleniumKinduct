package com.procon.vehiclefinance.tests;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.PlatformObject;
import com.procon.vehiclefinance.util.PlatformApiUtils;
import com.spireon.platform.utils.PlatformIdentityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.IOException;

public class EventGeneratorDemoTest {
	protected final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Test(description = "a test to demo device, vehicle, and event generated on the fly", groups =
			{"demo"})
	public void demoTestEventGenerator() throws UnirestException, IOException, InterruptedException {

		String apiUserName = System.getProperty("dealerUser");
		String apiPassword = System.getProperty("dealerPassword");
		String appToken = System.getProperty("dealerAppToken");

		String token = PlatformIdentityUtils.getJwtToken(apiUserName, apiPassword, appToken);

		String tripFile = "src/test/resources/trips/sample_events.csv";
		int eventDelay = 120000;

		//Create new device and vehicle and then add events for the device on the fly
		String vehicleName = Long.toString(System.currentTimeMillis());
		PlatformObject resultObj = PlatformApiUtils.createDeviceAndAsset(vehicleName, token);
		PlatformApiUtils.generateEvents(resultObj.deviceDto.getSerialNumber(), tripFile, eventDelay);

		logger.info("Traffic has been successfully generated for testing.");
		logger.info("newly created device serial # is: " + resultObj.deviceDto.getSerialNumber());
		logger.info("newly created asset name is: " + resultObj.assetDto.getName());
	}
}