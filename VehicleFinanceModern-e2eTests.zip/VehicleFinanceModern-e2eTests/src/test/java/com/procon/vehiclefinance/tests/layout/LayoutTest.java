package com.procon.vehiclefinance.tests.layout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.galenframework.api.GalenPageDump;
import com.procon.vehiclefinance.pageobjects.LoginPage;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;

import static java.util.Arrays.asList;


public class LayoutTest extends GalenBaseTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(GalenBaseTest.class);

	@JsonIgnoreProperties(ignoreUnknown = true)
	static class LoginData {
		public String userName;
		public String password;
		public String renewalsPage;
	}

	@BeforeMethod(alwaysRun = true)
	protected void setupTestMethod(Method method) throws IOException {

		JsonNode dataNode = envNode.at("/" + method.getName());

		LoginData data = null;
		try {
			data = mapper.treeToValue(dataNode, LoginData.class);
			userName = data.userName;
			password = data.password;
			renewalsPage = data.renewalsPage;

			if (userName == null) {
				userName = System.getProperty("userName");
				password = System.getProperty("password");
				renewalsPage = System.getProperty("renewalsPage");
			}

		} catch (JsonProcessingException e) {
			LOGGER.info("There is no cusomized data from test_data.json for this test case.");
		}
	}

	@Test(description = "Login Page UI Validation", groups = {"layout", "galen", "ExcludeFromFB"})
	public void testLoginPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		LoginPage loginPage = PageFactory.initElements(getDriver(),
				LoginPage.class);

		logoutUserIfNeeded(loginPage);

		String specFilePath = "/layout/loginPage.gspec";
//		String dumpPageName = "Login Page";
//		String dumpFolderPath = "login-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "NavBar Page UI Validation", groups = {"layout",
			"galen"})
	public void testNavBarPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		String specFilePath = "/layout/navbarPage.gspec";
//		String dumpPageName = "Nav Bar Page";
//		String dumpFolderPath = "navbar-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Renewals Page UI Validation", groups = {"layout",
			"galen", "ExcludeFromFB"})
	public void testRenewalsPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		String specFilePath = "/layout/renewalsPage.gspec";
//		String dumpPageName = "Renewals Page";
//		String dumpFolderPath = "renewals-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Vehicles (Map View) Page UI Validation", groups = {"layout",
			"galen"})
	public void testVehiclesMapViewPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		String specFilePath = "/layout/vehiclesMapViewPage.gspec";
//		String dumpPageName = "Vehicles (Map View) Page";
//		String dumpFolderPath = "vehicles-map-view-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Vehicles (List View) Page UI Validation", groups = {"layout",
			"galen"})
	public void testVehiclesListViewPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		MapPage mapPage = login();
		new WebDriverWait(getDriver(), 3).until(ExpectedConditions
				.elementToBeClickable(mapPage.getListViewButton())).isDisplayed();
		mapPage.getListViewButton().click();

		String specFilePath = "/layout/vehiclesListViewPage.gspec";
//		String dumpPageName = "Vehicles (List View) Page";
//		String dumpFolderPath = "vehicles-list-view-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Dashboard Page UI Validation", groups = {"layout",
			"galen"})
	public void testDashboardPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();
		NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(getDriver(), NavbarHeaderPage.class);
		navbarHeaderPage.clickDashboard();

		String specFilePath = "/layout/dashboardPage.gspec";
//		String dumpPageName = "Dashboard Page";
//		String dumpFolderPath = "dashboard-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Reports Page UI Validation", groups = {"layout",
			"galen"})
	public void testReportsPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(getDriver(), NavbarHeaderPage.class);
		navbarHeaderPage.clickReports();

		String specFilePath = "/layout/reportsPage.gspec";
//		String dumpPageName = "Reports Page";
//		String dumpFolderPath = "reports-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Alerts Page UI Validation", groups = {"layout",
			"galen"})
	public void testAlertsPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(getDriver(), NavbarHeaderPage.class);
		navbarHeaderPage.clickAlerts();

		String specFilePath = "/layout/alertsPage.gspec";
//		String dumpPageName = "Alerts Page";
//		String dumpFolderPath = "alerts-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Admin Page UI Validation", groups = {"layout",
			"galen"})
	public void testAdminPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(getDriver(), NavbarHeaderPage.class);
		navbarHeaderPage.clickAdmin();

		String specFilePath = "/layout/adminPage.gspec";
//		String dumpPageName = "Admin Page";
//		String dumpFolderPath = "admin-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	@Test(description = "Sales Page UI Validation", groups = {"layout",
			"galen"})
	public void testSalesPageDesktop() throws IOException {
//		load(baseUrl, 1920, 1080);
		load(baseUrl, 1280, 1024);

		login();

		NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(getDriver(), NavbarHeaderPage.class);
		navbarHeaderPage.clickSales();

		String specFilePath = "/layout/salesPage.gspec";
//		String dumpPageName = "Sales Page";
//		String dumpFolderPath = "sales-page-dump";
//		createPageDump(getDriver(), dumpPageName, specFilePath, dumpFolderPath);

		checkLayout(specFilePath, asList("desktop"));
	}

	// the purpose of this method is to create a page dump where needed during test case implementation
	// the page dump can be found within the "galen-page-dump" folder at the project root level.
	private void createPageDump(WebDriver driver, String dumpPageName, String specFilePath, String dumpFolderPath) throws IOException {
		GalenPageDump vehiclesPageDump = new GalenPageDump(dumpPageName);
		vehiclesPageDump.dumpPage(driver, specFilePath, "galen-page-dumps/" + dumpFolderPath);
	}
}
