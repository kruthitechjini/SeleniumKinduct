package com.procon.vehiclefinance.tests.admin;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Contacts;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRecipientsPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.services.ContactService.getContactList;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminRecipientsTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AdminRecipientsTest.class.getName());

    @Test(description = "Add/Edit/Cancel/Delete a Recipient", groups =
            {"admin"})
    public void testAddEditDeleteRecipients() {
        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        // Go to admin recipients page
        AdminRecipientsPage adminRecipientsPage = navbarHeaderPage
                .clickAdmin().clickRecipientsLink();
        adminRecipientsPage.clickAddRecipientBtn();

        String fName = "Automated";
        String lName = "Test";
        String email = String.format("tst+%d@spireon.com", System
                .currentTimeMillis());
        String phone = "1231231234";

        adminRecipientsPage.addEditRecipient(fName, lName, email, phone);

        // test cancel form functionality
        waitUntilSpinnerInvisible(driver, 20);
        adminRecipientsPage.editSearchedRecord(email);
        adminRecipientsPage.enterEmail("abc@spireon.com");
        adminRecipientsPage.cancelForm();

        // update recipient, this also confirms that it was added previously,
        // and that cancel step worked as expected
        adminRecipientsPage.editSearchedRecord(email);
        // new email address
        email = String.format("tst+%d@spireon.com", System.currentTimeMillis());
        adminRecipientsPage.addEditRecipient(null, null, email, null);

        // delete geofence
        adminRecipientsPage.deleteSearchedRecord(email);

        // logout
        navbarHeaderPage.logout();

    }

    @Test(description = "Admin Recipients - Verify Page elements, pagination, sort and search", groups = {"admin"})
    public void testAdminRecipientsPageElements() throws UnirestException {

        List<String> columns = Arrays.asList(
                "Name",
                "Email",
                "Mobile Number",
                "Number of Alerts",
                "Actions");
        List<String> columnsSort = Arrays.asList(
                "Name",
                "Email",
                "Mobile Number");
        List<String> columnsSearch = Arrays.asList(
                "Name",
                "Email",
                "Mobile Number");
        String searchKey;

        // Login
        login();

        //Go to admin recipients page
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        AdminRecipientsPage adminRecipientsPage = navbarHeaderPage.clickAdmin().clickRecipientsLink();

        //Verify title
        assertEquals(adminRecipientsPage.getPageTitle(), "Manage Recipients");

        //Verify total number of records
        assertEquals(adminRecipientsPage.getTotalRecordCount(), getContactList(driver).total);

        //Verify all columns exist
        List<String> gridColumns = adminRecipientsPage.getGridColumns();
        assertEquals(gridColumns, columns);

        //Verify grid fields
        HashMap<String, String> fields = adminRecipientsPage.getTableFirstRow();
        Contacts.Contact apiRespond = getContactList(driver).data.get(0);

        assertEquals(fields.get("Name"), apiRespond.fullName);
        assertEquals(fields.get("Name"), apiRespond.firstName + " " + apiRespond.lastName);
        assertEquals(fields.get("Email"), apiRespond.email);
        assertEquals(fields.get("Mobile Number"), apiRespond.mobileNumber);
        assertEquals(fields.get("Number of Alerts"), apiRespond.alertSpecCount);
        assertTrue(adminRecipientsPage.getEditAction().isDisplayed());
        assertTrue(adminRecipientsPage.getDeleteAction().isDisplayed());

        //Verify search is case insensitive
        searchKey = adminRecipientsPage.getTableFirstRow().get("Name");
        int count = adminRecipientsPage.search(searchKey);
        List<HashMap<String, String>> table = adminRecipientsPage.getFixedTable();

        assertEquals(adminRecipientsPage.search(searchKey.toLowerCase()), count);
        assertEquals(adminRecipientsPage.getFixedTable(), table);

        assertEquals(adminRecipientsPage.search(searchKey.toUpperCase()), count);
        assertEquals(adminRecipientsPage.getFixedTable(), table);

        //Verify 'X' icon
        assertTrue(adminRecipientsPage.getSearchInputCancel().isDisplayed());
        adminRecipientsPage.getSearchInputCancel().click();
        assertFalse(adminRecipientsPage.getSearchInputCancel().isDisplayed());

        //Verify when no text is entered in the search box , the background says 'Search'
        assertEquals(adminRecipientsPage.getSearchInput().getAttribute("placeholder"), "Search");

        //Verify "The user grid should update with the search input, does not require clicking a search icon or hitting enter"
        count = adminRecipientsPage.search(apiRespond.lastName);
        adminRecipientsPage.getSearchInput().clear();
        new Actions(driver).sendKeys(adminRecipientsPage.getSearchInput(), apiRespond.lastName).perform();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertEquals(adminRecipientsPage.getTotalRecordCount(), count);

        //Verify search by columns
        HashMap<String, String> firstRow = adminRecipientsPage.getTableFirstRow();
        columnsSearch.forEach(c -> assertTrue(adminRecipientsPage.search(firstRow.get(c)) > 0,
                "Search by column " + c + " doesn't work"));
        adminRecipientsPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver,2 , 10);

        //Verify pagination
        adminRecipientsPage.verifyPagination();

        //Verify sortable columns
        columnsSort.forEach(c -> {
            assertTrue(adminRecipientsPage.isColumnSortable(c),
                    "Column " + c + " is not sortable");
            adminRecipientsPage.verifyColumnSorting(c);
        });

        //logout
        navbarHeaderPage.logout();
    }
}
