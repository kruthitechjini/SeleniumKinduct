package com.procon.vehiclefinance.pageobjects.alerts;

import com.procon.vehiclefinance.pageobjects.alerts.AlertsNotificationHistoryPage;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;

public class AlertsPage {
    protected WebDriver driver;

    protected static final Logger logger = Logger
            .getLogger(AlertsPage.class.getName());

    @FindBy(xpath = "div.search-bar")
    private WebElement searchInput;

    // define elements in left bar for alerts
    @FindBy(xpath = "//label[text()='Auto Report']")
    private WebElement usersLink;

    @FindBy(linkText = "Alert Management")
    private WebElement alertManagementLink;

    @FindBy(linkText = "Notification History")
    private WebElement notificationHistoryLink;

    @FindBy(partialLinkText = "Outstanding Alerts ")
    private WebElement outstandingAlertsLink;


    public AlertsPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getSearchInput() {
        return searchInput;
    }

    public com.procon.vehiclefinance.pageobjects.alerts.AlertManagementPage clickAlertManagement() {
        alertManagementLink.click();
        return PageFactory.initElements(driver, com.procon.vehiclefinance.pageobjects.alerts.AlertManagementPage.class);
    }

    public AlertsNotificationHistoryPage AlertsNotificationHistoryLink() {
        notificationHistoryLink.click();
        return PageFactory.initElements(driver, AlertsNotificationHistoryPage.class);
    }

    public AlertsOutstandingAlertsPage alertsOutstandingAlertsLink() {
        outstandingAlertsLink.click();
        waitUntilSpinnerVisibleThenInvisible(driver,2,20);
        return PageFactory.initElements(driver, AlertsOutstandingAlertsPage.class);
    }

    public boolean isAlertFeaturePresent(String strAlertFeature) {
        return WebElements.isElementPresent(driver, By.partialLinkText(strAlertFeature));
    }
}

