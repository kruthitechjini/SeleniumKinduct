package com.procon.vehiclefinance.pageobjects.reports;

public enum DateRangeEnum {

    TODAY("Today"),
    YESTERDAY("Yesterday"),
    LAST_3_DAYS("Last 3 Days"),
    LAST_7_DAYS("Last 7 Days"),
    LAST_14_DAYS("Last 14 Days"),
    LAST_30_DAYS("Last 30 Days"),
    LAST_90_DAYS("Last 90 Days"),
    LAST_180_DAYS("Last 180 Days"),
    LAST_365_DAYS("Last 365 Days"),
    MORE_THAN_1_DAY("More than 1 day"),
    MORE_THAN_3_DAYS("More than 3 days"),
    MORE_THAN_7_DAYS("More than 7 days"),
    MORE_THAN_14_DAYS("More than 14 days"),
    MORE_THAN_30_DAYS("More than 30 days"),
    MORE_THAN_90_DAYS("More than 90 days"),
    CUSTOM("Custom"),

    //Mileage Report
    SEVEN_DAYS("7 days"),
    FOURTEEN_DAYS("14 days"),
    THIRTY_DAYS("30 days"),
    NINETY_DAYS("90 days");

    private String name;

    DateRangeEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
