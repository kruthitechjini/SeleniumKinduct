package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class VehicleRecoveryPage extends CommonGrid {

    //Create map of features and their locators
    private HashMap<String, String> featureLocatorMap = new HashMap<>();

    //Create map of elements and their locators
    private HashMap<String, String> elementLocatorMap = new HashMap<>();

    protected static final Logger logger = Logger
            .getLogger(VehicleRecoveryPage.class.getName());
    
    static final String mapZoomIn_css = "[title='Zoom in']";
    @FindBy(css = mapZoomIn_css)
    private WebElement mapZoomIn;

    static final String mapZoomOut_css = "[title='Zoom out']";
    @FindBy(css = mapZoomOut_css)
    private WebElement mapZoomOut;
    
    static final String locateContainer_css = "div[title^='Locate - ']";
    @FindBy(css = locateContainer_css)
    private WebElement locateContainer;
    
    static final String locateContainerSpinner_css = locateContainer_css + " div.spinner";
    @FindBy(css = locateContainer_css)
    private WebElement locateContainerSpinner;
    
    static final String locateBtn_xpath = "//button[text()='Locate']";
    @FindBy(xpath = locateBtn_xpath)
    private WebElement locateBtn;

    static final String starterStateLink_xpath = "//span[text()='STARTER']/following-sibling::a[1]";
    @FindBy(xpath = starterStateLink_xpath)
    private WebElement starterStateLink;
    
    static final String detailsTab_css = "a[href='#details-tab']";
    @FindBy(css = detailsTab_css)
    private WebElement detailsTab;
    
    static final String locationsTab_css = "a[href='#mostVisitedAddress-tab']";
    @FindBy(css = locationsTab_css)
    private WebElement locationsTab;
    
    static final String customerData_xpath = "//h4[text()='Customer']";
    @FindBy(xpath = customerData_xpath)
    private WebElement customerDataHeader;
    
    static final String panelTitle_css = "span.panel-title";
    @FindBy(css = panelTitle_css)
    private WebElement panelTitle;
    
    @FindBy(css = "div.col-xs-4 h4")
    private List<WebElement> detailsHeaders;
    
    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    @FindBy(css = "a[title='Filter']")
    private WebElement filterLink;

    @FindBy(css = "div.popover.top.trends-filter select")
    private WebElement dateRangeDropDown;

    @FindBy(css = "div.clearfix.text-right > button:nth-child(2)")
    private WebElement applyBtn;

    @FindBy(css = "div#mostVisitedAddress-tab div.pull-right > div > span")
    private WebElement headerLabel;

    @FindBy(css = "div.ember-table-table-row:nth-of-type(1) button.gridButton")
    private WebElement detailsButton;

    @FindBy(css = "div.trends-chart.half")
    private WebElement trendChart;

    public VehicleRecoveryPage(WebDriver driver) {
        super(driver);

        featureLocatorMap.put("Details", detailsTab_css);
        featureLocatorMap.put("Locations", locationsTab_css);
        featureLocatorMap.put("Locate Button", locateBtn_xpath);
        featureLocatorMap.put("Locate Container", locateContainer_css);
        featureLocatorMap.put("Starter State", starterStateLink_xpath);
  
        elementLocatorMap.put("Zoom In", mapZoomIn_css);
        elementLocatorMap.put("Zoom Out", mapZoomOut_css);

    }

    public boolean isElementAvailable(String elementName) {
        return isElementPresent(driver, By.cssSelector(elementLocatorMap.get(elementName)));
    }
    
    public boolean isVehicleFeaturePresent(String vehicleFeature) {
    	if (featureLocatorMap.get(vehicleFeature).startsWith("//")) {
            return isElementPresent(driver, By.xpath(featureLocatorMap.get(vehicleFeature)));
        } else {
            return isElementPresent(driver, By.cssSelector(featureLocatorMap.get(vehicleFeature)));
        }
    }

    public WebDriver getDriver() {
        return driver;
    }
    
    public void waitUntilPageDisplayed() {
    	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(panelTitle));
    }
    
    public void waitUntilLocateButtonDisplayed() {
    	new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(locateBtn));
    }
    
    public String getPanelTitle() {    	
    	return panelTitle.getText();
    }
    
    public List<String> getDetailsHeaders() {
    	List<String> headers = new ArrayList<String>();
    	for (WebElement header : detailsHeaders) {
    		headers.add(header.getText());
    	}
    	return headers;
    }

    public void clickLocationsTab() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(locationsTab)).click();
    }

    public void clickFilterLink() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(filterLink)).click();
    }

    public void selectDateRange(String dateRange) {
        if(dateRange != null) {
            new Select(dateRangeDropDown).selectByVisibleText(dateRange);
        }
    }

    public void clickApplyBtn() {
        applyBtn.click();
    }

    /**
     * Apply filter for given date range
     *
     * @param dateRange
     */
    public void applyFilter(String dateRange) {
        clickFilterLink();
        selectDateRange(dateRange);
        clickApplyBtn();
    }

    /**
     * Calculate date range for given days
     *
     * @param days
     * @param dateFormat
     * @return
     */
    public String getDateRange(int days, DateFormat dateFormat) {

        Calendar calendar = Calendar.getInstance();

        //Get current date
        String endDate = dateFormat.format(calendar.getTime());

        calendar.add(Calendar.DATE, -days);
        String startDate = dateFormat.format(calendar.getTime());

        return startDate + "-" + endDate;
    }

    public String getDateRangeUI() {
        return headerLabel.getText().split("\\|")[0].trim().split(":")[1].trim();
    }

    public void clickDetailsButton() {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(detailsButton)).click();
    }

    public WebElement getTrendChart() {
        return new WebDriverWait(driver, 5)
                .until(ExpectedConditions.visibilityOf((trendChart)));
    }
}