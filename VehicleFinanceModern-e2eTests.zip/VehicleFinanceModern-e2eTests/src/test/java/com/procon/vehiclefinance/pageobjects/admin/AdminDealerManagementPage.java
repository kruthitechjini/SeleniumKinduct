package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Dealer;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.spireon.automotive.cdm.v1.dto.LenderDealerPartnershipDto;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

import static org.testng.Assert.assertEquals;

public class AdminDealerManagementPage extends CommonGrid {

    private static final String MODAL_SAVE_NAME = "modalSave";

    @FindBy(css = "span.panel-title:not(.pull-right)")
    private WebElement panelTitle;

    @FindBy(id = "addOrEditDealer")
    private WebElement addDealerButton;

    @FindBy(name = "dealerId")
    private WebElement dealerId;

    @FindBy(name = "name")
    private WebElement dealerName;

    @FindBy(name = "firstName")
    private WebElement firstName;

    @FindBy(name = "lastName")
    private WebElement lastName;

    @FindBy(name = "email")
    private WebElement email;

    @FindBy(name = "newPassword")
    private WebElement password;

    @FindBy(name = "confirmPassword")
    private WebElement confirmPassword;

    @FindBy(name = "address")
    private WebElement address;

    @FindBy(name = "city")
    private WebElement city;

    @FindBy(name = "state")
    private WebElement state;

    @FindBy(name = "zip")
    private WebElement zip;

    @FindBy(name = "phone")
    private WebElement phone;

    @FindBy(name = "fax")
    private WebElement fax;

    public static final String SAVE_BTN_CSS = "div.modal-footer > button.btn-primary";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    public static final String CANCEL_BTN_CSS = "div.modal-footer > button.btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    @FindBy(className = "modal-body")
    private WebElement modalBody;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "div.panel-heading.clearfix select")
    private WebElement dealerStatusDropDown;

    @FindBy(css = "div.panel-heading.clearfix span.pull-right.panel-title")
    private WebElement dealerStatusLabel;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header h4.modal-title")
    private WebElement modalWindowTitle;

    @FindBy(css = "div.has-error span[for='dealerId']")
    private WebElement dealerIdErrorMessage;

    @FindBy(css = "div.has-error span[for='name']")
    private WebElement nameErrorMessage;

    @FindBy(css = "div.has-error span[for='firstName']")
    private WebElement firstNameErrorMessage;

    @FindBy(css = "div.has-error span[for='lastName']")
    private WebElement lastNameErrorMessage;

    @FindBy(css = "div.has-error span[for='email']")
    private WebElement emailErrorMessage;

    @FindBy(css = "div.has-error span[for='newPassword']")
    private WebElement passwordErrorMessage;

    @FindBy(css = "div.has-error span[for='address']")
    private WebElement addressErrorMessage;

    @FindBy(css = "div.has-error span[for='city']")
    private WebElement cityErrorMessage;

    @FindBy(css = "div.has-error span[for='state']")
    private WebElement stateErrorMessage;

    @FindBy(css = "div.has-error span[for='zip']")
    private WebElement postalCodeErrorMessage;

    @FindBy(css = "input[name='statusInactive']")
    private WebElement dealerStatusChkBox;

    @FindBy(css = "label.checkbox-inline input:not([name])")
    private List<WebElement> chkBoxList;

    @FindBy(linkText = "Request Installation")
    private WebElement requestInstallationLink;

    @FindBy(linkText = "Active Devices")
    private WebElement activeDevicesLink;

    @FindBy(linkText = "Order Devices")
    private WebElement orderDevicesLink;

    @FindBy(className = "admin-detail")
    private WebElement sectionText;

    public static final String CONFIRMATION_OK_BTN_CSS = "div.modal-footer > button[type='button'].btn.btn-primary";
    @FindBy(css = CONFIRMATION_OK_BTN_CSS)
    private WebElement confirmationOkBtn;

    public AdminDealerManagementPage(WebDriver webDriver) {
        super(webDriver);
    }

    public WebElement getDealerTableHeader() {
        return panelTitle;
    }

    public void clickAddDealerButton() {
        addDealerButton.click();
    }

    public void fillAndSubmitFormWithDealerData(Dealer dealer) {

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(firstName));

        enterText(driver, dealerId, dealer.getDealerId());
        enterText(driver, dealerName, dealer.getDealerName());
        enterText(driver, firstName, dealer.getFirstName());
        enterText(driver, lastName, dealer.getLastName());
        enterText(driver, email, dealer.getEmail());
        enterText(driver, password, dealer.getPassword());
        enterText(driver, confirmPassword, dealer.getConfirmPassword());

        if(dealer.getAddress() != null) {
            enterText(driver, address, dealer.getAddress().getStreet());
            enterText(driver, city, dealer.getAddress().getCity());
            if (dealer.getAddress().getState() != null)
                new Select(state).selectByVisibleText(dealer.getAddress().getState());
            enterText(driver, zip, dealer.getAddress().getPostalCode());
        }

        enterText(driver, phone, dealer.getPhone());
        enterText(driver, fax, dealer.getFax());

        updateCheckBox(driver, chkBoxList.get(0), dealer.getEnableRequestInstallation());
        updateCheckBox(driver, chkBoxList.get(1), dealer.getEnableDeviceOrdering());

        submitForm();
    }

    public void fillInvalidFormAndCancel() {
        waitUntilSpinnerInvisible(driver, 10);

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(firstName));

        new WebDriverWait(driver, 10)
                .until(elementToBeClickable(saveBtn))
                .click();

        assertEquals(dealerIdErrorMessage.getText(), "Dealer ID is required");
        assertEquals(nameErrorMessage.getText(), "Name is required");
        assertEquals(firstNameErrorMessage.getText(), "First Name is required");
        assertEquals(lastNameErrorMessage.getText(), "Last Name is required");
        assertEquals(emailErrorMessage.getText(), "Email is required");
        assertEquals(passwordErrorMessage.getText(), "Password is required");
        assertEquals(addressErrorMessage.getText(), "Address is required");
        assertEquals(cityErrorMessage.getText(), "City is required");
        assertEquals(stateErrorMessage.getText(), "State is required");
        assertEquals(postalCodeErrorMessage.getText(), "Postal Code is required");

        new WebDriverWait(driver, 10)
                .until(elementToBeClickable(cancelBtn))
                .click();

        new WebDriverWait(driver, 10)
                .until(invisibilityOfElementLocated(By.name(MODAL_SAVE_NAME)));
    }

    //some of these methods will be used in future
    public String getDealerNameFromModal() {
        return dealerName.getAttribute("value");
    }

    public String getFirstNameFromModal() {
        return firstName.getAttribute("value");
    }

    public String getLastNameFromModal() {
        return lastName.getAttribute("value");
    }

    public String getPhoneFromModal() {
        return phone.getAttribute("value");
    }

    public String getEmailFromModal() {
        return email.getAttribute("value");
    }

    public void submitForm() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(SAVE_BTN_CSS), 40);
    }

    public void cancelForm() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By.cssSelector(CANCEL_BTN_CSS));
    }

    public void clickEditDealerRecord() {
        int rowCount = driver.findElements(By.cssSelector(allRowsCssLocator)).size();
        if (rowCount > 1) {
            editLink.click();
        } else {
            throw new WebDriverException("No records returned");
        }
    }

    public WebElement getAddDealerButton() {
        return addDealerButton;
    }

    /**
     * Get header column names of grid.
     *
     * @return
     */
    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getDealerStatusDropDown() {
        return dealerStatusDropDown;
    }

    public WebElement getDealerStatusLabel() {
        return dealerStatusLabel;
    }

    /**
     * Get dealer status values
     *
     * @return
     */
    public List<String> getDealerStatusValues() {
        List<WebElement> dealerStatusDropDownElementList = new Select(dealerStatusDropDown).getOptions();

        List<String> dealerStatusDropDownValueList = new ArrayList<>();
        for (WebElement dealerStatusDropDownElement : dealerStatusDropDownElementList) {
            dealerStatusDropDownValueList.add(dealerStatusDropDownElement.getText());
        }

        return dealerStatusDropDownValueList;
    }

    /**
     * Get First Record from Grid
     *
     * @return
     */
    public HashMap<String, String> getTableFirstRow() {

        HashMap<String, String> gridFirstRecord = getTableFirstRow(gridBody);
        gridFirstRecord.remove("Actions");

        return gridFirstRecord;
    }

    public void selectDealerStatus(String dealerStatus) {
        if (dealerStatus != null) {
            new Select(dealerStatusDropDown).selectByVisibleText(dealerStatus);
        }
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }

    /**
     * Click on resend link for the given row
     */
    public void resendRecord(int rowNumber) {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector("div.ember-view.lazy-list-container" +
                        ".ember-table-table-block.ember-table-right-table-block > div:nth-child("
                        + rowNumber + ") a:first-child")))).click();
    }

    /**
     * Click on edit link for the given row
     */
    public void editRecord(int rowNumber) {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector("div.ember-view.lazy-list-container" +
                        ".ember-table-table-block.ember-table-right-table-block > div:nth-child("
                        + rowNumber + ") a:last-child")))).click();
    }

    public void makeDealerInactive() {
        updateCheckBox(driver, dealerStatusChkBox, true);
    }

    public void clickConfirmationOkBtn() {
        clickElementAndWaitForInvisibility(driver, confirmationOkBtn, By.cssSelector(CONFIRMATION_OK_BTN_CSS));
    }

    /**
     * Get First Record from API
     *
     * @param dealerData
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<LenderDealerPartnershipDto> dealerData) {

        HashMap<String, String> apiFirstRecord = new HashMap<>();

        apiFirstRecord.put("Dealer ID", dealerData.get(0).getLabel());
        apiFirstRecord.put("Dealer Name", dealerData.get(0).getAccount().getName());
        apiFirstRecord.put("Dealer Contact", dealerData.get(0).getAccount().getContact().getFirstName()
                + " " + dealerData.get(0).getAccount().getContact().getLastName());
        apiFirstRecord.put("Dealer Phone", dealerData.get(0).getAccount().getContact().getPhoneNumber());
        apiFirstRecord.put("Dealer Email", dealerData.get(0).getAccount().getContact().getEmail());
        apiFirstRecord.put("Status", dealerData.get(0).getAccount().getStatus());

        return apiFirstRecord;
    }

    public WebElement getActiveDevicesLink() {
        return activeDevicesLink;
    }

    public WebElement getRequestInstallationLink() {
        return requestInstallationLink;
    }

    public WebElement getOrderDevicesLink() {
        return orderDevicesLink;
    }

    public WebElement getAddress() {
        return address;
    }

    public WebElement getSectionText() {
        return sectionText;
    }

    public WebElement getDealerId() {
        return dealerId;
    }

    public WebElement setDealerName() {
        return dealerName;
    }
}
