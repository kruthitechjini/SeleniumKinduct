package com.procon.vehiclefinance.pageobjects.reports;

public enum ReportTypeEnum {
    ALERT_HISTORY("Alert History","15"),
    AUTO_REPORT_HISTORY("Auto Report History","16"),
    RESPONSE_HISTORY("Response History","22"),
    ALL_DEVICE_HISTORY("All Device History","17"),
    DAILY_DEVICE_HISTORY("Daily Device History","121"),
    STARTER_STATUS("Starter Status","24"),
    GEOFENCE_VIOLATIONS("GeoFence Violations","19"),
    GEOZONE_VIOLATIONS("GeoZone Violations","20"),
    EXCEPTIONS("Exceptions","18"),
    DRIVE_REPORT("Drive Report","26"),
    STOP_REPORT("Stop Report","25"),
    INVENTORY_STATUS("Inventory Status","21"),
    VEHICLE_INFORMATION("Vehicle Information","14"),
    SCHEDULED_HISTORY("Scheduled History","23"),
    REFERENCE_VERIFICATION("Reference Verification","59"),
    STIPULATION_REPORT("Stipulation Report","129"),
    EXCESSIVE_MILEAGE_REPORT("Excessive Mileage Report","131"),
    MILEAGE_SUMMARY_REPORT("Mileage Summary Report","133"),
    IMPOUND_STATUS("Impound Status","135"),
    INSTALLATION_REQUEST_HISTORY("Installation Request History","141"),
    // kahu reports
    BATTERY_STATUS_REPORT("Battery Status Report","115"),
    LOT_REPORT("Lot Report","117"),
    SALES_REPORT("Sales Report","113"),
    EXTENDED_OFF_LOT_REPORT("Extended Off Lot Report","119");

    private String name;
    private String id;

    ReportTypeEnum(String name,String id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }
}
