package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class AdminDeviceTransfersPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminDeviceTransfersPage.class.getName());

    @FindBy(linkText = "Send")
    private WebElement sendBtn;

    @FindBy(css = "div.panel-heading.clearfix button.btn-primary")
    private WebElement startNewTransferBtn;

    @FindBy(xpath = "//a[text()='Cancel']")
    private WebElement cancelActionBtn;

    @FindBy(xpath = "//a[text()='Resend']")
    private WebElement resendActionBtn;

    @FindBy(css = "div.recipient select")
    private WebElement selectedRecipient;

    @FindBy(css = "[name='selectedGroup']")
    private WebElement selectGroupDropdown;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source .ember-table-header-row input")
    private WebElement sourceGrpSelectAllChkbox;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.target .ember-table-header-row input")
    private WebElement targetGrpBoxSelectAllChkbox;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source")
    private WebElement sourceGroupBox;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source > div:nth-of-type(1)")
    private WebElement sourceGroupBoxHeadingPanel;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source > div:nth-of-type(2)")
    private WebElement sourceGroupBoxBodyContainer;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source > div:nth-of-type(3)")
    private WebElement sourceGroupBoxFooterPanel;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer ul > li > a > i.glyphicon-step-backward")
    private WebElement firstPageBtnOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer ul > li > a > i.glyphicon-step-forward")
    private WebElement lastPageBtnOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer ul > li > a > i.fa-caret-left")
    private WebElement previousBtnOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer ul > li > a > i.fa-caret-right")
    private WebElement nextBtnOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer ul > a > i.fa-refresh")
    private WebElement refreshBtnOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.source div.panel-footer div.pull-right")
    private WebElement pagingStatusOfSourceGroupBoxFooter;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.target")
    private WebElement targetGroupBox;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.target > div:nth-of-type(1)")
    private WebElement targetGroupBoxHeadingPanel;

    @FindBy(css = "div.row .device-transfer-vehicle-panel.target > div:nth-of-type(2)")
    private WebElement targetGroupBoxBodyContainer;

    @FindBy(css = "div.group-transfer-vehicle-divider button:nth-of-type(1)")
    private WebElement addBtn;

    @FindBy(css = "div.group-transfer-vehicle-divider button:nth-of-type(2)")
    private WebElement removeBtn;

    private final String closeBtn_css = "div.modal-footer button:nth-of-type(2)";
    @FindBy(css = closeBtn_css)
    private WebElement closeBtn;

    @FindBy(css = "div.modal-footer button:nth-of-type(1)")
    private WebElement transferNowBtn;

    @FindBy(css = "[data-bb-handler='accept']")
    private WebElement acceptTransferAuthBtn;

    @FindBy(css = "button.btn.btn-cancel")
    private WebElement emailSentConfirmation;

    @FindBy(css = "div.lazy-list-container.ember-table-right-table-block")
    private WebElement gridRowsContainer;

    @FindBy(css = "div.modal-footer button.btn.btn-primary")
    private WebElement confirmYesBtn;

    @FindBy(css = "div.modal-footer button.btn.btn-cancel")
    private WebElement confirmNoBtn;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "#modal textarea[name='comments']")
    private WebElement multipleSearchInput;

    @FindBy(css = "div#modal div:nth-child(1) > div:nth-child(2) > div > div > input")
    private WebElement senderDropDown;

    @FindBy(css = "div#modal div:nth-child(5) > div:nth-child(2) > div > div > input")
    private WebElement recipientDropDown;

    @FindBy(css = "div#modal textarea")
    private WebElement searchTextArea;


    public AdminDeviceTransfersPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickStartNewTransferBtn() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.
                elementToBeClickable(startNewTransferBtn)).click();

        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);

    }

    public void clickCloseBtn() {
        clickElementAndWaitForInvisibility(driver,closeBtn,By.cssSelector(closeBtn_css),10);
    }

    public void clickTransferNowBtn() {
        new WebDriverWait(driver, 25).until(ExpectedConditions.
                elementToBeClickable(transferNowBtn)).click();
    }

    public void clickEmailSentConfirmation() {
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(emailSentConfirmation)).click();
    }

    public void clickAddBtn() {
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(addBtn)).click();
    }

    public void clickTransferAuthorizationBtn() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.
                elementToBeClickable(acceptTransferAuthBtn)).click();

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
    }

    public void selectSerialNumbers(ArrayList<String> serialNumbers) {
        //search devices
        multipleSearchInput.clear();
        serialNumbers.forEach(sn -> multipleSearchInput.sendKeys(sn + ", "));

        //select devices
        String format = "//span[text()='%s']/parent::div/parent::div/descendant::input";
        new WebDriverWait(driver, 30).until(ExpectedConditions
                .visibilityOfNestedElementsLocatedBy(sourceGroupBox, By
                        .cssSelector("input.ember-view.ember-checkbox")));
        for (String serialNumber : serialNumbers) {
            String xpath = String.format(format, serialNumber);
            new WebDriverWait(driver, 20).until(ExpectedConditions
                    .elementToBeClickable(By.xpath(xpath))).click();
        }
    }

    public void selectRecipient(String recipient) {
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 50);

        Select select = new Select(selectedRecipient);
        select.selectByVisibleText(recipient);

        // need to catch the exception because there can be valid test
        // scenarios which have no available devices. In that case, we log a
        // warning and continue instead of failing
        try {
            new WebDriverWait(driver, 40).until(ExpectedConditions
                    .visibilityOfNestedElementsLocatedBy(sourceGroupBox, By
                            .cssSelector("input.ember-view.ember-checkbox")));
        } catch (TimeoutException e) {
            logger.log(Level.WARNING, "Available list has 0 devices");
        }
    }

    public void selectGroup(String group) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        new WebDriverWait(driver, 40).until(ExpectedConditions
                .visibilityOfNestedElementsLocatedBy(selectGroupDropdown, By.cssSelector("option.ember-view")));

        Select select = new Select(selectGroupDropdown);
        select.selectByVisibleText(group);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 1);
    }

    public void cancelTransfer(String serialNumber) {
        String format = "//span[text()='%s']/parent::div/parent::div//a[text()='Cancel']";
        waitUntilSpinnerInvisible(driver);
        String xpath = String.format(format, serialNumber);
        new WebDriverWait(driver, 10)
                .until(elementToBeClickable(gridRowsContainer.findElement(By.xpath(xpath)))).click();

        //Confirm transfer cancellation
        new WebDriverWait(driver, 10)
                .until(elementToBeClickable(confirmYesBtn)).click();
    }

    public boolean isActionPending(String serialNumber) {
        String format = "//span[text()='%s']";
        waitUntilSpinnerInvisible(driver);
        String xpath = String.format(format, serialNumber);
        if (isElementPresent(driver, By.xpath(xpath))) {
            return true;
        } else {
            return false;
        }
    }

    public void fillTransferDevicesForm(String recipient, String group, ArrayList<String> serialNumbersToTransfer) {
        //Start transfer process
        clickStartNewTransferBtn();

        //select recipient
        selectRecipient(recipient);

        //Select group
        selectGroup(group);

        //select and serial Numbers
        selectSerialNumbers(serialNumbersToTransfer);
        clickAddBtn();
    }

    public Boolean isModelWindowDisplayed() {
        return new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOf
                (modalWindow)).isDisplayed();
    }

    public Boolean isMultipleSearchInputEmpty() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String values = (String) js.executeScript("return arguments[0].value", multipleSearchInput);
        return values.isEmpty();
    }

    public WebElement getSenderDropDown() { return senderDropDown; }

    public WebElement getRecipientDropDown() {
        return recipientDropDown;
    }

    public WebElement getConfirmYesBtn() {
        return confirmYesBtn;
    }

    public WebElement getConfirmNoBtn() { return confirmNoBtn; }

    public WebElement getAddBtn() {
        return addBtn;
    }

    public WebElement getRemoveBtn() {
        return removeBtn;
    }

    public WebElement getSourceGroupBox() { return sourceGroupBox; }

    public WebElement getSourceGrpSelectAllChkbox() {
        return sourceGrpSelectAllChkbox;
    }

    public WebElement getSourceGroupBoxHeadingPanel() {
        return sourceGroupBoxHeadingPanel;
    }

    public WebElement getSourceGroupBoxBodyContainer() {
        return sourceGroupBoxBodyContainer;
    }

    public WebElement getSourceGroupBoxFooterPanel() {
        return sourceGroupBoxFooterPanel;
    }

    public WebElement getFirstPageBtnOfSourceGroupBoxFooter() {
        return firstPageBtnOfSourceGroupBoxFooter;
    }

    public WebElement getLastPageBtnOfSourceGroupBoxFooter() {
        return lastPageBtnOfSourceGroupBoxFooter;
    }

    public WebElement getPreviousBtnOfSourceGroupBoxFooter() {
        return previousBtnOfSourceGroupBoxFooter;
    }

    public WebElement getNextBtnOfSourceGroupBoxFooter() {
        return nextBtnOfSourceGroupBoxFooter;
    }

    public WebElement getRefreshBtnOfSourceGroupBoxFooter() {
        return refreshBtnOfSourceGroupBoxFooter;
    }

    public WebElement getPagingStatusOfSourceGroupBoxFooter() {
        return pagingStatusOfSourceGroupBoxFooter;
    }

    public WebElement getTargetGroupBox() {
        return targetGroupBox;
    }

    public WebElement getTargetGroupBoxHeadingPanel() {
        return targetGroupBoxHeadingPanel;
    }

    public WebElement getTargetGroupBoxBodyContainer() {
        return targetGroupBox;
    }

    public WebElement getTargetGrpSelectAllChkbox() {
        return targetGroupBox;
    }

}
