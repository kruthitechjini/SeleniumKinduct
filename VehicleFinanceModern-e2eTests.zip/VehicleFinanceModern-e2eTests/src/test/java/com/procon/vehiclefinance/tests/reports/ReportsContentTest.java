package com.procon.vehiclefinance.tests.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.PlatformObject;
import com.procon.vehiclefinance.pageobjects.reports.AdvancedReportsPage;
import com.procon.vehiclefinance.pageobjects.reports.AdvancedReportsPage.ReportColumns;
import com.procon.vehiclefinance.pageobjects.reports.AdvancedReportsPage.ReportCriteria;
import com.procon.vehiclefinance.pageobjects.reports.DateRangeEnum;
import com.procon.vehiclefinance.pageobjects.reports.Report;
import com.procon.vehiclefinance.pageobjects.reports.ReportTypeEnum;
import com.procon.vehiclefinance.util.DateTimeUtils;
import org.openqa.selenium.TimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.ReportService.getReportHistoryResults;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static com.procon.vehiclefinance.util.DateTimeUtils.getCurrentBrowserDate;
import static com.procon.vehiclefinance.util.PlatformApiUtils.*;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static org.testng.Assert.*;

public class ReportsContentTest extends ReportsBase {

    private static final Logger logger = LoggerFactory.getLogger
            (ReportsContentTest.class);

    /*private static final DateFormat UI_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy hh:mm a '('z')'");*/

    // there's currently an issue due to which the date is showing the
    // daylight saving value based on current date, instead of when the
    // report was actually run. So even though the report could have been run
    // when DST was on (PDT), the date in report header will show as (PST).
    // SO ignoring that part to compare for now
    private static final DateFormat UI_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy hh:mm a");

    private static final DateFormat API_DATE_FORMAT = new SimpleDateFormat
            ("yyyy-MM-dd'T'HH:mm:ssZ");

    private static final DateFormat CELL_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy h:mm a");

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String mileageThreshold;
        public String costPerMile;
        public List<ReportCriteria> reportCriteria;
        public List<ReportColumns> reportColumns;
        public List<String> eventNames;
        public String apiUserName;
        public String apiPassword;
        public String appToken;
        public String tripFile;
    }

    @Test(description = "Drive  Report - Generate Report", groups = {"reports"})
    public void testDriveReportContent() throws UnirestException, ParseException {

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -90);
        String minus90Date = CELL_DATE_FORMAT.format(c.getTime());

        //Run and Validate Report Name,Header info in UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .DRIVE_REPORT, null, null,
                DateRangeEnum.CUSTOM, minus90Date.split(" ")[0],
                getCurrentBrowserDate(driver, UI_DATE_FORMAT)
                        .split(" ")[0], "12:00 AM", "11:59 PM", "All Groups",
                100, UI_DATE_FORMAT);

        //Validate Active Report Grid Navigation control elements
        reportsPage.verifyNavigationBtns(reportsPage.getFirstPageBtn(), reportsPage.getPreviousBtn(),
                reportsPage.getNextBtn(), reportsPage.getLastPageBtn(),
                reportsPage.getSelectPageSize(), reportsPage.getPagingPositionDiv());

        //Get the Drive report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> eventData = reportData.eventList;

        //Validate Drive Event in reports list
        for (Report.ReportItem reportEvent : eventData) {
            assertEquals(reportEvent.alertTypeName.trim(), ReportTypeEnum
                    .DRIVE_REPORT.getName());
        }

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, eventData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Drive report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.eventList.size());
    }

    @Test(description = "Auto Report History - Generate Report ", groups =
            {"reports", "pipeline"})
    public void testAutoReportHistoryContent() throws UnirestException,
            ParseException {

        //Run Auto and Validate Report Name,Header info in UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .AUTO_REPORT_HISTORY,
                null, null, DateRangeEnum.LAST_14_DAYS, null, null,
                null, null, "All Groups", 60, UI_DATE_FORMAT);

        //Get the Auto Report History data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Sorting in descending order based on event date
        Comparator<Report.ReportItem> byDate = (reportItem1, reportItem2) -> {
            try {
                return UI_DATE_FORMAT.parse(reportItem2.eventDate).compareTo(
                        (UI_DATE_FORMAT
                                .parse(reportItem1.eventDate)));
            } catch (ParseException e) {
                return 0;
            }
        };
        alertData.sort(byDate);

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                UI_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Auto Report History headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Auto Report History Event in reports list
        for (Report.ReportItem reportEvent : alertData) {
            assertEquals(reportEvent.alertTypeName.trim(), "Auto Report");
        }

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());
    }

    @Test(description = "Response History - Generate Report ", groups =
            {"reports"})
    public void testResponseHistoryReportContent() throws UnirestException,
            ParseException {

        //Run Response History report through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .RESPONSE_HISTORY, null,
                null, DateRangeEnum.LAST_30_DAYS, null, null,
                null, null, "All Groups", 40, UI_DATE_FORMAT);

        //Get the Response History report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> eventData = reportData.eventList;

        //Sorting in descending order based on event date
        Comparator<Report.ReportItem> byDate = (reportItem1, reportItem2) -> {
            try {
                return UI_DATE_FORMAT.parse(reportItem2.eventDate).compareTo(
                        (UI_DATE_FORMAT
                                .parse(reportItem1.eventDate)));
            } catch (ParseException e) {
                return 0;
            }
        };
        eventData.sort(byDate);

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, eventData,
                UI_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Response History report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.eventList.size());
    }

    @Test(description = "Stop Report - Generate Report ", groups = {"reports", "pipeline"})
    public void testStopReportContent() throws UnirestException, IOException,
            ParseException, InterruptedException {

        // Run Stop report through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .STOP_REPORT, null, null,
                DateRangeEnum.LAST_90_DAYS, null, null,
                null, null, "All Groups", 40, UI_DATE_FORMAT);


        // Get the Stop report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> eventData = reportData.eventList;

        // Validate Stop Event in reports list
        for (Report.ReportItem r : eventData) {
            assertEquals(r.alertTypeName.trim(), ReportTypeEnum.STOP_REPORT
                    .getName());
        }

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, eventData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Stop report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.eventList.size());
    }

    @Test(description = "All Device History - Generate Report ", groups = {"reports"})
    public void testAllDeviceHistoryReportContent() throws UnirestException,
            ParseException, IOException, InterruptedException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread()
                .getStackTrace()[1].getMethodName());

        TestData data = null;
        try {

            data = mapper.treeToValue(dataNode, TestData.class);

        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Get the api user's token
        String token = getToken(data.apiUserName, data.apiPassword, data.appToken);

        String vehicleName = Long.toString(System.currentTimeMillis());

        //Create device & vehicle
        PlatformObject platformObject = createDeviceAndAsset(vehicleName, token);

        String serialNumber = platformObject.deviceDto.getSerialNumber();

        String deviceId = platformObject.deviceDto.getId();
        String assetId = platformObject.assetDto.getId();

        generateEvents(serialNumber, data.tripFile, 120000);

        logger.info("Event has been successfully generated for testing.");

        //Click Advanced Report Link
        AdvancedReportsPage advancedReportsPage = reportsLeftBarPage.clickAdvancedReportLink();

        //Run All device history report from Advanced Report Link
        advancedReportsPage.runAdvancedReport(ReportTypeEnum.ALL_DEVICE_HISTORY, "-- All Groups --",
                vehicleName, DateRangeEnum.LAST_90_DAYS, data.reportCriteria, data.reportColumns);

        waitUntilSpinnerInvisible(driver, 40);

        verifyReportHeaderInfo(driver, ReportTypeEnum.ALL_DEVICE_HISTORY, vehicleName, UI_DATE_FORMAT);

        // Get All device history report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Validate Event in reports list
        for (Report.ReportItem reportEvent : alertData) {
            assertTrue(data.eventNames.contains(reportEvent.alertTypeName.trim()));
        }

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get All device history report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());

        //Delete asset
        if (assetId != null) {
            if (!deleteVehicle(assetId, token)) {
                logger.warn("assetId -> {} could not be deleted ", assetId);
            } else {
                logger.info("assetId -> {} deleted ", assetId);
            }
        }

        //Delete device
        if (deviceId != null) {
            if (!deleteDevice(deviceId, token)) {
                logger.warn("deviceId -> {} could not be deleted ", deviceId);
            } else {
                logger.info("deviceId -> {} deleted ", deviceId);
            }
        }
    }

    @Test(description = "Reference Verification - Generate Report ", groups =
            {"reports"})
    public void testReferenceVerificationReportContent() throws UnirestException,
            ParseException {

        //Run Reference Verification through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.REFERENCE_VERIFICATION,
                "-- All Groups --", "-- All Vehicles --", null, null, null,
                null, null, "All Groups", 60, UI_DATE_FORMAT);

        //Get Reference Verification data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> stipData = reportData.stipList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, stipData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get Reference Verification report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Todo API is sending startdate and enddate but its not displayed in UI
        //Validate Report Content with API
        verifyReportUIWithAPI(null,
                null, expectedColumns,
                apiFirstRecord, reportData.stipList.size());
    }

    @Test(description = "Geo-Fence Violations - Generate Report ", groups =
            {"reports", "pipeline"})
    public void testGeoFenceViolationsReportContent()
            throws UnirestException, ParseException {

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -90);
        String minus90Date = CELL_DATE_FORMAT.format(c.getTime());

        //Run and Validate Report Name,Header info in UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.GEOFENCE_VIOLATIONS, null,
                null, DateRangeEnum.CUSTOM, minus90Date.split(" ")[0],
                getCurrentBrowserDate(driver, UI_DATE_FORMAT).split(" ")[0],
                "12:00 AM", "11:59 PM", "All Groups", 60, UI_DATE_FORMAT);

        //Get Geo Fence Violations report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get Geo Fence Violations report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());
    }

    @Test(description = "Exception - Generate Report ", groups =
            {"reports"})
    public void testExceptionReportContent() throws UnirestException,
            ParseException {

        //Run Exception through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .EXCEPTIONS,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.LAST_30_DAYS, null, null,
                null, null, "All Groups", 70, UI_DATE_FORMAT);

        //Get the Exception report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> deviceData = reportData.deviceList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, deviceData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get the Exception report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.deviceList.size());
    }

    @Test(description = "Scheduled History - Generate Report ", groups =
            {"reports"})
    public void testScheduledHistoryReportContent() throws UnirestException,
            ParseException {

        //Run Scheduled History report through UI
        runAndVerifyReportHeaderInfo(driver,
                ReportTypeEnum.SCHEDULED_HISTORY,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.LAST_7_DAYS, null, null,
                null, null, "All Groups", 120, UI_DATE_FORMAT);

        //Get Scheduled History report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> commandData = reportData.commandList;

        //Sorting in descending order based on event date
        Comparator<Report.ReportItem> byDate = (reportItem1, reportItem2) -> {
            try {
                return UI_DATE_FORMAT.parse(reportItem2.eventDate).compareTo(
                        (UI_DATE_FORMAT
                                .parse(reportItem1.eventDate)));
            } catch (ParseException e) {
                return 0;
            }
        };
        commandData.sort(byDate);

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, commandData,
                UI_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get Scheduled History report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.commandList.size());
    }

    @Test(description = "Geo-Zone Violations - Generate Report ", groups =
            {"reports", "pipeline"})
    public void testGeoZoneViolationsReportContent()
            throws UnirestException, ParseException {

        //Run Geo Zone Violations through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.GEOZONE_VIOLATIONS,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.LAST_30_DAYS, null, null, null, null,
                "All Groups", 40, UI_DATE_FORMAT);

        //Get Geo Zone Violations report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Validate Geo Zone Violations in reports list
        for (Report.ReportItem reportItem : alertData) {
            assertTrue(reportItem.alertTypeName.trim().contains("GeoZone"));
        }

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get Geo Zone Violations report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());
    }

    @Test(description = "Starter Status - Generate Report ", groups = {"reports", "pipeline"})
    public void testStarterStatusReportContent()
            throws UnirestException, ParseException {

        //Run Starter Status through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.STARTER_STATUS,
                "-- All Groups --", "-- All Vehicles --", null,
                null, null, null, null, "All Groups",
                40, UI_DATE_FORMAT);

        // Get Starter Status report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get the first row of the Starter Status
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, assetData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get Starter Status report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Todo API is sending startDate and endDate but its not displayed in UI
        //Validate Report Content with API
        verifyReportUIWithAPI(null, null, expectedColumns,
                apiFirstRecord, reportData.assetList.size());
    }

    @Test(description = "Inventory Status - Generate Report ", groups = {"reports"})
    public void testInventoryStatusReportContent() throws UnirestException, ParseException {

        final int REPORT_WAITING = 70;

        //Run Inventory Status through UI
        try {
            runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.INVENTORY_STATUS,
                    "-- All Groups --", "-- All Vehicles --", null, null, null,
                    null, null, "All Groups", REPORT_WAITING, UI_DATE_FORMAT);
        } catch (TimeoutException e) {
            fail("Report is generating more then " + REPORT_WAITING + "s. ", e);
        }

        //Get Inventory Status data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Validate Header Info:Number of devices, Out for Repossession,
        //Installed and Uninstalled with API response
        verifyReportHeaderInfo(assetData);

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, assetData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get Inventory Status report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Todo API is sending startdate and enddate but its not displayed in UI
        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());
    }

    /**
     * Verify Header Info for Inventory Status Report
     *
     * @param assetData
     */
    private void verifyReportHeaderInfo(List<Report.ReportItem> assetData) {

        int outForRepossessionCount = 0;
        int installedCount = 0;
        int uninstalledCount = 0;

        for (Report.ReportItem reportEvent : assetData) {
            switch (reportEvent.inventoryStatus.trim()) {
                case "Installed":
                    installedCount++;
                    break;
                case "Not Installed":
                    uninstalledCount++;
                    break;
                case "Out for Repossession":
                    outForRepossessionCount++;
                    break;
                default:
                    break;
            }
        }

        //Validate Header Info:Number of devices.
        assertEquals(reportsPage.getReportHeaderNumberOfDevicesLabel(),
                reportsPage.getTotalRecordCount(reportsPage.getPagingPositionDiv()));

        //Validate Header Info:Out for Repossession, Installed and
        //Uninstalled with API response.
        assertEquals(reportsPage.getReportHeaderOutForRepossessionLabel(),
                outForRepossessionCount);

        assertEquals(reportsPage.getReportHeaderInstalledLabel(),
                installedCount);

        assertEquals(reportsPage.getReportHeaderUninstalledLabel(),
                uninstalledCount);

        //Validate Number of Devices count with total count of (Out for
        // Repossession,Installed and Uninstalled records)
        assertEquals(reportsPage.getReportHeaderNumberOfDevicesLabel(),
                (installedCount + uninstalledCount + outForRepossessionCount));
    }

    @Test(description = "Vehicle Information - Generate Report ", groups = {"reports"})
    public void testVehicleInformationReportContent() throws UnirestException, ParseException {

        final int REPORT_WAITING = 100;

        //Run Vehicle Information through UI
        try {
            runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.VEHICLE_INFORMATION,
                    "-- All Groups --", "-- All Vehicles --", null, null, null,
                    null, null, "All Groups", REPORT_WAITING, UI_DATE_FORMAT);
        } catch (TimeoutException e) {
            fail("Report is generating more then " + REPORT_WAITING + "s. ", e);
        }

        //Get the Vehicle Information data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, assetData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get Vehicle Information report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());
    }


    @Test(description = "Stipulation Report - Generate Report ", groups =
            {"reports", "pipeline"})
    public void testStipulationReportContent() throws UnirestException,
            ParseException {

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -90);
        String minus90Date = CELL_DATE_FORMAT.format(c.getTime());

        //Run Stipulation report through UI
        runAndVerifyReportHeaderInfo(driver,
                ReportTypeEnum.STIPULATION_REPORT,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.CUSTOM, minus90Date.split(" ")[0],
                getCurrentBrowserDate(driver, UI_DATE_FORMAT).split(" ")[0],
                "12:00 AM", "11:59 PM",
                "All Groups", 30, UI_DATE_FORMAT);

        //Get the Stipulation report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> eventData = reportData.eventList;

        //Validate Stipulation Report Event in report list
        for (Report.ReportItem reportEvent : eventData) {
            assertEquals(reportEvent.alertTypeName.trim(), "Stipulation Event");
        }

        //Sorting in descending order based on event date
        Comparator<Report.ReportItem> byDate = (reportItem1, reportItem2) -> {
            try {
                return API_DATE_FORMAT.parse(reportItem2.eventDate).compareTo(
                        (API_DATE_FORMAT
                                .parse(reportItem1.eventDate)));
            } catch (ParseException e) {
                return 0;
            }
        };
        eventData.sort(byDate);

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord
                (driver, reportData, eventData, API_DATE_FORMAT,
                        CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Stipulation report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver,
                reportData.config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.eventList.size());
    }

    @Test(description = "Mileage Summary Report - Generate Report ", groups =
            {"reports", "slow"})
    public void testMileageSummaryReportContent() throws UnirestException,
            ParseException, IOException {

        //Run Mileage Summary Report through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum
                        .MILEAGE_SUMMARY_REPORT, null,
                null, DateRangeEnum.LAST_7_DAYS, null, null,
                null, null, "All Groups", 130, UI_DATE_FORMAT);

        //Validate Active Report Grid Navigation control elements
        reportsPage.verifyNavigationBtns(reportsPage.getFirstPageBtn(), reportsPage.getPreviousBtn(),
                reportsPage.getNextBtn(), reportsPage.getLastPageBtn(),
                reportsPage.getSelectPageSize(), reportsPage.getPagingPositionDiv());

        //Get Mileage Summary Report data
        Report.ReportHistoryResults historyResults = getReportHistoryResults(driver);
        List<Report.ReportOutput> historyResultsData = historyResults.data;

        int reportSpecId = 0;
        for (Report.ReportOutput historyData : historyResultsData) {

            if (historyData.reportName.equals(ReportTypeEnum
                    .MILEAGE_SUMMARY_REPORT.getName()) && DateTimeUtils.formatDate(driver,
                    historyData.executionStart.replaceAll("Z", "+0000"),
                    API_DATE_FORMAT, UI_DATE_FORMAT).equals
                    (curDate)) {

                reportSpecId = historyData.reportSpecId;
                break;
            }
        }

        assertTrue(reportSpecId > 0, "Report does not exist");

        Report.ReportData reportData = getActiveReportData
                (driver, reportSpecId);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord
                (driver, reportData, assetData, API_DATE_FORMAT,
                        CELL_DATE_FORMAT);

        //Get the Mileage Summary report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());
    }

    @Test(description = "Excessive Mileage Report - Generate Report ", groups
            = {"reports", "slow"})
    public void testExcessiveMileageReportContent() throws UnirestException,
            ParseException, IOException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread()
                .getStackTrace()[1].getMethodName());

        ReportsContentTest.TestData data = null;
        try {
            data = mapper.treeToValue(dataNode,
                    ReportsContentTest.TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Run Excessive Mileage Report through UI
        runAndVerifyReportHeaderInfo(driver,
                ReportTypeEnum.EXCESSIVE_MILEAGE_REPORT,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.SEVEN_DAYS, data.mileageThreshold,
                data.costPerMile, "All Groups", 120, UI_DATE_FORMAT);

        //Get Excessive Mileage Report data
        Report.ReportHistoryResults historyResults = getReportHistoryResults(driver);
        List<Report.ReportOutput> historyResultsData = historyResults.data;

        int reportSpecId = 0;
        for (Report.ReportOutput historyData : historyResultsData) {

            if (historyData.reportName.equals(ReportTypeEnum
                    .EXCESSIVE_MILEAGE_REPORT.getName()) && DateTimeUtils.formatDate(driver,
                    historyData.executionStart.replaceAll("Z", "+0000"),
                    API_DATE_FORMAT, UI_DATE_FORMAT).equals
                    (curDate)) {

                reportSpecId = historyData.reportSpecId;
                break;
            }
        }

        assertTrue(reportSpecId > 0, "Report does not exist");

        Report.ReportData reportData = getActiveReportData
                (driver, reportSpecId);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord
                (driver, reportData, assetData, API_DATE_FORMAT,
                        CELL_DATE_FORMAT);

        //Get the Excessive Mileage Report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());
    }
}
