package com.procon.vehiclefinance.services;

import com.spireon.automotive.cdm.v1.dto.CollectionResource;
import com.spireon.automotive.cdm.v1.dto.LenderDealerPartnershipDto;
import com.spireon.automotive.client.settings.ClientSettings;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DealerService extends ServiceCaller{

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DealerService.class);

    private ClientSettings clientSettings;
    private RestTemplate restTemplate;

    public DealerService(ClientSettings clientSettings) {
        this.restTemplate = new RestTemplate();
        this.clientSettings = clientSettings;
    }

    /**
     * Get Dealer data.
     *
     * @param token
     * @param queryParams
     * @return
     */
    public CollectionResource<LenderDealerPartnershipDto> getDealer(String token, Map<String,
            Object> queryParams) {

        //Using restTemplate
        String url = this.clientSettings.getBaseUrl();

        //Add query parameters to the URL
        StringBuffer updatedUrl = new StringBuffer();
        updatedUrl.append(url).append("?");
        Iterator it = queryParams.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            updatedUrl.append(pair.getKey().toString()).append("=").append(pair.getValue().toString());
            if (it.hasNext()) {
                updatedUrl.append("&");
            }
        }

        HttpHeaders headers = this.prepareHttpHeaders(token);
        HttpEntity<LenderDealerPartnershipDto> request = new HttpEntity((Object)null, headers);
        ResponseEntity<CollectionResource<LenderDealerPartnershipDto>> entity = this.restTemplate.exchange(updatedUrl.toString(),
                HttpMethod.GET, request, new ParameterizedTypeReference<CollectionResource<LenderDealerPartnershipDto>>() {
        }, new Object[0]);
        return (CollectionResource)entity.getBody();
    }

    /**
     * Get Dealer data with default parameters.
     *
     * @param token
     * @return
     */
    public CollectionResource<LenderDealerPartnershipDto> getDealer(String token) {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max","50");
        queryParams.put("filterOperator","or");
        queryParams.put("filters","[]");
        queryParams.put("sort", "name:asc");
        queryParams.put("limit", 50);
        queryParams.put("offset",0);

        return getDealer(token, queryParams);
    }

    /**
     * Get Dealer data with given search term.
     *
     * @param token
     * @param searchText
     * @return
     */
    public CollectionResource getDealer(String token, String searchText) {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max","50");
        queryParams.put("limit", "50");
        queryParams.put("sort", "name:asc");
        queryParams.put("term", searchText);

        return getDealer(token, queryParams);
    }

    /**
     * Get Dealer data with given dealer status.
     *
     * @param token
     * @param dealerStatusActive
     * @return
     */
    public CollectionResource getDealer(String token, boolean dealerStatusActive) {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max","50");
        queryParams.put("offset", 0);
        queryParams.put("limit", "50");
        queryParams.put("sort", "name:asc");
        queryParams.put("term", "");
        queryParams.put("dealerStatusActive", dealerStatusActive);

        return getDealer(token, queryParams);
    }

    /**
     * Prepare http headers for given token
     *
     * @param jwtToken
     * @return
     */
    private HttpHeaders prepareHttpHeaders(String jwtToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String correlationId = MDC.get("correlation");
        headers.add("X-Nspire-CorrelationId", correlationId);
        headers.add("Authorization", "Bearer " + jwtToken);
        return headers;
    }
}