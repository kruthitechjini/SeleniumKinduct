package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class AdminGroupsPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminGroupsPage.class.getName());

    @FindBy(css = ".pull-right.btn.btn-sm.btn-primary.gridButton")
    private WebElement addGroupBtn;

    @FindBy(css = ".row [name='name']")
    private WebElement groupNameInput;

    @FindBy(css = "div.group-edit-role-filter > select")
    private WebElement roleDropdown;

    //Define a WebElement that captures the container which holds all the check boxes, using css
    @FindBy(css = "div.row > div.col-xs-5:nth-child(1) tbody")
    private WebElement availableUserList;

    //Define a WebElement that captures the container which holds all the check boxes, using css
    @FindBy(css = "div.row > div.col-xs-5.form-group tbody")
    private WebElement selectedUserList;

    //From grid rows
    private final String fromGridRows_css = "div.row > div.col-xs-5 tbody:nth-child(1) tr";
    @FindBy(css = fromGridRows_css)
    private WebElement fromGridRows;

    // TODO once 'name' attributes are added, fix the CSS
    @FindBy(css = "div.col-xs-5:nth-of-type(1) div.grid-head input")
    private WebElement selectAllAvailableChkBox;

    @FindBy(css = "div.col-xs-5:nth-of-type(3) div.grid-head input")
    private WebElement selectAllSelectedChkBox;

    @FindBy(css = "button.add")
    private WebElement addUsersBtn;

    @FindBy(css = "button.rem")
    private WebElement removeUsersBtn;

    private static final String CANCEL_BTN_CSS = "div.modal-footer > button.btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    private static final String SAVE_BTN_CSS = "div.modal-footer > button.btn-primary";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "textarea[name='description']")
    private WebElement commentsInput;



    public AdminGroupsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickAddGroupBtn() {
        waitUntilSpinnerInvisible(driver, 15);
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(addGroupBtn)).click();
    }

    public void deleteGroup(String name) {
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 15);
        super.editSearchedRecord(name);

        removeUsersFromGroup(true, null);
        clickSave();
        search(name);
        super.deleteRecord();
    }

    /**
     * Create a group and add users to it
     *
     * @param name
     * @param roleFilter
     * @param selectAll
     * @param users
     * @param comments
     */
    public void createGroup(String name, String roleFilter, Boolean
            selectAll, List<String> users, String comments) {
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 15);
        enterName(name);
        addUsersToGroup(roleFilter, selectAll, users);
        enterComments(comments);
        clickSave();
    }

    /**
     * Update a group, optionally adding or removing users from it
     *
     * @param name
     * @param roleFilter
     * @param selectAllAdd
     * @param usersToAdd
     * @param selectAllRemove
     * @param usersToRemove
     * @param comments
     */
    public void updateGroup(String name, String roleFilter, Boolean
            selectAllAdd, List<String> usersToAdd, Boolean selectAllRemove,
                            List<String> usersToRemove, String comments) {
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 15);
        enterName(name);
        removeUsersFromGroup(selectAllRemove, usersToRemove);
        addUsersToGroup(roleFilter, selectAllAdd, usersToAdd);
        enterComments(comments);
        clickSave();
    }

    /**
     * Add users to the group
     *
     * @param roleFilter
     * @param selectAll
     * @param users
     */
    public void addUsersToGroup(String roleFilter, Boolean selectAll,
                                List<String> users) {
        waitUntilSpinnerInvisible(driver, 15);
        if (roleFilter != null) {
            new Select(roleDropdown).selectByVisibleText(roleFilter);
        }
        // need to catch the exception because there can be valid test
        // scenarios which have no available users. In that case, we log a
        // warning and continue instead of failing
        waitUntilAvailableUsersGridIsLoaded();

        if (selectAll) {
            selectAllAvailableChkBox.click();
        }
        if (users != null) {
            selectUsers(availableUserList, users);
        }

        if (selectAll || users != null) {
            new WebDriverWait(driver, 10).until(
                    elementToBeClickable(addUsersBtn))
                    .click();
        }
    }

    public void waitUntilAvailableUsersGridIsLoaded() {
        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .visibilityOfNestedElementsLocatedBy(availableUserList, By
                            .cssSelector("div.no-wrap")));
        } catch (TimeoutException e) {
            logger.log(Level.WARNING, "Available User list has 0 users");
        }
    }

    /**
     * Remove users from group
     *
     * @param selectAll
     * @param users
     */
    public void removeUsersFromGroup(Boolean selectAll, List<String> users) {
        waitUntilSpinnerVisibleThenInvisible(driver,1,30);
        waitUntilAvailableUsersGridIsLoaded();

        if (selectAll) {
            new WebDriverWait(driver,10).until(ExpectedConditions
                    .elementToBeClickable(selectAllSelectedChkBox)).click();
        }
        if (users != null) {
            selectUsers(selectedUserList, users);
        }
        if (selectAll || users != null) {
            new WebDriverWait(driver, 10).until(
                    elementToBeClickable(removeUsersBtn))
                    .click();
        }
    }

    public void enterName(String groupName) {
        if (groupName != null) {
            waitUntilSpinnerInvisible(driver, 30);
            //wait till the modal is ready by checking the name field
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(groupNameInput)).clear();
            groupNameInput.sendKeys(groupName);
        }
    }

    public void enterComments(String comments) {
        if (comments != null) {

            //wait till the modal is ready
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(commentsInput)).clear();
            commentsInput.sendKeys(comments);
        }
    }

    public void clickSave() {
        // wait for button to be clickable and click
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(saveBtn)).click();
    }

    public void cancelForm() {
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(cancelBtn)).click();
    }

    private void selectUsers(WebElement listElement, List<String> users) {
        String format = "//div[text()='%s']/ancestor::tr/descendant::input";
        for (String user : users) {
            String xpath = String.format(format, user);
            listElement.findElement(By.xpath(xpath)).click();
        }
    }

    public WebElement getAddGroupBtn() {
        return addGroupBtn;
    }
}