package com.procon.vehiclefinance.models;

public class ScheduledCommand {
    private String name;
    private String command;
    private String frequency;
    private String startDate;
    private String startTime;

    private ScheduledCommand(String name, String command, String frequency, String
            startDate, String startTime) {
        this.name = name;
        this.command = command;
        this.frequency = frequency;
        this.startDate = startDate;
        this.startTime = startTime;
    }

    public String getName() {
        return name;
    }

    public String getCommand() {
        return command;
    }

    public String getFrequency() {
        return frequency;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public static class ScheduledCommandBuilder {
        private String name;
        private String command;
        private String frequency;
        private String startDate;
        private String startTime;

        public ScheduledCommandBuilder name(String name) {
            this.name = name;
            return this;
        }

        public ScheduledCommandBuilder command(String command) {
            this.command = command;
            return this;
        }

        public ScheduledCommandBuilder frequency(String frequency) {
            this.frequency = frequency;
            return this;
        }

        public ScheduledCommandBuilder startDate(String startDate) {
            this.startDate = startDate;
            return this;
        }

        public ScheduledCommandBuilder startTime(String startTime) {
            this.startTime = startTime;
            return this;
        }

        public ScheduledCommand build() {
            return new ScheduledCommand(name, command, frequency, startDate, startTime);
        }
    }
}
