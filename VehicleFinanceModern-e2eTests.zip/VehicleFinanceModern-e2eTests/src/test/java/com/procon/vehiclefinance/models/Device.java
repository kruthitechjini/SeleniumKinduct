package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.services.DateDeserializer;
import com.procon.vehiclefinance.services.ServiceCaller;
import org.bson.BsonDateTime;

import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * This class defines the objects needed to handle the various response
 * objects from Device service calls
 */
public class Device {

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class DeviceDetail {
        public String accountGlobalId;
        public long accountId;
        public String accountName;
        public String accountUniqueId;
        public Integer deviceId;
        public String deviceGlobalId;
        public Integer assetId;
        public String address;
        public String name;
        public String assetName;
        public String serial;
        public String serialNumber;
        public String assetGroupName;

        @JsonDeserialize(using = DateDeserializer.class)
        public Date networkRenewalDate;

        @JsonDeserialize(using = DateDeserializer.class)
        public Date networkInstallDate;

        public String assetGlobalId;
        public Integer operatorId;
        public String assetVin;
        public Integer satellites;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceData {
        public List<DeviceDetail> data;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    public static class DeviceAlert {
        public String _class;
        public String globalId;
        public Integer alertTypeId;
        public String eventId;
        public String stateId;
        public Integer accountId;
        public String accountGlobalId;
        public Integer deviceId;
        public String deviceGlobalId;
        public Integer assetId;
        public String assetGlobalId;
        public Integer operatorId;
        public String assetName;
        public String locationName;
        public BsonDateTime alertDate;
        public Double lat;
        public Double lng;
        public Double odomoter;
        public Double heading;
        public Integer speed;
        public String address;
        public String city;
        public String state;
        public String zip;
        public Boolean active;
        public Boolean acknowledged;
        public String assetVin;
        public String serialNumber;
        public String alertTypeName;
        public BsonDateTime dateCreated;
        public Integer rss;
        public Double extVolts;
        public Integer satellites;
        public Double assetDistanceSum;
        public Integer alertHourOfDay;
        public String eventTypeName;
        public Integer totalCost;
    }

    public static class AssetTransferResponse {
        public boolean success;
        public String msg;
        public int count;
    }

    public static DeviceAlert createDeviceAlertObject(User.UserSettings userSettings,
                                                      Alert.AlertType alertType,
                                                      Device.DeviceDetail deviceDetail) {

        Device.DeviceAlert alert = new Device.DeviceAlert();
        alert._class = "com.procon.p7.vortex.DeviceAlert";
        String uuid = UUID.randomUUID().toString();
        alert.globalId = UUID.randomUUID().toString();
        alert.alertTypeId = alertType.id;
        alert.eventId = uuid;
        alert.stateId = uuid;
        alert.accountId = userSettings.accountId;

        alert.accountGlobalId = deviceDetail.accountGlobalId;
        alert.deviceId = deviceDetail.deviceId;
        alert.deviceGlobalId = deviceDetail.deviceGlobalId;
        alert.assetId = deviceDetail.assetId;
        alert.assetGlobalId = deviceDetail.assetGlobalId;
        alert.operatorId = deviceDetail.operatorId;
        alert.assetName = deviceDetail.assetName;
        alert.alertDate = new BsonDateTime(System.currentTimeMillis());
        alert.lat = 33.698853;
        alert.lng = -117.79864;
        alert.odomoter = 0d;
        alert.heading = 100d;
        alert.speed = 0;
        alert.address = "172 Deerfield Ave";
        alert.city = "Irvine";
        alert.state = "CA";
        alert.zip = "92606";
        alert.active = true;
        alert.acknowledged = false;
        alert.assetVin = deviceDetail.assetVin;
        alert.serialNumber = deviceDetail.serialNumber;
        alert.alertTypeName = alertType.name;
        alert.dateCreated = new BsonDateTime(System.currentTimeMillis());
        alert.rss = 29;
        alert.extVolts = 13.8;
        alert.satellites = deviceDetail.satellites;
        alert.assetDistanceSum = 444390301.959116;
        alert.alertHourOfDay = 20;
        alert.eventTypeName = alertType.description;
        alert.totalCost = 1;

        return alert;
    }

    public static class DeviceReferencesData {
        public int count;
        public List<DeviceReferencesDetail> data;
        public String msg;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceReferencesDetail {
        public String name;
        public long id;
    }

    public static class LandmarkData {
        public List<LandmarkDetail> content;
        public int max;
        public int offset;
        public int total;
    }

    public static class LandmarkDetail {
        public String city;
        public String dateCreated;
        public String dateUpdated;
        public String globalId;
        public String landmarkType;
        public String lat;
        public String lng;
        public String name;
        public String state;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceGeoFencesData {
        public List<DeviceGeoFencesDetail> data;
        public String errors;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceGeoFencesDetail {
        public String name;
        public String id;
        public String status;
        public String type;
        public String address;
        public String city;
        public String state;
        public String country;
        public String zip;
        public Double lat;
        public Double lng;
        public Integer assignedDevicesCount;
        public String mode;
    }

    public static class AssetApiData {
        public AssetApiDetail data;
        public String msg;
        public boolean success;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AssetApiDetail {
        public String status;
        public String locationLastReported;
        public Integer speed;
        public LastLocation lastLocation;
        public Double odometer;
    }

    public static class LastLocation {
        public Address address;
        public Double lat;
        public Double lng;
    }

    public static class Address {
        public String city;
        public String line1;
        public String postalCode;
        public String stateOrProvince;
    }

    public static class DeviceNotesData {
        public int count;
        public List<DeviceNotesDetail> data;
        public int max;
        public String msg;
        public int offset;
        public boolean success;
        public int total;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceNotesDetail {
        public String body;
        public String subject;
        public NotesUser usr;
        public String timestamp;
    }

    public static class NotesUser {
        public String firstName;
        public String lastName;
        public String userId;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceCommands {
        public List<DeviceCommandsData> data;
        public String errors;
        public int max;
        public String msg;
        public int total;
        public boolean success;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DeviceCommandsData {
        public String name;
        public String frequencyName;
        public Date lastRunDate;
        public Date nextRunDate;
        public List<DeviceDetail> assets;
        public String deviceCommandTypeName;
    }
}
