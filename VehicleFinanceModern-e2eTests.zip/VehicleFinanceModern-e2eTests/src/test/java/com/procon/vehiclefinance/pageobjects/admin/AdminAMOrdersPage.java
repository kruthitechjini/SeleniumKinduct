package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Account;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.procon.vehiclefinance.pageobjects.CommonGrid;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

public class AdminAMOrdersPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminAMOrdersPage.class.getName());

    @FindBy(css = "#adminManageTab a[href='#renew-tab']")
    protected WebElement renewTab;

    @FindBy(css = "#adminManageTab li.active a")
    protected WebElement activeTabLink;

    @FindBy(css = "div.panel-fill-height")
    protected WebElement ordersPanel;

    @FindBy(css = "div.panel-fill-height div.ember-table-tables-container")
    protected WebElement ordersTable;

    @FindBy(css = "div.command-spec-vehicle-panel")
    protected WebElement orderDetailsTable;

    @FindBy(css = "#modal[style='display: block;']")
    protected WebElement modalWindow;

    @FindBy(css = "div.modal-footer button.btn-cancel")
    protected WebElement modalCancelButton;

    @FindBy(css = "h4.modal-title")
    private WebElement modalWindowTitle;

    @FindBy(css = "a[title='View']")
    private WebElement viewLink;

    @FindBy(css = "dl.dl-horizontal > dt")
    private List<WebElement> keyList;

    @FindBy(css = "dl.dl-horizontal > dd")
    private List<WebElement> valueList;

    @FindBy(css = "div.modal-content div.ember-view.ui-sortable")
    private WebElement columnHeaderModalWindow;

    @FindBy(css = "button.close")
    private WebElement closeBtn;

    public AdminAMOrdersPage(WebDriver driver) {
        super(driver);
    }

    public HashMap<String, String> getLastOrder() {
        return getTableFirstRow(ordersTable);
    }

    public AdminAccountManagementPage openRenewTab() {
        if (activeTabLink.getAttribute("href").contains("orders-tab")) {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.elementToBeClickable(renewTab)).click();
        }
        return PageFactory.initElements(driver, AdminAccountManagementPage.class);
    }

    public void waitForNewOrder(HashMap<String, String> lastOrder, Integer timeout) {
        waitForNewTableRecord(ordersTable, lastOrder, timeout);
    }

    /**
     * Waiting for Order Complete
     * @param timeout - timeout in sec
     */
    public void waitForOrderComplete(Integer timeout) {
        Integer sleepTime = 2000;
        Integer timeSpent = 0;

        while (timeSpent < (timeout * 1000)) {
            clickRefreshBtn();
            if (getTableFirstRow(ordersTable).get("Order Status").equals("COMPLETED")) {
                break;
            }
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException ie) {
            }
            timeSpent = timeSpent + sleepTime;
        }
    }

    public HashMap<String, String> getLastOrderDetails() {
        String actionButtonLocator = firstRowLocator + " " + cellLocator + "  a[title='View']";
        WebElement viewButton = ordersTable.findElement(By.cssSelector(actionButtonLocator));
        viewButton.click();
        WebDriverWait waitModalOpened = new WebDriverWait(driver, 10);
        waitModalOpened.until(ExpectedConditions.elementToBeClickable(modalCancelButton));

        HashMap<String, String> orderDetails = getTableFirstRow(orderDetailsTable);

        modalCancelButton.click();
        WebDriverWait waitModalClosed = new WebDriverWait(driver, 1);
        waitModalClosed.until(ExpectedConditions.invisibilityOfElementLocated(By.id("modal")));

        return orderDetails;
    }

    public WebElement getViewLink() {
        return viewLink;
    }

    /**
     * Validate grid data format
     *
     * @param firstRowData
     * @param DATE_FORMAT
     */
    public void validateDataFormat(HashMap<String, String> firstRowData, DateFormat DATE_FORMAT) {

        //Validate order number
        assertTrue(firstRowData.get("Order No.").matches("^[G][-]\\d{6}$"));

        //Validate date submitted
        String dateTime = firstRowData.get("Date Submitted");

        DATE_FORMAT.setLenient(false);
        try {
            DATE_FORMAT.parse(dateTime);
        } catch (ParseException e) {
            assertNotEquals(e.getMessage(), "Unparseable date: " + "\"" + dateTime +
                    "\"", "Date Submitted is not " + "formatted as MM/dd/yyyy h:mm AM|PM ");
        }

        //Validate item count
        assertTrue(firstRowData.get("Item Count").matches("^\\d+$"));

        //Validate order total
        assertTrue(firstRowData.get("Order Total").matches("^\\$\\d+\\.\\d{2}$"));

        //Validate order status
        String orderStatus = firstRowData.get("Order Status");
        assertTrue(orderStatus.equals("PENDING") || orderStatus.equals("SUBMITTED")
                || orderStatus.equals("COMPLETED"));

        //Validate view link is displayed in action column
        assertTrue(getViewLink().isDisplayed());
    }

    /**
     * Validate order details data with data in orders grid
     *
     * @param firstRowData
     */
    public void validateOrderDetailsData(HashMap<String, String> firstRowData) {

        assertEquals(keyList.get(0).getText(), "Order Id:");
        assertEquals(keyList.get(1).getText(), "Status");
        assertEquals(valueList.get(0).getText(), firstRowData.get("Order No."));
        assertEquals(valueList.get(1).getText(), firstRowData.get("Order Status"));
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }

    public List<String> getModalWindowGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeaderModalWindow.findElements(By.cssSelector("span.ember-table-content"));

        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getOrderDetailsTable() {
        return orderDetailsTable;
    }

    public String getOrderTotalInOrderDetails() {

        List<HashMap<String, String>> orderDetailsDataList = getTable(orderDetailsTable,
                "div.ember-table-header-cell", "div.ember-table-body-container " +
                        "div.ember-table-table-row:not([style*='display:none;']) div.ember-table-cell");

        Double orderTotal = 0.0;
        for (HashMap<String, String> orderDetailsData : orderDetailsDataList) {
            //skip empty row in IE
            if (orderDetailsData.get("Device Name").isEmpty()) continue;

            orderTotal = orderTotal + Double.parseDouble(orderDetailsData.get("Price").replace("$", "")) +
                    Double.parseDouble(orderDetailsData.get("Tax").replace("$", ""));
        }
        return ("$" + String.format("%.2f", orderTotal));
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    /**
     * Get First Record from API
     *
     * @param orderData
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<Account.OrderData> orderData) {

        HashMap<String, String> apiFirstRecord = new LinkedHashMap<>();

        apiFirstRecord.put("Order No.", orderData.get(0).externalOrderId);
        apiFirstRecord.put("Date Submitted", orderData.get(0).dateSubmitted);
        apiFirstRecord.put("Item Count", Integer.toString(orderData.get(0).items.size()));
        apiFirstRecord.put("Order Total", "$" + orderData.get(0).orderTotal);

        //TODO Status for PENDING/SUBMITTED needs to be added
        if (orderData.get(0).status.equals("SHIPPED") || orderData.get(0).status.equals("CANCELLED")) {
            apiFirstRecord.put("Order Status", "COMPLETED");
        }

        return apiFirstRecord;
    }

    /**
     * Get First Record from API for order details
     *
     * @param orderData
     * @return
     */
    public HashMap<String, String> getApiFirstRecordOrderDetails(List<Account.OrderData> orderData) {

        final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.#");
        DECIMAL_FORMAT.setMinimumFractionDigits(2);

        HashMap<String, String> apiFirstRecord = new LinkedHashMap<>();

        apiFirstRecord.put("Device Name", orderData.get(0).items.get(0).deviceSerialNumber);
        apiFirstRecord.put("Price", "$" + DECIMAL_FORMAT.format(orderData.get(0).items.get(0).unitPrice));
        apiFirstRecord.put("Tax", "$" + DECIMAL_FORMAT.format(orderData.get(0).items.get(0).tax));

        if (orderData.get(0).items.get(0).renewalProductId == 204)
            apiFirstRecord.put("Expires On", "Unknown");

        return apiFirstRecord;
    }

    public void clickCloseBtn() {
        clickElementAndWaitForInvisibility(driver, modalCancelButton, By.id("modal"));
    }
}
