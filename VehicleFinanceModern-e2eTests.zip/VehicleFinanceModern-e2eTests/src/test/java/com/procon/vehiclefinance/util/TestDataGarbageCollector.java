package com.procon.vehiclefinance.util;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.reports.Report;
import com.procon.vehiclefinance.pageobjects.reports.ReportsLeftBarPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.procon.vehiclefinance.services.ContactService.deleteContact;
import static com.procon.vehiclefinance.services.ReportService.getSavedReports;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class TestDataGarbageCollector extends BaseTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(TestDataGarbageCollector.class);

    private NavbarHeaderPage navbarHeaderPage;

    /**
     * Method removes all Contacts/Recipients searched by command line parameter -PsearchKey
     * -PuserName=bhphdealer, -Ppassword=password, -PrenewalsPage=N should coming from command line
     *
     * @throws UnirestException
     */
    @Test(description = "Clean garbage Admin -> Recipients", groups = {"garbage"})
    public void cleanGarbageRecipients(ITestContext testContext) throws UnirestException {

        String searchStr = System.getProperty("searchKey");

        if (searchStr == null || searchStr.isEmpty() ) {
            fail("Search string for Recipient garbage collertor should contain a Recipients name pattern, email, phone");
        }

        login();

        deleteContact(driver, searchStr);
    }

    /**
     * Clean saved reports searched by command line parameter -PsearchKey="name or part of name"
     * -PuserName=bhphdealer, -Ppassword=password, -PrenewalsPage=N should coming from command line
     */
    @Test(description = "Clean saved reports", groups = {"garbage"})
    public void cleanSavedReports() throws UnirestException {

        String searchStr = System.getProperty("searchKey");

        if (searchStr == null || searchStr.isEmpty()) {
            fail("Search string for Saved Report garbage collertor should contain a saved report name pattern");
        }

        login();
        LOGGER.info("Logged in as " + userName);

        //Go to reports
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        navbarHeaderPage.clickReports();
        ReportsLeftBarPage reportsLeftBarPage = PageFactory.initElements(driver, ReportsLeftBarPage.class);

        //Get the list of saved reports
        waitUntilSpinnerVisibleThenInvisible(driver, 3, 10);
        reportsLeftBarPage.getSavedReportsNameList().forEach(reportName -> {
            if(reportName.contains(searchStr)) {
                try {
                    deleteSavedReport(reportsLeftBarPage, reportName);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (UnirestException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void deleteSavedReport(ReportsLeftBarPage reportsLeftBarPage, String reportName) throws IOException, UnirestException {

        reportsLeftBarPage.deleteSavedReport(reportName);
        //Get saved reports data through service call to validate that the report was deleted
        Report.SavedReportResults savedReportsResponse = null;
        savedReportsResponse = getSavedReports(driver);

        List<String> savedReportList = new ArrayList<>();
        savedReportsResponse.data.forEach(savedReport -> savedReportList.add(savedReport.userName));
        assertFalse(savedReportList.contains(reportName), "Saved report '" + reportName + "' not deleted");
        LOGGER.info("Saved report " + reportName + " DELETED");
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            // press escape key to dismiss advanced reports page if present
            new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }
}
