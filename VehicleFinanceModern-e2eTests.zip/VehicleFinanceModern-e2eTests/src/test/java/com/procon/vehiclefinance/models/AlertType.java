package com.procon.vehiclefinance.models;

import java.util.ArrayList;

/**
 * Created by sdhume on 8/18/17.
 */
public enum AlertType {
    AUTO_REPORT("Auto Report"),
    BATTERY_DISCONNECT("Battery Disconnect"),
    DRIVE_REPORT("Drive Report"),
    GEOFENCES("GeoFences"),
    GEOZONE_ALERT("GeoZone Alert"),
    IMPOUND_LOT("Impound Lot"),
    LOW_BATTERY_VOLTAGE("Low Battery Voltage"),
    MAX_SPEED("Max Speed"),
    POWER_UP_WITH_GPS("Power Up with GPS"),
    STOP_REPORT("Stop Report"),
    TOW_ALERT("Tow Alert"),
    VEHICLE_ABANDONMENT("Vehicle Abandonment");

    private String alertType;

    AlertType(String alertType) {
        this.alertType = alertType;
    }

    public String getAlertType() {
        return alertType;
    }

    public static ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        for (AlertType alertType : AlertType.values()) {
            values.add(alertType.getAlertType());
        }
        return values;
    }
}