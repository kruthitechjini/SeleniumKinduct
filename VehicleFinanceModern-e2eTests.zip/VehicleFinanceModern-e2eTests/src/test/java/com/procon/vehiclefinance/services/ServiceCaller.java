package com.procon.vehiclefinance.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.admin.User;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Set;

public class ServiceCaller {

    protected static String baseUrl;
    private static String userSettingsEndpoint;

    static {
        baseUrl = System.getProperty("baseUrl");
        userSettingsEndpoint = baseUrl + "extJs/userSettings";

        // set Unirest to map responses to objects
        Unirest.setObjectMapper(new com.mashape.unirest.http.ObjectMapper() {
            private com.fasterxml.jackson.databind.ObjectMapper jacksonObjectMapper
                    = new com.fasterxml.jackson.databind.ObjectMapper();

            //DateDeserializer.class using for deserializing Date value
            @Override
            public <T> T readValue(String value, Class<T> valueType) {
                try {
                    return jacksonObjectMapper.readValue(value, valueType);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public String writeValue(Object value) {
                try {
                    return jacksonObjectMapper.writeValueAsString(value);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    /**
     * Get the user settings. These settings contain some user related info
     * like userId, accountId, first/last name etc. See:
     * {@link com.procon.vehiclefinance.pageobjects.admin.User.UserSettings UserSettings}
     *
     * @param driver WebDriver object
     * @return UserSettings object
     * @throws UnirestException
     * @throws IOException
     */
    public static User.UserSettings getUserSettings(WebDriver driver) throws UnirestException, IOException {
        HttpResponse<String> response = Unirest.get
                (userSettingsEndpoint)
                .header("Cookie", getDriverCookies(driver))
                .asString();
        // the response is not a true Json object, it has some var declaration:
        // "var userSettings = {...}"
        String userString = response.getBody();
        String json = userString.substring(userString.indexOf("{"));

        // map the json string to object
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, User.UserSettings.class);
    }

    protected static String getDriverCookies(WebDriver driver) {
        Set<Cookie> cookies = driver.manage().getCookies();
        StringBuilder cookie = new StringBuilder();
        for (Cookie c : cookies) {
            cookie.append(c.getName());
            cookie.append("=");
            cookie.append(c.getValue());
            cookie.append(";");
        }
        return cookie.toString();
    }

    /**
     * Get cookie value for the given cookie name.
     *
     * @param driver
     * @param cookieName
     * @return
     */
    public static String getCookieValue(WebDriver driver, String cookieName) {

        Set<Cookie> cookies = driver.manage().getCookies();
        String cookieValue = null;
        for (Cookie c : cookies) {
            if (c.getName().equals(cookieName)) {
                cookieValue = c.getValue();
            }
        }
        return cookieValue;
    }
}
