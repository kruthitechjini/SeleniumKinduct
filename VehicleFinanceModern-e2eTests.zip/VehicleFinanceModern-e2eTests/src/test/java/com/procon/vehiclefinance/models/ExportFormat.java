package com.procon.vehiclefinance.models;

public enum ExportFormat {
    CSV("csv"),
    PDF("pdf"),
    XLS("xls");

    private String type;

    ExportFormat(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}

