package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.models.Vehicles;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.util.WebElements;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class VehiclesPage extends CommonGrid {

    private static final String RECOVERY_COMPANY_NAME = "company";

    //Create map of features and their locators
    private HashMap<String, String> featureLocatorMap = new HashMap<>();

    //Create map of elements and their locators
    private HashMap<String, String> elementLocatorMap = new HashMap<>();

    //Map all button when active
    static final String MAP_ALL_WHEN_ACTIVE_CSS = "a.btn-map-all-list.icon-map-all" +
            ".active";
    @FindBy(css = MAP_ALL_WHEN_ACTIVE_CSS)
    private WebElement mapAllWhenActive;

    @FindBy(css = "div.leaflet-marker-pane > img")
    protected List<WebElement> mapMarkers;

    static final String SUCCESS_BUBBLE_CSS = "span.status-success";
    @FindBy(css = SUCCESS_BUBBLE_CSS)
    private WebElement bubbleSuccessIcon;

    // used when there are multiple bubbles on the page
    @FindBy(css = SUCCESS_BUBBLE_CSS)
    private List<WebElement> bubbleSuccessIcons;

    static final String BUBBLE_CSS = "div.command-status";
    @FindBy(css = BUBBLE_CSS)
    private List<WebElement> bubbleIcons;

    @FindBy(css = "div.command-status div.container")
    private WebElement bubbleTitle;

    // used when there are multiple bubbles on the page
    @FindBy(css = "div.command-status div.container")
    private List<WebElement> bubbleTitles;

    @FindBy(css = "div.leaflet-marker-pane img")
    private WebElement geoFenceViewMarker;

    @FindBy(css = "div.modern-bubble-headline-title.ellipsis")
    private WebElement geoFenceViewLinkBubbleHeader;

    protected static final Logger logger = LoggerFactory
            .getLogger(VehiclesPage.class.getName());

    static final String MAP_GRID_CSS = "ol.list-unstyled > li";
    @FindBy(css = MAP_GRID_CSS)
    private WebElement mapGrid;

    static final String LIST_GRID_CSS = "div.antiscroll-inner div.ember-view.ember-table-table-row.ember-table-last-row";
    @FindBy(css = LIST_GRID_CSS)
    private WebElement listGrid;

    static final String ADVANCED_FILTER_CSS = ".fa.fa-lg.fa-filter";
    @FindBy(css = ADVANCED_FILTER_CSS)
    private WebElement advancedFilter;

    static final String GROUPS_DROPDOWN_CSS = "select.mapVehicleGroupFilter:not([name])";
    @FindBy(css = GROUPS_DROPDOWN_CSS)
    private WebElement groupsDropdown;

    @FindBy(css = "div.modal div.col-xs-4.vehicle-details-device-container.left-divider > div:nth-child(2) label")
    private WebElement groupsLabel;

    static final String GROUP_FILTER_CSS = "select.ember-view.ember-select" +
            ".form-control.input-sm.mapVehicleGroupFilter";
    @FindBy(css = GROUP_FILTER_CSS)
    private WebElement groupFilter;

    //depends on user class can be vehicle-list-scroll or vehicle-list-scroll-status
    static final String VEHICLES_LIST_CSS = "div[class^='vehicle-list-scroll']";
    @FindBy(css = VEHICLES_LIST_CSS)
    private WebElement vehiclesList;

    static final String MAP_ZOOM_IN_CSS = "[title='Zoom in']";
    @FindBy(css = MAP_ZOOM_IN_CSS)
    private WebElement mapZoomIn;

    static final String MAP_ZOOM_OUT_CSS = "[title='Zoom out']";
    @FindBy(css = MAP_ZOOM_OUT_CSS)
    private WebElement mapZoomOut;

    static final String RESIZE_PAGE_CSS = "div.vehicles-container.horizontal" +
            ".split-layout div.grippy";
    @FindBy(css = RESIZE_PAGE_CSS)
    private WebElement resizePage;

    static final String PREVIOUS_PAGE_CSS = "[title='Previous']";
    @FindBy(css = PREVIOUS_PAGE_CSS)
    private WebElement previousPage;

    static final String NEXT_PAGE_CSS = "[title='Next']";
    @FindBy(css = NEXT_PAGE_CSS)
    private WebElement nextPage;

    static final String REFRESH_PAGE_CSS = "i.fa-refresh";
    @FindBy(css = REFRESH_PAGE_CSS)
    private WebElement refreshPage;

    static final String DEVICE_STATUS_CSS = "label[for='deviceStatus']";
    @FindBy(css = DEVICE_STATUS_CSS)
    private WebElement deviceStatus;

    static final String STARTER_STATUS_CSS = "label[for='starter']";
    @FindBy(css = STARTER_STATUS_CSS)
    private WebElement startterStatus;

    static final String WARNING_STATUS_CSS = "label[for='warning']";
    @FindBy(css = WARNING_STATUS_CSS)
    private WebElement warningStatus;

    static final String REPORTING_CSS = "label[for='reporting']";
    @FindBy(css = REPORTING_CSS)
    private WebElement reportingFilter;

    static final String SELECT_ALL_CHECK_BOX_CSS = "input.ember-view" +
            ".ember-checkbox.vehicles.check-all";
    @FindBy(css = SELECT_ALL_CHECK_BOX_CSS)
    private WebElement selectAllCheckBox;

    @FindBy(css = "li.list-striped:nth-of-type(1) div.no-wrap")
    private WebElement firstVehicleNameDiv;

    static final String LOCATE_BTN_CSS = "a[title='Locate']";
    @FindBy(css = LOCATE_BTN_CSS)
    private WebElement locateBtn;

    static final String MORE_COMMANDS_BTN_CSS = "div.btn-group.pull-right > [type='button']";
    @FindBy(css = MORE_COMMANDS_BTN_CSS)
    private WebElement moreCommandsBtn;

    static final String DRIVE_REPORT_BTN_XPATH = "//a[text()='Drive Report']";
    @FindBy(xpath = DRIVE_REPORT_BTN_XPATH)
    private WebElement driveReportBtn;

    @FindBy(css = "[class='command-menu'] li:nth-child(5) Select")
    private WebElement driveReportDropdown;

    @FindBy(css = "div.modal-body > div > div:nth-child(2) label")
    private WebElement SendCommandEventsLbl;

    @FindBy(css = "div.modal-body > div > div:nth-child(2) input")
    private WebElement SendCommandEventsInput;

    @FindBy(css = "div.modal-body > div > div:nth-child(3) label")
    private WebElement SendCommandIntervalLbl;

    @FindBy(css = "div.modal-body > div > div:nth-child(3) input")
    private WebElement SendCommandIntervalInput;

    @FindBy(css = "div.modal-footer button.btn-cancel")
    private WebElement SendCommandCancelBtn;

    @FindBy(css = "div.modal-footer button.btn-primary")
    private WebElement SendCommandBtn;

    @FindBy(css = "div.form > div:nth-of-type(1) >div > div >span")
    private WebElement SendCommandEventValidationMsg;

    @FindBy(css = "div.form > div:nth-of-type(2) >div > div >span")
    private WebElement SendCommandIntervalValidationMsg;

    static final String STOP_REPORT_BTN_XPATH = "//a[text()='Stop Report']";
    @FindBy(xpath = STOP_REPORT_BTN_XPATH)
    private WebElement stopReportBtn;

    static final String SET_MAX_SPEED_BTN_XPATH = "//a[text()='Set Max Speed']";
    @FindBy(xpath = SET_MAX_SPEED_BTN_XPATH)
    private WebElement setMaxSpeedBtn;

    static final String AUTO_REPORT_BTN_XPATH = "//a[text()='Auto Report']";
    @FindBy(xpath = AUTO_REPORT_BTN_XPATH)
    private WebElement autoReportBtn;

    static final String TOW_ALERT_BTN_XPATH = "//a[text()='Tow Alert']";
    @FindBy(xpath = TOW_ALERT_BTN_XPATH)
    private WebElement towAlertBtn;

    static final String DETAIL_PANEL_HEADING_CSS = "div.panel.panel-default" +
            ".vehicle-detail-panel div.panel-heading";
    @FindBy(css = DETAIL_PANEL_HEADING_CSS)
    private WebElement detailPanelHeading;

    static final String SET_QUICK_FENCE_BTN_CSS = "//button[text()='Set QuickFence']";
    @FindBy(xpath = SET_QUICK_FENCE_BTN_CSS)
    private WebElement setQuickFenceBtn;

    static final String SET_AGAIN_QUICK_FENCE_BTN_XPATH = "//button[text()" +
            "='Set Again']";
    @FindBy(xpath = SET_AGAIN_QUICK_FENCE_BTN_XPATH)
    private WebElement setAgainQuickFenceBtn;

    static final String STARTER_ENABLE_LINK_XPATH = "//span[text()" +
            "='STARTER']/following-sibling::a[1]";
    @FindBy(xpath = STARTER_ENABLE_LINK_XPATH)
    private WebElement starterEnableLink;

    @FindBy(xpath = "//button[text()='GeoFences']")
    private WebElement geoFenceBtn;

    static final String STARTER_DISABLE_LINK_XPATH = "//span[text()" +
            "='STARTER']/following-sibling::a[2]";
    @FindBy(xpath = STARTER_DISABLE_LINK_XPATH)
    private WebElement starterDisableLink;

    static final String STARTER_DISABLE_SEND_BTN_CSS = "button[data-bb-handler='send']";
    @FindBy(css = STARTER_DISABLE_SEND_BTN_CSS)
    private WebElement starterDisableSendButton;

    static final String WARNING_LINK_XPATH = "//span[text()='WARNING']";
    @FindBy(xpath = WARNING_LINK_XPATH)
    private WebElement warningLink;

    static final String STARTER_LINK_XPATH = "//span[text()='STARTER']";
    @FindBy(xpath = STARTER_LINK_XPATH)
    private WebElement starterLink;

    static final String SEARCH_INPUT_CSS = "input.ember-view.ember-text-field" +
            ".search.form-control.input-sm";
    @FindBy(css = SEARCH_INPUT_CSS)
    private WebElement searchInput;

    static final String DETAILS_TAB_CSS = "li.details-tab.active > a";
    @FindBy(css = DETAILS_TAB_CSS)
    private WebElement detailsTab;

    static final String NOTESTAB_CSS = "li.notes-tab > a";
    @FindBy(css = NOTESTAB_CSS)
    private WebElement notesTab;

    static final String GEO_FENCE_TAB_CSS = "li.geofence-tab > a";
    @FindBy(css = GEO_FENCE_TAB_CSS)
    private WebElement geofenceTab;

    static final String STIP_TAB_CSS = "li.stip-tab > a";
    @FindBy(css = STIP_TAB_CSS)
    private WebElement stipTab;

    static final String PROFILE_CHANGES_TAB_CSS = "li.profile-tab > a";
    @FindBy(css = PROFILE_CHANGES_TAB_CSS)
    private WebElement profileChangesTab;

    static final String LOCATIONS_TAB_CSS =
            "a[href='#mostVisitedAddress-tab']"; //".mostVisitedAddress-tab>a";
    @FindBy(css = LOCATIONS_TAB_CSS)
    private WebElement locationsTab;

    static final String RECOVERY_TAB_CSS = "li.recovery-tab > a";
    @FindBy(css = RECOVERY_TAB_CSS)
    private WebElement recoveryTab;

    static final String RECOVERY_LINK_CSS = "a[href^='recovery/']";
    @FindBy(css = RECOVERY_LINK_CSS)
    private WebElement recoveryLink;

    @FindBy(id = "vehicleShowTab")
    private WebElement vehicleShowTab;

    @FindBy(css = "[title='Create']")
    private WebElement createRecoveryLink;

    @FindBy(css = "div.modal-footer button:nth-of-type(1)")
    private WebElement recoveryCancelLink;

    @FindBy(css = "div.modal-footer button:nth-of-type(2)")
    private WebElement recoveryCreateLink;

    @FindBy(css = "li.connect-tab")
    private WebElement connectTab;

    @FindBy(css = " #vehicle-tab-buttons-container > a.gridButton")
    private WebElement connectBtn;

    @FindBy(css = "[name='company']")
    private WebElement recoveryCompanyTxtBox;

    @FindBy(css = "[name='firstName']")
    private WebElement recoveryFirstNameTxtBox;

    @FindBy(css = "[name='lastName']")
    private WebElement recoveryLastNameTxtBox;

    @FindBy(css = "[name='email']")
    private WebElement recoveryEmailTxtBox;

    @FindBy(css = "div.bootbox-body.bootbox-wrap")
    private WebElement recoveryCreatedModalText;

    @FindBy(css = "div.bootbox-body.bootbox-wrap > a")
    private WebElement recoveryCreatedLinkText;

    @FindBy(css = "button.btn.btn.btn-primary.newPrimaryButton")
    private WebElement recoveryLinkTextConfirmation;

    static final String HISTORY_TAB_CSS = "a[href='#30dayhistory-tab']";
    @FindBy(css = HISTORY_TAB_CSS)
    private WebElement historyTab;

    static final String UPGRADES_TAB_CSS = ".upgrades-tab>a";
    @FindBy(css = UPGRADES_TAB_CSS)
    private WebElement upgradesTab;

    static final String QUICK_EDIT_BTN_CSS = "div.action-wrapper a[title='Edit']";
    @FindBy(css = QUICK_EDIT_BTN_CSS)
    private WebElement quickEditBtn;

    static final String EDIT_BTN_CSS = "div" +
            ".vehicles-tab-buttons-container a[title='Edit']";
    @FindBy(css = EDIT_BTN_CSS)
    private WebElement editBtn;

    @FindBy(css = "div.modal-content")
    private WebElement modelWindow;

    static final String VEHICLE_INFO_PRINT_BTN_CSS = "a[title='Print']";
    @FindBy(css = VEHICLE_INFO_PRINT_BTN_CSS)
    private WebElement printBtn;

    @FindBy(css = "[placeholder='First Name']")
    private WebElement operatorFirstNameTxtBox;

    @FindBy(css = "[placeholder='Last Name']")
    private WebElement operatorLastNameTxtBox;

    @FindBy(css = "[placeholder='Email']")
    private WebElement operatorEmailTxtBox;

    @FindBy(css = "[placeholder='Address']")
    private WebElement operatorAddressTxtBox;

    @FindBy(css = "input[name='operatorAddressCity']")
    private WebElement operatorAddressCityTxtBox;

    @FindBy(css = "select[name='country']")
    private WebElement operatorCountryDropDown;

    @FindBy(css = "select[name='operatorAddressState']")
    private WebElement operatorAddressStateDropDown;

    @FindBy(css = "input[name='operatorAddressZip']")
    private WebElement operatorAddressZipTxtBox;

    @FindBy(css = "[name='operatorPhone']")
    private WebElement operatorPhoneTxtBox;

    @FindBy(css = "input[placeholder='Stock Number']")
    private WebElement vehicleStockNumberTxtBox;

    @FindBy(css = "[title='Decode VIN']")
    private WebElement vehicleDecodeVinTxtBox;

    @FindBy(css = "div.modal-footer > button[type='button']")
    private WebElement vinModelOkBtn;

    @FindBy(css = "[placeholder='VIN']")
    private WebElement vehicleVinNumberTxtBox;

    @FindBy(css = "select[name='licensePlateCountry']")
    private WebElement licensePlateCountryDropDown;

    @FindBy(css = "[placeholder='License Plate']")
    private WebElement vehicleLicensePlateTxtBox;

    @FindBy(css = "select[name='licensePlateState']")
    private WebElement licencePlateStateDropDown;

    @FindBy(css = "[placeholder='Initial Odometer']")
    private WebElement vehicleInitialOdometerMilesTxtBox;

    @FindBy(css = "[placeholder='Name']")
    private WebElement deviceDisplayNameTxtBox;

    @FindBy(css = "[name='groupId']")
    private WebElement deviceGroupInputBox;

    @FindBy(css = "[name='deviceStatus']")
    private WebElement deviceInstalledStatusDropDown;

    @FindBy(css = "[name= 'dateInstalled']")
    private WebElement deviceDateInstalledTxtBox;

    private static final String SAVE_BTN_CSS = "[name='modalSave']";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "div.bootbox.modal.fade.bootbox-alert.in > div > div > div.modal-body>div")
    private WebElement invalidVinPopup;

    @FindBy(css = "[placeholder='Make']")
    private WebElement vehicleMakeTxtBox;

    @FindBy(css = "[placeholder='Model']")
    private WebElement vehicleModelTxtBox;

    @FindBy(css = "[placeholder='Year']")
    private WebElement vehicleYearTxtBox;

    @FindBy(css = "[placeholder='Color']")
    private WebElement vehicleColorTxtBox;

    @FindBy(css = "div:nth-child(1) > div > div:nth-child(2) > span")
    private WebElement profileDataRow1Txt;

    @FindBy(css = "div:nth-child(2) > div > div:nth-child(2) > span")
    private WebElement profileDataRow2Txt;

    @FindBy(css = "div.tab-pane.active")
    private WebElement activeTable;

    //Details tab elements
    @FindBy(css = "div#details-tab div:nth-child(1) > ul > li:nth-child(1) > span.info")
    private WebElement firstNameTxt;

    @FindBy(css = "div#details-tab div:nth-child(1) > ul > li:nth-child(2) > span.info")
    private WebElement lastNameTxt;

    @FindBy(css = "div#details-tab li:nth-child(3) > span.info.formatted-address")
    private WebElement addressTxt;

    @FindBy(css = "div#details-tab div:nth-child(1) > ul > li:nth-child(5) > span.info")
    private WebElement operatorEmailTxt;

    @FindBy(css = "div#details-tab div:nth-child(1) > ul > li:nth-child(4) > span.info")
    private WebElement operatorPhoneTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(1) > span.info")
    private WebElement displayNameTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(2) > span.info")
    private WebElement stockNumberTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(3) > span.info")
    private WebElement vinNumberTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(4) > span.info")
    private WebElement makeTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(5) > span.info")
    private WebElement modelTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(6) > span.info")
    private WebElement yearTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(7) > span.info")
    private WebElement vehicleColorTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(8) > span.info")
    private WebElement licencePlateTxt;

    @FindBy(css = "div#details-tab div:nth-child(2) > ul > li:nth-child(9) > span.info")
    private WebElement licencePlateStateTxt;

    @FindBy(css = "div#details-tab li:nth-child(10) > span.info")
    private WebElement initialOdometerTxt;

    @FindBy(css = "div#details-tab div:nth-child(3) > ul > li:nth-child(4) > span.info")
    private WebElement vehicleDeviceGroupTxt;

    @FindBy(css = "div#details-tab span.info-with-button > span")
    private WebElement vehicleDeviceStatusTxt;

    @FindBy(css = "div#details-tab div:nth-child(3) > ul > li:nth-child(9) > span.info")
    private WebElement vehicleInstalledDateTxt;

    @FindBy(css = "a.btn-filter-list")
    private WebElement filterBtn;

    @FindBy(css = "div.popover.right[style*='display: block;'] div.form-group button.btn-default:nth-of-Type(1)")
    private WebElement clearFilterBtn;

    @FindBy(css = "div.form-group button.btn-default:nth-of-Type(2)")
    private WebElement applyFilterBtn;

    @FindBy(css = "div.panel-toolbar.panel-secondary-heading select")
    private WebElement selectPageSizeOfMapView;

    @FindBy(css = "div.form-group:nth-of-type(1) select")
    private WebElement deviceStatusDropdown;

    @FindBy(css = "div.form-group:nth-of-type(2) select")
    private WebElement reportingDropdown;

    @FindBy(xpath = "//button[text()='Locate']")
    private WebElement locateCommandBtn;

    @FindBy(xpath = "//button[text()='Set QuickFence']")
    private WebElement setQuickFenceBulkBtn;

    @FindBy(xpath = "//button[text()='View']")
    private WebElement viewQuickFenceBtn;

    @FindBy(xpath = "//span[text()='WARNING']/following-sibling::a[1]")
    private WebElement warningOnLink;

    @FindBy(xpath = "//span[text()='WARNING']/following-sibling::a[2]")
    private WebElement warningOffLink;

    @FindBy(css = "button.btn-tiny-fixed:nth-of-type(3)")
    private WebElement clearQuickFenceBtn;

    @FindBy(css = "li.list-striped:nth-of-type(1) div.no-wrap")
    private WebElement vehicleName;

    // used to get all vehicle names showing in the list on the left
    @FindBy(css = "li.list-striped div.no-wrap")
    private List<WebElement> vehicleNames;

    @FindBy(css = "div.leaflet-popup-content")
    private WebElement mapBubble;

    @FindBy(css = "div.panel-heading.clearfix > a")
    private WebElement dragPanelBtn;

    static final String MAP_LOCATE_BTN_CSS = "div#map-container div.modern-bubble-content > div > a:nth-child(1)";
    @FindBy(css = MAP_LOCATE_BTN_CSS)
    private WebElement mapBubbleLocateLink;

    static final String MAP_HISTORY_BTN_CSS = "div#map-container div.modern-bubble-content > div > a:nth-child(2)";
    @FindBy(css = MAP_HISTORY_BTN_CSS)
    private WebElement mapBubbleHistoryLink;

    static final String MAP_PRINT_BTN_CSS = "div#map-container div.modern-bubble-content > div > a:nth-child(3)";
    @FindBy(css = MAP_PRINT_BTN_CSS)
    private WebElement mapBubblePrintLink;

    static final String MAP_RECOVERY_BTN_CSS = "div#map-container div" +
            ".modern-bubble-content > div > a:nth-child(4)";
    @FindBy(css = MAP_RECOVERY_BTN_CSS)
    private WebElement mapBubbleRecoveryLink;

    @FindBy(css = "div.modern-bubble-stats > div:nth-child(1)")
    private WebElement batteryStatus;

    @FindBy(css = "div#map-container div:nth-child(1) > h5")
    private WebElement batteryStatusMsg;

    @FindBy(css = "div.modern-bubble-stats > div:nth-child(2)")
    private WebElement cellSignalStatus;

    @FindBy(css = "div#map-container div:nth-child(2) > h5")
    private WebElement cellSignalStatusMsg;

    @FindBy(css = "div.modern-bubble-stats > div:nth-child(3)")
    private WebElement gpsStatus;

    @FindBy(css = "div#map-container div:nth-child(3) > h5")
    private WebElement gpsStatusMsg;

    @FindBy(css = "div > div.col-xs-10.no-wrap")
    private WebElement locateStatusPopup;

    @FindBy(css = "input[name='btnPrint']")
    private WebElement popUpPrintBtn;

    @FindBy(css = "div.leaflet-control-layers-base input[checked='checked']")
    private WebElement popUpLeafletRadioBtn;

    static final String GOOGLE_MAPS_BTN_CSS = "div#map-container div" +
            ".google-links > a:nth-child(1)";
    @FindBy(css = GOOGLE_MAPS_BTN_CSS)
    private WebElement googleMapsBtn;

    static final String BING_MAPS_BTN_CSS = "div#map-container div" +
            ".google-links > a:nth-child(2)";
    @FindBy(css = BING_MAPS_BTN_CSS)
    private WebElement bingMapsBtn;

    @FindBy(css = "#vehicleShowTab  > li.\\33 0dayhistory-tab")
    private WebElement historyTabLink;

    @FindBy(css = "button.btn-cancel")
    private WebElement cancelBtn;

    @FindBy(css = "input#searchboxinput")
    private WebElement googleMapsSearchInput;

    @FindBy(css = "input#maps_sb")
    private WebElement bingMapsSearchInput;

    @FindBy(css = "a.status-close")
    private WebElement closeCommand;

    @FindBy(css = "div#details-tab span.info-with-button > a.btn.btn-primary.btn-xs")
    private WebElement deactivateDeviceBtn;

    @FindBy(css = "button.sbtn.rounded-left")
    private WebElement mapViewBtn;

    @FindBy(css = "button.sbtn.rounded-right")
    private WebElement listViewBtn;

    @FindBy(css = "a.btn-filter")
    private WebElement filterBtnListView;

    @FindBy(css = "select[name='dealer']")
    private WebElement dealerDropdown;

    @FindBy(css = "div.ember-view.ui-sortable")
    private WebElement listViewColumnHeader;

    @FindBy(css = "button[title='Show/Hide Columns']")
    private WebElement columnSelectorBtn;

    @FindBy(css = "button[title='Print']")
    private WebElement listViewPrintAllBtn;

    @FindBy(css = "button[data-toggle='dropdown']")
    private WebElement exportBtn;

    @FindBy(xpath = "//button[text()='Return To Inventory']")
    private WebElement returnOnInventoryBtn;

    @FindBy(xpath = "//button[text()='Activate']")
    private WebElement activateBtn;

    @FindBy(css = "div.paging-component select")
    private WebElement selectPageSizeOfListView;

    @FindBy(css = "a.btn.btn-xs.btn-primary.gridButton[title='Print']")
    private WebElement listViewPrintVehicleInfoBtn;

    @FindBy(css = "div.popover-content li:nth-child(1) > div > span")
    private WebElement exportCSVLink;

    @FindBy(css = "div.popover-content li:nth-child(2) > div > span")
    private WebElement exportPDFLink;

    @FindBy(css = "div.popover-content li:nth-child(3) > div > span")
    private WebElement exportXLSLink;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header > h4.modal-title")
    private WebElement modalWindowTitle;

    @FindBy(css = "div.has-error span[for='company']")
    private WebElement recoveryCompanyErrorMessage;

    @FindBy(css = "div.has-error span[for='email']")
    private WebElement recoveryEmailErrorMessage;

    @FindBy(linkText = "TERMINATE DEVICE")
    private WebElement terminateBtn;

    @FindBy(partialLinkText = "REVOKE")
    private WebElement revokeBtn;

    @FindBy(css = "#iconLocateDevice")
    private WebElement quickLocateIcon;

    @FindBy(css = "div.modern-bubble-content font[color='red']")
    private WebElement statusStoppedField;

    private static final String VEHICLE_LIST_CHECKBOX_CSS = "li.list-striped:nth-of-type(%d) input";

    protected static final String HEADER_COLUMN_SPAN_XPATH = "//div[contains(@class,'active')]" +
            "//div[contains(@class,'ember-table-header-container')]//span[text()='%s']";
    protected static final String HEADER_COLUMN_DIV_XPATH = HEADER_COLUMN_SPAN_XPATH + "/../..";

    public boolean isSendCommandEventValidationMsgDisplayed() {
        return SendCommandEventValidationMsg.isDisplayed();
    }

    public boolean isSendCommandIntervalValidationMsgDisplayed() {
        return SendCommandIntervalValidationMsg.isDisplayed();
    }

    public void clickSendCommandBtn() {
        SendCommandBtn.click();
    }

    public void enterSendCommandEvents(String reportEvents) {
        SendCommandEventsInput.sendKeys(reportEvents);
    }

    public void clearSendCommandEventInput() {
        SendCommandEventsInput.clear();
    }

    public void enterSendCommandInterval(String reportInterval) {
        SendCommandIntervalInput.sendKeys(reportInterval);
    }

    public void clearSendCommandIntervalInput() {
        SendCommandIntervalInput.clear();
    }

    public boolean isGeoFenceBtnDisplayed() {
        return geoFenceBtn.isDisplayed();
    }

    public void clickGeoFenceButton() {
        geoFenceBtn.click();
    }

    /**
     * Validate the number of status bubbles expected
     *
     * @param numOfBubblesExpected
     */
    public void validateNumberOfStatusBubbles(int numOfBubblesExpected) {

        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions.numberOfElementsToBe
                    (By.cssSelector(BUBBLE_CSS), numOfBubblesExpected));
        } catch (TimeoutException e) {
            logger.error("Timeout exception. Not all expected bubbles are showing up within 10 seconds.");
            throw e;
        }
    }

    public enum DeviceStatusEnum {
        ALL("All"),
        NOT_INSTALLED("Not Installed"),
        INSTALLED("Installed"),
        OUT_FOR_Repocession("Out for Repossession"),
        ACTIVE("Active"),
        INVENTORY("Inventory");

        private String deviceStatus;

        DeviceStatusEnum(String deviceStatus) {
            this.deviceStatus = deviceStatus;
        }

        public String getDeviceStatus() {
            return deviceStatus;
        }
    }

    public enum ReportingEnum {
        ALL("All"),
        WITHIN_7_DAYS("Within 7 Days"),
        NOT_WITHIN_7_DAYS("Not Within 7 Days");

        private String name;

        ReportingEnum(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public boolean isSendCommandEventsPlaceHolderPresent() {
        return isElementAttributePresent(SendCommandEventsInput, "placeholder", "Events");
    }

    public boolean isSendCommandMinutesPlaceHolderPresent() {
        return isElementAttributePresent(SendCommandIntervalInput, "placeholder", "Minutes");
    }

    private boolean isElementAttributePresent(WebElement webElement, String attributeName, String attributeValue) {
        return webElement.getAttribute(attributeName).equals(attributeValue);
    }

    public String getSendCommandEventsLbl() {
        return SendCommandEventsLbl.getText();
    }

    public String getSendCommandIntervalLbl() {
        return SendCommandIntervalLbl.getText();
    }

    public int getNumberOfRowsDisplayedInMapGrid() {
        int rowCount = driver.findElements(By.cssSelector(MAP_GRID_CSS)).size();
        return rowCount;
    }

    public int getNumberOfRowsDisplayedInListGrid() {
        int rowCount = driver.findElements(By.cssSelector(LIST_GRID_CSS)).size();
        return rowCount;
    }

    // used for scenario where multiple successful bubbles are expected
    public void waitForSuccessfulBubbles(int numOfSuccessBubblesExpected) {
        try {
            new WebDriverWait(driver, 20).until(and(ExpectedConditions.numberOfElementsToBe
                            (By.cssSelector(SUCCESS_BUBBLE_CSS), numOfSuccessBubblesExpected)
                    , (ExpectedConditions.attributeContains(By.cssSelector(SUCCESS_BUBBLE_CSS), "title", "Successful"))));
        } catch (TimeoutException e) {
            logger.warn("Timeout exception. Not all expected successful bubbles are showing up within 20 seconds.");
            throw e;
        }
    }

    public WebElement getBubbleSuccessIcon() {
        return bubbleSuccessIcon;
    }

    public List<WebElement> getBubbleSuccessIcons() {
        return bubbleSuccessIcons;
    }

    public WebElement getBubbleTitle() {
        return bubbleTitle;
    }

    public List<String> getBubbleTitlesText() {
        List<String> bubbleTitlesTextList = new ArrayList<>();
        for (WebElement bubbleTitle : bubbleTitles) {
            bubbleTitlesTextList.add(bubbleTitle.getAttribute("title"));
        }

        return bubbleTitlesTextList;
    }

    public VehiclesPage(WebDriver driver) {
        super(driver);

        featureLocatorMap.put("Advanced Filtering", ADVANCED_FILTER_CSS);
        featureLocatorMap.put("Device Status", DEVICE_STATUS_CSS);
        featureLocatorMap.put("Reporting", REPORTING_CSS);
        featureLocatorMap.put("Starter Status", STARTER_STATUS_CSS);
        featureLocatorMap.put("Warning Status", WARNING_STATUS_CSS);
        featureLocatorMap.put("Search", SEARCH_INPUT_CSS);
        featureLocatorMap.put("Group Filter", GROUP_FILTER_CSS);
        featureLocatorMap.put("Locate", LOCATE_BTN_CSS);
        featureLocatorMap.put("QuickFence", DETAIL_PANEL_HEADING_CSS);
        featureLocatorMap.put("Details", DETAILS_TAB_CSS);
        featureLocatorMap.put("History", HISTORY_TAB_CSS);
        featureLocatorMap.put("Notes", NOTESTAB_CSS);
        featureLocatorMap.put("GeoFence", GEO_FENCE_TAB_CSS);
        featureLocatorMap.put("Profile Changes", PROFILE_CHANGES_TAB_CSS);
        featureLocatorMap.put("References", STIP_TAB_CSS);
        featureLocatorMap.put("Locations", LOCATIONS_TAB_CSS);
        featureLocatorMap.put("Recovery", RECOVERY_TAB_CSS);
        featureLocatorMap.put("Upgrades (GoldStar Connect)", UPGRADES_TAB_CSS);
        featureLocatorMap.put("Starter Enable/Disable", STARTER_LINK_XPATH);
        featureLocatorMap.put("Warning On/Off", WARNING_LINK_XPATH);
        featureLocatorMap.put("Drive Report", DRIVE_REPORT_BTN_XPATH);
        featureLocatorMap.put("Stop Report", STOP_REPORT_BTN_XPATH);
        featureLocatorMap.put("Set Max Speed", SET_MAX_SPEED_BTN_XPATH);
        featureLocatorMap.put("Tow Alert", TOW_ALERT_BTN_XPATH);
        featureLocatorMap.put("Auto Report", AUTO_REPORT_BTN_XPATH);
        featureLocatorMap.put("Vehicle Info Print button", VEHICLE_INFO_PRINT_BTN_CSS);

        elementLocatorMap.put("Group Filter", GROUP_FILTER_CSS);
        elementLocatorMap.put("Map All Active", MAP_ALL_WHEN_ACTIVE_CSS);
        elementLocatorMap.put("Search", SEARCH_INPUT_CSS);
        elementLocatorMap.put("Groups Dropdown", GROUPS_DROPDOWN_CSS);
        elementLocatorMap.put("Vehicles List", VEHICLES_LIST_CSS);
        elementLocatorMap.put("Zoom In", MAP_ZOOM_IN_CSS);
        elementLocatorMap.put("Zoom Out", MAP_ZOOM_OUT_CSS);
        elementLocatorMap.put("Resize Page", RESIZE_PAGE_CSS);
        elementLocatorMap.put("Previous Page", PREVIOUS_PAGE_CSS);
        elementLocatorMap.put("Next Page", NEXT_PAGE_CSS);
        elementLocatorMap.put("Refresh Vehicles List", REFRESH_PAGE_CSS);
    }

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    public boolean isVehicleFeaturePresent(String vehicleFeature) {
        if (vehicleFeature.equalsIgnoreCase("QuickFence")) {
            String detailPanelHeadingHtmlStr = detailPanelHeading.getAttribute("innerHTML");
            return detailPanelHeadingHtmlStr.contains("Quickfence is set") ||
                    detailPanelHeadingHtmlStr.contains("Set QuickFence");
        } else {
            if (featureLocatorMap.get(vehicleFeature).startsWith("//")) {
                return isElementPresent(driver, By.xpath(featureLocatorMap.get(vehicleFeature)));
            } else {
                return isElementPresent(driver, By.cssSelector(featureLocatorMap.get(vehicleFeature)));
            }
        }
    }

    public boolean isDeviceSelected() {
        return isElementPresent(driver, By.cssSelector(DETAILS_TAB_CSS));
    }

    public void searchVehicle(String searchString) {
        waitUntilSpinnerInvisible(driver);
        searchInput.clear();
        waitUntilSpinnerInvisible(driver);
        searchInput.sendKeys(searchString);
    }

    public void searchUniqueVehicle(String serialNumber) {

        //search serial number
        searchVehicle(serialNumber);

        // Retry policy to make sure only one record shows in the grid
        RetryPolicy retryPolicy = new RetryPolicy()
                .retryIf(r -> r.equals(false))
                .withDelay(2, TimeUnit.SECONDS)
                .withMaxRetries(5);

        // Run with retries
        Failsafe
                .with(retryPolicy)
                .onRetry((c, f, ctx) -> {
                    logger.warn("One record should be visible in the grid..not more not less");
                })
                .onFailure(f -> {
                    throw new AssertionError("Failing because unique record is not searched...");
                })
                .get(() -> getNumberOfRowsDisplayedInMapGrid() == 1);
    }

    public void searchUniqueVehicleListView(String serialNumber) {

        //search serial number
        searchVehicle(serialNumber);

        // Retry policy to make sure only one record shows in the grid
        RetryPolicy retryPolicy = new RetryPolicy()
                .retryIf(r -> r.equals(false))
                .withDelay(2, TimeUnit.SECONDS)
                .withMaxRetries(5);

        // Run with retries
        Failsafe
                .with(retryPolicy)
                .onRetry((c, f, ctx) -> {
                    logger.warn("One record should be visible in the grid..not more not less");
                })
                .onFailure(f -> {
                    throw new AssertionError("Failing because unique record is not searched...");
                })
                .get(() -> getNumberOfRowsDisplayedInListGrid() == 1);
    }

    public void selectAll() {
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
        selectAllCheckBox.click();
    }

    public void clickRecoveryTab() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(recoveryTab)).click();
    }

    public void clickCreateRecoveryLink() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(createRecoveryLink)).click();
    }

    public void clickCancelLink() {
        waitUntilSpinnerInvisible(driver);
        recoveryCancelLink.click();
    }

    public void clickCreateLink() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(recoveryCreateLink)).click();
    }

    public void clickConnectTab() {
        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(connectTab)).click();
        } catch (TimeoutException e) {
            logger.error("Connect tab unavailable for current device", e);
        }
    }

    public void clickConnectBtn() {

        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(connectBtn)).click();
        } catch (TimeoutException e) {
            logger.error("Connect btn unavailable for current device", e);
        }
    }

    public void submitRecoveryForm(String company, String firstName, String lastName, String email) {
        enterText(driver, recoveryCompanyTxtBox, company);
        enterText(driver, recoveryFirstNameTxtBox, firstName);
        enterText(driver, recoveryLastNameTxtBox, lastName);
        enterText(driver, recoveryEmailTxtBox, email);
    }

    public String getRecoveryModalText() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 1);
        return recoveryCreatedModalText.getText().replace(recoveryCreatedLinkText.getText(), "").trim();
    }

    public String getRecoveryLinkText() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 1);
        return recoveryCreatedLinkText.getText();
    }

    public void clickRecoveryLinkTextConfirmation() {
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(recoveryLinkTextConfirmation)).click();
    }

    public void fillInvalidRecoveryFormAndCancel() {

        clickCreateRecoveryLink();

        //Validate modal window
        assertTrue(getModalWindow().isDisplayed());
        assertEquals(getModalWindowTitle().getText(), "Create Recovery Link");

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(recoveryCompanyTxtBox));

        clickCreateLink();

        assertEquals(recoveryCompanyErrorMessage.getText(), "Company is required");
        assertEquals(recoveryEmailErrorMessage.getText(), "Email is required");

        new WebDriverWait(driver, 10).until(elementToBeClickable(cancelBtn)).click();

        new WebDriverWait(driver, 10)
                .until(invisibilityOfElementLocated(By.name(RECOVERY_COMPANY_NAME)));

    }

    /**
     * Create Recovery Link
     *
     * @param company
     * @param firstName
     * @param lastName
     * @param email
     * @return
     */
    public String createRecoveryLink(String company, String firstName, String lastName, String email) {

        clickCreateRecoveryLink();

        //Validate modal window
        assertTrue(getModalWindow().isDisplayed());

        submitRecoveryForm(company, firstName, lastName, email);
        clickCreateLink();
        String linkText = getRecoveryLinkText();
        logger.info("Recovery link Text: " + linkText);

        assertEquals(getRecoveryModalText(), "The recovery link has been successfully created " +
                "and sent to the recipient.\n" + "If the email was not received, please advise the recipient " +
                "to check their spam folder.");

        clickRecoveryLinkTextConfirmation();

        new WebDriverWait(driver, 10)
                .until(invisibilityOfElementLocated(By.name(RECOVERY_COMPANY_NAME)));

        return linkText;
    }

    /**
     * Select recovery tab
     *
     * @param serialNumber
     */
    public void searchAndClickRecoveryLinkForSerial(String serialNumber) {
        searchUniqueVehicle(serialNumber);
        selectVehicle(1);
        clickRecoveryTab();
    }

    public boolean isElementAvailable(String elementName) {
        return isElementPresent(driver, By.cssSelector(elementLocatorMap.get(elementName)));
    }

    public boolean isRecoveryLinkPresent(String linkString) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        //Element tag could be "a" for active link and "span" for expired Link
        String format = "//*[text()='%s']";
        String xpath = String.format(format, linkString);
        return isElementPresent(driver, By.xpath(xpath));
    }

    public VehicleNotesPage clickNotesTab() {
        waitUntilSpinnerInvisible(driver);
        notesTab.click();
        waitUntilSpinnerInvisible(driver);
        return PageFactory.initElements(driver, VehicleNotesPage.class);
    }

    public VehicleRecoveryPage clickFirstRecoveryLink() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(recoveryLink)).click();
        try {
            new WebDriverWait(driver, 3).until(ExpectedConditions.invisibilityOf(recoveryLink));
        } catch (Exception e) {
        }

        return PageFactory.initElements(driver, VehicleRecoveryPage.class);
    }

    public String getFirstRecoveryLinkText() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(recoveryLink));
        return recoveryLink.getText();
    }

    public VehicleLocationsPage clickLocationsTab() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(locationsTab)).click();
        return PageFactory.initElements(driver, VehicleLocationsPage.class);
    }

    public String getFirstVehicleName() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(firstVehicleNameDiv));
        return firstVehicleNameDiv.getText();
    }

    public String getActiveTab() {
        return vehicleShowTab.findElement(By.cssSelector("li.active")).getText();
    }

    public VehicleHistoryPage clickHistoryTab() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(historyTab)).click();
        return PageFactory.initElements(driver, VehicleHistoryPage.class);
    }

    public Boolean isQuickEditBtnPresent() {
        return isElementPresent(driver, By.cssSelector(QUICK_EDIT_BTN_CSS));
    }

    public Boolean isEditBtnPresent() {
        return isElementPresent(driver, By.cssSelector(EDIT_BTN_CSS));
    }

    public Boolean isLocateBtnPresent() {
        return isElementPresent(driver, By.cssSelector(LOCATE_BTN_CSS));
    }

    public void waitForLocateCommandBtnVisible() {
        try {
            new WebDriverWait(driver, 3).until(ExpectedConditions.visibilityOf(locateCommandBtn));
        } catch (TimeoutException e) {
            logger.error("Timeout exception. Locate Command button doesn't show up within 3 seconds.");
            throw e;
        }
    }

    public Boolean isNotesTabPresent() {
        return isElementPresent(driver, By.cssSelector(NOTESTAB_CSS));
    }

    public Boolean isProfileChangesTabPresent() {
        return isElementPresent(driver, By.cssSelector(PROFILE_CHANGES_TAB_CSS));
    }

    public Boolean isHistoryTabPresent() {
        return isElementPresent(driver, By.cssSelector(HISTORY_TAB_CSS));
    }

    public Boolean isRecoveryTabPresent() {
        return isElementPresent(driver, By.cssSelector(RECOVERY_TAB_CSS));
    }

    public WebElement getQuickEditBtn() {
        return quickEditBtn;
    }

    public WebElement getEditBtn() {
        return editBtn;
    }

    public WebElement getPrintBtn() {
        return printBtn;
    }

    public void clickQuickEditBtn() {
        new Actions(driver).moveToElement(quickEditBtn).build().perform();
        new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOf(quickEditBtn)).click();
    }

    public WebElement getModelWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modelWindow));
    }

    /**
     * Enter customer address
     *
     * @param address
     */
    public void enterOperatorAddress(Address address) {
        if (address != null) {
            enterText(driver, operatorAddressTxtBox, address.getStreet());
            enterText(driver, operatorAddressCityTxtBox, address.getCity());

            Select dropdownCountry = new Select(operatorCountryDropDown);
            dropdownCountry.selectByVisibleText(address.getCountry());

            Select dropdownState = new Select(operatorAddressStateDropDown);
            dropdownState.selectByVisibleText(address.getState());

            enterText(driver, operatorAddressZipTxtBox, address.getPostalCode());
        }
    }

    public void enterVinNumber(String vinNumber) {
        new WebDriverWait(driver, 2).until(
                visibilityOf(vehicleVinNumberTxtBox));

        vehicleVinNumberTxtBox.clear();
        enterText(driver, vehicleVinNumberTxtBox, vinNumber);
    }

    public void clickDecodeVIN() {
        new WebDriverWait(driver, 2).until(
                elementToBeClickable(vehicleDecodeVinTxtBox)).click();
    }

    public void enterDisplayName(String displayName) {
        new WebDriverWait(driver, 2).until(
                visibilityOf(deviceDisplayNameTxtBox));

        deviceDisplayNameTxtBox.clear();
        enterText(driver, deviceDisplayNameTxtBox, displayName);
    }

    public WebElement getGroupsInput() {
        return deviceGroupInputBox;
    }

    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    public void selectStatus(String deviceStatus) {
        if (deviceStatus != null) {
            Select dropdownStatus = new Select(deviceInstalledStatusDropDown);
            dropdownStatus.selectByVisibleText(deviceStatus);
        }
    }

    public void enterInstalledDate(String installedDate) {
        new WebDriverWait(driver, 2).until(
                elementToBeClickable(deviceDateInstalledTxtBox));

        deviceDateInstalledTxtBox.clear();
        enterText(driver, deviceDateInstalledTxtBox, installedDate);
    }

    public void clickSave() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(SAVE_BTN_CSS), 60);
    }

    public void clickOk() {
        new WebDriverWait(driver, 2).until(elementToBeClickable(vinModelOkBtn)).click();
    }

    public WebElement getinvalidVinPopUp() {
        return new WebDriverWait(driver, 2).until(visibilityOf(invalidVinPopup));
    }

    public Boolean verifyVehicleMakeTxt(String make) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(vehicleMakeTxtBox, make));
    }

    public Boolean verifyVehicleModelTxt(String model) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(vehicleModelTxtBox, model));
    }

    public Boolean verifyVehicleYearTxt(String year) {
        return new WebDriverWait(driver, 2).until(
                textToBePresentInElementValue(vehicleYearTxtBox, year));
    }

    public String getFirstNameTxt() {
        return firstNameTxt.getText();
    }

    public String getLastNameTxt() {
        return lastNameTxt.getText();
    }

    public String getaddressTxt() {
        return addressTxt.getText();
    }

    public String getOperatorEmailTxt() {
        return operatorEmailTxt.getText();
    }

    public String getOperatorPhoneTxt() {
        return operatorPhoneTxt.getText();
    }

    public String getVinNumberTxt() {
        return vinNumberTxt.getText();
    }

    public String getLicencePlateTxt() {
        return licencePlateTxt.getText();
    }

    public String getLicencePlateStateTxt() {
        return licencePlateStateTxt.getText();
    }

    public String getColorTxt() {
        return vehicleColorTxt.getText();
    }

    public String getVehicleDeviceGroupTxt() {
        return vehicleDeviceGroupTxt.getText();
    }

    public String getVehicleDeviceStatusTxt() {
        return vehicleDeviceStatusTxt.getText();
    }

    public String getVehicleInstalledDateTxt() {
        return vehicleInstalledDateTxt.getText();
    }

    public void clickProfileChangesTab() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(profileChangesTab)).click();
    }

    public void clickDetailsTab() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(detailsTab)).click();
    }

    /**
     * Search with serial number and edit
     *
     * @param serialNumber
     */
    public void searchAndEditVehicle(String serialNumber) {
        searchUniqueVehicle(serialNumber);
        selectVehicle(1);
        clickQuickEditBtn();
    }

    /**
     * Enter customer information
     *
     * @param person
     */

    public void enterCustomerData(Person person) {
        if (person != null) {
            if (person.getFirstName() != null) {
                enterTextAndConfirmEntry(driver, operatorFirstNameTxtBox, person.getFirstName());
            }
            if (person.getLastName() != null) {
                enterTextAndConfirmEntry(driver, operatorLastNameTxtBox, person.getLastName());
            }
            if (person.getEmail() != null) {
                enterTextAndConfirmEntry(driver, operatorEmailTxtBox, person.getEmail());
            }
            if (person.getPhone() != null) {
                enterText(driver, operatorPhoneTxtBox, person.getPhone());
            }
        }
    }

    /**
     * Enter vehicle information
     *
     * @param vehicles
     * @param address
     */
    public void enterVehicleInfo(Vehicles vehicles, Address address) {
        if (vehicles != null) {
            enterTextAndConfirmEntry(driver, vehicleStockNumberTxtBox, String.valueOf(vehicles.getStockNumber()));
            enterTextAndConfirmEntry(driver, vehicleVinNumberTxtBox, vehicles.getVin());
            clickDecodeVIN();
            enterTextAndConfirmEntry(driver, vehicleLicensePlateTxtBox, vehicles.getVehicleLicencePlate());
            enterTextAndConfirmEntry(driver, vehicleColorTxtBox, vehicles.getVehicleColor());
        }

        if (address != null) {

            licensePlateCountryDropDown.click();
            Select licensePlateDropdownCountry = new Select(licensePlateCountryDropDown);
            licensePlateDropdownCountry.selectByVisibleText(address.getCountry());

            licencePlateStateDropDown.click();
            Select licencePlateDropdownState = new Select(licencePlateStateDropDown);
            licencePlateDropdownState.selectByVisibleText(address.getState());
        }

    }

    public void selectGroup(String groupName) {
        if (groupName != null) {
            WebElement groupsInput = getGroupsInput();
            groupsInput.click();
            groupsInput.sendKeys(groupName);
            getGroupsLabel().click();
        }
    }

    /**
     * Edit vehicle information
     *
     * @param customer
     * @param address
     * @param vehicles
     * @param deviceGroupName
     * @param vehicleDeviceStatus
     * @param installedDate
     */
    public void editVehicleDetails(String displayName, Person customer, Address address, Vehicles vehicles,
                                   String deviceGroupName, String vehicleDeviceStatus, String installedDate) {

        searchAndEditVehicle(displayName);
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
        getModelWindow();

        //Enter details in customer section
        enterCustomerData(customer);
        enterOperatorAddress(address);

        //Enter details in vehicle section
        enterVehicleInfo(vehicles, address);

        //Enter details in device section
        selectGroup(deviceGroupName);
        selectStatus(vehicleDeviceStatus);
        enterInstalledDate(installedDate);
        clickSave();
    }

    /**
     * Get data of the given row number
     *
     * @param rowNumber
     * @return
     */
    public HashMap<String, String> getTableRow(int rowNumber) {
        return getTableRow(activeTable, rowNumber);
    }


    public WebElement getLocateBtn() {
        return locateBtn;
    }

    /**
     * Get the default selected option from vehicle list show dropdown
     *
     * @return
     */
    public WebElement getSelectPageSize(String view) {

        if (view.equals("MapView")) {
            return selectPageSizeOfMapView;
        } else {
            return selectPageSizeOfListView;
        }
    }

    /**
     * Get all options of select Drive Report drop down
     *
     * @return
     */
    public List<String> getDriveReportDropdownValues() {

        List<WebElement> showDropDownElementList = new Select(driveReportDropdown).getOptions();

        List<String> showDropDownValueList = new ArrayList<>();
        for (WebElement showDropDownElement : showDropDownElementList) {
            showDropDownValueList.add(showDropDownElement.getText());
        }

        return showDropDownValueList;
    }

    public void selectDriveReportOption(String option) {
        //Select Custom Drive Report
        Select driveReportOption = new Select(driveReportDropdown);
        driveReportOption.selectByVisibleText(option);
    }


    public WebElement getFilterBtn() {
        return filterBtn;
    }

    public WebElement getClearFilterBtn() {
        return clearFilterBtn;
    }

    public WebElement getDeviceStatusDropdown() {
        return deviceStatusDropdown;
    }

    public WebElement getLocateCommandBtn() {
        return locateCommandBtn;
    }

    public WebElement getReportingDropdown() {
        return reportingDropdown;
    }

    public WebElement getSetQuickFenceBulkBtn() {
        return setQuickFenceBulkBtn;
    }

    public WebElement getDetailPanelHeading() {
        return detailPanelHeading;
    }

    public WebElement getSetQuickFenceBtn() {
        return setQuickFenceBtn;
    }

    public WebElement getDriveReportBtn() {
        return new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOf(driveReportBtn));
    }

    public WebElement getStopReportBtn() {
        return new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOf(stopReportBtn));
    }

    public WebElement getSetMaxSpeedBtn() {
        return setMaxSpeedBtn;
    }

    public WebElement getAutoReportBtn() {
        return autoReportBtn;
    }

    public WebElement getTowAlertBtn() {
        return towAlertBtn;
    }

    public WebElement getSetAgainQuickFenceBtn() {
        return setAgainQuickFenceBtn;
    }

    public WebElement getViewQuickFenceBtn() {
        return viewQuickFenceBtn;
    }

    public WebElement getClearQuickFenceBtn() {
        return clearQuickFenceBtn;
    }

    public WebElement getWarningLink() {
        return warningLink;
    }

    public WebElement getStarterEnableLink() {
        return starterEnableLink;
    }

    public WebElement getStarterDisableLink() {
        return starterDisableLink;
    }

    public WebElement getStarterLink() {
        return starterLink;
    }

    public WebElement getStarterDisableSendButton() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .presenceOfElementLocated(By.cssSelector(STARTER_DISABLE_SEND_BTN_CSS)));

        return starterDisableSendButton;
    }

    public WebElement getWarningOnLink() {
        return warningOnLink;
    }

    public WebElement getWarningOffLink() {
        return warningOffLink;
    }

    public void selectDeviceStatus(DeviceStatusEnum deviceStatus) {
        if (deviceStatus != null) {
            new Select(getDeviceStatusDropdown()).selectByVisibleText(deviceStatus.getDeviceStatus());
        }
    }

    public void selectReporting(ReportingEnum reporting) {
        if (reporting != null) {
            new Select(getReportingDropdown()).selectByVisibleText(reporting.getName());
        }
    }

    /**
     * Apply filters to display vehicle list
     *
     * @param deviceStatus
     */
    public void applyFilter(DeviceStatusEnum deviceStatus) {
        filterBtn.click();
        selectDeviceStatus(deviceStatus);
        applyFilterBtn.click();
    }

    /**
     * Clear filters
     */
    public void clearFilter() {
        filterBtn.click();
        clearFilterBtn.click();
    }

    public WebElement getGroupsDropdown() {
        return groupsDropdown;
    }

    public void selectGroups(String group) {
        if (group != null) {
            new Select(getGroupsDropdown()).selectByVisibleText(group);
        }
    }

    public List<String> getGroupsDropdownList() {
        List<String> list = new ArrayList<>();

        new Select(getGroupsDropdown()).getOptions().forEach(w -> list.add(w.getText()));

        return list;
    }

    /**
     * toggle the given row in vehicles list
     *
     * @param rowNumber
     * @param state:    true or false
     */
    public void toggleVehicle(int rowNumber, boolean state) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 15);
        WebElement checkbox =
                driver.findElement(By.cssSelector(String.format(VEHICLE_LIST_CHECKBOX_CSS, rowNumber)));
        WebElements.updateCheckBox(driver, checkbox, state);
    }

    /**
     * Select the given row in vehicles list
     *
     * @param rowNumber
     */
    public void selectVehicle(int rowNumber) {
        toggleVehicle(rowNumber, true);
    }

    /**
     * Unselect the given row in vehicles list
     *
     * @param rowNumber
     */
    public void unselectVehicle(int rowNumber) {
        toggleVehicle(rowNumber, false);
    }

    /**
     * Select the given row in vehicles list
     *
     * @param rowNumber
     */
    public boolean isVehicleVisible(int rowNumber) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        try {
            if (driver.findElement(By.cssSelector(String.format(VEHICLE_LIST_CHECKBOX_CSS, rowNumber)))
                    .isDisplayed()) {
                return true;
            } else {
                return false;
            }
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Click on References tab
     *
     * @return
     */
    public VehicleReferencesPage clickReferencesTab() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(stipTab)).click();
        return PageFactory.initElements(driver, VehicleReferencesPage.class);
    }

    public WebElement getVehicleName() {
        return vehicleName;
    }

    public List<String> getVehicleNameText() {
        List<String> vehicleNameTextList = new ArrayList<>();
        for (WebElement vehicleName : vehicleNames) {
            vehicleNameTextList.add(vehicleName.getText());
        }

        return vehicleNameTextList;
    }

    /**
     * Click on GeoFence tab
     *
     * @return
     */
    public VehicleGeoFencePage clickGeoFenceTab() {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(geofenceTab)).click();
        return PageFactory.initElements(driver, VehicleGeoFencePage.class);
    }

    public WebElement getMapBubble() {
        return mapBubble;
    }

    public void clickDragPanelBtn() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(dragPanelBtn)).click();
    }

    public WebElement mapBubbleHistoryLink() {
        return mapBubbleHistoryLink;
    }

    public WebElement mapBubbleLocateLink() {
        return mapBubbleLocateLink;
    }

    public WebElement mapBubblePrintLink() {
        return mapBubblePrintLink;
    }

    public WebElement mapBubbleRecoveryLink() {
        return mapBubbleRecoveryLink;
    }

    public WebElement getBatteryStatus() {
        return batteryStatus;
    }

    public WebElement getCellSignal() {
        return cellSignalStatus;
    }

    public WebElement getGpsStatus() {
        return gpsStatus;
    }

    public WebElement getBatteryStatusMsg() {
        return batteryStatusMsg;
    }

    public WebElement getCellSignalStatusMsg() {
        return cellSignalStatusMsg;
    }

    public WebElement getGpsStatusMsg() {
        return gpsStatusMsg;
    }

    public WebElement getGoogleMapsBtn() {
        return googleMapsBtn;
    }

    public WebElement getBingMapsBtnMapsBtn() {
        return bingMapsBtn;
    }

    public void clickLocateLink() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(MAP_LOCATE_BTN_CSS)))).click();
    }

    public void clickHistoryLink() {
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(MAP_HISTORY_BTN_CSS)))).click();
    }

    public void clickPrintLink() {
        new WebDriverWait(driver, 20).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(MAP_PRINT_BTN_CSS)))).click();
    }

    public void clickRecoveryLink() {
        new WebDriverWait(driver, 20).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(MAP_RECOVERY_BTN_CSS)))
        ).click();
    }

    public WebElement getLocateStatusPopup() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(locateStatusPopup));
    }

    public WebElement getHistoryTabLink() {
        return historyTabLink;
    }

    public WebElement getPopUpPrintBtn() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(popUpPrintBtn));
    }

    public WebElement getPopUpLeafletRadioBtn() {
        return popUpLeafletRadioBtn;
    }

    public WebElement getCancelBtn() {
        return cancelBtn;
    }

    public WebElement getGoogleMapsSearchInput() {
        return googleMapsSearchInput;
    }

    public WebElement getBingMapsSearchInput() {
        return bingMapsSearchInput;
    }

    public void clickGoogleMapsLink() {
        new WebDriverWait(driver, 20).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(GOOGLE_MAPS_BTN_CSS)))).click();
    }

    public void clickBingMapsLink() {
        new WebDriverWait(driver, 20).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector(BING_MAPS_BTN_CSS)))).click();
    }

    public WebElement getCloseCommand() {
        return closeCommand;
    }

    public WebElement getMapViewBtn() {
        return mapViewBtn;
    }

    public WebElement getListViewBtn() {
        return listViewBtn;
    }

    /**
     * Clear filters list view
     */
    public void clearFilterListView() {
        filterBtnListView.click();
        clearFilterBtn.click();
    }

    public WebElement getDealerDropdown() {
        return dealerDropdown;
    }

    public void selectDealers(String dealerName) {
        if (dealerName != null) {
            new Select(getDealerDropdown()).selectByVisibleText(dealerName);
        }
    }

    public void applyFilterMapView(DeviceStatusEnum deviceStatus, ReportingEnum reporting) {

        filterBtn.click();
        selectDeviceStatus(deviceStatus);
        selectReporting(reporting);
        applyFilterBtn.click();
    }

    public void applyFilterListView(DeviceStatusEnum deviceStatus, ReportingEnum reporting) {

        filterBtnListView.click();
        selectDeviceStatus(deviceStatus);
        selectReporting(reporting);
        applyFilterBtn.click();
    }

    public List<String> getListViewGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = listViewColumnHeader.findElements(By
                .cssSelector("div.ember-table-content-container span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getColumnSelectorBtn() {
        return columnSelectorBtn;
    }

    public WebElement getListViewPrintAllBtn() {
        return listViewPrintAllBtn;
    }

    public WebElement getExportBtn() {
        return exportBtn;
    }

    public WebElement getReturnOnInventoryBtn() {
        return returnOnInventoryBtn;
    }

    public WebElement getActivateBtn() {
        return activateBtn;
    }

    public WebElement getFilterBtnListView() {
        return filterBtnListView;
    }

    /**
     * Select the given row in vehicles list in List View
     *
     * @param rowNumber
     */
    public void selectVehicleListView(int rowNumber) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 15);
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By.cssSelector
                        ("div.antiscroll-box div.ember-table-table-row:nth-of-type("
                                + rowNumber + ") input")))).click();
    }

    public WebElement getListViewPrintVehicleInfoBtn() {
        return listViewPrintVehicleInfoBtn;
    }

    public List<String> getShowColumns() {
        List<WebElement> elements = driver.findElements(By.cssSelector("div.popover-content ul.list-unstyled " +
                "li label"));

        List<String> selectedColumns = new ArrayList<>();
        for (WebElement element : elements) {
            String attributeValue = element.findElement(By.cssSelector("input")).getAttribute("checked");
            if (attributeValue != null && attributeValue.equals("true")) {
                selectedColumns.add(element.getText());
            }
        }

        return selectedColumns;
    }

    public WebElement getExportCSVLink() {
        return exportCSVLink;
    }

    public WebElement getExportPDFLink() {
        return exportPDFLink;
    }

    public WebElement getExportXLSLink() {
        return exportXLSLink;
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }

    /**
     * Click on expire link in the given row
     *
     * @param rowNumber
     */
    public void clickExpireLink(int rowNumber) {
        driver.findElement(By.cssSelector("div#recovery-tab div:nth-child(" + rowNumber +
                ") > div > div:nth-child(10) > span > a")).click();
    }

    public String getDisplayNameTxt() {
        return displayNameTxt.getText();
    }

    public String getMakeTxt() {
        return makeTxt.getText();
    }

    public String getModelTxt() {
        return modelTxt.getText();
    }

    public String getYearTxt() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", yearTxt);

        return new WebDriverWait(driver, 5).until(visibilityOf(yearTxt)).getText();
    }

    public String getStockNumberTxt() {
        return stockNumberTxt.getText();
    }

    public WebElement getRecoveryTab() {
        return recoveryTab;
    }

    /**
     * Click on the given recovery link
     *
     * @param linkText
     * @return
     */
    public VehicleRecoveryPage clickOnCreatedRecoveryLink(String linkText) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.cssSelector("a[href^='recovery/" + linkText + "']"))).click();
        return PageFactory.initElements(driver, VehicleRecoveryPage.class);
    }

    public boolean isMapAllActive() {
        return driver.findElements(By.cssSelector(MAP_ALL_WHEN_ACTIVE_CSS)).size() > 0 ? true : false;
    }

    /**
     * Verify is any elements Pins or assets clusters (circles with number of assets inside)
     *
     * @return
     */
    public boolean mapMarkersShow() {
        //have to wait while assets are being loaded. There is no spinner shows
        try {
            new WebDriverWait(driver, 10)
                    .until(ExpectedConditions.elementToBeClickable(By.cssSelector("img.leaflet-clickable")));
        } catch (TimeoutException e) {
        }

        return mapMarkers.size() > 0 ? true : false;
    }

    public WebElement getProfileChangesTab() {
        return profileChangesTab;
    }

    public WebElement getActiveTable() {
        return activeTable;
    }

    /**
     * Click on edit button, select device status, save and refresh the table
     *
     * @param deviceStatus
     */
    public void selectAndSaveStatus(String deviceStatus) {
        clickQuickEditBtn();
        assertTrue(getModelWindow().isDisplayed());
        selectStatus(deviceStatus);
        clickSave();
        clickRefreshBtn(new WebDriverWait(driver, 20)
                .until(ExpectedConditions.elementToBeClickable(activeTable
                        .findElement(By.cssSelector(getRefreshBtnCSS())))));
    }

    public String getHeaderColumnDivXpath() {
        return HEADER_COLUMN_DIV_XPATH;
    }

    public WebElement getRevokeBtn() {
        return new WebDriverWait(driver, 3).until(elementToBeClickable(revokeBtn));
    }

    public WebElement getTerminateBtn() {
        return new WebDriverWait(driver, 3).until(elementToBeClickable(terminateBtn));
    }

    public boolean isQuickLocateIconDisplayed() {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        return quickLocateIcon.isDisplayed();
    }

    public WebElement getMoreCommandsBtn() {
        new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(moreCommandsBtn));
        return moreCommandsBtn;
    }

    public String mapBubbleStatus() {
        return statusStoppedField.getText();
    }

    public boolean isDriveReportBtnVisible() {
        try {
            return getDriveReportBtn().isDisplayed();
        } catch (TimeoutException e) {
            return !e.getMessage().contains("Expected condition failed: waiting for visibility of Proxy element for: DefaultElementLocator 'By.xpath: " +
                    DRIVE_REPORT_BTN_XPATH + "'");
        }
    }

    public boolean isStopReportBtnVisible() {
        try {
            return getStopReportBtn().isDisplayed();
        } catch (TimeoutException e) {
            return !e.getMessage().contains("Expected condition failed: waiting for visibility of Proxy element for: DefaultElementLocator 'By.xpath: " +
                    STOP_REPORT_BTN_XPATH + "'");
        }
    }
}
