package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.testng.Assert.assertEquals;

public class AdminImpoundLotsPage extends CommonGrid {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminImpoundLotsPage.class);

    @FindBy(css = "input[type='search']")
    private WebElement searchInput;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "div.ember-view.ember-table-tables-container.ember-table-content-selectable")
    private WebElement impoundLotsTable;

    private static final String MAP_PINS_CSS = "div.leaflet-marker-pane img";
    @FindBy(css = MAP_PINS_CSS)
    private WebElement mapPins;

    @FindBy(css = "div.modern-bubble-headline-title.ellipsis")
    private WebElement mapBubbleHeadline;

    @FindBy(css = "dd.formatted-address.map-bubble-location")
    private WebElement mapBubbleContent;


    @FindBy(linkText = "Suggest one here")
    private WebElement reportMissingImpoundLotLink;

    @FindBy(name = "lotName")
    private WebElement lotName;

    @FindBy(name = "streetAddress")
    private WebElement streetAddress;

    @FindBy(name = "city")
    private WebElement city;

    @FindBy(name = "state")
    private WebElement state;

    @FindBy(name = "zip")
    private WebElement zip;

    @FindBy(name = "phone")
    private WebElement phone;

    @FindBy(name = "website")
    private WebElement website;

    @FindBy(css = "div.modal-footer button.btn.btn-primary")
    private WebElement sendButton;

    @FindBy(css = "div.modal-footer button.btn.btn-cancel")
    private WebElement cancelButton;

    @FindBy(css = "body > div.bootbox.modal.fade.bootbox-alert.in > div > div > div.modal-footer > button")
    private WebElement okButton; //appears after email is sent

    @FindBy(css = "span[for='lotName']")
    private WebElement lotNameValidationMsg;

    @FindBy(css = "span[for='streetAddress']")
    private WebElement streetAddressValidationMsg;

    @FindBy(css = "span[for='city']")
    private WebElement cityValidationMsg;

    @FindBy(css = "span[for='state']")
    private WebElement stateValidationMsg;

    @FindBy(css = "span[for='zip']")
    private WebElement zipValidationMsg;

    @FindBy(css = "div.modal-dialog div.bootbox-wrap")
    private WebElement impoundDetailsSubmissionDialog;

    @FindBy(css = "div.form")
    private WebElement impoundLotEntryForm;

    public boolean isImpoundLotEntryFormHidden() {
        return !isElementPresent(driver, By.cssSelector("div.form"));
    }

    public String getimpoundDetailsSubmissionDialogText() {
        return impoundDetailsSubmissionDialog.getText();
    }

    public String getLotNameValidationTextMsg() {
        return lotNameValidationMsg.getText();
    }

    public String getStreetAddressValidationMsg() {
        return streetAddressValidationMsg.getText();
    }

    public String getCityValidationMsg() {
        return cityValidationMsg.getText();
    }

    public String getStateValidationMsg() {
        return stateValidationMsg.getText();
    }

    public String getZipValidationMsg() {
        return zipValidationMsg.getText();
    }

    public AdminImpoundLotsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getSearchInput() {
        return searchInput;
    }

    public WebElement getMapBubbleHeadline() {
        return mapBubbleHeadline;
    }

    public WebElement getMapBubbleContent() {
        return mapBubbleContent;
    }

    public void clickReportMissingImpoundLotLink() {
        reportMissingImpoundLotLink.click();
    }

    public WebElement getLotName() {
        return lotName;
    }

    public WebElement getStreetAddress() {
        return streetAddress;
    }

    public WebElement getCity() {
        return city;
    }

    public WebElement getState() {
        return state;
    }

    public WebElement getZip() {
        return zip;
    }

    public WebElement getPhone() {
        return phone;
    }

    public WebElement getWebsite() {
        return website;
    }

    public WebElement getOkButton() {
        return okButton;
    }

    public WebElement getSendButton() {
        return sendButton;
    }

    public WebElement getCancelButton() {
        return cancelButton;
    }

    private void fillForm(String lot_name, String street_address, String city, String state, String zip, String phone, String website) {
        //Wait for form to load
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        getLotName().sendKeys(lot_name);
        getStreetAddress().sendKeys(street_address);
        getCity().sendKeys(city);
        getState().click(); //Click 'state' dropdown
        getState().sendKeys(state);
        getZip().sendKeys(zip);
        getPhone().sendKeys(phone);
        getWebsite().sendKeys(website);
    }

    public void clickSend() {
        getSendButton().click();
    }

    public void clickCancel() {
        getCancelButton().click();
    }

    public void fillImpoundLotForm(String lot_name, String street_address, String city, String state, String zip, String phone, String website) {
        fillForm(lot_name, street_address, city, state, zip, phone, website);
    }

    public void clickOk() {
        new WebDriverWait(driver, 15).until(
                elementToBeClickable(getOkButton())).click();
    }


    /**
     * Get number of map pins displayed.
     *
     * @return
     */
    public int getNumberOfMapPins() {
        return driver.findElements(By.cssSelector(MAP_PINS_CSS)).size();
    }

    /**
     * Enter search text
     *
     * @param text
     */
    public void enterSearchText(String text) {
        enterText(driver, searchInput, text);
    }

    /**
     * Get header column names of grid.
     *
     * @return
     */
    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<String>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    /**
     * Validate the number of map pins expected
     *
     * @param numOfMapPins
     */
    public void validateNumberOfMapPins(int numOfMapPins) {

        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions.numberOfElementsToBe
                    (By.cssSelector(MAP_PINS_CSS), numOfMapPins));
        } catch (TimeoutException e) {
            LOGGER.error("Timeout exception. Not all expected map pins are showing up within 10 seconds.");
            throw e;
        }
    }

    /**
     * Click on the given map pin number
     *
     * @param pinNumber
     */
    public void clickMapPin(int pinNumber) {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(driver.findElement(By
                        .cssSelector(MAP_PINS_CSS + ":nth-of-type(" + pinNumber + ")")))).click();
    }

    /**
     * Get data of the given row
     *
     * @param rowNumber
     * @return
     */
    public HashMap<String, String> getTableRow(int rowNumber) {
        return getTableRow(impoundLotsTable, rowNumber);
    }

    /**
     * Click on the given row
     *
     * @param rowNumber
     */
    public void clickRow(int rowNumber) {
        clickRow(impoundLotsTable.findElement(By.cssSelector("div.ember-table-body-container")),
                rowNumber);
    }

    /**
     * Validate Grid Navigation control buttons
     */
    public void verifyNavigationBtns() {

        if (getTotalRecordCount() > getPageSizeSelection()) {

            verifyFooterNavBtns(false, false, true, true);
            assertEquals(getPageSizeSelection(), getPageUpperBound());
            assertEquals(getPageSizeSelection(), getNumberOfMapPins());

            //Click next button and validate page upper bound and grid navigation control buttons
            clickNextBtn();
            if (getTotalRecordCount() == getPageUpperBound()) {
                verifyFooterNavBtns(true, true, false, false);
                assertEquals(getNumberOfMapPins(), getTotalRecordCount() - getPageSizeSelection());
            } else {
                assertEquals(getPageSizeSelection() * 2, getPageUpperBound());
                verifyFooterNavBtns(true, true, true, true);
                assertEquals(getPageSizeSelection(), getNumberOfMapPins());
            }

            //Click Previous button and validate page upper bound and grid navigation control buttons
            clickPreviousBtn();
            assertEquals(getPageSizeSelection(), getPageUpperBound());
            assertEquals(getPageSizeSelection(), getNumberOfMapPins());
            verifyFooterNavBtns(false, false, true, true);

            //Click LastPage button and validate total record count and grid navigation control buttons
            clickLastPageBtn();
            assertEquals(getTotalRecordCount(), getPageUpperBound());
            assertEquals(getTotalRecordCount() % getPageSizeSelection(), getNumberOfMapPins());
            // TODO open issue: https://jira.spireon.com/browse/VFM-4234
            /*verifyFooterNavBtns(true, true, false, false);*/

            //Click First button and validate Page upper bound and grid navigation control buttons
            clickFirstPageBtn();
            assertEquals(getPageSizeSelection(), getPageUpperBound());
            assertEquals(getPageSizeSelection(), getNumberOfMapPins());
            verifyFooterNavBtns(false, false, true, true);

        } else {
            verifyFooterNavBtns(false, false, false, false);
            assertEquals(getTotalRecordCount(), getPageUpperBound());
            assertEquals(getTotalRecordCount(), getNumberOfMapPins());
        }
    }

    /**
     * Get First Record from API
     *
     * @param landmarkDetailList
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<Device.LandmarkDetail> landmarkDetailList) {

        HashMap<String, String> apiFirstRecord = new LinkedHashMap<>();

        apiFirstRecord.put("Name", landmarkDetailList.get(0).name);
        apiFirstRecord.put("City", landmarkDetailList.get(0).city);
        apiFirstRecord.put("State", landmarkDetailList.get(0).state);

        return apiFirstRecord;
    }
}
