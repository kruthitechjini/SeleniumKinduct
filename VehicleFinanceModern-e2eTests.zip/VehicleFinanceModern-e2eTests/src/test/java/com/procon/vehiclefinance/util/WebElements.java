package com.procon.vehiclefinance.util;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;

public class WebElements {

    public static final String SPINNER_CSS = "div.loading-mask";
    public static final String AJAX_SPINNER_CSS = "ajax-loader.gif";
    public static final String FADE_DIV_CSS = "div.modal-backdrop.fade";
    private static final Logger LOGGER = LoggerFactory.getLogger(WebElements.class);

    public static boolean isElementPresent(WebDriver driver, By by) {
        return !driver.findElements(by).isEmpty();
    }

    /**
     * Click on an element and wait for it to be invisible. Waits for the
     * element to be clickable.
     *
     * @param driver  WebDriver
     * @param element element to click
     * @param by      locator to check for invisibility
     * @param timeout time to wait before timing out
     */
    public static void clickElementAndWaitForInvisibility(WebDriver driver,
                                                          WebElement element,
                                                          By by, long timeout) {
        //make sure element can be clicked
        //new WebDriverWait(driver, timeout).until(ExpectedConditions
                //.elementToBeClickable(element)).click();

        // after element is clicked wait for it to be invisible
        new WebDriverWait(driver, timeout).until(ExpectedConditions
                .invisibilityOfElementLocated(by));
    }

    /**
     * Click on an element and wait for it to be invisible. Waits for the
     * element to be clickable for default timeout of 15 seconds.
     *
     * @param driver  WebDriver
     * @param element element to click
     * @param by      locator to check for invisibility
     */
    public static void clickElementAndWaitForInvisibility(WebDriver driver,
                                                          WebElement element,
                                                          By by) {
        clickElementAndWaitForInvisibility(driver, element, by, 15);
    }

    /**
     * Click on element of Modal (popup) windows and wait invisibility
     * @param driver
     * @param element - element to click which close the modal window
     */
    public static void clickElementAndWaitForInvisibility(WebDriver driver,
                                                          WebElement element)
    {
        try {
            clickElementAndWaitForInvisibility(driver, element, By.cssSelector("div.modal-backdrop.fade"), 5);
        }
        //IE throw different exception each time
        catch (Exception e) { }
    }
    /**
     * Enter text in a WebElement. Waits for spinner to be invisible and the
     * element to be clickable before trying to enter text.
     *
     * @param driver     WebDriver
     * @param inputField input field
     * @param text       text to be entered
     * @param timeout    time to wait before timing out
     */
    public static void enterText(WebDriver driver, WebElement inputField,
                                 String text, long timeout) {
        if (text == null)
            return;
        waitUntilSpinnerInvisible(driver, timeout);
        new WebDriverWait(driver, timeout).until(
                elementToBeClickable(inputField)).clear();
        inputField.sendKeys(text);
    }

    /**
     * Enter text in a WebElement. Waits for spinner to be invisible and the
     * element to be clickable before trying to enter text. Default timeout
     * is 15 seconds.
     *
     * @param driver     WebDriver
     * @param inputField input field
     * @param text       text to be entered
     */
    public static void enterText(WebDriver driver, WebElement inputField,
                                 String text) {
        enterText(driver, inputField, text, 15);
    }

    /**
     * Enter text in a WebElement and validate that full text is correctly entered in the WebElement
     *
     * @param driver
     * @param inputField
     * @param text
     */
    public static void enterTextAndConfirmEntry(WebDriver driver, WebElement inputField, String text) {
        RetryPolicy retryPolicy = new RetryPolicy()
                .withBackoff(2,8,TimeUnit.SECONDS)
                .withMaxRetries(4)
                .retryIf(temp -> temp.equals(text) == false);
        enterText(driver, inputField, text);

        Failsafe.with(retryPolicy)
                .onRetry((c, f, ctx) -> {
                    LOGGER.warn("Full text not entered" + "#{}. Retrying...", ctx.getExecutions());
                    enterText(driver, inputField, text);
                })
                .onFailure(f -> {
                    throw new AssertionError ("enterText failed with retry");
                })
                .get(() -> inputField.getAttribute("value"));
    }

    /**
     * Wait for the spinner to be visible with a default timeout of 15 seconds
     *
     * @param driver WebDriver
     */
    public static void waitUntilSpinnerVisible(WebDriver driver) {
        waitUntilSpinnerVisible(driver, 15);
    }

    /**
     * Wait for the spinner to be visible
     *
     * @param driver  WebDriver
     * @param timeout time to wait
     */
    public static void waitUntilSpinnerVisible(WebDriver driver, long
            timeout) {
        try {
            new WebDriverWait(driver, timeout).until(ExpectedConditions
                    .visibilityOfElementLocated(By.cssSelector(SPINNER_CSS)));
        }
        catch (Exception e) { }
    }

    /**
     * Wait for the spinner to be invisible with a default timeout of 15 seconds
     *
     * @param driver WebDriver
     */
    public static void waitUntilSpinnerInvisible(WebDriver driver) {
        waitUntilSpinnerInvisible(driver, 15);
    }

    /**
     * Wait for the spinner to be invisible
     *
     * @param driver  WebDriver
     * @param timeout time to wait
     */
    public static void waitUntilSpinnerInvisible(WebDriver driver, long
            timeout) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions
                .invisibilityOfAllElements(driver.findElements(By.cssSelector
                        (SPINNER_CSS))));
    }

    /**
     * This method handles a situation where spinner is invisible for some duration and then it shows up
     *
     * @param driver WebDriver
     * @param untilVisibleWait time to wait
     * @param untilInvisibleWait time to wait
     */
    public static void waitUntilSpinnerVisibleThenInvisible(WebDriver driver, int untilVisibleWait, int untilInvisibleWait) {
        try {
            waitUntilSpinnerVisible(driver, untilVisibleWait);
        } catch (TimeoutException e) {
        }

        try {
            waitUntilSpinnerInvisible(driver, untilInvisibleWait);
        } catch (TimeoutException e) {
        }
    }

    /**
     * Correctly selects or unselects a checkbox based on the desired state
     *
     * @param driver  WebDriver
     * @param element Checkbox webelement
     * @param state   state (null/true/false)
     */
    public static void updateCheckBox(WebDriver driver, WebElement element,
                                      Boolean state) {
        if (state == null)
            return;
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(element));

        // need to click only if the current state and desired state are
        // different
        if ((state && !element.isSelected()) || (!state && element.isSelected())) {
            element.click();
        }
    }

    /**
     * Wait for the ajax spinner to be visible
     *
     * @param driver  WebDriver
     * @param timeout time to wait
     */
    public static void waitUntilAjaxSpinnerVisible(WebDriver driver, long
            timeout) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions
                .visibilityOfElementLocated(By.cssSelector(AJAX_SPINNER_CSS)));

    }

    /**
     * Wait for the ajax spinner to be invisible
     *
     * @param driver  WebDriver
     * @param timeout time to wait
     */
    public static void waitUntilAjaxSpinnerInvisible(WebDriver driver, long
            timeout) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions
                .invisibilityOfElementLocated(By.cssSelector(AJAX_SPINNER_CSS)));

    }

    /**
     * This method handles a situation where ajax spinner is invisible for some duration and then it shows up
     *
     * @param driver WebDriver
     * @param untilVisibleWait time to wait
     * @param untilInvisibleWait time to wait
     */
    public static void waitUntilAjaxSpinnerVisibleThenInvisible(WebDriver driver, int untilVisibleWait, int
            untilInvisibleWait) {
        try {
            waitUntilAjaxSpinnerVisible(driver, untilVisibleWait);
        } catch (TimeoutException e) {
            LOGGER.warn("Timeout exception. There is no ajax spinners to become visible.");
        }

        try {
            waitUntilAjaxSpinnerInvisible(driver, untilInvisibleWait);
        } catch (TimeoutException e) {
            LOGGER.warn("Timeout exception. Ajax spinner doesn't become invisible within specified time.");
        }
    }

    /**
     * waiting for the fading effect to be gone on the page
     *
     * @param driver webdriver
     * @param timeout wait time in seconds
     */
    public static void waitUntilFadingDivInvisible(WebDriver driver, long timeout) {
        new WebDriverWait(driver, timeout).until(ExpectedConditions
                .invisibilityOfElementLocated(By.cssSelector(FADE_DIV_CSS)));

    }

    /**
     * Scroll to an element and click
     * @param driver
     * @param elementToClick
     */
    public static void scrollAndClick(WebDriver driver, WebElement elementToClick)
    {
        //scroll to the element
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToClick);
        //wait while to be clickable and click
        new WebDriverWait(driver, 5).until(elementToBeClickable(elementToClick)).click();
    }
}
