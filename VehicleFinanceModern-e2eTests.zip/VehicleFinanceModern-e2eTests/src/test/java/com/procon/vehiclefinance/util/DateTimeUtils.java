package com.procon.vehiclefinance.util;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.text.DateFormat;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

public class DateTimeUtils {

    /**
     * Convert the input date to the given format
     * after applying the current timezone
     *
     * @param driver
     * @param format
     * @return
     * @throws ParseException
     */
    public static String formatDate(WebDriver driver, Date date, DateFormat format) {

        format.setTimeZone(TimeZone.getTimeZone(getCurrentBrowserTimeZone(driver)));
        return format.format(date);
    }

    /**
     * Convert the input date string with input format to output format
     * after applying the current timezone
     *
     * @param driver
     * @param date
     * @param inputFormat
     * @param outputFormat
     * @return
     * @throws ParseException
     */
    public static String formatDate(WebDriver driver, String date, DateFormat inputFormat,
                                    DateFormat outputFormat) throws ParseException {

        String timeZone = getCurrentBrowserTimeZone(driver);

        return formatDate(date, inputFormat, timeZone, outputFormat, timeZone);
    }

    /**
     * Convert the input date string with input format and input timezone, to
     * output format after applying the current timezone
     *
     * @param driver
     * @param date
     * @param inputFormat
     * @param inputTimeZone
     * @param outputFormat
     * @return
     * @throws ParseException
     */
    public static String formatDate(WebDriver driver, String date, DateFormat inputFormat,
                                    String inputTimeZone, DateFormat outputFormat)
            throws ParseException {

        return formatDate(date, inputFormat, inputTimeZone, outputFormat,
                getCurrentBrowserTimeZone(driver));
    }

    /**
     * Convert the input date string with input format and input timezone to
     * output format with output timezone
     *
     * @param date
     * @param inputFormat
     * @param inputTimeZone
     * @param outputFormat
     * @param outputTimeZone
     * @return
     * @throws ParseException
     */
    public static String formatDate(String date, DateFormat inputFormat, String inputTimeZone, DateFormat outputFormat,
                                    String outputTimeZone) throws ParseException {

        inputFormat.setTimeZone(TimeZone.getTimeZone(inputTimeZone));
        outputFormat.setTimeZone(TimeZone.getTimeZone(outputTimeZone));

        return outputFormat.format(inputFormat.parse(date));
    }

    /**
     * Get browser current date
     *
     * @param driver
     * @param format
     * @return
     * @throws ParseException
     */
    public static String getCurrentBrowserDate(WebDriver driver, DateFormat format) {

        format.setTimeZone(TimeZone.getTimeZone(getCurrentBrowserTimeZone(driver)));
        return format.format(((JavascriptExecutor) driver)
                .executeScript("return new Date().getTime();"));
    }

    /**
     * Get first ZoneId based on gmtOffset. Used to calculate
     * expected time format from remote browser.
     *
     * @param gmtOffset
     * @return
     */
    private static String getFirstZoneId(String gmtOffset) {

        //Looks like this list here also has etc/+8 with offset of -8:
        // https://www.mkyong.com/java8/java-display-all-zoneid-and-its-utc-offset/

        List<String> zoneList = new ArrayList<>(ZoneId.getAvailableZoneIds());
        LocalDateTime dt = LocalDateTime.now();

        for (String zoneId : zoneList) {

            //Get ZoneOffset from zoneID
            ZoneId zone = ZoneId.of(zoneId);
            ZonedDateTime zdt = dt.atZone(zone);
            ZoneOffset zos = zdt.getOffset();

            //replace Z to +00:00
            //String offset = zos.getId().replaceAll("Z", "+00:00");
            String offset = zos.getId().replaceAll(":", "");

            //Return the first ZoneID matching gmt offset
            if (offset.equalsIgnoreCase(gmtOffset)) {
                return zoneId;
            }
        }
        return null;
    }

    /**
     * Manipulate date to given number of days
     *
     * @param format
     * @param daysToAdjust
     * @return
     */
    public static String getAdjustedDate(DateFormat format, int daysToAdjust) {

        Calendar c = Calendar.getInstance();// convert date to calendar

        //Days may be greater than or less than 0
        if (daysToAdjust != 0) {
            c.add(Calendar.DATE, daysToAdjust); // manipulate date
        }

        return format.format(c.getTime());
    }

    /**
     * Get current browser time zone
     *
     * @param driver
     * @return
     */
    public static String getCurrentBrowserTimeZone(WebDriver driver) {

        //Looks like this getFirstZoneId here also has etc/+8 with offset of -8:
        // https://www.mkyong.com/java8/java-display-all-zoneid-and-its-utc-offset/

        /*        //Get Date from browser to determine GMT Offset
        String timeZone = ((JavascriptExecutor) driver).executeScript("return new Date().toString()").toString();

        if (timeZone.indexOf("+") > -1) {

            //Parse GMT Offset and get first ZoneId matching GMT offset (ex +0530)
            timeZone = getFirstZoneId(timeZone.substring(timeZone.indexOf("+"), timeZone.indexOf("+") + 5).trim());
        }else if(timeZone.indexOf("-") > -1) {

            //Parse GMT Offset and get first ZoneId matching GMT offset (ex -0700)
            timeZone = getFirstZoneId(timeZone.substring(timeZone.indexOf("-"), timeZone.indexOf("-") + 5).trim());
        }*/

        String snippet = "var result = \"unknown\"; \n" +
                "try{\n" +
                "    result = /.*\\s(.+)/.exec((new Date()).toLocaleDateString(navigator.language, { timeZoneName:'short' }))[1];\n" +
                "}catch(e){\n" +
                "    result = (new Date()).toTimeString().match(new RegExp(\"[A-Z](?!.*[\\(])\",\"g\")).join('');\n" +
                "}\n" +
                "return result;";
        String timeZone = ((JavascriptExecutor) driver).executeScript(snippet).toString();

        return timeZone;
    }
}
