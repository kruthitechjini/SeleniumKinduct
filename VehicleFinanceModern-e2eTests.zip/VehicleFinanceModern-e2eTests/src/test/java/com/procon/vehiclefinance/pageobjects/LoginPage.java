package com.procon.vehiclefinance.pageobjects;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.services.O2cService;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;

import static com.procon.vehiclefinance.services.ServiceCaller.getUserSettings;
import static com.procon.vehiclefinance.util.WebElements.enterText;

public class LoginPage {

    private WebDriver driver;

    @FindBy(id = "login_main_section")
    private WebElement logo;

    @FindBy(css = "input[name='username']")
    private WebElement usernameField;

    @FindBy(css = "input[name='password']")
    private WebElement passwordField;

    @FindBy(id = "signInBtn")
    private WebElement signInBtn;

    @FindBy(css = "a[href='/session/forgotPassword']")
    private WebElement forgotUsernamePasswordLink;

    @FindBy(css = "div.terms > a[href='/policy/privacy']")
    private WebElement privacyPolicyLink;

    @FindBy(css = "div.terms > a[href='/policy/termsOfUse']")
    private WebElement termsAndConditionsLink;

    @FindBy(css = "div.alert.alert-danger")
    private WebElement alertLabel;

    @FindBy(css = "div.footer > p")
    private WebElement supportMessage;

    @FindBy(id = "login_ad_section")
    private WebElement loginAdvSection;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public MapPage temporaryLogin(String userName, String password) {
        enterText(driver, usernameField, userName);
        enterText(driver, passwordField, password);
        signInBtn.click();

        if (driver.getCurrentUrl().contains("renewals/show")) {
            RenewalsPage renewalsPage = PageFactory.initElements(driver, RenewalsPage.class);
            return renewalsPage.continueAndRenewLater();
        } else {
            return PageFactory.initElements(driver, MapPage.class);
        }

    }

    /**
     * Enter the username and password and click on Sign In button. This
     * expects the user to have expiring devices which prompt an interim page
     * with renewal message.
     *
     * @param userName username
     * @param password password
     * @return the page object associated with RenewalsPage, which is shown
     * after loginWithRenewals
     */
    public RenewalsPage loginWithRenewals(String userName, String password) {
        enterText(driver, usernameField, userName);
        enterText(driver, passwordField, password);
        signInBtn.click();
        return PageFactory.initElements(driver, RenewalsPage.class);
    }

    /**
     * Enter the username and password and click on Sign In button.
     *
     * @param userName username
     * @param password password
     * @return the MapPage page object
     */
    public MapPage loginWithNoRenewals(String userName, String password) {
        // driver.manage().timeouts().pageLoadTimeout(45, TimeUnit.SECONDS ); // may be required for local testing - please leave in.
        usernameField.sendKeys(userName);
        passwordField.sendKeys(password);
        signInBtn.click();
        return PageFactory.initElements(driver, MapPage.class);
    }

    /**
     * Login the user without knowning if renewals page is expected or not from the test data
     * A call to the o2c endpoint is made to decide if renewals page should be handled
     *
     * @param userName
     * @param password
     * @return map page object
     * @throws IOException
     * @throws UnirestException
     */
    public MapPage login(String userName, String password) throws IOException, UnirestException {
        usernameField.sendKeys(userName);
        passwordField.sendKeys(password);
        signInBtn.click();

        User.UserSettings userSettings = getUserSettings(driver);
        boolean expectRenewalPage = O2cService.expectRenewalPage(driver, userSettings.accountId);

        MapPage mapPage;

        if (expectRenewalPage) {
            RenewalsPage renewalsPage = PageFactory.initElements(driver, RenewalsPage.class);
            mapPage = renewalsPage.continueAndRenewLater();
        } else {
            mapPage = PageFactory.initElements(driver, MapPage.class);
        }

        return mapPage;
    }

    public String getLogoImgSrc() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(logo))
                .findElement(By.tagName("img")).getAttribute("src");
    }

    public WebElement getPrivacyPolicyLink() {
        return this.privacyPolicyLink;
    }

    public WebElement getTermsAndConditionsLink() {
        return this.termsAndConditionsLink;
    }

    public String getAlertText() {
        return this.alertLabel.getText();
    }

    public String getSupportText() {
        return this.supportMessage.getText();
    }


    public WebElement getUsernameField() {
        return usernameField;
    }

    public String getLoginAdvSectionSrc() {
        return loginAdvSection.getAttribute("src");
    }
}
