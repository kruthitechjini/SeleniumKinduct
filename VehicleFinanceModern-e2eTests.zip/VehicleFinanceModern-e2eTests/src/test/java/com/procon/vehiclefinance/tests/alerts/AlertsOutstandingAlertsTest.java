package com.procon.vehiclefinance.tests.alerts;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Alert;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsOutstandingAlertsPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsPage;
import com.procon.vehiclefinance.tests.BaseTest;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.AlertService.generateAlerts;
import static com.procon.vehiclefinance.services.AlertService.getOutstandingAlerts;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AlertsOutstandingAlertsTest extends BaseTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlertsOutstandingAlertsTest.class);

    private NavbarHeaderPage navbarHeaderPage;
    private AlertsPage alertsPage;
    private String serialNumber;
    private Map<String, String> alertType;

    // this class needs to be static for Jackson to be able to databind to it
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String serialNumber;
        public Map<String, String> alertType;
    }

    @BeforeMethod(alwaysRun = true)
    private void login(Method method) {
        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;
            serialNumber = data.serialNumber;
            alertType = data.alertType;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }
        } catch (JsonProcessingException e) {
            // no need to do anything, login with default values
        }

        login();

        setZaleniumMessage("Starting " + method.getName());
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        alertsPage = navbarHeaderPage.clickAlerts();
    }

    @AfterMethod(alwaysRun = true)
    private void logout(ITestResult testResult, ITestContext context) throws
            IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Clear selected outstanding alerts", groups =
            {"alerts"})
    public void testClearSelectedOutstandingAlerts() throws UnirestException, IOException {

        AlertsOutstandingAlertsPage alertsOutstandingAlertsPage = alertsPage.alertsOutstandingAlertsLink();

        // confirm that alert checkboxes are available
        List<Integer> availableAlertTypeIds = alertsOutstandingAlertsPage
                .getAvailableAlertTypeIds();
        assertTrue(availableAlertTypeIds.size() > 0, "No Alert Types are " +
                "present in UI, can't create alerts.");

        int numOfExistingAlerts = alertsOutstandingAlertsPage
                .getTotalRecordCount();
        String dismissedAlertGlobalId;
        List<Alert.AlertData> alertData;

        if (serialNumber == null || PROD_ENVS.contains(env)) {
            LOGGER.warn("No serial number provided OR prod environment " +
                    "detected. Test will continue with pre-existing alerts");
            // get outstanding alerts to verify that 1st one was dismissed
            alertData = getOutstandingAlerts(driver, availableAlertTypeIds).data;
            assertTrue(alertData.size() > 0, "No outstanding alerts present.");
            dismissedAlertGlobalId = alertData.get(0).globalId;
        } else {
            Device.DeviceAlert alert = generateAlerts(driver, serialNumber,
                    Arrays.asList(availableAlertTypeIds.get(0))).get(0);
            dismissedAlertGlobalId = alert.globalId;
            RetryPolicy retryPolicy = new RetryPolicy()
                    .withBackoff(1, 8, TimeUnit.SECONDS)
                    .withMaxRetries(4)
                    .retryIf((Integer numAlerts) -> numAlerts <=
                            numOfExistingAlerts);
            Failsafe.with(retryPolicy)
                    .onRetry(r -> {
                        alertsOutstandingAlertsPage.selectAllAlertTypes();
                        alertsOutstandingAlertsPage.clickFilterBtn();
                    })
                    .onFailure(f -> {
                        throw new AssertionError("Generated Alert" +
                                " did not show in UI");
                    })
                    .get(() -> alertsOutstandingAlertsPage.getTotalRecordCount());
        }

        // TODO: 8/28/18 issue https://jira.spireon.com/browse/VFM-5041
        alertsOutstandingAlertsPage.unSelectAllAlertTypes();

        //select first record and click clear selected button
        alertsOutstandingAlertsPage.selectFirstRow();
        alertsOutstandingAlertsPage.clickBtnClearSelected();

        // get the outstanding alerts again and confirm that alert that was
        // just dismissed is not present anymore
        alertData = getOutstandingAlerts(driver, availableAlertTypeIds).data;
        for (Alert.AlertData alert : alertData) {
            if (alert.globalId == dismissedAlertGlobalId) {
                fail("Alert was not dismissed: " + dismissedAlertGlobalId);
            }
        }
    }

    @Test(description = "Outstanding Alerts Filters", groups = {"alerts"})
    public void testOutstandingAlertFilters() throws UnirestException, IOException {

        /**
         * Steps
         * 1. get available alert types from UI
         * 2. generate alert for each alert type
         * 3. filter records for some alert types
         * 4. make sure correct records are filtered
         * 5. Clear All functionality
         */

        AlertsOutstandingAlertsPage alertsOutstandingAlertsPage = alertsPage.alertsOutstandingAlertsLink();

        // Get available alert types from UI
        List<Integer> availableAlertTypeIds = alertsOutstandingAlertsPage
                .getAvailableAlertTypeIds();
        assertTrue(availableAlertTypeIds.size() > 0, "No Alert Types are " +
                "present in UI, can't create alerts.");

        int numOfExistingAlerts = alertsOutstandingAlertsPage
                .getTotalRecordCount();

        if (serialNumber == null || PROD_ENVS.contains(env)) {
            LOGGER.warn("No serial number provided OR prod environment " +
                    "detected. Test will continue with pre-existing alerts if present");
        } else {
            generateAlerts(driver, serialNumber,
                    availableAlertTypeIds).get(0);
            RetryPolicy retryPolicy = new RetryPolicy()
                    .withBackoff(1, 8, TimeUnit.SECONDS)
                    .withMaxRetries(4)
                    .retryIf((Integer numAlerts) -> numAlerts <=
                            numOfExistingAlerts);
            Failsafe.with(retryPolicy)
                    .onRetry(r -> {
                        alertsOutstandingAlertsPage.selectAllAlertTypes();
                        alertsOutstandingAlertsPage.clickFilterBtn();
                    })
                    .onFailure(f -> {
                        throw new AssertionError("Generated Alert" +
                                " did not show in UI");
                    })
                    .get(() -> alertsOutstandingAlertsPage.getTotalRecordCount());
        }

        alertsOutstandingAlertsPage.unSelectAllAlertTypes();
        //Check if filteration happens correct.  Create a subset of alerts to test
        for (Integer alertId : availableAlertTypeIds.subList(0, 2)) {
            alertsOutstandingAlertsPage.selectAlertType(alertId); //select alert type to filter
            alertsOutstandingAlertsPage.clickFilterBtn();

            //Make sure only one alert type is filtered
            String alertTypeStr;
            int alertTypeId;

            for (HashMap<String, String> alertRec : alertsOutstandingAlertsPage.getAlertListInGrid()) {
                alertTypeStr = alertRec.get("Type");
                alertTypeId = alertsOutstandingAlertsPage.getAlertTypeId(alertTypeStr);
                assertTrue(alertId == alertTypeId);
            }

            //unselect selected alert so that it is not included in the filter again
            alertsOutstandingAlertsPage.unSelectAlertType(alertId);
        }

        //Select and clear all alerts and check if all alerts are cleared
        alertsOutstandingAlertsPage.selectAllAlertTypes();
        alertsOutstandingAlertsPage.clickFilterBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        alertsOutstandingAlertsPage.clickClearAllBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        List<HashMap<String, String>> alertsList = alertsOutstandingAlertsPage.getAlertListInGrid();
        assertEquals(alertsList.size(), 0);
    }
}

