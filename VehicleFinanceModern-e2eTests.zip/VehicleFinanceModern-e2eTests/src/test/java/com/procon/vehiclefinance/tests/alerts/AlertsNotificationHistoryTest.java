package com.procon.vehiclefinance.tests.alerts;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Alert;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsNotificationHistoryPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertsPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.services.AlertService.getAlertFilterResults;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class AlertsNotificationHistoryTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AlertsNotificationHistoryTest.class.getName());

    // this class needs to be static for Jackson to be able to databind to it
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @Test(description = "Notification History - verify page elements", groups =
            {"alerts"})
    public void testVerifyNotificationHistoryPageElements() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        AlertsNotificationHistoryTest.LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, AlertsNotificationHistoryTest.LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        MapPage mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        // Navigate to AlertsNotificationHistory
        AlertsPage alertsPage = navbarHeaderPage.clickAlerts();
        AlertsNotificationHistoryPage alertsNotificationHistoryPage = alertsPage.AlertsNotificationHistoryLink();


        // Confirm page elements are present
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(alertsNotificationHistoryPage.isPanelTitlePresent());
        assertTrue(alertsNotificationHistoryPage.getPanelTitleText().equals("Notification History - Last 30 Days"));
        assertTrue(alertsNotificationHistoryPage.getSearchPlaceHolderText().equals("Search"));
        assertTrue(alertsNotificationHistoryPage.getAlertsDropdownPlaceHolderText().contains("All Alert Types"));
        assertTrue(alertsNotificationHistoryPage.isGridDisplayed());
        assertTrue(alertsNotificationHistoryPage.navigationControlFirstPageIsDisplayed());
        assertTrue(alertsNotificationHistoryPage.navigationControlNextPageIsDisplayed());
        assertTrue(alertsNotificationHistoryPage.navigationControlPreviousPageIsDisplayed());
        assertTrue(alertsNotificationHistoryPage.navigationControlLastPageIsDisplayed());
        assertTrue(alertsNotificationHistoryPage.navigationControlRefreshPageIsDisplayed());
        assertTrue(alertsNotificationHistoryPage.isclearAllBtnDisplayed());
        assertTrue(alertsNotificationHistoryPage.isClearSelectedBtnDisplayed());
        assertTrue(alertsNotificationHistoryPage.isPagingStatusDisplayed().contains("of"));

        // get current date - 30 days
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:sss'Z'");
        Calendar c = Calendar.getInstance();// convert date to calendar
        c.add(Calendar.DATE, -30); // manipulate date
        String dateStr = dateFormat.format(c.getTime());

        String filterStr = "[{\"property\":\"alertSpecId\"," +
                "\"operator\":\"exists\",\"value\":true," +
                "\"type\":\"Boolean\"},{\"property\":\"acknowledged\"," +
                "\"operator\":\"ne\",\"value\":true,\"type\":\"Boolean\"}," +
                "{\"property\":\"alertDate\",\"operator\":\"gte\"," +
                "\"value\":\"" + dateStr + "\",\"type\":\"Date\"}]";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("filters", filterStr);
        queryParams.put("sorts", "[{\"property\":\"alertDate\"," +
                "\"direction\":\"DESC\"}]");
        queryParams.put("doCount", true);

        //Get Notification History data for Last 30 Days
        Alert.AlertFilterResults results = getAlertFilterResults(driver,
                queryParams);

        if (results.total > 0) {

            //Get recipient text in the grid
            String recipient = alertsNotificationHistoryPage.getRecipietText();

            List<String> recipientList;
            if (!recipient.equals("") && !recipient.equals(null)) {
                recipientList = Arrays.asList(recipient.split(", "));
            } else {
                recipientList = new ArrayList<>();
            }

            //Confirm Notification modal can be opened and elements are present
            alertsNotificationHistoryPage.clickViewNotificationButton();
            assertTrue(alertsNotificationHistoryPage.getNotificationModalAlertInfoLabelText().equals("ALERT INFO"));
            assertTrue(alertsNotificationHistoryPage.getNotificationModalLocationInfoLabelText().equals("LOCATION INFO"));
            assertTrue(alertsNotificationHistoryPage.getNotificationModalRecipientsLabelText().equals("RECIPIENTS"));
            assertEquals(alertsNotificationHistoryPage.getNotificationModalRecipients(), recipientList);

            //close Notification modal
            alertsNotificationHistoryPage.clickNotificationModalCancelBtn();

            //Confirm Notification History Map can be opened and elements are present
            alertsNotificationHistoryPage.clickNotificationMapModalBtn();
            assertTrue(alertsNotificationHistoryPage.getNotificationMapModalLabelText().equals("Notification History Map"));
            alertsNotificationHistoryPage.clickNotificationMapModalCancelBtn();

        } else {
            logger.log(Level.WARNING, "No records found");
        }

        // logout
        navbarHeaderPage.logout();
    }
}
