package com.procon.vehiclefinance.pageobjects.reports;

import com.fasterxml.jackson.annotation.JsonCreator;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class AdvancedReportsPage extends ReportSelectionPanel {

    protected static final Logger logger = Logger
            .getLogger(AdvancedReportsPage.class.getName());

    protected WebDriver driver;

    // header elements
    @FindBy(css = "div.modal-header > button.close")
    private WebElement closeBtn;

    @FindBy(css = "div.modal-header > h4.modal-title")
    private WebElement headerLabel;

    // left panel elements
    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(1) select")
    private WebElement reportTypeDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(2) input")
    private WebElement groupsInput;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(2) label")
    private WebElement groupsLabel;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(3) input")
    private WebElement vehiclesInput;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(3) label")
    private WebElement vehiclesLabel;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(4) select")
    private WebElement dateRangeDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.has-error > span.help-block")
    private WebElement helpBlockLabel;

    @FindBy(css = "div.modal-body div.selection-panel div.custom-date > div.row:nth-of-type(1) input")
    private WebElement customStartDateInput;

    @FindBy(css = "div.modal-body div.selection-panel div.custom-date > div.row:nth-of-type(1) select")
    private WebElement customStartTimeDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.custom-date > div.row:nth-of-type(2) input")
    private WebElement customEndDateInput;

    @FindBy(css = "div.modal-body div.selection-panel div.custom-date > div.row:nth-of-type(2) select")
    private WebElement customEndTimeDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(2) select")
    private WebElement deviceStatusDropdown;

    @FindBy(css = "div.modal-body div.selection-panel input[placeholder='-- All Dealers --']")
    private WebElement dealerTextInput;

    @FindBy(css = "div.modal-body div.selection-panel ul li")
    private List<WebElement> dealerArrowDownList;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(4) select")
    private WebElement dateRangeDropdownInstReqHist;

    // right panel elements

    @FindBy(css = "a[href='#criteria-tab']")
    private WebElement criteriaTabLink;

    @FindBy(css = "a[href='#columns-tab']")
    private WebElement columnsTabLink;

    @FindBy(css = "a[href='#save-cfg-tab']")
    private WebElement saveConfigTabLink;

    //Saved Configuration elements
    @FindBy(id = "report-scheduled")
    private WebElement scheduledDeliveryCheckBox;

    @FindBy(css = "input[name='userName']")
    private WebElement reportNameInput;

    @FindBy(css = "div.time-select select")
    private WebElement startTimeDropDown;

    @FindBy(css = "div.modal .ember-view .col-sm-3:nth-child(1) select")
    private WebElement chooseReceipientSelectBox;

    @FindBy(css = "div.col-sm-1.alert-management-add-button-width > button")
    private WebElement addBtn;

    @FindBy(css = "div.modal div.advanced-reports-tab div.ember-view div:nth-child(5) select.ember-select")
    private WebElement chooseFormatSelectBox;

    @FindBy(css = "#column_field_stockNumber")
    private WebElement stockNumberCheckBox;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    public enum ReportCriteria {
        SELECT_ALL("checkAll"),
        AUTO_REPORT("alertCriteria0"),
        GEOFENCE_VIOLATIONS("alertCriteria1"),
        GEOZONE_VIOLATIONS("alertCriteria2"),
        DRIVE_REPORT("alertCriteria3"),
        STOP_REPORT("alertCriteria4"),
        LOW_BATTERY_VOLTAGE("alertCriteria5"),
        BATTERY_DISCONNECT("alertCriteria6"),
        POWER_UP_GPS("alertCriteria7"),
        VEHICLE_ABANDONMENT("alertCriteria8"),
        TOW_ALERT("alertCriteria9"),
        MAX_SPEED("alertCriteria10"),
        LOCATE("alertCriteria11"),
        STIPULATION_EVENT("alertCriteria12"),
        ON_BACKUP_BATTERY("alertCriteria13"),
        IGNITION_ON("alertCriteria14"),
        IGNITION_OFF("alertCriteria15"),
        STARTER_DISABLE("responseCriteria0"),
        STARTER_ENABLE("responseCriteria1"),
        SET_GEOFENCE("responseCriteria2"),
        WARNING_ON("responseCriteria3"),
        WARNING_OFF("responseCriteria4"),
        SET_STOP_REPORT("responseCriteria5"),
        SET_DRIVE_REPORT("responseCriteria6"),
        TOW_ALERT_ON("responseCriteria7"),
        TOW_ALERT_OFF("responseCriteria8"),
        SET_MAX_SPEED("responseCriteria9");

        private String id;

        ReportCriteria(String id) {
            this.id = id;
        }

        public String getId() {
            return id;
        }

        @JsonCreator
        public static ReportCriteria forValue(String value) {
            return ReportCriteria.valueOf(value.replaceAll(" ", "_").toUpperCase());
        }

        public static HashSet<String> getValues(List<ReportCriteria> criteriaList) {
            HashSet<String> values = new HashSet<>();
            for (ReportCriteria criteria : criteriaList) {
                values.add(criteria.name().replace("_", " "));
            }
            return values;
        }
    }

    public enum ReportColumns {
        DISPLAY_NAME("column_field_displayName"),
        STOCK_NUMBER("column_field_stockNumber"),
        VIN("column_field_vin"),
        ODOMETER("column_field_odometer"),
        HEADING("column_field_heading"),
        STATUS("column_field_status"),
        NEW_LOCATION("column_field_newLoc"),
        GROUP("column_field_group"),
        SERIAL("column_field_serial"),
        RESPONSE("column_field_response"),
        DATE_TIME("column_field_date"),
        TYPE("column_field_type"),
        EVENT("column_field_event"),
        ADDRESS("column_field_address"),
        LATITUDE("column_field_latitude"),
        LONGITUDE("column_field_longitude"),
        SPEED("column_field_speed"),
        SATS("column_field_sats"),
        E_VOLTS("column_field_evolts"),
        USER("column_field_user");

        private String id;

        ReportColumns(String id) {
            this.id = id;
        }

        public String getId() {
            return id;
        }

        @JsonCreator
        public static ReportColumns forValue(String value) {
            return ReportColumns.valueOf(value.replaceAll("[\\-\\s]", "_").toUpperCase());
        }
    }

    // TODO Define elements for columns and save configuration tab

    private static final String CANCEL_BTN_CSS = "div.modal-footer > button.btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    private static final String RUN_BTN_CSS = "div.modal-footer > button.btn-primary";
    @FindBy(css = RUN_BTN_CSS)
    private WebElement runBtn;

    public AdvancedReportsPage(WebDriver driver) {
        this.driver = driver;
    }

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    @Override
    public WebElement getReportTypeDropdown() {
        return reportTypeDropdown;
    }

    @Override
    public WebElement getGroupsInput() {
        return groupsInput;
    }

    @Override
    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    @Override
    public WebElement getVehiclesLabel() {
        return vehiclesLabel;
    }

    @Override
    public WebElement getVehiclesInput() {
        return vehiclesInput;
    }

    @Override
    public WebElement getDateRangeDropdown() {
        return dateRangeDropdown;
    }

    @Override
    public WebElement getHelpBlockLabel() {
        return helpBlockLabel;
    }

    @Override
    public WebElement getCustomStartDateInput() {
        return customStartDateInput;
    }

    @Override
    public WebElement getCustomStartTimeDropdown() {
        return customStartTimeDropdown;
    }

    @Override
    public WebElement getCustomEndDateInput() {
        return customEndDateInput;
    }

    @Override
    public WebElement getCustomEndTimeDropdown() {
        return customEndTimeDropdown;
    }

    public WebElement getCriteriaTabLink() {
        return criteriaTabLink;
    }

    public WebElement getColumnsTabLink() {
        return columnsTabLink;
    }

    public WebElement getSaveConfigTabLink() {
        return saveConfigTabLink;
    }

    public WebElement getChooseReceipientSelectBox() {
        return new WebDriverWait(driver, 10).until(elementToBeClickable(chooseReceipientSelectBox));
    }

    public WebElement getAddBtn() {
        return addBtn;
    }

    public WebElement getDealerTextInput() {
        return dealerTextInput;
    }

    public WebElement getDateRangeDropdownInstReqHist() {
        return dateRangeDropdownInstReqHist;
    }

    public WebElement getReportNameInput() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(reportNameInput));
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    /**
     * Select list of criteria passed
     *
     * @param reportCriteriaList
     */
    public void selectReportCriteria(List<ReportCriteria> reportCriteriaList) {
        for (ReportCriteria criteria : reportCriteriaList) {
            driver.findElement(By.id(criteria.getId())).click();
        }
    }

    /**
     * Select list of columns passed
     *
     * @param reportColumnsList
     */
    public void selectReportColumns(List<ReportColumns> reportColumnsList) {
        for (ReportColumns columns : reportColumnsList) {
            driver.findElement(By.id(columns.getId())).click();
        }
    }

    @Override
    public void clickRunButton() {
        clickElementAndWaitForInvisibility(driver, runBtn, By.cssSelector
                (RUN_BTN_CSS));
    }

    public void checkStockNumberBox(Boolean state) {
        updateCheckBox(driver, stockNumberCheckBox, state);
    }

    public void clickCancelButton() {
        clickElementAndWaitForInvisibility(driver, cancelBtn, By
                .cssSelector(CANCEL_BTN_CSS));
    }

    public void clickSaveConfigTabLink() {
        new WebDriverWait(driver, 40).until(
                elementToBeClickable(saveConfigTabLink)).click();
    }

    /**
     * Click on Columns Tab
     */
    public void clickColumnsTabLink() {
        new WebDriverWait(driver, 20).until(
                elementToBeClickable(columnsTabLink)).click();
    }

    protected void enterReportName(String reportNameText) {
        enterText(driver, reportNameInput, reportNameText);
    }

    public void runAdvancedReport(ReportTypeEnum reportType, String groupNames, String vehicleNames,
                                  DateRangeEnum dateRange, String reportName, String date, Boolean stockStatus,
                                  List<String> recipients, String reportFormat) {
        enterReportParams(reportType, groupNames, vehicleNames, dateRange);
        selectCustomDate(date);
        checkStockNumberBox(stockStatus);
        clickSaveConfigTabLink();
        enterReportName(reportName);
        addRecipient(recipients, reportFormat);
        clickRunButton();
    }

    /**
     * Run advanced report for Installation Request History
     *
     * @param reportType
     * @param dealerName
     * @param dateRange
     * @param reportName
     * @param recipients
     * @param reportFormat
     */
    public void runAdvancedReport(ReportTypeEnum reportType, String dealerName, DateRangeEnum dateRange,
                                  String reportName, List<String> recipients, String reportFormat) {
        selectReportType(reportType);
        selectDealer(dealerName);
        selectDateRangeIRH(dateRange);
        clickSaveConfigTabLink();
        enterReportName(reportName);
        addRecipient(recipients, reportFormat);
        clickRunButton();
    }

    /**
     * Run advanced report by selecting list of Criterias and Columns
     *
     * @param reportType
     * @param groupNames
     * @param vehicleNames
     * @param dateRange
     * @param reportCriteriaList
     * @param reportColumnsList
     */
    public void runAdvancedReport(ReportTypeEnum reportType, String groupNames, String vehicleNames,
                                  DateRangeEnum dateRange, List<ReportCriteria> reportCriteriaList,
                                  List<ReportColumns> reportColumnsList) {
        enterReportParams(reportType, groupNames, vehicleNames, dateRange);
        selectReportCriteria(reportCriteriaList);
        clickColumnsTabLink();
        selectReportColumns(reportColumnsList);
        clickRunButton();
    }

    protected void selectCustomDate(String date) {
        if (date != null) {
            enterText(driver, customStartDateInput, date);
        }
    }

    private void selectChooseFormat(String chooseFormat) {
        if (chooseFormat != null) {
            new Select(chooseFormatSelectBox).selectByVisibleText(chooseFormat);
        }
    }

    protected void addRecipient(List<String> recipients, String chooseFormat) {
        if (recipients != null) {
            Select select = new Select(getChooseReceipientSelectBox());
            for (String recipient : recipients) {
                select.selectByVisibleText(recipient);
                new WebDriverWait(driver, 10).until(
                        elementToBeClickable(addBtn)).click();
            }
        }
        selectChooseFormat(chooseFormat);
    }

    /**
     * Get a list of already added recipient names
     *
     * @return list of recipient names
     */
    public List<String> getAddedRecipientsList() {
        getReportNameInput();
        List<WebElement> recipientTableRows = driver.findElements(By.cssSelector
                ("#save-cfg-tab div.alert-recipient-grid-body > table > tbody > tr"));
        List<String> recipientList = new ArrayList<>();
        for (WebElement row : recipientTableRows) {
            String name = row.findElement(By.cssSelector("td:nth-child(1)"))
                    .getText().trim();
            recipientList.add(name);
        }
        return recipientList;
    }

    /**
     * Delete existing recipients from the recipient list
     *
     * @param recipients list of recipients to delete
     */
    private void deleteRecipients(List<String> recipients) {
        getReportNameInput();
        if (recipients != null) {
            for (String recipient : recipients) {
                List<WebElement> recipientTableRows = driver.findElements(By.cssSelector
                        ("#save-cfg-tab div.alert-recipient-grid-body > table > " +
                                "tbody > tr"));
                for (WebElement row : recipientTableRows) {
                    if (recipient.equals(row.findElement(By.cssSelector
                            ("td:nth-child(1)")).getText().trim())) {
                        WebElement deleteBtn = row.findElement(By.cssSelector
                                ("td:nth-child(3) > a"));
                        deleteBtn.click();
                        break;
                    }
                }
            }
        }
    }

    /**
     * To change recipient of the report and save
     *
     * @param recipientsToAdd
     * @param recipientsToRemove
     * @param format
     */
    public void editRecipients(List<String> recipientsToAdd, List<String> recipientsToRemove, String format) {
        clickSaveConfigTabLink();
        deleteRecipients(recipientsToRemove);
        addRecipient(recipientsToAdd, format);
    }

    private void selectDealer(String dealerName) {
        if (dealerName != null) {
            dealerTextInput.sendKeys(dealerName);
            try {
                new WebDriverWait(driver, 10).until(e -> dealerArrowDownList.size() == 1);
                dealerArrowDownList.get(0).click();
            }
            catch (TimeoutException e) {
                throw new TimeoutException("There are more than 1 dealer found. " + e);
            }
        }
    }

    private void selectDateRangeIRH(DateRangeEnum dateRange) {
        if (dateRange != null) {
            List<WebElement> options = getDateRangeDropdownInstReqHist().findElements(By.tagName("option"));

            for (WebElement option : options) {
                if (option.getText().contains(dateRange.getName())) {
                    option.click();
                    break;
                }
            }
        }
    }
}
