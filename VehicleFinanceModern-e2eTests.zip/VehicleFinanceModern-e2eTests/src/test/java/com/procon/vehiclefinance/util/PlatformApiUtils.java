package com.procon.vehiclefinance.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.PlatformObject;
import com.spireon.platform.cdm.v1.dto.AssetDto;
import com.spireon.platform.cdm.v1.dto.DeviceDto;
import com.spireon.platform.utils.PlatformAssetBuilder;
import com.spireon.platform.utils.PlatformDeviceBuilder;
import com.spireon.platform.utils.PlatformIdentityUtils;
import com.spireon.platform.utils.PlatformUtils;
import com.spireon.platform.utils.model.RabbitmqEvent;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import static com.spireon.platform.utils.RabbitMQEventPublisher.sendEvent;

public class PlatformApiUtils {
    protected static final Logger logger = LoggerFactory.getLogger(PlatformApiUtils.class);

    /**
     * Get Token
     *
     * @param userName, password, appToken
     * @return token
     */
    public static String getToken(String userName, String password, String appToken) {
        return PlatformIdentityUtils.getJwtToken(userName, password, appToken);
    }

    /**
     * Create a device & asset on the fly (using a default VIN number)
     *
     * @param vehicleName
     * @param token
     * @return
     * @throws UnirestException
     */
    public static PlatformObject createDeviceAndAsset(String vehicleName, String token) throws UnirestException {
        return createDeviceAndAsset(vehicleName, "5N1AR1NB5CC624613", token);
    }

    /**
     * Create a new device & vehicle on the fly
     *
     * @param vehicleName the name for the new vehicle
     * @param vinNumber   vin number to be used for new asset
     * @param token       token to be used for platform API calls
     * @return PlatformObject that includes the DeviceDto, AssetDto, and a result boolean in it
     * @throws UnirestException
     */
    public static PlatformObject createDeviceAndAsset(String vehicleName, String vinNumber, String token) throws UnirestException {

        // build an AssetDto object with provided info
        AssetDto assetDto = new PlatformAssetBuilder().withMake("Ford")
                .withModel(vehicleName).withYear(1966).withVin(vinNumber)
                .withDescription(vehicleName).withName(vehicleName)
                .withInitialOdometer(123D).build();

        // prepare the device to be created
        String deviceName = Long.toString(System.currentTimeMillis());

        // special handing for device IMEI to make it 15 characters
        StringBuffer imeiStrBuffer = new StringBuffer();
        imeiStrBuffer.append(deviceName);
        int fillerInt = 1;

        while (imeiStrBuffer.length() < 15) {
            imeiStrBuffer.append(Integer.toString(fillerInt));
            fillerInt++;
        }

        // create device
        DeviceDto deviceDto = new PlatformDeviceBuilder().withSerialNumber(deviceName)
                .withName(deviceName).withDescription(deviceName)
                .withImei(imeiStrBuffer.toString()).build();

        AssetDto resultAssetDto = PlatformUtils.createAsset(assetDto, token);
        DeviceDto resultDeviceDto = PlatformUtils.createDevice(deviceDto, token);
        PlatformUtils.instrument(resultAssetDto.getId(), resultDeviceDto.getId(), token);

        logger.info("Newly created asset name: " + resultAssetDto.getName());
        logger.info("Newly created device serial #: " + resultDeviceDto.getSerialNumber());

        PlatformObject platformObject = new PlatformObject();
        platformObject.assetDto = resultAssetDto;
        platformObject.deviceDto = resultDeviceDto;

        return platformObject;
    }

    /**
     * Delete a vehicle
     *
     * @param vehicleId ID of the vehicle to be deleted
     * @return boolean result of the deletion - successful or failed
     * @throws UnirestException, IOException
     */
    public static Boolean deleteVehicle(String vehicleId, String token) throws UnirestException {
        int result = PlatformUtils.deleteAsset(vehicleId, token);

        return (result == 204) ? true : false;
    }

    /**
     * Delete a device (soft delete to set the device inactive)
     *
     * @param deviceId ID of the device to be deleted
     * @return boolean result of the deletion - successful or failed
     * @throws UnirestException, IOException
     */
    public static Boolean deleteDevice(String deviceId, String token) throws UnirestException {
        int result = PlatformUtils.deleteDevice(deviceId, token);

        return (result == 204) ? true : false;
    }

    /**
     * Generate events for a given device
     *
     * @param deviceSerial serial number of the device where the events are generated for
     * @param tripFile     path to a trip file with events
     * @param eventDelay   interval between each event in the trip
     * @throws UnirestException, IOException
     */
    public static void generateEvents(String deviceSerial, String tripFile, int eventDelay)
            throws IOException, UnirestException, InterruptedException {
        int deviceTypeId = 17;

        String CSV_DATA_FILE = tripFile;

        Reader in = new FileReader(CSV_DATA_FILE);
        CSVParser parser = CSVFormat.RFC4180.withHeader()
                .withIgnoreEmptyLines().parse(in);

        LinkedList<RabbitmqEvent> events = new LinkedList<>();

        for (CSVRecord record : parser) {
            Map<String, Object> singleRecord = new LinkedHashMap<>();

            for (String key : parser.getHeaderMap().keySet()) {
                singleRecord.put(key, record.get(key));
            }

            ObjectMapper mapper = new ObjectMapper();
            RabbitmqEvent event = mapper.convertValue(singleRecord, RabbitmqEvent.class);

            events.add(event);

        }

        sendEvent(events, deviceSerial, deviceTypeId, eventDelay);
    }
}
