package com.procon.vehiclefinance.tests.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Contacts;
import com.procon.vehiclefinance.models.ExportFormat;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.pageobjects.reports.AdvancedReportsPage;
import com.procon.vehiclefinance.pageobjects.reports.DateRangeEnum;
import com.procon.vehiclefinance.pageobjects.reports.Report;
import com.procon.vehiclefinance.pageobjects.reports.ReportTypeEnum;
import com.procon.vehiclefinance.util.DateTimeUtils;
import com.procon.vehiclefinance.util.PlatformApiUtils;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import javax.mail.Flags;
import javax.mail.MessagingException;
import javax.mail.search.AndTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.ContactService.createContact;
import static com.procon.vehiclefinance.services.ContactService.deleteContact;
import static com.procon.vehiclefinance.services.ReportService.*;
import static com.procon.vehiclefinance.services.ServiceCaller.getUserSettings;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvFirstRow;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static com.procon.vehiclefinance.util.Email.getEmailAttachments;
import static com.procon.vehiclefinance.util.Email.markEmailsAsRead;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class ReportsTest extends ReportsBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportsTest.class);

    /*private static final DateFormat UI_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy hh:mm a '('z')'");*/

    // there's currently an issue due to which the date is showing the
    // daylight saving value based on current date, instead of when the
    // report was actually run. So even though the report could have been run
    // when DST was on (PDT), the date in report header will show as (PST).
    // SO ignoring that part to compare for now
    private static final DateFormat UI_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy hh:mm a");

    private static final DateFormat API_DATE_FORMAT = new SimpleDateFormat
            ("yyyy-MM-dd'T'HH:mm:ssZ");

    private static final DateFormat CELL_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy h:mm a");

    //this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ReportsDropDownData {
        public List<String> reportTypeList;
        public List<String> reportDateRange;
        public String vehiclesPlaceholderText;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ImpoundTestData {
        public String serialNumber;
        public String tripFile;
    }

    @Test(description = "Validate UI Elements of Reports tab", groups =
            {"reports", "pipeline"})
    public void testReportsUIElements() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        ReportsTest.ReportsDropDownData data = null;
        try {
            data = mapper.treeToValue(dataNode, ReportsTest.ReportsDropDownData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Validate UI elements of left selection panel dropdown
        verifySelectionPanelDropDowns(data.reportTypeList, data
                .vehiclesPlaceholderText, data.reportDateRange);

        // validate saved reports header elements
        assertEquals(reportsLeftBarPage.getSavedReportsLabel().getText(),
                "Saved Reports");
        assertTrue(reportsLeftBarPage.getAToZLink().isEnabled());
        assertTrue(reportsLeftBarPage.getScheduledLink().isEnabled());
        assertTrue(reportsLeftBarPage.getRecentLink().isEnabled());

        // validate report histroy is displayed
        assertTrue(reportsPage.getReportHistoryTab().isDisplayed());

        //Validate UI elements of Advanced report pop-up
        verifyAdvancedReportUI(data.reportTypeList, data.vehiclesPlaceholderText,
                data.reportDateRange);
    }

    @Test(description = "Validate Daily Device History Report through " +
            "Advanced Report Link and Saved Report actions", groups = {"reports"})
    public void testDailyDeviceHistoryAdvancedReport()
            throws UnirestException, ParseException, IOException {

        LocalDateTime localDateTime = LocalDateTime.now().minusMonths(6);
        String reportDate = localDateTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));

        //Create Recipient 1 using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);
        List<String> addRecipientList = new ArrayList<>();
        addRecipientList.add(recipient.fullName);

        //Create Recipient 2 using contact service call
        recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);
        List<String> changeRecipientList = new ArrayList<>();
        changeRecipientList.add(recipient.fullName);

        //Navigate to Advanced Reports page
        AdvancedReportsPage advancedReportsPage = reportsLeftBarPage.clickAdvancedReportLink();

        assertTrue(advancedReportsPage.getModalWindow().isDisplayed());

        String reportName = ReportTypeEnum.DAILY_DEVICE_HISTORY.getName() + "_" +
                TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());

        //Create Daily Device History Report from Advanced Report Link
        advancedReportsPage.runAdvancedReport(ReportTypeEnum.DAILY_DEVICE_HISTORY,
                "-- All Groups --", "-- All Vehicles --", DateRangeEnum.CUSTOM, reportName,
                reportDate, true, addRecipientList, "PDF");

        //Validate Daily Device History Report
        validateDailyDeviceHistory(advancedReportsPage, reportName, addRecipientList, changeRecipientList,
                UI_DATE_FORMAT, API_DATE_FORMAT, CELL_DATE_FORMAT);
    }

    @Test(description = "Validate Alert History Report Content,Email & EXPORT options",
            groups = {"reports"})
    public void testAlertHistoryExportOptions() throws ParseException,
            UnirestException, IOException, MessagingException {

        //Mark all "unread" mails with subject 'Report: Alert History' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Report: Alert History"));

        markEmailsAsRead(searchTerm, "INBOX");

        //Run Alert History report through UI
        runAndVerifyReportHeaderInfo(driver, ReportTypeEnum.ALERT_HISTORY,
                "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.LAST_30_DAYS, null, null, null, null,
                "All Groups", 110, UI_DATE_FORMAT);

        //Get Alert History report data
        Report.ReportData reportData = getActiveReportData(driver);
        List<Report.ReportItem> alertData = reportData.alertList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, alertData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);
        apiFirstRecord.put("Actions", "");

        //Get the Alert History report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Header Info: start date, end date
        //TODO open issue: https://jira.spireon.com/browse/VFM-3638
        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver,
                reportData.config.get("startDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT),
                formatDate(driver, reportData.config.get("endDate").textValue(),
                        API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.alertList.size());

        //Click on the Export button and validate the 3 export links are displayed
        reportsPage.clickExportBtn();
        assertTrue(reportsPage.getPdfLink().isDisplayed());
        assertTrue(reportsPage.getCsvLink().isDisplayed());
        assertTrue(reportsPage.getXlsLink().isDisplayed());

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));

        String reportId = reportsPage.getActiveReportId();

        //Export each file type and validate that its downloaded correctly
        exportAndValidateDownloads(reportId);

        File file = new File(String.format("./download/%s.%s", reportId, "csv"));

        //TODO open issue: https://jira.spireon.com/browse/VFM-5107
        //Verify CSV first record with API response
        /*verifyCsvContentWithAPI(file, apiFirstRecord, alertData);*/

        //Send report email in PDF format
        reportsPage.sendReportEmail("PDF", emailId);

        //Search for all "unread" mails with subject 'Report: Alert History'
        List<File> fileList = getEmailAttachments(searchTerm, "INBOX",
                System.getProperty("user.dir"));

        assertFalse(fileList.isEmpty(), "Email was sent without attachment");

        //Validate email received with pdf attachment
        assertEquals(fileList.get(0).getName(), "AlertHistory.pdf");

        //Validate downloaded file size is greater than 0 bytes
        assertTrue(fileList.get(0).length() > 0);
    }

    /**
     * Validate UI elements of left selection panel dropdown
     *
     * @param reportTypeList
     * @param vehiclesPlaceholderText
     * @param reportDateRange
     */

    private void verifySelectionPanelDropDowns(List<String> reportTypeList, String
            vehiclesPlaceholderText, List<String> reportDateRange) {

        //Validate contents of report type dropdown
        assertEquals(reportsLeftBarPage.getReportTypes(), reportTypeList);

        //Validate the default selection for Groups dropdown
        assertEquals(reportsLeftBarPage.getGroupsInput().getAttribute
                ("placeholder"), "-- All Groups --");

        //Validate the default selection for Vehicles dropdown
        assertEquals(reportsLeftBarPage.getVehiclesInput().getAttribute
                ("placeholder"), vehiclesPlaceholderText);

        //Validate contents of date range dropdown
        assertEquals(reportsLeftBarPage.getDateRanges(), reportDateRange);

        //When custom date range is selected, custom fields are shown
        reportsLeftBarPage.selectDateRange(DateRangeEnum.CUSTOM);
        assertTrue(reportsLeftBarPage.getCustomStartDateInput().isDisplayed());
        assertTrue(reportsLeftBarPage.getCustomStartTimeDropdown().isDisplayed());
        assertTrue(reportsLeftBarPage.getCustomEndDateInput().isDisplayed());
        assertTrue(reportsLeftBarPage.getCustomEndTimeDropdown().isDisplayed());
        assertTrue(reportsLeftBarPage.getRunReportBtn().isEnabled());
    }

    /**
     * Validate UI elements of Advanced report pop-up
     *
     * @param reportTypeList
     * @param vehiclesPlaceholderText
     * @param reportDateRange
     */
    private void verifyAdvancedReportUI(List<String> reportTypeList, String
            vehiclesPlaceholderText, List<String> reportDateRange) {

        //Validate advanced report section
        AdvancedReportsPage advancedReportsPage = reportsLeftBarPage
                .clickAdvancedReportLink();

        assertEquals(advancedReportsPage.getReportTypes(), reportTypeList);

        //Validate the default selection for Groups dropdown
        assertEquals(advancedReportsPage.getGroupsInput().getAttribute
                ("placeholder"), "-- All Groups --");

        //Validate the default selection for Vehicles dropdown
        assertEquals(advancedReportsPage.getVehiclesInput().getAttribute
                ("placeholder"), vehiclesPlaceholderText);

        //Validate contents of date range dropdown
        assertEquals(advancedReportsPage.getDateRanges(), reportDateRange);

        //When custom date range is selected, custom fields are shown
        advancedReportsPage.selectDateRange(DateRangeEnum.CUSTOM);
        assertTrue(advancedReportsPage.getCustomStartDateInput().isDisplayed());
        assertTrue(advancedReportsPage.getCustomStartTimeDropdown().isDisplayed());
        assertTrue(advancedReportsPage.getCustomEndDateInput().isDisplayed());
        assertTrue(advancedReportsPage.getCustomEndTimeDropdown().isDisplayed());

        assertTrue(advancedReportsPage.getColumnsTabLink().isDisplayed());
        assertTrue(advancedReportsPage.getSaveConfigTabLink().isDisplayed());

        advancedReportsPage.clickCancelButton();
    }

    /**
     * Export each file type and validate that its downloaded correctly and
     * its size is greater than zero bytes
     *
     * @param reportId
     */
    private void exportAndValidateDownloads(String reportId) {

        for (ExportFormat format : ExportFormat.values()) {
            File file = new File(String.format("./download/%s.%s", reportId,
                    format.getType()));
            try {
                InputStream is = exportReport(driver, reportId, format);
                FileUtils.copyInputStreamToFile(is, file);
            } catch (UnirestException | IOException e) {
                e.printStackTrace();
                fail(e.getMessage());
            }

            //Validate file is downloaded
            assertTrue(file.exists());

            //Validate downloaded file size is greater than 0 bytes
            assertTrue(file.length() > 0);
        }
    }

    /**
     * Verify csv first record with API response
     *
     * @param file
     * @param apiFirstRecord
     * @param alertData
     * @throws ParseException
     * @throws UnirestException
     * @throws IOException
     */
    private void verifyCsvContentWithAPI(File file, HashMap<String,
            String> apiFirstRecord, List<Report.ReportItem> alertData)
            throws ParseException, UnirestException, IOException {

        HashMap<String, String> csvFirstRecord = getCsvFirstRow(file);

        csvFirstRecord.put("Date Time", formatDate(driver,
                csvFirstRecord.get("Date Time"), UI_DATE_FORMAT,
                getUserSettings(driver).userTz, CELL_DATE_FORMAT));
        csvFirstRecord.put("Actions", "");

        try {
            apiFirstRecord.put("Address",
                    alertData.get(0).address.replace("<br/>", ", ").trim());
        } catch (NullPointerException e) {
            apiFirstRecord.put("Address", "");
        }

        //Validate first row of the exported csv file of Alert History report with api response.
        assertEquals(csvFirstRecord, apiFirstRecord);
    }

    // sample test method to show how to get the report data through direct
    // service calls
    //@Test
    public void testGetReport() throws UnirestException, IOException {

        User.UserSettings userSettings = getUserSettings(driver);
        int accountId = userSettings.accountId;
        int requestedByAccountUserId = userSettings.accountUserId;

        // **** retrieve report history ********

        // get current date - 30 days
        DateFormat dateFormat = new SimpleDateFormat
                ("yyyy-MM-dd'T'HH:mm:sss'Z'");
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -30);
        String dateStr = dateFormat.format(c.getTime());

        String filterStrFormat = "[{\"property\":\"accountId\",\"value\":%d," +
                "\"type\":\"Long\"},{\"property\":\"executionStart\"," +
                "\"value\":\"%s\",\"type\":\"Date\"," +
                "\"operator\":\"gte\"}," +
                "{\"property\":\"requestedByAccountUserId\",\"value\":%d," +
                "\"type\":\"Long\"}]";
        String filterStr = String.format(filterStrFormat, accountId,
                dateStr, requestedByAccountUserId);

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("offset", 0);
        queryParams.put("filters", filterStr);
        queryParams.put("sorts", "[{\"property\":\"executionStart\"," +
                "\"direction\":\"DESC\"}]");

        // get the history of reports
        Report.ReportHistoryResults historyResults = getReportHistoryResults
                (driver, queryParams);

        queryParams = new HashMap<>();
        String filters = "[{\"property\":\"userSaved\",\"value\":true}," +
                "{\"property\":\"requestedBy.id\",\"value\":%d," +
                "\"type\":\"Long\"}]";
        queryParams.put("filters", String.format(filters, requestedByAccountUserId));
        queryParams.put("sorts", "[{\"property\":\"userName\"," +
                "\"direction\":\"ASC\"}]");

        // get saved reports
        Report.SavedReportResults savedReports = getSavedReports(driver, queryParams);

        // **** run a new report ********

        // Run a new Alert History Report for last 7 days
        String reportInputFormat = "{\"startTime\":\"12:00 AM\"," +
                "\"startDate\":\"%s\",\"endDate\":\"%s\"," +
                "\"endTime\":\"11:59 PM\",\"dateRange\":%d," +
                "\"selectedAsset\":null,\"selectedBatteryStatus\":null," +
                "\"selectedAlertTypes\":[],\"selectedResponseTypes\":[]," +
                "\"excessiveMileageThreshold\":1500," +
                "\"excessiveMileageCost\":0.54,\"selectedStatus\":[]," +
                "\"columns\":[],\"status\":[],\"reportFormat\":\"csv\"," +
                "\"noSubgroups\":true}";

        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        c = Calendar.getInstance();
        String curDate = dateFormat.format(c.getTime());

        c.add(Calendar.DATE, -7);
        String minus7Date = dateFormat.format(c.getTime());

        queryParams = new HashMap<>();
        queryParams.put("name", "reportOutput");
        queryParams.put("input", String.format(reportInputFormat, minus7Date,
                curDate, 7));
        queryParams.put("sTz", userSettings.userTz);
        queryParams.put("format", "json");

        // Run a new Alert History Report
        Report.ReportOutput reportOutput = outputReport(driver, "15",
                queryParams);
        String reportId = reportOutput.id;

        // get the actual report data
        Report.ReportData reportData = getDisplayReport(driver, reportId,
                queryParams, Report.ReportData.class);

        InputStream is = exportReport(driver, reportId, ExportFormat.CSV);
        FileUtils.copyInputStreamToFile(is, new File("./test.csv"));
    }

    @Test(description = "Validate Impound Status Report through Advanced Report Link",
            groups = {"reports", "slow"})
    public void testImpoundStatusContent() throws UnirestException,
            ParseException, IOException, InterruptedException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        ImpoundTestData data = null;
        try {
            data = mapper.treeToValue(dataNode, ImpoundTestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        PlatformApiUtils.generateEvents(data.serialNumber, data.tripFile, 120000);

        LOGGER.info("Event has been successfully generated for testing.");

        //Create Recipient using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);
        List<String> addRecipientList = new ArrayList<>();
        addRecipientList.add(recipient.fullName);

        //Click Advanced Report Link
        AdvancedReportsPage advancedReportsPage = reportsLeftBarPage
                .clickAdvancedReportLink();

        String reportName = ReportTypeEnum.IMPOUND_STATUS.getName() + "_" +
                TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());

        //Create Impound Status Report from Advanced Report Link
        advancedReportsPage.runAdvancedReport(ReportTypeEnum.IMPOUND_STATUS,
                "-- All Groups --", "-- All Vehicles --",
                null, reportName, null, null,
                addRecipientList, "CSV");

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 120);

        //Validate Recipient of the report is saved
        reportsLeftBarPage.editSavedReport(reportName);
        advancedReportsPage.clickSaveConfigTabLink();
        assertTrue(addRecipientList.equals(advancedReportsPage.getAddedRecipientsList()));
        advancedReportsPage.clickCancelButton();

        //Validate Header Info:Active tab name, Groups, Report created date.
        verifyReportHeaderInfo(driver, ReportTypeEnum.IMPOUND_STATUS, "All Groups",
                UI_DATE_FORMAT);

        //Get Impound Status data
        Report.ReportHistoryResults historyResults = getReportHistoryResults(driver);
        List<Report.ReportOutput> historyResultsData = historyResults.data;

        int reportSpecId = 0;
        for (Report.ReportOutput historyData : historyResultsData) {

            if (historyData.reportName.equals(reportName) && DateTimeUtils
                    .formatDate(driver, historyData.executionStart.replaceAll
                                    ("Z", "+0000"), API_DATE_FORMAT,
                            UI_DATE_FORMAT).equals(curDate)) {

                reportSpecId = historyData.reportSpecId;
                break;
            }
        }

        assertTrue(reportSpecId > 0, "Report does not exist");

        Report.ReportData reportData = getActiveReportData
                (driver, reportSpecId);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, assetData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get Impound Status report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(), API_DATE_FORMAT,
                UI_DATE_FORMAT), formatDate(driver,
                reportData.config.get("endDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());

        //Delete Report
        reportsLeftBarPage.deleteSavedReport(reportName);

        //Get saved reports data through service call to validate that the
        //report was deleted
        Report.SavedReportResults savedReportsResponse = getSavedReports(driver);

        List<String> savedReports = new ArrayList<>();
        savedReportsResponse.data.forEach(report -> savedReports.add(report.userName));

        assertFalse(savedReports.contains(reportName));
    }

    @Test(description = "Validate Installation Request History Report through" +
            " Advanced Report Link", groups = {"reports", "slow"})
    public void testInstallationRequestHistoryReportContent()
            throws UnirestException, ParseException, IOException {

        //Create Recipient using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        int recipientId = recipient.id;
        List<String> addRecipientList = new ArrayList<>();
        addRecipientList.add(recipient.fullName);

        //Click Advanced Report Link
        AdvancedReportsPage advancedReportsPage = reportsLeftBarPage
                .clickAdvancedReportLink();

        String reportName = "InstReqHist_" + TimeUnit.MILLISECONDS.toMinutes(System
                .currentTimeMillis());

        //Create Installation Request History Report from Advanced Report Link
        advancedReportsPage.runAdvancedReport(ReportTypeEnum.INSTALLATION_REQUEST_HISTORY,
                "-- All Dealers --", DateRangeEnum.LAST_7_DAYS, reportName,
                addRecipientList, "CSV");

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 120);

        //Validate Recipient of the report is saved
        reportsLeftBarPage.editSavedReport(reportName);
        advancedReportsPage.clickSaveConfigTabLink();
        assertTrue(addRecipientList.equals(advancedReportsPage.getAddedRecipientsList()));
        advancedReportsPage.clickCancelButton();

        //Validate Header Info:Active tab name, Groups, Report created date.
        verifyReportHeaderInfo(driver, ReportTypeEnum.INSTALLATION_REQUEST_HISTORY, "All Dealers",
                UI_DATE_FORMAT);

        //Get Installation Request History Report data
        Report.ReportHistoryResults historyResults = getReportHistoryResults(driver);
        List<Report.ReportOutput> historyResultsData = historyResults.data;

        int reportSpecId = 0;
        for (Report.ReportOutput historyData : historyResultsData) {

            if (historyData.reportName.equals(reportName) && DateTimeUtils.formatDate
                    (driver, historyData.executionStart.replaceAll("Z",
                            "+0000"), API_DATE_FORMAT, UI_DATE_FORMAT).equals
                    (curDate)) {

                reportSpecId = historyData.reportSpecId;
                break;
            }
        }

        assertTrue(reportSpecId > 0, "Report does not exist");

        Report.ReportData reportData = getActiveReportData
                (driver, reportSpecId);
        List<Report.ReportItem> assetData = reportData.assetList;

        //Get First Record from API Response
        HashMap<String, String> apiFirstRecord = getApiFirstRecord(driver, reportData, assetData,
                API_DATE_FORMAT, CELL_DATE_FORMAT);

        //Get Installation Request History report headers from API Response
        String[] expectedColumns = apiFirstRecord.keySet().toArray(new
                String[apiFirstRecord.keySet().size()]);

        //Validate Report Content with API
        verifyReportUIWithAPI(formatDate(driver, reportData
                        .config.get("startDate").textValue(), API_DATE_FORMAT,
                UI_DATE_FORMAT), formatDate(driver,
                reportData.config.get("endDate").textValue(),
                API_DATE_FORMAT, UI_DATE_FORMAT), expectedColumns,
                apiFirstRecord, reportData.assetList.size());

        //Delete Report
        reportsLeftBarPage.deleteSavedReport(reportName);

        //Get saved reports data through service call to validate that the
        //report was deleted
        Report.SavedReportResults savedReportsResponse = getSavedReports(driver);

        List<String> savedReports = new ArrayList<>();
        savedReportsResponse.data.forEach(report -> savedReports.add(report.userName));

        assertFalse(savedReports.contains(reportName));

        //Delete added recipients
        assertEquals(deleteContact(driver, recipientId).msg, "Data deleted");
    }
}
