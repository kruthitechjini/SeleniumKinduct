package com.procon.vehiclefinance.tests.sales;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.reports.ReportsLeftBarPage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;

import javax.mail.MessagingException;
import java.io.IOException;
import java.text.ParseException;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class SalesTestBHPH extends SalesBase {

    @Test(description = "Create new sale, send emails, resend invitation and cancel sale ", groups = {"sales"})
    public void testVerifySalesBHPH() throws MessagingException, ParseException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        verifySales(data);
    }

    @Test(description = "E2E: Repossession (Revoke Consumer Access)", groups = {"sales"})
    public void testVerifyRevokeConsumerAccessBHPH() throws MessagingException, IOException, UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        verifyRevokeConsumerAccess();

        //Validate the device is still available on other pages of the web app like vehicles, alerts and reports
        assertTrue(salesPage.validateSerialNumberInVehiclesPage(navbarHeaderPage, getSerialNumber(), getVehicleName(),
                false));

        assertTrue(salesPage.validateSerialNumberInAlertsPage(navbarHeaderPage, getSerialNumber(), getVehicleName(),
                data.groupName, false));

        ReportsLeftBarPage reportsLeftBarPage = PageFactory.initElements(driver, ReportsLeftBarPage.class);
        assertTrue(salesPage.validateSerialNumberInReportsPage(navbarHeaderPage, reportsLeftBarPage, getSerialNumber(),
                getVehicleName(), false));
    }

    @Test(description = "E2E: Consumer Freedom (Revoke Dealer Access)", groups = {"sales"})
    public void testVerifyRevokeDealerAccessBHPH() throws MessagingException, IOException, UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        verifyRevokeDealerAccess();

        //Validate the device is NOT available on other pages of the web app like vehicles, alerts and reports
        assertFalse(salesPage.validateSerialNumberInVehiclesPage(navbarHeaderPage, getSerialNumber(), getVehicleName(),
                false));

        //TODO open issue: https://jira.spireon.com/browse/VFM-5080
        //Alert Management screen shows "Dealer Revoked" device
        /*assertFalse(salesPage.validateSerialNumberInAlertsPage(navbarHeaderPage, serialNumber, vehicleName,
                data.groupName, false));*/

        ReportsLeftBarPage reportsLeftBarPage = PageFactory.initElements(driver, ReportsLeftBarPage.class);
        assertFalse(salesPage.validateSerialNumberInReportsPage(navbarHeaderPage, reportsLeftBarPage, getSerialNumber(),
                getVehicleName(), false));
    }
}
