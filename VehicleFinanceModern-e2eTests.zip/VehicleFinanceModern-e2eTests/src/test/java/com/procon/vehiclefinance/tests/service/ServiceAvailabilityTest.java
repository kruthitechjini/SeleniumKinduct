package com.procon.vehiclefinance.tests.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.spireon.platform.utils.PlatformIdentityUtils.getJwtToken;
import static org.testng.Assert.assertEquals;

public class ServiceAvailabilityTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceAvailabilityTest.class);
	private static final String TEST_DATA_FILE =
		"src/test/resources/test_data.json";

	protected ObjectMapper mapper = new ObjectMapper();
	protected JsonNode envNode;
	protected String env;
	ServiceAvailabilityTest.TestData data = null;

	// this class needs to be static for Jackson to be able to databind to it
	@JsonIgnoreProperties(ignoreUnknown = true)
	static class TestData {
		public String userName;
		public String password;
		public String serviceUrl;
		public String appToken;
	}

	@BeforeClass(alwaysRun = true)
	public void setupTest() throws IOException {
		env = System.getProperty("env");
		JsonNode doc = mapper.readTree(new File(TEST_DATA_FILE));
		envNode = doc.at("/" + env);
	}

	@BeforeMethod(alwaysRun = true)
	public void getTestData(Method method) {
		JsonNode dataNode = envNode.at("/" + method.getName());

		try {
			data = mapper.treeToValue(dataNode, ServiceAvailabilityTest.TestData.class);
		} catch (JsonProcessingException e) {
			LOGGER.info("No test data defined for this method.");
			data = null;
		}
	}

	@Test(description = "Verify platform reporting service is up & running", groups = {"serviceAvail"})
	public void testReportServiceAvailability() throws UnirestException, IOException {
		String platformReportSvcUrl = data.serviceUrl;

		// check one endpoint of platform reporting service
		HttpResponse<String> response = Unirest.get(platformReportSvcUrl)
				.asString();

		assertEquals(response.getStatus(), 200);
	}

	@Test(description = "Verify automotive service is up & running", groups = {"serviceAvail"})
	public void testAutomotiveServiceAvailability() throws UnirestException {
		String automotiveSvcUrl = data.serviceUrl;
		String dealerUser = data.userName;
		String dealerPassword = data.password;
		String dealerAppToken = data.appToken;
		String token = getJwtToken(dealerUser, dealerPassword, dealerAppToken);

		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("limit", 1);

		// get one vehicle record using automotive service
		HttpResponse<String> vehiclesResponse = Unirest.get(automotiveSvcUrl + "/vehicles")
				.queryString(queryParams)
				.header("Authorization", "Bearer " + token)
				.asString();

		assertEquals(vehiclesResponse.getStatus(), 200);
	}

	@Test(description = "Verify GL service is up & running", groups = {"serviceAvail"})
	public void testGlServiceAvailability() throws UnirestException {
		String userName = data.userName;
		String password = data.password;
		String appToken = data.appToken;
		String glSvcUrl = data.serviceUrl;
		String token = getJwtToken(userName, password, appToken);

		String landmarksEndpoint =  glSvcUrl + "api/1.0.0/landmarks";

		HashMap<String, Object> queryParams = new HashMap<>();
		queryParams.put("max", "1");
		queryParams.put("sortBy", "name:asc");
		queryParams.put("offset", 0);

		HttpResponse<String> response = Unirest.get(landmarksEndpoint)
				.queryString(queryParams)
				.header("Authorization", "Bearer " + token)
				.asString();

		assertEquals(response.getStatus(), 200);
	}

	@Test(description = "Verify EIS service is up & running", groups = {"serviceAvail"})
	public void testEisServiceAvailability() throws UnirestException, IOException {
		String eisSvcUrl = data.serviceUrl;
		String eisOrdersEndpoint =  eisSvcUrl + "/orders";

		String token = getJwtToken(data.userName, data.password, data.appToken);

		HttpResponse<String> eisOrderResponse = Unirest.get(eisOrdersEndpoint)
				.header("Authorization", "Bearer " + token)
				.queryString("limit", 1)
				.asString();

		assertEquals(eisOrderResponse.getStatus(), 200);
	}
}
