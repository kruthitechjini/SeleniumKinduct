package com.procon.vehiclefinance.tests.vehicles;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.*;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.sales.SalesPage;
import com.procon.vehiclefinance.pageobjects.vehicles.*;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.DeviceStatusEnum;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.ReportingEnum;
import com.procon.vehiclefinance.services.DealerService;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.Email;
import com.procon.vehiclefinance.util.PlatformApiUtils;
import com.spireon.automotive.cdm.v1.dto.CollectionResource;
import com.spireon.automotive.cdm.v1.dto.LenderDealerPartnershipDto;
import com.spireon.automotive.client.settings.ClientSettings;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.jodah.failsafe.function.CheckedConsumer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.WordUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.search.AndTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.DeviceDetailsService.getDevice;
import static com.procon.vehiclefinance.services.DeviceHistoryService.getDeviceHistory;
import static com.procon.vehiclefinance.services.DeviceHistoryService.getDeviceTopAddresses;
import static com.procon.vehiclefinance.services.DeviceService.*;
import static com.procon.vehiclefinance.services.GroupService.getGroups;
import static com.procon.vehiclefinance.services.ServiceCaller.getUserSettings;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvFirstRow;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvNumberOfRecords;
import static com.procon.vehiclefinance.util.DateTimeUtils.*;
import static com.procon.vehiclefinance.util.Email.markEmailsAsRead;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static com.spireon.platform.utils.PlatformIdentityUtils.getJwtToken;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.testng.Assert.*;

public class VehiclesTest extends BaseTest {

    protected MapPage mapPage;
    protected VehiclesPage vehiclesPage;
    protected NavbarHeaderPage navbarHeaderPage;

    private static final Logger logger = LoggerFactory.getLogger(VehiclesTest.class);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String serialNumber;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String displayName;
        public String group;
        public String serialNumberSubString;
        public String vinNumber;
        public String vehicleMake;
        public String vehicleModel;
        public String vehicleYear;
        public String vehicleDeviceGroup;
        public String vehicleDeviceStatus;
        public String vehicleInstalledDate;
        public String minimumVisits;
        public List<String> serialNumberList;
        public String dealerName;
        public String apiUserName;
        public String apiPassword;
        public String appToken;
        public String geoFence;
        public String geoFenceType;
        public String recoveryLink;
        public String requester;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickVehicles(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;
            serialNumber = data.serialNumber;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Vehicles Page
        vehiclesPage = navbarHeaderPage.clickVehicles();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //Reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Verify page elements on Vehicle panel", groups =
            {"bvt", "prodsmoke", "vehicles", "pipeline"})
    public void testVerifyPageElementsOnVehiclePanel() {

        assertTrue(vehiclesPage.isElementAvailable("Group Filter"));
        assertTrue(vehiclesPage.isElementAvailable("Map All Active"));
        assertTrue(vehiclesPage.isElementAvailable("Groups Dropdown"));
        assertTrue(vehiclesPage.isElementAvailable("Search"));
        assertTrue(vehiclesPage.isElementAvailable("Vehicles List"));
        assertTrue(vehiclesPage.isElementAvailable("Zoom In"));
        assertTrue(vehiclesPage.isElementAvailable("Zoom Out"));
        assertTrue(vehiclesPage.isElementAvailable("Resize Page"));
        assertTrue(vehiclesPage.isElementAvailable("Previous Page"));
        assertTrue(vehiclesPage.isElementAvailable("Next Page"));
        assertTrue(vehiclesPage.isElementAvailable("Refresh Vehicles List"));

    }

    @Test(description = "Verify Create Link in Vehicle Recovery tab", groups =
            {"prodsmoke", "vehicles"})
    public void testVerifyCreateLinkInVehicleRecoveryTab()
            throws MessagingException, IOException, UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");

        //Use user settings time zone to format the date
        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone(getUserSettings(driver).userTz));

        //Get current date with user settings time zone
        String recoveryLinkCreatedDate = getAdjustedDate(DATE_FORMAT, 0);

        //Get expiration date with user settings time zone
        String recoveryLinkExpirationDate = getAdjustedDate(DATE_FORMAT, 30);

        //Use current browser time zone to format the date
        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone(getCurrentBrowserTimeZone(driver)));

        //Get expiration date with current browser timezone
        String recoveryLinkExpirationDateUI = getAdjustedDate(DATE_FORMAT, 30);

        //Search vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);

        //Select vehicle
        vehiclesPage.selectVehicle(1);

        //Get vehicle details
        Vehicles vehicleDetails = new Vehicles.VehiclesBuilder()
                .displayName(vehiclesPage.getVehicleName().getText())
                .stockNumber(vehiclesPage.getStockNumberTxt())
                .vin(vehiclesPage.getVinNumberTxt())
                .vehicleMake(WordUtils.capitalize(vehiclesPage.getMakeTxt().toLowerCase()))
                .vehicleModel(WordUtils.capitalize(vehiclesPage.getModelTxt().toLowerCase()))
                .vehicleYear(vehiclesPage.getYearTxt())
                .vehicleLicencePlate(vehiclesPage.getLicencePlateTxt().toLowerCase())
                .vehicleColor(vehiclesPage.getColorTxt().toLowerCase())
                .build();

        //Mark all "unread" mails with given subject as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Vehicle Recovery Link: " + vehicleDetails.getDisplayName()
                        + " - " + vehicleDetails.getVin() + " " + recoveryLinkCreatedDate));

        markEmailsAsRead(searchTerm, "INBOX");

        //Click recovery tab
        vehiclesPage.clickRecoveryTab();

        //Validate recovery tab
        assertEquals(vehiclesPage.getRecoveryTab().getText(), "Recovery");
        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(vehiclesPage.columnHeader())).isDisplayed());

        //Validate mandatory fields should show error messages if these fields are empty
        vehiclesPage.fillInvalidRecoveryFormAndCancel();

        //Create Recovery link
        String linkText = vehiclesPage.createRecoveryLink("TestCompany", "Automated", "Test",
                "automationtests05@gmail.com");

        //Check newly created recovery link should display on top of the table
        assertTrue(vehiclesPage.isRecoveryLinkPresent(linkText),
                "Recovery link: " + linkText + " should be in the Recovery tab for device: " + serialNumber);

        String setMailContent = "Please click on the following link to access data regarding an asset marked" +
                " for recovery. Link: " + data.recoveryLink + linkText +
                " Link Expiration Date: " + recoveryLinkExpirationDate + " Requester: " + data.requester +
                " Vehicle Information: Display Name: " + vehicleDetails.getDisplayName() +
                " Stock Number: " + vehicleDetails.getStockNumber() + " VIN: " + vehicleDetails.getVin() +
                " Make: " + vehicleDetails.getVehicleMake() + " Model: " + vehicleDetails.getVehicleModel() +
                " Year: " + vehicleDetails.getVehicleYear() + " Color: " + vehicleDetails.getVehicleColor() +
                " License Plate: " + vehicleDetails.getVehicleLicencePlate() +
                " Important: this secure link has been assigned to you and contains sensitive, " +
                "asset-identifying information. This recovery link will be available for no more than 30 days. " +
                "All access is monitored and logged. Do not forward or share this link with unauthorized persons.";

        Email email = new Email();

        RetryPolicy retryPolicy = new RetryPolicy()
                .withDelay(10, TimeUnit.SECONDS)
                .withMaxRetries(3)
                .retryIf((Message[] messageList) -> messageList.length == 0);

        List<Message> messageList = email.getMessages("INBOX", searchTerm, retryPolicy);

        //Validate email received
        assertTrue(!messageList.isEmpty(), "No mails found");

        //Get the mail content
        String getMailContent = email.getMailContent(messageList.get(0));

        //Validate mail content
        assertEquals(setMailContent, getMailContent);

        HashMap<String, String> recoveryTableFirstRow = vehiclesPage.getTableRow(1);

        //Validate 'Expiration' and 'Access Log' column values
        //'Expiration' column should display [Created Recovery Link date + 30 days]
        // and 'Access Log' column should be empty
        assertEquals(recoveryTableFirstRow.get("Expiration"), recoveryLinkExpirationDateUI);
        assertEquals(recoveryTableFirstRow.get("Access Log"), "");

        //Click on 'Expire' link under 'Action' column
        vehiclesPage.clickExpireLink(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Get current date with browser timezone
        String recoveryLinkExpiredDate = getCurrentBrowserDate(driver, DATE_FORMAT);

        recoveryTableFirstRow = vehiclesPage.getTableRow(1);

        //Validate 'Expiration' column should display [Date on which link was expired]
        // and 'Access Log' column should be empty
        assertEquals(recoveryTableFirstRow.get("Expiration"), recoveryLinkExpiredDate);
        assertEquals(recoveryTableFirstRow.get("Access Log"), "");
    }

    @Test(description = "Verify Notes tab", groups = {"vehicles"})
    public void testVerifyNotesTab() {

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        VehicleNotesPage vehicleNotesPage = vehiclesPage.clickNotesTab();

        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(vehicleNotesPage.columnHeader())).isDisplayed());

        //Validate Grid Columns.
        assertEquals(vehicleNotesPage.getGridColumns(), vehicleNotesPage.getExpectedColumns(),
                "Columns list should match for Vehicle Notes tab");

        HashMap<String, String> existingNote = vehicleNotesPage.getFirstNote();

        //Create Note
        String noteText = "TestNote " + System.currentTimeMillis();
        vehicleNotesPage.clickAddNoteLink();
        vehicleNotesPage.addEditNote(noteText);
        vehicleNotesPage.waitForNewNote(existingNote, 60);
        HashMap<String, String> firstNote = vehicleNotesPage.getFirstNote();

        assertTrue(firstNote.get("Date").matches("\\d{1,2}/\\d{1,2}/\\d{4}"),
                "Notes Date: " + firstNote.get("Date") + " should be in MM/DD/YYY format");

        assertEquals(firstNote.get("Created By"), navbarHeaderPage.getDisplayName(),
                "Created By should show the user's First and Last Name");

        //Check first note in the table
        assertEquals(firstNote.get("Comment"), noteText,
                "New Note: " + noteText + " should be in the Notes table for device: " + serialNumber);

        String updatedNote = "TestNote " + System.currentTimeMillis();

        //Edit existing note
        vehicleNotesPage.editRecord(noteText);
        vehicleNotesPage.addEditNote(updatedNote);
        vehicleNotesPage.waitForNewNote(firstNote, 60);

        //Check updated note in the table
        firstNote = vehicleNotesPage.getFirstNote();
        assertEquals(firstNote.get("Comment"), updatedNote,
                "Note text should be changed from: " + noteText + " to: " + updatedNote);
        assertTrue(vehicleNotesPage.isNotePresent(updatedNote),
                "Updated Note: " + updatedNote + " should be in the Notes table for device: " + serialNumber);

        existingNote = vehicleNotesPage.getFirstNote();

        //Delete updated note
        vehicleNotesPage.deleteRecord(updatedNote);
        vehicleNotesPage.waitForNewNote(existingNote, 60);

        //Check updated note not in the table
        firstNote = vehicleNotesPage.getFirstNote();
        assertNotEquals(firstNote.get("Comment"), updatedNote,
                "Note text: " + updatedNote + " should be removed from the table");
        assertFalse(vehicleNotesPage.isNotePresent(updatedNote),
                "Delete Note: " + updatedNote + " should not be in the Notes table for device: " + serialNumber);
    }


    @Test(description = "Recovery page displays when recovery link is clicked", groups = {"vehicles"})
    public void testRecoveryPageDisplays() {

        // TODO: 10/19/18 https://jira.spireon.com/browse/VFM-5212

        final List<String> DETAIL_SECTIONS = Arrays.asList("CUSTOMER", "VEHICLE", "DEVICE");

        //Search and select vehicle then click recovery tab
        vehiclesPage.searchAndClickRecoveryLinkForSerial(serialNumber);

        //Create Recovery link
        String linkText = vehiclesPage.createRecoveryLink("TestCompany", "Automated", "Test",
                "automationtests05@gmail.com");

        String vehicleName = vehiclesPage.getFirstVehicleName();

        //Click on the created recovery link displayed on top of the list
        VehicleRecoveryPage vehicleRecoveryPage = vehiclesPage.clickOnCreatedRecoveryLink(linkText);

        //Recovery page will be opened in new browser tab
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        vehicleRecoveryPage.waitUntilPageDisplayed();
        assertEquals(vehicleRecoveryPage.getPanelTitle(), vehicleName);

        assertTrue(vehicleRecoveryPage.isVehicleFeaturePresent("Locate Container"));
        assertTrue(vehicleRecoveryPage.isVehicleFeaturePresent("Details"));
        assertTrue(vehicleRecoveryPage.isVehicleFeaturePresent("Locations"));
        vehicleRecoveryPage.waitUntilLocateButtonDisplayed();
        assertTrue(vehicleRecoveryPage.isVehicleFeaturePresent("Locate Button"));
        assertTrue(vehicleRecoveryPage.isVehicleFeaturePresent("Starter State"));

        assertEquals(vehicleRecoveryPage.getDetailsHeaders(), DETAIL_SECTIONS, "Not all vehicle details displayed.");

        //Close tab
        driver.close();

        driver.switchTo().window(tabs.get(0));
    }

    @Test(description = "Verify Vehicle Locations Details Page Elements", groups = {"vehicles"})
    public void testVerifyVehicleLocationsDetails() {

        adjustScreenWidth(driver);

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Click Locations tab
        VehicleLocationsPage vehicleLocationsPage = vehiclesPage.clickLocationsTab();
        if (!vehiclesPage.getActiveTab().equals("Locations")) {
            logger.warn("Active tab: " + vehiclesPage.getActiveTab() + " Trying Locations again!");
            vehicleLocationsPage = vehiclesPage.clickLocationsTab();
        }

        // TODO: 9/11/18 App issue on Windows in IE and Chrome https://jira.spireon.com/browse/VFM-5094
        if (platform.toLowerCase().contains("win")) {
            return;
        }

        VehicleLocationDetailsPage vehicleLocationDetailsPage = vehicleLocationsPage.clickLocationDetails();

        //All events will display on the map.
        assertTrue(vehicleLocationDetailsPage.isMapMarkerVisible(), "Events will display on the map");

        //Events grid should have the columns: Date, Event, Day
        assertEquals(vehicleLocationDetailsPage.getGridColumns(), vehicleLocationDetailsPage.getExpectedColumns(),
                "Columns list should match for Vehicle Details page");

        HashMap<String, String> lastEvent = vehicleLocationDetailsPage.getLastEvent();

        //Day column displays day of the week
        assertTrue(vehicleLocationDetailsPage.getWeekDays().contains(lastEvent.get("Day")),
                "Day column displays 3 characters day of the week");

        vehicleLocationDetailsPage.clickBackButton();
    }

    @Test(description = "Verify Drive Report - Page elements for single device", groups = {"vehicles"})
    public void testVerifyDriveReportPageElementsForSingleDevice() {

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Validate Drive Report command button exists
        vehiclesPage.getMoreCommandsBtn().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(vehiclesPage.getDriveReportBtn().isEnabled());

        //Validate values in DriveReportDropdown
        final List<String> EXPECTED_DRIVE_REPORT_DROPDOWN_VALUES = Arrays.asList("Off", "2 min", "5 min", "10 min", "Custom");
        assertEquals(EXPECTED_DRIVE_REPORT_DROPDOWN_VALUES, vehiclesPage.getDriveReportDropdownValues(),
                "Drive Report Dropdown List is not matching");

        //Select Drive Report of type custom
        vehiclesPage.selectDriveReportOption("Custom");
        vehiclesPage.getDriveReportBtn().click();

        //Clear text boxes on the popup
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        vehiclesPage.clearSendCommandEventInput();
        vehiclesPage.clearSendCommandIntervalInput();

        //Validate UI elements
        assertTrue(vehiclesPage.isSendCommandEventsPlaceHolderPresent(), "Place holder Events not present");
        assertTrue(vehiclesPage.isSendCommandMinutesPlaceHolderPresent(), "Place holder Minutes not present");

        assertEquals(vehiclesPage.getSendCommandEventsLbl(), "Enter the number of Report Events between (1-300)",
                "Label missing - Enter the number of Report Events between (1-300)");
        assertEquals(vehiclesPage.getSendCommandIntervalLbl(), "Please enter interval minutes between (2-30)",
                "Label missing - Please enter interval minutes between (2-30)");

        //Test Events validation message
        vehiclesPage.clickSendCommandBtn();
        assertTrue(vehiclesPage.isSendCommandEventValidationMsgDisplayed(),
                "Event validation message is not displayed");
        vehiclesPage.enterSendCommandEvents("5");

        //Test interval validation message
        vehiclesPage.clickSendCommandBtn();
        assertTrue(vehiclesPage.isSendCommandIntervalValidationMsgDisplayed(),
                "Interval validation message is not displayed");
        vehiclesPage.enterSendCommandInterval("10");

        //Make sure the bubble show up.  Don't have to wait for the success
        vehiclesPage.clickSendCommandBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        vehiclesPage.validateNumberOfStatusBubbles(1);
    }

    @Test(description = "Validate Vehicle History Tab, Map bubble and Export option", groups = {"vehicles"})
    public void testValidateHistoryTab() throws
            IOException, ParseException, UnirestException {

        final List<String> GRID_COLUMNS = Arrays.asList("Date & Time", "Event", "Location", "User");

        final DateFormat DATE_FORMAT = new SimpleDateFormat
                ("MM/dd/yyyy h:mma '('z')'");

        final DateFormat CSV_DATE_FORMAT = new SimpleDateFormat
                ("MM/dd/yyyy hh:mm a");

        DATE_FORMAT.setLenient(false);

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Click on History tab
        VehicleHistoryPage vehicleHistoryPage = vehiclesPage.clickHistoryTab();

        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(vehicleHistoryPage.columnHeader())).isDisplayed());

        //Validate Grid Columns.
        assertEquals(vehicleHistoryPage.getGridColumns(), GRID_COLUMNS,
                "Columns list should match for Vehicle History tab");

        //Get first row data
        HashMap<String, String> historyTableFirstRow = vehicleHistoryPage
                .getTableRow(1);

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));

        File file = new File("./download/" + "VehiclesHistory.csv");

        long deviceId = getDevices(driver, serialNumber).data.get(0).deviceId;

        //Export CSV file
        InputStream is = exportDeviceHistory(driver, deviceId, "csv");
        FileUtils.copyInputStreamToFile(is, file);

        //Get CSV first record
        HashMap<String, String> csvFirstRecord = getCsvFirstRow(file);
        csvFirstRecord.put("Date & Time", formatDate(driver, csvFirstRecord.get("Date Time"),
                CSV_DATE_FORMAT, getUserSettings(driver).userTz, DATE_FORMAT));
        csvFirstRecord.remove("Date Time");
        csvFirstRecord.remove("formattedTotalCost");

        //Validate first row of csv file with first row of grid
        assertEquals(historyTableFirstRow, csvFirstRecord);

        //Validate date & time format in first row of grid
        String dateTime = historyTableFirstRow.get("Date & Time");
        try {
            DATE_FORMAT.parse(dateTime);
        } catch (ParseException e) {
            assertNotEquals(e.getMessage(), "Unparseable date: " +
                    "\"" + dateTime + "\"", "Date & Time is not " +
                    "formatted as MM/dd/yyyy h:mmAM|PM (timezone)");
        }

        HashMap<String, String> mapBubbleContent = vehicleHistoryPage
                .getMapMarkerPopUpContent();

        //Verify time in map bubble with that in the first row before clicking first row
        verifyEventLocationDateTime(historyTableFirstRow, mapBubbleContent);

        //Click on first row
        vehicleHistoryPage.clickRow(1);

        //Verify Event name, location name and Date and time in first row of
        //grid and map bubble
        verifyEventLocationDateTime(historyTableFirstRow, mapBubbleContent);

        //Click on second row
        vehicleHistoryPage.clickRow(2);

        //Get second row data
        HashMap<String, String> historyTableSecondRow = vehicleHistoryPage
                .getTableRow(2);

        mapBubbleContent = vehicleHistoryPage.getMapMarkerPopUpContent();

        //Verify Event name, location name and Date and time in second row of
        //grid and map bubble
        verifyEventLocationDateTime(historyTableSecondRow, mapBubbleContent);

        //TODO open issue: https://jira.spireon.com/browse/VFM-4109
        //Total number of records in service call and exported csv file
        //are not equal
        /*//Validate total number of records in service call and csv file
        assertEquals(getDeviceHistory(driver, deviceId).total,
                getCsvNumberOfRecords(file, true));*/

        //Verify second page first row with map bubble content
        if (vehicleHistoryPage.getNumberOfPages() > 1) {

            vehicleHistoryPage.clickNextBtn();

            historyTableFirstRow = vehicleHistoryPage.getTableRow(1);

            vehicleHistoryPage.clickRow(1);

            mapBubbleContent = vehicleHistoryPage.getMapMarkerPopUpContent();

            verifyEventLocationDateTime(historyTableFirstRow, mapBubbleContent);
        }

        //TODO open issue: https://jira.spireon.com/browse/VFM-4507
        //On click of 'More Reports' button 'All Device History' is not selected in type drop down
        /*//Verify more reports button
        ReportsLeftBarPage reportsLeftBarPage = vehicleHistoryPage
                .clickMoreReportsBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Verify All device history is selected in type drop down
        assertEquals(new Select(reportsLeftBarPage.getReportTypeDropdown())
                .getFirstSelectedOption().getText(), "All Device History");*/
    }

    /**
     * Verify Event name, location name and Date and time in grid row and
     * map bubble
     *
     * @param historyTableRow
     * @param mapBubbleContent
     * @throws IOException
     * @throws UnirestException
     * @throws ParseException
     */
    private void verifyEventLocationDateTime(HashMap<String, String> historyTableRow,
                                             HashMap<String, String> mapBubbleContent) {

        //Validate Event name
        assertEquals(historyTableRow.get("Event"), mapBubbleContent.get("Event"));

        // TODO open issue: https://jira.spireon.com/browse/VFM-4040
        //Location data is null in history grid for 'Config Response'
        //event types
        /*//Validate Location
        assertEquals(historyTableRow.get("Location"), mapBubbleContent.get
                ("Location").replaceAll(",\\s*", ", "));*/

        //Validate Date and time
        assertEquals(historyTableRow.get("Date & Time"), mapBubbleContent.get("Local Time"));
    }

    @Test(description = "Verify Vehicle Information profile changes", groups = {"vehicles"})
    public void testEditVehicleInfo() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        Person customer = new Person.PersonBuilder()
                .firstName("Automated")
                .lastName("Test")
                .email(emailId)
                .phone("5555555555")
                .build();

        Address address = new Address.AddressBuilder()
                .street("1429 W Royal Lane")
                .country("United States")
                .city("Juneau")
                .state("AK - Alaska")
                .postalCode("99801")
                .build();

        Vehicles vehicleDetails = new Vehicles.VehiclesBuilder()
                .stockNumber(String.valueOf(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis())))
                .vin(data.vinNumber)
                .vehicleMake(data.vehicleMake)
                .vehicleModel(data.vehicleModel)
                .vehicleYear(data.vehicleYear)
                .vehicleLicencePlate(String.valueOf(TimeUnit.MILLISECONDS.toHours(System.currentTimeMillis())))
                .vehicleColor("black")
                .build();

        adjustScreenWidth(driver);

        //Verify left edit button is enabled
        vehiclesPage.searchUniqueVehicle(data.displayName);
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
        assertTrue(vehiclesPage.getQuickEditBtn().isEnabled());

        //Select the first vehicle from the list
        vehiclesPage.selectVehicle(1);

        //Verify top right edit and print button
        assertTrue(vehiclesPage.getEditBtn().isEnabled());
        assertTrue(vehiclesPage.getPrintBtn().isEnabled());

        //Verify on edit model window is opened and data can be edited
        vehiclesPage.searchAndEditVehicle(data.displayName);
        assertTrue(vehiclesPage.getModelWindow().isDisplayed());

        //Enter details with wrong vin number
        vehiclesPage.enterVinNumber("ABCD");
        vehiclesPage.clickDecodeVIN();
        assertEquals(vehiclesPage.getinvalidVinPopUp().getText(), "VIN must be 17 characters long");
        vehiclesPage.clickOk();

        //Enter details with correct vin number
        vehiclesPage.enterVinNumber(data.vinNumber);
        vehiclesPage.clickDecodeVIN();

        //Verify Make/Model/year
        assertTrue(vehiclesPage.verifyVehicleMakeTxt(data.vehicleMake));
        assertTrue(vehiclesPage.verifyVehicleModelTxt(data.vehicleModel));
        assertTrue(vehiclesPage.verifyVehicleYearTxt(data.vehicleYear));

        vehiclesPage.clickCancelLink();

        //Edit vehicle information
        vehiclesPage.editVehicleDetails(data.displayName, customer, address, vehicleDetails,
                data.vehicleDeviceGroup, data.vehicleDeviceStatus, data.vehicleInstalledDate);

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(data.displayName);
        vehiclesPage.selectVehicle(1);

        assertEquals(vehiclesPage.getFirstNameTxt(), customer.getFirstName().toUpperCase());
        assertEquals(vehiclesPage.getLastNameTxt(), customer.getLastName().toUpperCase());
        assertEquals(vehiclesPage.getaddressTxt(), address.getStreet().toUpperCase() + "\n" +
                address.getCity().toUpperCase() + "," + " " + address.getState().substring(0, 2) + " "
                + address.getPostalCode() + "\n" + address.getCountry().toUpperCase());
        assertEquals(vehiclesPage.getOperatorEmailTxt(), customer.getEmail().toUpperCase());
        assertEquals(vehiclesPage.getOperatorPhoneTxt().replaceAll("[\\s\\-()]", ""),
                customer.getPhone().trim());
        assertEquals(vehiclesPage.getVinNumberTxt(), vehicleDetails.getVin().toUpperCase());
        assertEquals(vehiclesPage.getLicencePlateTxt(), vehicleDetails.getVehicleLicencePlate().toUpperCase());
        assertEquals(vehiclesPage.getLicencePlateStateTxt().substring(0, 2), address.getState().substring(0, 2));
        assertEquals(vehiclesPage.getColorTxt(), vehicleDetails.getVehicleColor().toUpperCase());

        assertEquals(vehiclesPage.getVehicleDeviceGroupTxt(), data.vehicleDeviceGroup.toUpperCase());
        assertEquals(vehiclesPage.getVehicleDeviceStatusTxt(), data.vehicleDeviceStatus.toUpperCase());
        assertEquals(vehiclesPage.getVehicleInstalledDateTxt(), data.vehicleInstalledDate);

        /*
        //Verify changes in profile tab by changing stockNumber and displayName
        String stockNumber = vehicleDetails.getStockNumber();
        vehicleDetails.setStockNumber(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));

        //TODO When vehicle info is edited, incorrect entries show in Vehicle> profile
        //https://jira.spireon.com/browse/VFM-4168

        vehiclesPage.editVehicleDetails(serialNumber,null,null,vehicleDetails,vehicleDisplayName2,
                null,null,null);

        vehiclesPage.clickProfileChangesTab();

        waitUntilSpinnerVisibleThenInvisible(driver,1,2);

        assertEquals(vehiclesPage.getTableRow(1).get("Changes"),"Stock Number:"+" "+ stockNumber
                + " "+ "(old)" + " "+"to"+ " "+vehicleDetails.getStockNumber() + " " + "(new)");

        assertEquals(vehiclesPage.getTableRow(2).get("Changes"),"Vehicle Name:"+" "+ vehicleDisplayName1 + " "+
                "(old)" + " "+"to"+ " "+ vehicleDisplayName2 + " " + "(new)");*/
    }

    @Test(description = "Verify Vehicle List and Filters ", groups = {"vehicles"})
    public void testValidateListAndFilters() throws IOException, UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        List<String> devices = data.serialNumberList;

        int totalVehicles = getDevices(driver).total;

        //Validate records in UI should match record count in api response.
        assertEquals(vehiclesPage.getTotalRecordCount(), totalVehicles);

        //Validate Grid Navigation control elements
        vehiclesPage.verifyNavigationBtns(vehiclesPage.getSelectPageSize("MapView"));

        //Validate filter based on a substring of serial number
        vehiclesPage.searchVehicle(data.serialNumberSubString);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                data.serialNumberSubString).total);

        //Validate filter based on a substring of display name
        vehiclesPage.searchVehicle(data.displayName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, data.displayName).total);

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate apply filter button
        vehiclesPage.applyFilter(DeviceStatusEnum.INSTALLED);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, DeviceStatusEnum.INSTALLED).total);
        assertTrue(vehiclesPage.getFilterBtn().getAttribute("class")
                .contains("active"));

        //Validate clear filter button
        vehiclesPage.clearFilter();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(vehiclesPage.getTotalRecordCount(), totalVehicles);
        assertFalse(vehiclesPage.getFilterBtn().getAttribute("class")
                .contains("active"));

        //Validate filter based on a group
        vehiclesPage.selectGroups(data.group);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        List<Group.GroupItem> groups = getGroups(driver).data;
        long groupId = 0;
        for (Group.GroupItem grp : groups) {
            if (grp.name.equals(data.group)) {
                groupId = grp.id;
                break;
            }
        }
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                groupId, data.group, true).total);

        vehiclesPage.selectGroups("-- All Groups --");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(devices.get(0));
        vehiclesPage.selectVehicle(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate Locate button
        assertTrue(new WebDriverWait(driver, 10).until(ExpectedConditions
                .visibilityOf(vehiclesPage.getLocateBtn())).isEnabled());

        //Validate command buttons
        validateCommandButtons();

        //Validate More command buttons
        validateMoreCommandButtons();

        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate multiple vehicles selection at a time
        vehiclesPage.searchVehicle(devices.toString().replaceAll("\\[|\\]", ""));
        vehiclesPage.selectAll();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate command buttons
        validateCommandButtons();

        //Validate More command buttons
        validateMoreCommandButtons();
    }

    /**
     * Validate command buttons
     */
    public void validateCommandButtons() {

        assertTrue(new WebDriverWait(driver, 3).until(ExpectedConditions
                .visibilityOf(vehiclesPage.getLocateCommandBtn())).isDisplayed());

        try {
            new WebDriverWait(driver, 5)
                    .until(ExpectedConditions.or
                            (presenceOfElementLocated(By.xpath("//button[text()='Set QuickFence']")),
                                    presenceOfElementLocated(By.xpath("//button[text()='Set Again']"))));
        } catch (TimeoutException e) {
            fail("There are no 'Set QuickFence' or 'QuickFence is set' buttons. ", e);
        }

        String detailPanelHeadingHtmlStr = vehiclesPage.getDetailPanelHeading()
                .getAttribute("innerHTML");

        if (detailPanelHeadingHtmlStr.contains("Set QuickFence")) {

            // TODO open issue: https://jira.spireon.com/browse/VFM-4077
            assertTrue(vehiclesPage.getSetQuickFenceBtn().isEnabled());
        } else {
            assertTrue(vehiclesPage.getSetAgainQuickFenceBtn().isEnabled());
            assertTrue(vehiclesPage.getViewQuickFenceBtn().isEnabled());
            assertTrue(vehiclesPage.getClearQuickFenceBtn().isEnabled());
        }

        assertTrue(vehiclesPage.getWarningLink().isDisplayed());
        assertTrue(vehiclesPage.getWarningOnLink().isDisplayed());
        assertTrue(vehiclesPage.getWarningOffLink().isDisplayed());

        assertTrue(vehiclesPage.getStarterLink().isDisplayed());
        assertTrue(vehiclesPage.getStarterEnableLink().isDisplayed());
        assertTrue(vehiclesPage.getStarterDisableLink().isDisplayed());
        assertTrue(vehiclesPage.getMoreCommandsBtn().isEnabled());
    }

    /**
     * Validate More command buttons
     */
    public void validateMoreCommandButtons() {

        vehiclesPage.getMoreCommandsBtn().click();
        assertTrue(vehiclesPage.getSetMaxSpeedBtn().isEnabled());
        assertTrue(vehiclesPage.getAutoReportBtn().isEnabled());
        assertTrue(vehiclesPage.getTowAlertBtn().isEnabled());
    }

    @Test(description = "Verify References Tab", groups = {"vehicles", "pipeline"})
    public void testVerifyReferencesTab() throws IOException, UnirestException, MessagingException {

        //Mark all "unread" mails with subject 'References' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("References"));

        markEmailsAsRead(searchTerm, "INBOX");

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Get vehicle id
        long deviceId = getDevices(driver, serialNumber).data.get(0).deviceId;

        //Get References data
        Device.DeviceReferencesData deviceReferencesData = getDeviceReferences
                (driver, deviceId);

        //Delete all references starting with pattern 'Automated_Test-'
        List<Long> referenceIdList = new ArrayList<>();
        deviceReferencesData.data.forEach(deviceReferencesDetail -> {
            if (deviceReferencesDetail.name.startsWith("Automated_Test-")) {
                referenceIdList.add(deviceReferencesDetail.id);
            }
        });

        if (!referenceIdList.isEmpty()) {
            assertEquals(deleteDeviceReferences(driver, referenceIdList).success,
                    true);
        }

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Click on References tab
        VehicleReferencesPage vehicleReferencesPage = vehiclesPage.clickReferencesTab();

        //Click Add Reference link and verify model window is opened
        // and data can be edited
        vehicleReferencesPage.getAddReferenceLink().click();
        assertTrue(vehicleReferencesPage.getModelWindow().isDisplayed());

        String customerName = "Automated_Test" + "-" + System.currentTimeMillis();

        Address address = new Address.AddressBuilder()
                .street("1429 W Royal Lane")
                .country("United States")
                .city("Juneau")
                .state("AK - Alaska")
                .postalCode("99801")
                .build();

        //Create a reference
        vehicleReferencesPage.addReferenceDetails(customerName,
                address, data.minimumVisits);

        //Get first row data
        HashMap<String, String> referencesTableFirstRow = vehicleReferencesPage
                .getTableRow(1);

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));

        File file = new File("./download/" + "ReferenceVerification.csv");

        //Export CSV file
        InputStream is = exportDeviceReferences(driver,
                "ReferenceVerification", deviceId, "csv");
        FileUtils.copyInputStreamToFile(is, file);

        //Get CSV first record
        HashMap<String, String> csvFirstRecord = getCsvFirstRow(file);
        csvFirstRecord.put("Address", csvFirstRecord.get("Address").replaceAll(",",
                ""));

        //Get References data using service call
        deviceReferencesData = getDeviceReferences(driver, deviceId);
        int numberOfRecords = deviceReferencesData.total;

        //Validate total number of records in service call and csv file
        assertEquals(numberOfRecords, getCsvNumberOfRecords(file, true));

        //Validate first row of csv file with first row of grid
        assertEquals(referencesTableFirstRow, csvFirstRecord);

        //TODO open issue: https://jira.spireon.com/browse/VFM-4142
        //Send email in CSV format
        /*vehicleReferencesPage.sendEmail("CSV", emailId);

        List<File> fileList = getEmailAttachments(searchTerm, "INBOX",
                System.getProperty("user.dir"));

        assertFalse(fileList.isEmpty(), "Email was sent without attachment");

        //Validate email received with csv attachment
        assertEquals(fileList.get(0).getName(), "ReferenceVerification.csv");

        file = new File("./"+"ReferenceVerification.csv");

        csvFirstRecord = getCsvFirstRow(file);
        csvFirstRecord.put("Address", csvFirstRecord.get("Address").replaceAll(",",
                ""));

        //Validate total number of records in service call and csv file
        assertEquals(numberOfRecords, getCsvNumberOfRecords(file, true));

        //Validate first row of csv file with first row of grid
        assertEquals(referencesTableFirstRow, csvFirstRecord);

        //Click on stip report link and set stip report
        vehicleReferencesPage.clickSetStipReportLink();
        vehicleReferencesPage.setStipReport();

        //Validate stip report bubble shows
        assertTrue(new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(vehicleReferencesPage.getStipReportMap
                        ())).isDisplayed());
        assertEquals(vehicleReferencesPage.getStipReportMap().getAttribute
                ("title"), "Stipreport - " + vehiclesPage.getVehicleName()
                .getText());*/

        long referenceId = deviceReferencesData.data.stream()
                .filter(deviceReferencesDetail -> deviceReferencesDetail.name.equals(customerName))
                .findAny().map(deviceReferencesDetail -> deviceReferencesDetail.id).orElse((long) 0);

        //Delete created reference
        assertEquals(deleteDeviceReferences(driver, referenceId).success, true);
    }

    @Test(description = "GeoFence - Save/View/Clear GeoFence", groups = {"vehicles"})
    public void testVerifyGeoFenceTab() throws UnirestException {

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Click on GeoFence tab
        VehicleGeoFencePage vehicleGeoFencePage = vehiclesPage.clickGeoFenceTab();

        //Validate Geo-Fence Tab grid is displayed
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(vehicleGeoFencePage.columnHeader().isDisplayed());

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 250);
        queryParams.put("sort", "name");

        //Get GeoFence data
        Device.DeviceGeoFencesData geoFenceData = getGeoFences(driver, queryParams);

        List<String> geoFenceList = new ArrayList<>();
        geoFenceList.add("Not Selected");
        geoFenceData.data.forEach(deviceDetail -> geoFenceList.add(deviceDetail.name));

        //Verify Geo-Fence Name drop down
        assertEquals(geoFenceList, vehicleGeoFencePage.getGeoFenceList());

        //Verify Geo-Fence Type drop down
        assertEquals(VehicleGeoFencePage.GeoFenceTypeEnum.getValues(),
                vehicleGeoFencePage.getGeoFenceTypeList());

        //Verify Action Links: View/Clear/Save.
        assertTrue(vehicleGeoFencePage.getFirstRowViewLink().isDisplayed());
        assertTrue(vehicleGeoFencePage.getFirstRowClearLink().isDisplayed());
        assertTrue(vehicleGeoFencePage.getFirstRowSaveLink().isDisplayed());
    }

    @Test(description = "Verify Geofence commands and UI elements for multiple devices", groups = {"vehicles"})
    public void testValidateGeoFenceCommandsForMultipleDevices() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        List<String> devices = data.serialNumberList;

        VehicleGeoFencePage vehicleGeoFencePage = PageFactory.initElements(driver, VehicleGeoFencePage.class);

        for (String device : devices) {

            //Get device id
            int deviceId = getDevices(driver, device).data.get(0).deviceId;

            //Get GeoFences which are already saved
            Device.DeviceGeoFencesData geoFencesSetData = getGeoFences(driver, deviceId);

            String geoFenceId = null;

            //Search if the test data GeoFence and Type is already saved for the device.
            for (Device.DeviceGeoFencesDetail geoFencesDetail : geoFencesSetData.data) {
                if (geoFencesDetail.name.split(" - ")[0].equals(data.geoFence)
                        && geoFencesDetail.mode.equals(data.geoFenceType)) {
                    geoFenceId = geoFencesDetail.id;
                    break;
                }
            }

            //Clear GeoFence if it is already saved.
            if (geoFenceId != null) {
                assertEquals(deleteGeoFences(driver, geoFenceId).msg, "Data deleted");
            }
        }

        //Select multiple devices at a time
        vehiclesPage.searchVehicle(devices.toString().replaceAll("\\[|\\]", ""));
        vehiclesPage.selectAll();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Check availability of GeoFence button
        assertTrue(vehiclesPage.isGeoFenceBtnDisplayed(), "GeoFence button is not displayed");

        //Click bulk GeoFence button and make sure popup with expected elements exists
        vehiclesPage.clickGeoFenceButton();

        //Validate modal window
        assertTrue(vehicleGeoFencePage.getModalWindow().isDisplayed());
        assertEquals(vehicleGeoFencePage.getModalWindowTitle().getText(), "Bulk GeoFence");

        //Check the UI elements on UI page
        String expectedLblStr = "Please select a GeoFence and a type. Clicking on \"SAVE\" will save the selected " +
                "GeoFence type, if applicable, on all your selected devices. If the GeoFence type already exists " +
                "on a device, no command will be issued. Clicking on \"CLEAR\" will remove the selected GeoFence, " +
                "if applicable, on all your selected devices.";

        assertEquals(vehicleGeoFencePage.getMainTextFromBulkGeoFencePopup(), expectedLblStr,
                "Main label text does not match expected");
        assertTrue(vehicleGeoFencePage.isGeoFenceBulkDropdownIsDisplayed(),
                "Geofence drop down is not displayed");
        assertTrue(vehicleGeoFencePage.isGeoFenceTypeBulkDropdownIsDisplayed(),
                "Geofence Type drop down is not displayed");
        assertTrue(vehicleGeoFencePage.isGeoFenceBulkCancelBtnIsDisplayed(),
                "Bulk Geofence Cancel button is not displayed");
        assertTrue(vehicleGeoFencePage.isGeoFenceBulkSaveBtnIsDisplayed(),
                "Bulk Geofence Save button is not displayed");

        //Validate mandatory fields in the GeoFence popup
        vehicleGeoFencePage.bulkGeoFencePopupSave();
        assertTrue(vehicleGeoFencePage.isGeoFenceSelectValidationMsgDisplayed(),
                "Geofence Select validation message not displayed");
        assertTrue(vehicleGeoFencePage.isGeoFenceTypeValidationMsgDisplayed(),
                "Geofence Type Select validation message not displayed");

        //Select GeoFence and Type
        vehicleGeoFencePage.selectGeoFenceBulk(data.geoFence);
        vehicleGeoFencePage.selectGeoFenceTypeBulk(data.geoFenceType);

        //Save GeoFence
        vehicleGeoFencePage.saveGeofenceBulk();

        //Make sure the bubbles show up. Don't have to wait for the success.
        vehiclesPage.validateNumberOfStatusBubbles(devices.size());
    }

    @Test(testName = "Verify Vehicle Locations Details filter for Date Range 30 days",
            groups = {"goldstarsmoke", "goldstar"})
    public void testVerifyVehicleLocationsDetailsFilter30() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;
        serialNumber = data.serialNumber;

        Integer dateRange = 30;

        adjustScreenWidth(driver);

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //get device with serial number = serialNumber
        DeviceDetails.Device device = getDevice(driver, serialNumber);
        String deviceId = String.valueOf(device.deviceId);

        //Click Locations tab
        VehicleLocationsPage vehicleLocationsPage = vehiclesPage.clickLocationsTab();
        vehicleLocationsPage.setFilterDateRange("Last 30 Days");

        String env = System.getProperty("env");
        TimeZone timeZone = env.contains("prod")
                ? TimeZone.getTimeZone("America/Los_Angeles") : TimeZone.getTimeZone("UTC");
        logger.debug("TmeZone: " + timeZone);
        DateFormat rangeDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        rangeDateFormat.setTimeZone(timeZone);

        Calendar c = Calendar.getInstance(timeZone);
        Date rangeEnd = c.getTime();
        c.add(Calendar.DATE, -1 * dateRange);
        Date rangeStart = c.getTime();

        TimeZone tz = timeZone;
        Integer tzOffset = tz.getOffset(new Date().getTime()) / 1000 / 60;

        String[] currentDateRange = vehicleLocationsPage.getDateRange();
        assertEquals(currentDateRange[1], rangeDateFormat.format(rangeEnd),
                "Date range end date does not match with current date");
        assertEquals(currentDateRange[0], rangeDateFormat.format(rangeStart),
                "Date range start does not match with current date - 30 days");

        //VehicleLocationDetailsPage vehicleLocationDetailsPage = vehicleLocationsPage.clickLocationDetails();

        Map<String, Object> addressParams = new HashMap<>();
        addressParams.put("startTime", "12:00 AM");
        addressParams.put("endTime", "11:59 PM");
        addressParams.put("max", 10);
        addressParams.put("validDays", "1,2,3,4,5,6,7");
        addressParams.put("deviceId", deviceId);
        addressParams.put("range", dateRange);
        addressParams.put("tzOffset", tzOffset);
        addressParams.put("_", System.currentTimeMillis());

        DeviceHistory.DeviceTopAddressesResults deviceTopAddressesResults =
                getDeviceTopAddresses(driver, addressParams);

        // Using faux trip to load data for vehicle
        if (deviceTopAddressesResults.data.isEmpty()) {
            String tripFile = "src/test/resources/trips/aston_to_reynolds.csv";
            int eventDelay = 1200000;
            try {
                PlatformApiUtils.generateEvents(serialNumber, tripFile, eventDelay);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
                throw new AssertionError("Failed to generate trip from: " + tripFile + " for device: " + serialNumber);
            }
            // Waiting for trip data to be processed by the system and appear on vehicle locations page
            RetryPolicy retryPolicy = new RetryPolicy()
                    .withDelay(1, TimeUnit.SECONDS)
                    .withMaxRetries(30)
                    .retryOn(org.openqa.selenium.TimeoutException.class);
            Failsafe.with(retryPolicy)
                    .withFallback((CheckedConsumer<? extends Throwable>) failure
                            -> {
                        throw new AssertionError("Failed to generate location data for device: " + serialNumber);
                    })
                    .run(() -> {
                        vehiclesPage.unselectVehicle(1);
                        vehiclesPage.selectVehicle(1);
                        vehicleLocationsPage.waitForLocationDetailsButton();
                    });

            deviceTopAddressesResults = getDeviceTopAddresses(driver, addressParams);
        }

        assertTrue(deviceTopAddressesResults.data != null && deviceTopAddressesResults.data.size() > 0,
                "List of Location addresses is empty");

        assertTrue(deviceTopAddressesResults.count > 0, "Should be at least one address");

        DateFormat apiDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        apiDateFormat.setTimeZone(timeZone);

        Date apiRangeStart = rangeStart; //getStartOfDay(rangeStart);
        Date apiRangeEnd = rangeEnd; //getEndOfDay(rangeEnd);
        DateFormat eventDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
        eventDateFormat.setTimeZone(timeZone);

        for (DeviceHistory.DeviceTopAddressesOutput address : deviceTopAddressesResults.data) {
            assertTrue(address.stateIds.size() > 0, "Each address should have list of state id's");

            // for each address getting list of events (Details in UI)
            Map<String, Object> queryParams = new HashMap<>();
            queryParams.put("id", deviceId);
            queryParams.put("startDate", apiDateFormat.format(rangeStart));
            queryParams.put("endDate", apiDateFormat.format(rangeEnd));
            queryParams.put("limitTotal", "false");
            queryParams.put("stateId", String.join(",", address.stateIds));
            queryParams.put("ignoreGeozoneViolations", true);

            DeviceHistory.DeviceHistoryResults deviceHistoryResults = getDeviceHistory(driver, queryParams);

            assertTrue(deviceHistoryResults.data != null && deviceHistoryResults.data.size() > 0,
                    "Location Events Data is empty");

            // for each event in verifying that it is inside dateRange and presented in the local time zone
            for (DeviceHistory.DeviceHistoryOutput entry : deviceHistoryResults.data) {
                try {
                    Date startDate = eventDateFormat.parse(entry.startDate);

                    //event startDate should be inside of range
                    assertTrue(!(startDate.before(apiRangeStart) || startDate.after(apiRangeEnd)),
                            "Event StarDate : " + entry.startDate
                                    + " is out of range: " + apiRangeStart + " - " + apiRangeEnd);

                    //event startDate should be in user time zone
                    //df is using default time zone here
                    SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm aaa");
                    String expectedDate = df.format(startDate);
                    logger.debug("Checking date: " + startDate + " formatted date: " + entry.formattedStartDate);
                    assertEquals(entry.formattedStartDate, expectedDate,
                            "Event startDate should be in user time zone");
                } catch (java.text.ParseException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Test(description = "Verify Vehicle Map bubble information", groups = {"vehicles"})
    public void testVehicleMapPinInfo() throws UnirestException, ParseException, IOException {

        final DecimalFormat DECIMAL_FORMAT = new DecimalFormat(
                "0.####");

        final DateFormat MAP_BUBBLE_DATE_FORMAT = new SimpleDateFormat
                ("MM/dd/yyyy h:mma '('z')'");

        final DateFormat API_DATE_FORMAT = new SimpleDateFormat
                ("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        vehiclesPage.clickDragPanelBtn();

        //Validate map bubble shows
        assertTrue(new WebDriverWait(driver, 10).until(ExpectedConditions
                .visibilityOf(vehiclesPage.getMapBubble())).isDisplayed());

        VehicleHistoryPage vehicleHistoryPage = PageFactory.initElements
                (driver, VehicleHistoryPage.class);

        HashMap<String, String> mapBubbleContent = vehicleHistoryPage
                .getMapMarkerPopUpContent();

        String[] positionArr = mapBubbleContent.get("Position").split(", ");
        String position = DECIMAL_FORMAT.format(Double.valueOf(positionArr[0])) + "," +
                DECIMAL_FORMAT.format(Double.valueOf(positionArr[1]));
        mapBubbleContent.put("Position", position);
        mapBubbleContent.put("Status", mapBubbleContent.get("Status").split(" ")[0]);
        mapBubbleContent.remove("Event");
        mapBubbleContent.remove("Odometer");

        Device.DeviceData deviceData = getDevices(driver, serialNumber);
        String globalId = deviceData.data.get(0).assetGlobalId;

        Device.AssetApiData assetApiData = getAssetApi(driver, globalId);

        String location;
        if (assetApiData.data.lastLocation.address != null) {
            location = assetApiData.data.lastLocation.address.line1 + ", " +
                    assetApiData.data.lastLocation.address.city + "," + assetApiData.data.lastLocation.address.stateOrProvince;

            if (assetApiData.data.lastLocation.address.postalCode != null) {
                location += " " + assetApiData.data.lastLocation.address.postalCode;
            }
        } else {
            location = "Unknown";
        }

        HashMap<String, String> apiContent = new HashMap<>();

        if (assetApiData.data.status.equals("OK") && assetApiData.data.speed == 0) {
            apiContent.put("Status", "Stopped");
        } else if (assetApiData.data.status.equals("OK") && assetApiData.data.speed > 0) {
            apiContent.put("Status", "Moving");
        } else {
            apiContent.put("Status", assetApiData.data.status);
        }

        apiContent.put("As of", formatDate(driver, assetApiData.data.locationLastReported,
                API_DATE_FORMAT, getUserSettings(driver).userTz, MAP_BUBBLE_DATE_FORMAT));
        apiContent.put("Position", DECIMAL_FORMAT.format(assetApiData.data.lastLocation.lat)
                + "," + DECIMAL_FORMAT.format(assetApiData.data.lastLocation.lng));
        apiContent.put("Location", location);

        //TODO Event name is not exist in Asset Api call and odometer value in asset api is not matching with odometer
        // value in map bubble
        /*apiContent.put("Event", assetApiData.data.eventTypeName);
        apiContent.put("Odometer", assetApiData.data.odometer + " (est.)");*/

        //Validate map bubble content with service call response
        assertEquals(mapBubbleContent, apiContent);

        //Validate links
        assertTrue(vehiclesPage.mapBubbleLocateLink().isEnabled());
        assertTrue(vehiclesPage.mapBubbleHistoryLink().isEnabled());
        assertTrue(vehiclesPage.mapBubblePrintLink().isEnabled());
        assertTrue(vehiclesPage.mapBubbleRecoveryLink().isEnabled());

        //Validate icons
        assertTrue(vehiclesPage.getBatteryStatus().isDisplayed());
        assertTrue(vehiclesPage.getCellSignal().isDisplayed());
        assertTrue(vehiclesPage.getGpsStatus().isDisplayed());

        //Validate map links
        assertTrue(vehiclesPage.getGoogleMapsBtn().isDisplayed());
        assertTrue(vehiclesPage.getBingMapsBtnMapsBtn().isDisplayed());

        //Verify Locate link
        vehiclesPage.clickLocateLink();
        assertTrue(vehiclesPage.getLocateStatusPopup().isDisplayed());
        vehiclesPage.getCloseCommand().click();

        //Verify History link
        vehiclesPage.clickHistoryLink();
        assertTrue(vehiclesPage.getHistoryTabLink().getAttribute("class").contains("active"));

        vehiclesPage.clickDragPanelBtn();

        //Verify when clicked, the Print modal will display for the selected vehicle
        vehiclesPage.clickPrintLink();
        List<String> openWindows = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(openWindows.get(1));
        assertTrue(vehiclesPage.getPopUpPrintBtn().isEnabled());
        assertTrue(vehiclesPage.getPopUpLeafletRadioBtn().isEnabled());

        //Close window
        driver.close();

        driver.switchTo().window(openWindows.get(0));

        //Verify Recovery link
        vehiclesPage.clickRecoveryLink();
        assertTrue(vehiclesPage.getModelWindow().isDisplayed());
        vehiclesPage.getCancelBtn().click();

        //Verify Battery Status
        verifyBatteryStatusMsg(vehiclesPage.getBatteryStatus().getAttribute("title")
                .replace("Volts", "").trim());

        //Verify Cell Signal Status
        verifyCellSignalMsg(vehiclesPage.getCellSignal().getAttribute("title"));

        //Verify GPS Status
        verifyGpsStatusMsg(vehiclesPage.getGpsStatus().getAttribute("title").replace
                ("Satellites", "").trim());

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Click Google maps
        vehiclesPage.clickGoogleMapsLink();
        waitUntilSpinnerVisible(driver, 3);

        //Google maps will be opened in new browser tab
        openWindows = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(openWindows.get(1));

        String[] googleMapsCoordinatesArr = new WebDriverWait(driver, 20).until
                (ExpectedConditions.visibilityOf(vehiclesPage
                        .getGoogleMapsSearchInput())).getAttribute("value").split(",");

        String googleMapsCoordinates = DECIMAL_FORMAT.format(Double.valueOf
                (googleMapsCoordinatesArr[0])) + "," + DECIMAL_FORMAT.format(Double.valueOf
                (googleMapsCoordinatesArr[1]));

        //Verify Google Maps link has identical Coordinates to UI
        assertEquals(googleMapsCoordinates, position);

        //Close tab
        driver.close();

        driver.switchTo().window(openWindows.get(0));

        //Click Bing maps
        vehiclesPage.clickBingMapsLink();
        waitUntilSpinnerVisible(driver, 3);

        //Bing maps will be opened in new browser tab
        openWindows = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(openWindows.get(1));

        String[] bingMapsCoordinatesArr = new WebDriverWait(driver, 10).until
                (ExpectedConditions.visibilityOf(vehiclesPage
                        .getBingMapsSearchInput())).getAttribute("value").split(",");

        String bingMapsCoordinates = DECIMAL_FORMAT.format(Double.valueOf
                (bingMapsCoordinatesArr[0])) + "," + DECIMAL_FORMAT.format(Double.valueOf
                (bingMapsCoordinatesArr[1]));

        //Verify Bing Maps link has identical Coordinates to UI
        assertEquals(bingMapsCoordinates, position);

        //Close tab
        driver.close();

        driver.switchTo().window(openWindows.get(0));
    }

    /**
     * Verify battery status message
     *
     * @param volt
     */
    public void verifyBatteryStatusMsg(String volt) {

        if (volt != null) {
            if (Float.parseFloat(volt) < 11.0) {
                assertEquals(vehiclesPage.getBatteryStatusMsg().getAttribute
                        ("innerText"), "Low Battery");
            }
            if (Float.parseFloat(volt) >= 11.0 && Float.parseFloat(volt) <= 11.8) {
                assertEquals(vehiclesPage.getBatteryStatusMsg().getAttribute
                        ("innerText"), "Fair");
            }
            if (Float.parseFloat(volt) >= 11.9) {
                assertEquals(vehiclesPage.getBatteryStatusMsg().getAttribute
                        ("innerText"), "Good");
            }
        } else {
            logger.warn("Unknown");
        }
    }

    /**
     * Verify cell signal message
     *
     * @param cellSignal
     */
    public void verifyCellSignalMsg(String cellSignal) {

        if (cellSignal != null) {
            if (Integer.parseInt(cellSignal) > 0 & Integer.parseInt(cellSignal) <= 7) {
                assertEquals(vehiclesPage.getCellSignalStatusMsg().getAttribute
                        ("innerText"), "Poor");
            }
            if (Integer.parseInt(cellSignal) >= 8 & Integer.parseInt(cellSignal) <= 15) {
                assertEquals(vehiclesPage.getCellSignalStatusMsg().getAttribute
                        ("innerText"), "Fair");
            }
            if (Integer.parseInt(cellSignal) >= 16) {
                assertEquals(vehiclesPage.getCellSignalStatusMsg().getAttribute
                        ("innerText"), "Good");
            }
        } else {
            logger.warn("Unknown");
        }
    }

    /**
     * Verify GPS status message
     *
     * @param gpsStatus
     */
    public void verifyGpsStatusMsg(String gpsStatus) {

        if (gpsStatus != null) {
            if (Integer.parseInt(gpsStatus) > 0 & Integer.parseInt(gpsStatus) <= 2) {
                assertEquals(vehiclesPage.getGpsStatusMsg().getAttribute
                        ("innerText"), "Poor");
            }
            if (Integer.parseInt(gpsStatus) >= 3 & Integer.parseInt(gpsStatus) <= 4) {
                assertEquals(vehiclesPage.getGpsStatusMsg().getAttribute
                        ("innerText"), "Fair");
            }
            if (Integer.parseInt(gpsStatus) >= 5) {
                assertEquals(vehiclesPage.getGpsStatusMsg().getAttribute
                        ("innerText"), "Good");
            }
        } else {
            logger.warn("Unknown");
        }
    }

    @Test(description = "Verify Vehicle List and Filters - List View", groups = {"vehicles"})
    public void testValidateListAndFiltersForListView() throws UnirestException, IOException {

        ClientSettings clientSettings = new ClientSettings();

        clientSettings.setBaseUrl(String.format("%s/lenders/dealers", System.getProperty("automotiveSvcUrl")));

        DealerService client = new DealerService(clientSettings);

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        List<String> devices = data.serialNumberList;

        //Get Default Vehicles View from User settings
        User.UserSettings userSettings = getUserSettings(driver);
        String defaultVehiclesView = userSettings.defaultVehiclesView.value;
        long accountUserId = userSettings.accountUserId;

        if (defaultVehiclesView.equals("map")) {

            //Validate map view is displayed
            assertTrue(vehiclesPage.getMapViewBtn().getAttribute("class").contains(
                    "active"));
        } else {

            //Validate list view is displayed
            assertTrue(vehiclesPage.getListViewBtn().getAttribute("class").contains(
                    "active"));
        }

        //Toggle to list view
        vehiclesPage.getListViewBtn().click();
        assertTrue(vehiclesPage.getListViewBtn().getAttribute("class").contains(
                "active"));

        //Toggle to map view
        vehiclesPage.getMapViewBtn().click();
        assertTrue(vehiclesPage.getMapViewBtn().getAttribute("class").contains(
                "active"));

        //Clear filter
        vehiclesPage.clearFilter();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate records in UI should match record count in api response.
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver, true).total);

        //Validate Grid Navigation control elements
        vehiclesPage.verifyNavigationBtns(vehiclesPage.getSelectPageSize("MapView"));

        //Validate filter based on a substring of serial number
        vehiclesPage.searchVehicle(data.serialNumberSubString);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                data.serialNumberSubString).total);

        //Validate filter based on a substring of display name
        vehiclesPage.searchVehicle(data.displayName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, data.displayName).total);

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        long lenderId = getDevices(driver, true).data.get(0).accountId;

        //Get the api user's token
        String apiToken = getJwtToken(data.apiUserName, data.apiPassword, data.appToken);

        //Get dealer Id from automotive services
        CollectionResource<LenderDealerPartnershipDto> dealers = client.getDealer(apiToken);

        String dealerId = null;
        for (LenderDealerPartnershipDto dealer : dealers.getContent()) {
            if (dealer.getAccount().getName().equals(data.dealerName)) {
                dealerId = dealer.getAccountId();
                break;
            }
        }

        //Validate filter the list of vehicles based on dealers
        vehiclesPage.selectDealers(data.dealerName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDeviceDealers(driver, dealerId, lenderId).total);

        //Clear dealer
        vehiclesPage.selectDealers("-- All Dealers --");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate apply filter button for Active
        vehiclesPage.applyFilterMapView(DeviceStatusEnum.ACTIVE, null);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, DeviceStatusEnum.ACTIVE, null).total);

        //When filter applied filter button should be blue(active).
        assertTrue(vehiclesPage.getFilterBtn().getAttribute("class")
                .contains("active"));

        //Validate Edit button
        assertTrue(vehiclesPage.getQuickEditBtn().isEnabled());

        //Search and select a vehicle
        vehiclesPage.searchUniqueVehicle(devices.get(0));
        vehiclesPage.selectVehicle(1);

        //Validate command buttons
        validateCommandButtons();
        assertTrue(vehiclesPage.getReturnOnInventoryBtn().isEnabled());

        //Validate More command buttons
        validateMoreCommandButtons();

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate apply filter button for Inventory
        vehiclesPage.applyFilterMapView(DeviceStatusEnum.INVENTORY, null);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, DeviceStatusEnum.INVENTORY, null).total);

        //When filter applied filter button should be blue(active).
        assertTrue(vehiclesPage.getFilterBtn().getAttribute("class")
                .contains("active"));

        //Validate Edit button is not displayed
        boolean quickEditBtnDisplayed = true;
        try {
            if (vehiclesPage.getQuickEditBtn().isEnabled()) {
                quickEditBtnDisplayed = true;
            }
        } catch (NoSuchElementException e) {
            quickEditBtnDisplayed = false;
        }

        assertFalse(quickEditBtnDisplayed);

        //Search and select a vehicle
        vehiclesPage.searchUniqueVehicle(devices.get(1));
        vehiclesPage.selectVehicle(1);

        //Validate command buttons
        validateCommandButtons();
        assertTrue(vehiclesPage.getActivateBtn().isEnabled());

        //Validate More command buttons
        validateMoreCommandButtons();

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate clear filter button
        vehiclesPage.clearFilter();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver, true).total);

        //When filter cleared filter button color should be white(not active)
        assertFalse(vehiclesPage.getFilterBtn().getAttribute("class")
                .contains("active"));

        //Validate multiple vehicles selection at a time
        vehiclesPage.searchVehicle(devices.toString().replaceAll("\\[|\\]", ""));
        vehiclesPage.selectAll();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate command buttons
        validateCommandButtons();

        //Validate More command buttons
        validateMoreCommandButtons();

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate filter based on a group
        vehiclesPage.selectGroups(data.group);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        List<Group.GroupItem> groups = getGroups(driver).data;
        long groupId = 0;
        for (Group.GroupItem grp : groups) {
            if (grp.name.equals(data.group)) {
                groupId = grp.id;
                break;
            }
        }

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                groupId, data.group, true, true).total);

        //Clear group
        vehiclesPage.selectGroups("-- All Groups --");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Toggle to List view
        vehiclesPage.getListViewBtn().click();

        vehiclesPage.getColumnSelectorBtn().click();

        //Validate Grid Columns
        assertEquals(vehiclesPage.getListViewGridColumns(), vehiclesPage.getShowColumns(),
                "Columns list should match with List View Grid");

        vehiclesPage.getColumnSelectorBtn().click();

        //Validate header buttons
        assertTrue(vehiclesPage.getColumnSelectorBtn().isDisplayed());
        assertTrue(vehiclesPage.getListViewPrintAllBtn().isDisplayed());
        assertTrue(vehiclesPage.getExportBtn().isDisplayed());

        //Validate Sort on each column in list view
        for (String column : vehiclesPage.getListViewGridColumns()) {
            assertTrue(vehiclesPage.isColumnSortable(column));
        }

        //Validate filter based on a substring of serial number
        vehiclesPage.searchVehicle(data.serialNumberSubString);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                data.serialNumberSubString).total);

        //Validate filter based on a substring of display name
        vehiclesPage.searchVehicle(data.displayName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, data.displayName).total);

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        int totalDevices = vehiclesPage.getTotalRecordCount();

        //Filter devices Reporting within last 7 days
        vehiclesPage.applyFilterListView(null, ReportingEnum.WITHIN_7_DAYS);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        int devicesWithIn7Days = vehiclesPage.getTotalRecordCount();

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(devicesWithIn7Days,
                getDevices(driver, null, ReportingEnum.WITHIN_7_DAYS).total);

        //Filter devices Reporting not within last 7 days
        vehiclesPage.applyFilterListView(null, ReportingEnum.NOT_WITHIN_7_DAYS);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        int devicesNotWithIn7Days = vehiclesPage.getTotalRecordCount();

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(devicesNotWithIn7Days,
                getDevices(driver, null, ReportingEnum.NOT_WITHIN_7_DAYS).total);

        //Validate sum of count within 7 days & counts not within 7 days match the total count of vehicles
        assertEquals(devicesWithIn7Days + devicesNotWithIn7Days, totalDevices);

        //Clear filter
        vehiclesPage.clearFilterListView();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate filter the list of vehicles based on dealers
        vehiclesPage.selectDealers(data.dealerName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDeviceDealers(driver, dealerId, lenderId).total);

        //Clear dealer
        vehiclesPage.selectDealers("-- All Dealers --");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate filter based on a group
        vehiclesPage.selectGroups(data.group);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(), getDevices(driver,
                groupId, data.group, true, true).total);

        //Clear group
        vehiclesPage.selectGroups("-- All Groups --");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate export links CSV, PDF and XLS
        assertTrue(vehiclesPage.getExportCSVLink().isEnabled());
        assertTrue(vehiclesPage.getExportPDFLink().isEnabled());
        assertTrue(vehiclesPage.getExportXLSLink().isEnabled());

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));

        //Validate export devices in CSV, PDF and XLS
        for (ExportFormat format : ExportFormat.values()) {
            File file = new File(String.format("./download/%s.%s", "vehicleFinanceDeviceVehicleRestService",
                    format.getType()));
            try {
                InputStream is = exportDeviceData(driver, accountUserId,
                        format.getType());
                FileUtils.copyInputStreamToFile(is, file);
            } catch (UnirestException | IOException e) {
                e.printStackTrace();
                fail(e.getMessage());
            }

            //Validate file is downloaded
            assertTrue(file.exists());

            //Validate downloaded file size is greater than 0 bytes
            assertTrue(file.length() > 0);
        }

        //Validate apply filter button for Active
        vehiclesPage.applyFilterListView(DeviceStatusEnum.ACTIVE, null);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, DeviceStatusEnum.ACTIVE, null).total);

        //When filter applied filter button should be blue(active).
        assertTrue(vehiclesPage.getFilterBtnListView().getAttribute("class")
                .contains("active"));

        //Search and select a vehicle
        vehiclesPage.searchUniqueVehicleListView(devices.get(0));
        vehiclesPage.selectVehicleListView(1);

        //Validate print button for selected vehicle
        assertTrue(vehiclesPage.getListViewPrintVehicleInfoBtn().isEnabled());

        //Validate Edit button
        assertTrue(vehiclesPage.getEditBtn().isEnabled());

        //Validate command buttons
        validateCommandButtons();
        assertTrue(vehiclesPage.getReturnOnInventoryBtn().isEnabled());

        //Validate More command buttons
        validateMoreCommandButtons();

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate apply filter button for Inventory
        vehiclesPage.applyFilterListView(DeviceStatusEnum.INVENTORY, null);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Total vehicle records in the UI and total records in API should be same
        assertEquals(vehiclesPage.getTotalRecordCount(),
                getDevices(driver, DeviceStatusEnum.INVENTORY, null).total);

        //When filter applied filter button should be blue(active).
        assertTrue(vehiclesPage.getFilterBtnListView().getAttribute("class")
                .contains("active"));

        //Search and select a vehicle
        vehiclesPage.searchUniqueVehicleListView(devices.get(1));
        vehiclesPage.selectVehicleListView(1);

        //Validate Edit button is not displayed
        quickEditBtnDisplayed = true;
        try {
            if (vehiclesPage.getEditBtn().isEnabled()) {
                quickEditBtnDisplayed = true;
            }
        } catch (NoSuchElementException e) {
            quickEditBtnDisplayed = false;
        }

        assertFalse(quickEditBtnDisplayed);

        //Validate command buttons
        validateCommandButtons();
        assertTrue(vehiclesPage.getActivateBtn().isEnabled());

        //Validate More command buttons
        validateMoreCommandButtons();

        //Clear search
        vehiclesPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Clear filter list view
        vehiclesPage.clearFilterListView();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate navigation controls present
        vehiclesPage.verifyNavigationElementsPresent(vehiclesPage.getSelectPageSize("ListView"));

        vehiclesPage.selectPageSizeValue(CommonGrid.SelectPageSizesEnum.TWENTY_FIVE.getName(),
                vehiclesPage.getSelectPageSize("ListView"));
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate Grid Navigation control elements
        vehiclesPage.verifyNavigationBtns(vehiclesPage.getSelectPageSize("ListView"));

        //Validate print all button
        assertTrue(vehiclesPage.getListViewPrintAllBtn().isEnabled());
    }

    @Test(description = "Vehicle Note - Paginate and Sort", groups = {"vehicles"})
    public void testVehicleNoteSortPaginate() {

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Click on Notes tab
        VehicleNotesPage vehicleNotesPage = vehiclesPage.clickNotesTab();

        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(vehicleNotesPage.columnHeader())).isDisplayed());

        //Validate Pagination Info
        vehicleNotesPage.verifyPagination(vehiclesPage.getActiveTable());

        List<String> columnList = vehicleNotesPage.getGridColumns();

        //Validate Sort on each column
        columnList.forEach(column -> {
            if (!column.equals("Actions"))
                assertTrue(vehicleNotesPage.isColumnSortable(vehiclesPage.getHeaderColumnDivXpath(), column));
        });

        //Verify Ability to sort in ascending & descending when click on 'Date', 'Comment' and 'Created By' columns
        columnList.forEach(column -> {
            if (!column.equals("Actions"))
                vehicleNotesPage.verifyColumnSorting(vehiclesPage.getHeaderColumnDivXpath(), column);
        });
    }

    @Test(description = "Vehicles - Click Recovery Link and validate filters", groups = {"vehicles"})
    public void testVehicleRecoveryLinkFilters() {

        // TODO: 10/19/18 https://jira.spireon.com/browse/VFM-5212

        final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");

        DATE_FORMAT.setTimeZone(TimeZone.getTimeZone(getCurrentBrowserTimeZone(driver)));

        //Search and select vehicle then click recovery tab
        vehiclesPage.searchAndClickRecoveryLinkForSerial(serialNumber);

        //Create Recovery link
        String linkText = vehiclesPage.createRecoveryLink("TestCompany", "Automated", "Test",
                "automationtests05@gmail.com");

        //Click on the created recovery link displayed on top of the list
        VehicleRecoveryPage vehicleRecoveryPage = vehiclesPage.clickOnCreatedRecoveryLink(linkText);

        //Recovery page will be opened in new browser tab
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        vehicleRecoveryPage.waitUntilPageDisplayed();

        //Click Locations tab
        vehicleRecoveryPage.clickLocationsTab();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //TODO open issue: https://jira.spireon.com/browse/VFM-5105
        //date range changes to next day after 5:00 PM PT
        /*//Click Filter and select "Last 30 Days", select all days of week and click Apply
        vehicleRecoveryPage.applyFilter("Last 30 Days");

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate Date Range
        assertEquals(vehicleRecoveryPage.getDateRange(30, DATE_FORMAT), vehicleRecoveryPage.getDateRangeUI());

        //Click Filter and select "Last 60 Days", select all days of week and click Apply
        vehicleRecoveryPage.applyFilter("Last 60 Days");

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate Date Range
        assertEquals(vehicleRecoveryPage.getDateRange(60, DATE_FORMAT), vehicleRecoveryPage.getDateRangeUI());

        //Click Filter and select "Last 90 Days", select all days of week and click Apply
        vehicleRecoveryPage.applyFilter("Last 90 Days");

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate Date Range
        assertEquals(vehicleRecoveryPage.getDateRange(90, DATE_FORMAT), vehicleRecoveryPage.getDateRangeUI());*/

        //Click Details Button
        vehicleRecoveryPage.clickDetailsButton();

        assertTrue(new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(vehicleRecoveryPage.columnHeader())).isDisplayed());

        final List<String> DETAILS_GRID_COLUMNS = Arrays.asList("Date", "Event", "Day");

        //Validate Grid Columns.
        assertEquals(vehicleRecoveryPage.getGridColumns(), DETAILS_GRID_COLUMNS,
                "Columns list is not matching");

        //Validate rectangular block shows on the right showing graphical representation of time
        assertTrue(vehicleRecoveryPage.getTrendChart().isDisplayed());
    }

    @Test(description = "Vehicles - Verify Profile Changes tab, Sort and Paginate", groups = {"vehicles"})
    public void testVehicleProfileChangesTab() {

        final List<String> GRID_COLUMNS = Arrays.asList("Date", "Changes", "By");

        final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");

        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        String deviceStatusOld = WordUtils.capitalize(vehiclesPage.getVehicleDeviceStatusTxt().toLowerCase());

        //Validate Profile Changes tab is displayed
        assertTrue(vehiclesPage.isProfileChangesTabPresent());
        assertEquals(vehiclesPage.getProfileChangesTab().getText(), "Profile Changes");

        //Click on Profile Changes tab
        vehiclesPage.clickProfileChangesTab();

        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(vehiclesPage.columnHeader())).isDisplayed());

        //Validate Grid Columns.
        assertEquals(vehiclesPage.getGridColumns(), GRID_COLUMNS,
                "Columns list should match for Profile changes tab");

        //Get first row data
        HashMap<String, String> profileChangesTableFirstRow = vehiclesPage.getTableRow(1);

        //Validate date format in first row of grid
        DATE_FORMAT.setLenient(false);
        String date = profileChangesTableFirstRow.get("Date");
        try {
            DATE_FORMAT.parse(date);
        } catch (ParseException e) {
            assertNotEquals(e.getMessage(), "Unparseable date: " +
                    "\"" + date + "\"", "Date & Time is not " +
                    "formatted as MM/dd/yyyy hh:mm:ss AM|PM");
        }

        //Change device status
        String deviceStatusNew;
        if (deviceStatusOld.equals("Installed")) {
            deviceStatusNew = "Not Installed";
        } else {
            deviceStatusNew = "Installed";
        }
        vehiclesPage.selectAndSaveStatus(deviceStatusNew);

        profileChangesTableFirstRow = vehiclesPage.getTableRow(1);

        //Validate 'Change' column should show the field that was changed,
        // From should show the old value of the changed field and To should show the new value of the changed field.
        assertEquals(profileChangesTableFirstRow.get("Changes"), "Device Status: "
                + deviceStatusOld + " (old) to " + deviceStatusNew + " (new)");

        //Validate 'By' should show the user's First and Last Name
        assertEquals(profileChangesTableFirstRow.get("By"), navbarHeaderPage.getDisplayName());

        //Undo the changes
        vehiclesPage.selectAndSaveStatus(deviceStatusOld);

        //Validate By default, profile changes are sorted by Date descending.
        assertTrue(vehiclesPage.isColumnSortedDescending(vehiclesPage.getHeaderColumnDivXpath(), "Date"));

        //Change sort to 'Changes' ascending.
        vehiclesPage.clickHeaderColumn(vehiclesPage.getHeaderColumnDivXpath(), "Changes");
        assertTrue(vehiclesPage.isColumnSortedAscending(vehiclesPage.getHeaderColumnDivXpath(), "Changes"));

        //Validate any change to sort should not be remembered after reloads app.
        driver.navigate().refresh();

        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);
        vehiclesPage.clickProfileChangesTab();
        assertTrue(vehiclesPage.isColumnSortedDescending(vehiclesPage.getHeaderColumnDivXpath(), "Date"));
        assertFalse(vehiclesPage.isColumnSortedAscending(vehiclesPage.getHeaderColumnDivXpath(), "Changes"));

        //Validate depending on the user's resolution, horizontal and vertical scrollbars
        // should appear when needed.
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 3);

        vehiclesPage.verifyGridVerticalScrollbar("div.active div.ember-table-body-container.antiscroll-wrap div.antiscroll-inner");

        //TODO open issue: https://jira.spireon.com/browse/VFM-5176
        //Profile Changes tab does not allow to scroll horizontally if the width of the screen is reduced
        /*Dimension size = driver.manage().window().getSize();
        int width = size.width;
        int height = size.height;

        driver.manage().window().setSize(new Dimension(800,800));

        vehiclesPage.verifyGridHorizontalScrollbar("div.active div.ember-table-body-container.antiscroll-wrap");
        vehiclesPage.verifyGridVerticalScrollbar("div.active div.ember-table-body-container.antiscroll-wrap");

        driver.manage().window().setSize(new Dimension(width,height));*/

        List<String> columnList = vehiclesPage.getGridColumns();

        //Validate Sort on each column
        columnList.forEach(column -> assertTrue(vehiclesPage
                .isColumnSortable(vehiclesPage.getHeaderColumnDivXpath(), column)));

        //Verify Ability to sort in ascending & descending when click on 'Date', 'Changes' and 'By' columns
        columnList.forEach(column -> vehiclesPage
                .verifyColumnSorting(vehiclesPage.getHeaderColumnDivXpath(), column));

        //Validate Pagination Info
        vehiclesPage.verifyPagination(vehiclesPage.getActiveTable());
    }

    @Test(description = "Vehicles - Verify Connect tab", groups = {"vehicles"})
    public void testVehicleConnectTab() throws UnirestException {
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);
        vehiclesPage.clickConnectTab();
        vehiclesPage.clickConnectBtn();

        SalesPage connectPage = PageFactory.initElements(driver, SalesPage.class);

        assertEquals(connectPage.getDeviceSerialDropdown().getAttribute("placeholder"), serialNumber);
        assertEquals(connectPage.getVehicleName().getAttribute("value"), getDevices(driver, serialNumber).data.get(0).assetName);

    }

    @Test(description = "Verify Quick Locate", groups = {"vehicles"})
    public void testQuickLocateDevice() {
        //Search and select vehicle
        vehiclesPage.searchUniqueVehicle(serialNumber);
        vehiclesPage.selectVehicle(1);

        //Verify Vehicle has Quick Locate icon
        assertTrue(vehiclesPage.isQuickLocateIconDisplayed());

        //Verify QL devices does not show Stop report/Drive report when click on "More Commands"
        vehiclesPage.getMoreCommandsBtn().click();
        assertEquals(vehiclesPage.mapBubbleStatus(), "Stopped");
        assertFalse(vehiclesPage.isDriveReportBtnVisible());
        assertFalse(vehiclesPage.isStopReportBtnVisible());

        //Verify QL event with real device
        vehiclesPage.waitForLocateCommandBtnVisible();
        vehiclesPage.getLocateBtn().click();

        RetryPolicy successfulLocate = new RetryPolicy()
                .retryOn(TimeoutException.class)
                .withDelay(5, TimeUnit.SECONDS)
                .withMaxRetries(3);
        Failsafe.with(successfulLocate)
                .onRetry((c, t, ctx) -> LOGGER.warn("Attempt #{} to get Success locate command", ctx.getExecutions()))
                .onSuccess(c -> LOGGER.info("Device -> Locate - SUCCESS"))
                .run(() -> vehiclesPage.waitForSuccessfulBubbles(1));

        VehicleHistoryPage historyTab = vehiclesPage.clickHistoryTab();

        assertEquals(historyTab.getTableRow(1).get("Event"), "Locate");
    }
}
