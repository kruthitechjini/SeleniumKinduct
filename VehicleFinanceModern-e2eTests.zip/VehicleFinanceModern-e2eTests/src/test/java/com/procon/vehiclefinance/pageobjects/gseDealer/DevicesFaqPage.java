package com.procon.vehiclefinance.pageobjects.gseDealer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.logging.Logger;

public class DevicesFaqPage {

    @FindBy(css = "span.panel-title")
    private WebElement panelTitle;

    @FindBy(css = "div.panel-body > ol")
    private WebElement devicesFAQ;

    public String getPanelTitleText() {
        return panelTitle.getText();
    }

    WebDriver driver;
    protected static final Logger logger = Logger
            .getLogger(DevicesFaqPage.class.getName());

    public DevicesFaqPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getDevicesFaq() {
        return devicesFAQ;
    }
}
