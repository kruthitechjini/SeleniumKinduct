package com.procon.vehiclefinance.pageobjects.reports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class ReportsLeftBarPage extends ReportSelectionPanel {

    protected static final Logger logger = LoggerFactory.getLogger(ReportsLeftBarPage.class);

    private WebDriver driver;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(1) select")
    private WebElement reportTypeDropdown;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(2) input")
    private WebElement groupsInput;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(2) label")
    private WebElement groupsLabel;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(3) input")
    private WebElement vehiclesInput;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(3) label")
    private WebElement vehiclesLabel;

    @FindBy(css = "section.west div.reports-basic > div.row:nth-of-type(4) select")
    private WebElement dateRangeDropdown;

    @FindBy(css = "section.west div.reports-basic div.has-error > span.help-block")
    private WebElement helpBlockLabel;

    // custom date range elements
    @FindBy(css = "section.west div.reports-basic div.custom-date > div.row:nth-of-type(1) input")
    private WebElement customStartDateInput;

    @FindBy(css = "section.west div.reports-basic div.custom-date > div.row:nth-of-type(1) select")
    private WebElement customStartTimeDropdown;

    @FindBy(css = "section.west div.reports-basic div.custom-date > div.row:nth-of-type(2) input")
    private WebElement customEndDateInput;

    @FindBy(css = "section.west div.reports-basic div.custom-date > div.row:nth-of-type(2) select")
    private WebElement customEndTimeDropdown;

    @FindBy(css = "section.west div.row > div.advanced > a")
    private WebElement advancedReportLink;

    @FindBy(css = "section.west div.run > button")
    private WebElement runReportBtn;

    // saved reports elements
    @FindBy(css = "section.saved-reports-panel > div.heading > span")
    private WebElement savedReportsLabel;

    @FindBy(css = "section.saved-reports-panel > div.heading > small.col-xs-1 > a")
    private WebElement aToZLink;

    @FindBy(css = "section.saved-reports-panel > div.heading > small.col-xs-3 > a")
    private WebElement scheduledLink;

    @FindBy(css = "section.saved-reports-panel > div.heading > small.col-xs-2 > a")
    private WebElement recentLink;

    @FindBy(css = "div.modal div.modal-footer button.btn-danger")
    protected WebElement deletePopUpBtn;

    @FindBy(css = "input[name=\"excessiveMileageThreshold\"]")
    private WebElement mileageThresholdInput;

    @FindBy(css = "input[name=\"excessiveMileageCost\"]")
    private WebElement costPerMileInput;

    @FindBy(css = "div.vehicleSelectPrompt > div.typeahead-input-wrapper ul > li:nth-of-type(2)")
    private WebElement secondVehicleInVehiclesList;

    @FindBy(css = "section.saved-reports-panel div.row.content")
    private List<WebElement> savedReportsList;

    public ReportsLeftBarPage(WebDriver driver) {
        this.driver = driver;
    }

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    @Override
    public WebElement getReportTypeDropdown() {
        return reportTypeDropdown;
    }

    @Override
    public WebElement getGroupsInput() {
        return groupsInput;
    }

    @Override
    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    @Override
    public WebElement getVehiclesLabel() {
        return vehiclesLabel;
    }

    @Override
    public WebElement getVehiclesInput() {
        return vehiclesInput;
    }

    @Override
    public WebElement getDateRangeDropdown() {
        return dateRangeDropdown;
    }

    @Override
    public WebElement getHelpBlockLabel() {
        return helpBlockLabel;
    }

    @Override
    public WebElement getCustomStartDateInput() {
        return customStartDateInput;
    }

    @Override
    public WebElement getCustomStartTimeDropdown() {
        return customStartTimeDropdown;
    }

    @Override
    public WebElement getCustomEndDateInput() {
        return customEndDateInput;
    }

    @Override
    public WebElement getCustomEndTimeDropdown() {
        return customEndTimeDropdown;
    }

    @Override
    public WebElement getMileageThresholdDropdown() {
        return mileageThresholdInput;
    }

    @Override
    public WebElement getCostPerMileDropdown() {
        return costPerMileInput;
    }

    public WebElement getAdvancedReportLink() {
        return advancedReportLink;
    }

    public AdvancedReportsPage clickAdvancedReportLink() {
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
        advancedReportLink.click();
        return PageFactory.initElements(driver, AdvancedReportsPage.class);
    }

    public WebElement getRunReportBtn() {
        return runReportBtn;
    }

    public WebElement getAToZLink() {
        return aToZLink;
    }

    public WebElement getScheduledLink() {
        return scheduledLink;
    }

    public WebElement getRecentLink() {
        return recentLink;
    }

    public WebElement getSavedReportsLabel() {
        return savedReportsLabel;
    }

    @Override
    public void clickRunButton() {
        runReportBtn.click();
    }

    /**
     * Check if the header link in Saved Reports is displayed. The header
     * links are 'A-Z', 'Scheduled' and 'Recent'
     *
     * @param headerLink text of the link
     * @return true if the link is displayed, false if not
     */
    public boolean isSavedReportHeaderLinkDisplayed(String headerLink) {
        switch (headerLink.toLowerCase()) {
            case "a-zlink":
            case "atozlink":
                return aToZLink.isDisplayed();
            case "scheduledlink":
                return scheduledLink.isDisplayed();
            case "recentlink":
                return recentLink.isDisplayed();
            default:
                return false;
        }

    }

    /**
     * Search for the given report name
     *
     * @param reportName
     * @return
     */
    private WebElement getSavedReportElement(String reportName) {
        waitUntilSpinnerInvisible(driver, 30);
        int retryCount = 5;
        String cssSelector = "section.saved-reports-panel > div.scroll-body > div" +
                ".row.content";
        while (true) {
            List<WebElement> savedReportElements = driver.findElements(By
                    .cssSelector(cssSelector));
            for (WebElement row : savedReportElements) {
                WebElement titleElement = row.findElement(By.cssSelector("span" +
                        ".row > span.saved-report-summary"));
                if (titleElement.getAttribute("title").equals(reportName)) {
                    return row;
                }
            }
            if (--retryCount < 0) break;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return null;
            }
        }
        return null;
    }

    /**
     * Search for the given report name and click on edit button
     *
     * @param reportName
     */
    public void editSavedReport(String reportName) {
        waitUntilSpinnerInvisible(driver, 10);
        WebElement savedReportElement = getSavedReportElement(reportName);
        if (savedReportElement == null) {
            throw new NoSuchElementException("No saved report with matching " +
                    "name: " + reportName + " found");
        }
        String editButtonCss = "span.row > div.report-actions > div" +
                ".pull-right > button:nth-of-type(1)";
        WebElement editButton = savedReportElement.findElement(By.cssSelector
                (editButtonCss));
        new WebDriverWait(driver, 10).until(elementToBeClickable(editButton)).click();
    }

    /**
     * Search for the given report name and click on run button
     *
     * @param reportName
     */
    public void runSavedReport(String reportName) {
        WebElement savedReportElement = getSavedReportElement(reportName);
        if (savedReportElement == null) {
            throw new NoSuchElementException("No saved report with matching " +
                    "name: " + reportName + " found");
        }
        String runButtonCss = "span.row > div.report-actions > div" +
                ".pull-right > button:nth-of-type(3)";
        WebElement runButton = savedReportElement.findElement(By.cssSelector
                (runButtonCss));
        new WebDriverWait(driver, 10).until(elementToBeClickable(runButton)).click();
    }

    /**
     * Search for the given report name and click on delete button
     *
     * @param reportName
     */
    public void deleteSavedReport(String reportName) {
        WebElement savedReportElement = getSavedReportElement(reportName);
        if (savedReportElement == null) {
            throw new NoSuchElementException("No saved report with matching " +
                    "name: " + reportName + " found");
        }
        String deleteButtonCss = "span.row > div.report-actions > div" +
                ".pull-right > button:nth-of-type(2)";
        WebElement deleteButton = savedReportElement.findElement(By.cssSelector
                (deleteButtonCss));
        new WebDriverWait(driver, 10).until(elementToBeClickable(deleteButton)).click();
        clickDeletePopUpBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 5);
    }

    public void clickDeletePopUpBtn() {
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(deletePopUpBtn)).click();
    }

    public WebElement getSecondVehicleInVehiclesList() {
        return secondVehicleInVehiclesList; //first vehicle starts from 2nd row
    }

    public AdvancedReportsPageGSE clickAdvancedReportLinkGSE() {
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
        advancedReportLink.click();
        return PageFactory.initElements(driver, AdvancedReportsPageGSE.class);
    }

    public List<String> getSavedReportsNameList() {
        List<String> list = new ArrayList<>();

        savedReportsList.forEach(e -> list.add(e.getText()));

        return list;
    }
}
