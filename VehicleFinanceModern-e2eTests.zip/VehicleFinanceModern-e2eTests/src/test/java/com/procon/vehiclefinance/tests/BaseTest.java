package com.procon.vehiclefinance.tests;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.procon.vehiclefinance.pageobjects.LoginPage;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.RenewalsPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.util.MyFormatter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.*;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.ConsoleHandler;

import static org.testng.Assert.fail;

public class BaseTest implements IHookable {

    private static final String RENEWALS_URL_PART = "renewals";
    private static final String VEHICLES_URL_PART = "vehicles";
    protected static final String TEST_DATA_FILE =
            "src/test/resources/test_data.json";

    protected static final Logger LOGGER = LoggerFactory
            .getLogger(BaseTest.class);
    protected static final List<String> PROD_ENVS = Arrays.asList("bhphprod",
            "kahuprod");

    protected ObjectMapper mapper = new ObjectMapper();
    protected JsonNode envNode;
    protected String env;

    protected WebDriver driver;
    protected String baseUrl;
    protected String userName;
    protected String password;
    protected String renewalsPage;
    protected String serialNumber;
    protected String logoSrc;
    protected String invalidLoginTest;
    protected String adminUserTypeData;
    protected String emailId;
    protected String emailPassword;
    protected String videoUrl;
    protected String rPortalLaunchName;
    protected String platform;
    protected String browser;
    protected String ffVersion;
    protected String hub_url;
    protected String full_hub_url = null;

    /**
     * Override the run in order to associate screenshots with the tests in
     * Reportportal.io.  Without this method, screenshots and logs are associated
     * with the 'aftermethod' instead of the test.
     *
     * @param callBack
     * @param testResult
     */
    @Override
    public void run(IHookCallBack callBack, ITestResult testResult) {
        callBack.runTestMethod(testResult);
        if (rPortalLaunchName != null && !rPortalLaunchName.trim().isEmpty()) {
            //Send Gridlastic Links to ReportPortal Log
            if (videoUrl != null && !videoUrl.trim().isEmpty()) {
                LOGGER.info("Video Link: " + testResult.getTestClass().getName() + ": \n" + videoUrl + ((RemoteWebDriver) driver).getSessionId());
            }
            //Send screenshots to report portal if any
            if (testResult.getThrowable() != null) {
                try {
                    File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                    String name = testResult.getMethod().getMethodName();
                    LOGGER.info("RP_MESSAGE#FILE#{}#{}", scrFile.getAbsolutePath(), "Screenshot-" + name);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @BeforeClass(alwaysRun = true)
    public void setupSuite(ITestContext context) throws IOException {
        // setup logger with console handler
        //logger.setUseParentHandlers(false);
        MyFormatter formatter = new MyFormatter();
        ConsoleHandler handler = new ConsoleHandler();
        handler.setFormatter(formatter);
        //logger.addHandler(handler);

        env = System.getProperty("env");
        JsonNode doc = mapper.readTree(new File(TEST_DATA_FILE));
        envNode = doc.at("/" + env);


        baseUrl = System.getProperty("baseUrl");
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
        serialNumber = System.getProperty("serialNumber");
        logoSrc = System.getProperty("logoSrc");
        invalidLoginTest = System.getProperty("invalidLoginTest");
        adminUserTypeData = System.getProperty("adminUserTypeData");
        emailId = System.getProperty("emailId");
        emailPassword = System.getProperty("emailPassword");
        videoUrl = System.getProperty("video_url");
        rPortalLaunchName = System.getProperty("rPortalLaunchName");


        // Setup Driver
        platform = System.getProperty("platform", "linux");
        browser = System.getProperty("browser", "chrome");
        ffVersion = System.getProperty("ffVersion", "59");
        hub_url = System.getProperty("hub_url", "");
        full_hub_url = null;
        if (!hub_url.isEmpty()) {
            full_hub_url = "http://" + hub_url + "/wd/hub";
            LOGGER.info("hub_url: {}", full_hub_url);
        }
    }

    @BeforeMethod(alwaysRun = true)
    public void openBrowser(ITestContext context) throws IOException {
        try {
            driver = getBrowserDriver(context, browser, hub_url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

        LOGGER.info("Working on platform '{}', browser '{}'", platform, browser);
    }

    private WebDriver getBrowserDriver(ITestContext context, String browser, String hub_url)
            throws IOException, MalformedURLException {

        WebDriver driver = null;

        switch (browser.toLowerCase()) {
            case "ff":
            case "firefox":

                if (hub_url.isEmpty()) {
                    driver = new FirefoxDriver();
                } else {
                    DesiredCapabilities ffCapabilities = setCapabilities(hub_url, platform, browser, ffVersion);
                    driver = new RemoteWebDriver(new URL(full_hub_url), ffCapabilities);

                    if (platform.equalsIgnoreCase("linux")) {
                        driver.manage().window().setSize(new Dimension(1920, 1080));
                    }
                }
                break;
            case "internetexplorer":
            case "ie":
                if (hub_url.isEmpty()) {
                    String ieDriverPath = System.getProperty("webdriver.ie.driver",
                            "./IEDriverServer.exe");
                    System.setProperty("webdriver.ie.driver", ieDriverPath);
                    driver = new InternetExplorerDriver();
                } else {
                    DesiredCapabilities ieCapabilities = setCapabilities(hub_url, platform, browser, "");
                    driver = new RemoteWebDriver(new URL(full_hub_url), ieCapabilities);
                }
                break;
            default:
                if (hub_url.isEmpty()) {
                    String chromeDriverPath = System.getProperty(
                            "webdriver.chrome.driver", "./chromedriver");
                    System.setProperty("webdriver.chrome.driver", chromeDriverPath);
                    driver = new ChromeDriver();
                } else {
                    DesiredCapabilities capabilities = setCapabilities(hub_url, platform, browser, "");
                    driver = new RemoteWebDriver(new URL(full_hub_url), capabilities);
                }
        }

        return driver;

    }

    protected DesiredCapabilities setCapabilities(String hubUrl, String platform, String browser, String ffVersion) {

        DesiredCapabilities capabilities = new DesiredCapabilities();

        if (hubUrl.toLowerCase().contains("gridlastic.com")) {
            // set platform
            if (platform.equalsIgnoreCase("windows") || platform.equalsIgnoreCase("win")) {
                capabilities.setPlatform(Platform.WIN10);
                capabilities.setCapability("platformName", "windows");
            } else {
                capabilities.setPlatform(Platform.LINUX);
            }

            // set browser & specific capabilities
            if (browser.equalsIgnoreCase("ff") || browser.equalsIgnoreCase("firefox")) {
                capabilities.setBrowserName("firefox");
                capabilities.setVersion(ffVersion);

                FirefoxOptions Options = new FirefoxOptions();
                StringBuffer binaryPath = new StringBuffer();

                if (platform.equalsIgnoreCase("linux")) {
                    binaryPath.append("/home/ubuntu/Downloads/firefox");
                    binaryPath.append(ffVersion);
                    binaryPath.append("/firefox");
                }
                else if (platform.toLowerCase().startsWith("win")) {
                    binaryPath.append("C:\\Program Files (x86)\\Mozilla Firefox\\firefox");
                    binaryPath.append(ffVersion);
                    binaryPath.append("\\firefox.exe");
                }

                Options.setBinary(binaryPath.toString());
                capabilities.setCapability("moz:firefoxOptions", Options);

            } else if (browser.equalsIgnoreCase("internetexplorer") || browser.equalsIgnoreCase("ie")) {
                capabilities.setBrowserName("internet explorer");
                capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
            } else {
                capabilities.setBrowserName("chrome");
            }

            capabilities.setCapability("video", "True");
        } else {
            setZaleniumCapabilities(capabilities);
        }

        // this is needed for zalenium & gridlastic for chrome
        if (browser.equalsIgnoreCase("chrome")) {
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("disable-infobars");
            chromeOptions.addArguments(Arrays.asList("--window-position=0,0"));
            chromeOptions.addArguments(Arrays.asList("--window-size=1920,1080"));
            capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
        }

        return capabilities;
    }


    protected void setZaleniumCapabilities(MutableCapabilities capabilities) {
        String buildName = System.getProperty("buildName");
        if (buildName != null && !buildName.trim().isEmpty()) {
            capabilities.setCapability("build", buildName);
        }
        // idle timeout of 2.5 minutes
        capabilities.setCapability("idleTimeout", 150);

        //disable/enable video recording
        capabilities.setCapability("recordVideo", System.getProperty("zaleniumRecordVideo"));

        capabilities.setCapability("name", this.getClass().getSimpleName());
    }

    protected void setZaleniumMessage(String message) {
        driver.manage().addCookie(new Cookie("zaleniumMessage", message));
    }

    protected MapPage login() {
        try {
            driver.get(baseUrl);
        } catch (NullPointerException npe) {
            fail("Error initializing driver. ", npe);
        }

        LoginPage loginPage = PageFactory.initElements(driver,
                LoginPage.class);

        // in case of retries, the user may be logged in already. In that
        // case, try to logout first
        if (driver.getCurrentUrl().contains(RENEWALS_URL_PART)) {
            loginPage = PageFactory.initElements(driver, RenewalsPage.class)
                    .logout();
        } else if (driver.getCurrentUrl().contains(VEHICLES_URL_PART)) {
            loginPage = PageFactory.initElements(driver, NavbarHeaderPage.class)
                    .logout();
        }

        MapPage mapPage = null;

        // TODO: 12/6/18 Temporary disabled Renewal page verification
        mapPage = loginPage.temporaryLogin(userName, password);

/*        if (renewalsPage.equals("Y")) {
            RenewalsPage renewalsPage = loginPage.loginWithRenewals(userName, password);
            mapPage = renewalsPage.continueAndRenewLater();
        } else if (renewalsPage.equals("N")) {
            mapPage = loginPage.loginWithNoRenewals(userName, password);
        } else { // if test data doesn't indicate if renewals page is expected or not
        try {
            mapPage = loginPage.login(userName, password);
        } catch (IOException e) {
            LOGGER.error(e.fillInStackTrace().toString());
            fail("IOException encountered during login process!");
        } catch (UnirestException e) {
            LOGGER.error(e.fillInStackTrace().toString());
            fail("UnirestException encountered during login process!");
        }
        } */

        if (mapPage == null) fail("Login timeout");
        return mapPage;
    }

    public void adjustScreenWidth(WebDriver driver) {
        Dimension targetSize;
        Dimension size = driver.manage().window().getSize();

        LOGGER.info("Initial screen size: " + size);
        if (size.width < 1400) {
            Integer width = size.width < 1400 ? 1400 : size.width;
            targetSize = new Dimension(width, size.height);
            driver.manage().window().setSize(targetSize);
            size = driver.manage().window().getSize();
            LOGGER.info("Updated screen size: " + size);
        }
    }

    public void takeScreenShotOnFailure(ITestResult testResult, ITestContext
            context) throws IOException {
        Throwable t = testResult.getThrowable();
        if (t instanceof AssertionError || t instanceof WebDriverException) {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String name = testResult.getMethod().getMethodName();
            String tmp = context.getOutputDirectory();
            String outputDir = tmp.substring(0, tmp.lastIndexOf(File.separator));
            String filename = String.format("%s_%s.png", name, System
                    .currentTimeMillis());
            try {
                FileUtils.copyFile(scrFile, new File(outputDir + File
                        .separator + filename));
            } catch (IOException e) {
                LOGGER.warn("Failed to copy screenshot: %s", e
                        .getLocalizedMessage());
            }
            Reporter.setCurrentTestResult(testResult);
            Reporter.log("<a href=\"" + filename + "\">Screenshot</a>");
        }
    }

    @AfterMethod(alwaysRun = true)
    public void teardown(ITestResult testResult, ITestContext
            context) throws IOException {

        //Report video url and screenshot links to HTML reports
        Reporter.setCurrentTestResult(testResult);

        if (driver == null) {
            LOGGER.warn("WebDriver is null in AfterMethod. No screenshot or video link will be reported");
            return;
        }

        if (testResult.isSuccess()) {
            driver.manage().addCookie(new Cookie("zaleniumTestPassed",
                    "true"));
        } else {
            driver.manage().addCookie(new Cookie("zaleniumTestPassed",
                    "false"));
        }

        if (videoUrl != null && !videoUrl.trim().isEmpty()) {
            Reporter.log("<a href=\"" + videoUrl + ((RemoteWebDriver) driver).getSessionId() + "\">Video Link: " + testResult.getTestClass().getName() + "." + testResult.getName() + "</a>", true);
        }

        takeScreenShotOnFailure(testResult, context);

        driver.quit();
    }
}
