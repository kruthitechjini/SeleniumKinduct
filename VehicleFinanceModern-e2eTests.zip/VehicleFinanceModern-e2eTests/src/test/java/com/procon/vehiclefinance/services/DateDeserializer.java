package com.procon.vehiclefinance.services;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.util.Date;

/**
 * Deserialize Data field to skip the null value. A standard @JsonInclude(Include.NON_NULL) not working/ jackson serializing null values
 * Put @JsonDeserialize(using = DateDeserializer.class) before Date field where maybe NULL value
 */
public class DateDeserializer extends StdDeserializer<Date> {
    public DateDeserializer() {
        this(null);
    }

    public DateDeserializer(Class<?> clazz) {
        super(clazz);
    }


    public Date deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
        JsonNode node = parser.getCodec().readTree(parser);
        try {
            long longDate = node.longValue();
            return new Date(longDate);
        } catch (Exception e) {
            return null;
        }
    }

}
