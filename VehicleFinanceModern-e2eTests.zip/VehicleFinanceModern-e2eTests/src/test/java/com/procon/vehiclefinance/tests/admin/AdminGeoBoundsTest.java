package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.models.GeoCoord;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminGeoBoundsPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.DeviceService.getGeoFences;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvFirstRow;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;
import static com.procon.vehiclefinance.util.WebElements.*;
import static org.testng.Assert.*;

public class AdminGeoBoundsTest extends BaseTest {

    private static final Logger logger = LoggerFactory
            .getLogger(AdminGeoBoundsTest.class);

    protected MapPage mapPage;
    private AdminLeftBarPage adminLeftBarPage;
    private NavbarHeaderPage navbarHeaderPage;
    private AdminGeoBoundsPage adminGeoBoundsPage;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String searchText;
        public String searchByName;
        public String searchByShape;
        public String searchByState;
        public String searchByZipCode;
        public String latitude;
        public String longitude;
        public String geoZone;
        public String address;
        public String city;
        public String state;
        public String zip;
        public String country;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        AdminUserTypesTest.LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, AdminUserTypesTest.LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            } else {
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {
        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {

            // press escape key to dismiss advanced reports page if present
            new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Add/Edit/Cancel/Delete a GeoFence", groups = {"admin"})
    public void testAddEditDeleteGeoFence() {

        //Navigate to Admin GeoFence Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoFencesLink();
        adminGeoBoundsPage.clickAddGeoFencesBtn();

        String name = "Automated Test Geofence " + System.currentTimeMillis();
        GeoCoord geoCoord = new GeoCoord.GeoCoordBuilder().lat(32.890027D)
                .lng(-96.976221D).build();
        String radius = "5";

        adminGeoBoundsPage.addGeoBoundByLatLong(name, geoCoord, true,
                radius, "circle");

        Address address = new Address.AddressBuilder()
                .street("1429 W Royal Lane")
                .build();

        // test cancel form functionality
        waitUntilSpinnerInvisible(driver, 15);
        adminGeoBoundsPage.editSearchedRecord(name);
        adminGeoBoundsPage.enterName("Automated Test GeoZone New");
        adminGeoBoundsPage.cancelForm();

        // update geofence, this also confirms that it was added previously,
        // and that cancel step worked as expected
        adminGeoBoundsPage.editAddress(name, address, false);

        // delete geofence
        adminGeoBoundsPage.deleteGeoBound(name);
    }

    @Test(description = "Add a Geozone by address, edit/cancel and delete it",
            groups = {"prodsmoke", "admin"})
    public void testAddEditDeleteGeoZone() {

        //Navigate to Admin GeoZone Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoZonesLink();
        adminGeoBoundsPage.clickAddGeoZonesBtn();

        String name = "Automated Test Geozone " + System.currentTimeMillis();
        Address address = new Address.AddressBuilder()
                .street("16802 Aston St")
                .city("Irvine")
                .state("CA - California")
                .postalCode("92606")
                .country("United States")
                .build();
        String radius = "5";

        adminGeoBoundsPage.addGeoBoundByAddress(name, address, true, radius,
                "polygon");

        // test cancel form functionality
        waitUntilSpinnerInvisible(driver, 15);
        adminGeoBoundsPage.editSearchedRecord(name);
        adminGeoBoundsPage.enterName("Automated Test GeoZone New");
        adminGeoBoundsPage.cancelForm();

        // update geozone, this also confirms that it was added previously,
        // and that cancel step worked as expected
        GeoCoord geoCoord = new GeoCoord.GeoCoordBuilder().lat(32.890027D)
                .lng(-96.976221D).build();
        adminGeoBoundsPage.editLatLong(name, geoCoord, false, null, null);

        // delete geozone
        adminGeoBoundsPage.deleteGeoBound(name);
    }

    @Test(description = "Admin GeoFence - Verify page element", groups = {"admin"})
    public void testAdminGeoFencePageElements() throws UnirestException {

        final List<String> GRID_COLUMNS = Arrays.asList("Name", "Shape", "Address", "Latitude", "Longitude", "Assigned", "Actions");

        //Navigate to Admin GeoFence Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoFencesLink();

        //Validate GeoFence title
        assertTrue(adminGeoBoundsPage.getPanelTitle().isDisplayed());
        assertEquals(adminGeoBoundsPage.getPanelTitle().getText(), "GeoFences");

        //Validate Grid Columns.
        assertEquals(adminGeoBoundsPage.getGridColumns(), GRID_COLUMNS,
                "Column list does not match expected list for GeoFences grid");

        //Validate GeoFence List is visible
        int totalRecordCount = getGeoFences(driver).total;
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), totalRecordCount);

        //Validate Add, Edit, Delete buttons are visible
        assertTrue(adminGeoBoundsPage.getAddGeoFencesBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getEditLink().isDisplayed());
        assertTrue(adminGeoBoundsPage.getDeleteLink().isDisplayed());

        //Validate Grid Navigation control elements and Show dropdown present
        adminGeoBoundsPage.verifyNavigationElementsPresent();

        //Validate Map All button
        assertTrue(adminGeoBoundsPage.getMapAllBtn().isDisplayed());
    }

    @Test(description = "Admin GeoFence - Paginate, Search and Sort", groups = {"admin"})
    public void testAdminGeoFenceSearchSortPaginate() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Navigate to Admin GeoFence Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoFencesLink();

        //Validate search input is displayed
        assertTrue(adminGeoBoundsPage.getSearchInput().isDisplayed());

        int totalRecordCount = adminGeoBoundsPage.getTotalRecordCount();

        adminGeoBoundsPage.search(data.searchText.toLowerCase());
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        int totalRecordsSearchByLowercase = adminGeoBoundsPage.getTotalRecordCount();

        adminGeoBoundsPage.search(data.searchText.toUpperCase());
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        int totalRecordsSearchByUppercase = adminGeoBoundsPage.getTotalRecordCount();

        //Validate search is case insensitive
        assertEquals(totalRecordsSearchByLowercase, totalRecordsSearchByUppercase);

        //Validate when no text is entered in the search box , the background says 'Search'
        assertEquals(adminGeoBoundsPage.getSearchInput().getAttribute("placeholder"), "Search");

        //Validate when user type a value to search, user grid should update with the search input
        adminGeoBoundsPage.search(data.searchText);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), getGeoFences(driver, data.searchText).total);

        //Validate user is able to search by name, shape, address(state and zip code)
        adminGeoBoundsPage.search(data.searchByName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        Device.DeviceGeoFencesData geoFencesData = getGeoFences(driver, data.searchByName);

        //Validate total record count in UI with API
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), geoFencesData.total);

        //Validate first record in grid with first record in api
        assertEquals(adminGeoBoundsPage.getTableFirstRow(), adminGeoBoundsPage.getApiFirstRecord(geoFencesData.data));

        adminGeoBoundsPage.search(data.searchByShape);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        geoFencesData = getGeoFences(driver, data.searchByShape);

        //Validate total record count in UI with API
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), geoFencesData.total);

        //Validate first record in grid with first record in api
        assertEquals(adminGeoBoundsPage.getTableFirstRow(), adminGeoBoundsPage.getApiFirstRecord(geoFencesData.data));

        adminGeoBoundsPage.search(data.searchByState);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        geoFencesData = getGeoFences(driver, data.searchByState);

        //Validate total record count in UI with API
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), geoFencesData.total);

        //Validate first record in grid with first record in api
        assertEquals(adminGeoBoundsPage.getTableFirstRow(), adminGeoBoundsPage.getApiFirstRecord(geoFencesData.data));

        adminGeoBoundsPage.search(data.searchByZipCode);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        geoFencesData = getGeoFences(driver, data.searchByZipCode);

        //Validate total record count in UI with API
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), geoFencesData.total);

        //Validate first record in grid with first record in api
        assertEquals(adminGeoBoundsPage.getTableFirstRow(), adminGeoBoundsPage.getApiFirstRecord(geoFencesData.data));

        //Validate clear icon
        String searchValue = adminGeoBoundsPage.getSearchInput().getText();
        if (searchValue != null || searchValue != "") {
            assertTrue(adminGeoBoundsPage.getSearchInputCancel().isDisplayed());
        }

        //Validate text box should be cleared once the clear(x) icon is clicked
        adminGeoBoundsPage.getSearchInputCancel().click();
        assertEquals(adminGeoBoundsPage.getSearchInput().getText(), "");

        //Validate search with special characters, search result page should be blank
        adminGeoBoundsPage.search("#");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), 0);

        adminGeoBoundsPage.search("&");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), 0);

        //Clear search
        adminGeoBoundsPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate total record count matches after clearing search
        assertEquals(adminGeoBoundsPage.getTotalRecordCount(), totalRecordCount);

        //Validate Sort on each column
        for (String column : adminGeoBoundsPage.getGridColumns()) {
            if (!(column.equals("Assigned") || column.equals("Actions"))) {
                assertTrue(adminGeoBoundsPage.isColumnSortable(column));
            }
        }

        //Validate select page size values
        assertEquals(adminGeoBoundsPage.getSelectPageSizeValues(), CommonGrid.SelectPageSizesEnum.getValues());

        //Validate default selected option should be 50
        assertEquals(adminGeoBoundsPage.getPageSizeSelection(), 50);

        //When the user changes the value in the Show dropdown, the # of Geofences displayed in the grid
        //should automatically update to that number
        adminGeoBoundsPage.selectPageSizeValue(CommonGrid.SelectPageSizesEnum.TWENTY_FIVE.getName());

        if (adminGeoBoundsPage.getTotalRecordCount() >= 25) {
            assertEquals(adminGeoBoundsPage.getPageUpperBound(), 25);
        } else {
            assertEquals(adminGeoBoundsPage.getPageUpperBound(), adminGeoBoundsPage.getTotalRecordCount());
        }

        //Validate grid navigation control buttons
        adminGeoBoundsPage.verifyNavigationBtns();

        //Validate tooltip of navigation controls
        adminGeoBoundsPage.verifyNavigationBtnsTooptip();
    }

    @Test(description = "Admin GeoFence - MAP ALL", groups = {"admin"})
    public void testAdminGeoFenceMapAll() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Navigate to Admin GeoFence Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoFencesLink();

        //Click on map all button
        adminGeoBoundsPage.getMapAllBtn().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate total records in grid and total map pins should be same
        assertEquals(adminGeoBoundsPage.getPageUpperBound(), adminGeoBoundsPage.getNumberOfMapPins());

        adminGeoBoundsPage.clickRow(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);

        //Click on first map pin
        adminGeoBoundsPage.clickMapPin(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate map pin bubble Location, Position and Shape should be same as first row of grid
        validateGridDataWithMapPin(adminGeoBoundsPage.getTableFirstRow());

        //Search a text
        adminGeoBoundsPage.search(data.searchText);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate total records in grid and total map pins should be same
        assertEquals(adminGeoBoundsPage.getPageUpperBound(), adminGeoBoundsPage.getNumberOfMapPins());

        adminGeoBoundsPage.clickRow(1);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 2);

        //Click on first map pin
        adminGeoBoundsPage.clickMapPin(1);

        //Validate map pin bubble Location, Position and Shape should be same as first row of grid
        validateGridDataWithMapPin(adminGeoBoundsPage.getTableFirstRow());
    }

    /**
     * Validate Map Bubble data with grid row data.
     *
     * @param firstRowData
     */
    private void validateGridDataWithMapPin(HashMap<String, String> firstRowData) {

        final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#");
        DECIMAL_FORMAT.setMinimumFractionDigits(6);

        assertEquals(adminGeoBoundsPage.getMapBubbleHeadline().getText(),
                firstRowData.get("Name"));

        assertEquals(adminGeoBoundsPage.getMapBubbleLocation().getText(),
                firstRowData.get("Address"));

        assertEquals(adminGeoBoundsPage.getMapBubblePosition().getText(),
                DECIMAL_FORMAT.format(Double.valueOf(firstRowData.get("Latitude"))) + ", "
                        + DECIMAL_FORMAT.format(Double.valueOf(firstRowData.get("Longitude"))));

        assertEquals(adminGeoBoundsPage.getMapBubbleShape().getText(),
                firstRowData.get("Shape"));
    }

    @Test(description = "Admin GeoFence - Modal page elements and input validation", groups = {"admin"})
    public void testAdminGeoFenceModalPageElements() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Navigate to Admin GeoFence page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoFencesLink();

        //Click on add button
        adminGeoBoundsPage.clickAddGeoFencesBtn();

        //Validate modal window fields
        assertTrue(adminGeoBoundsPage.getModalWindow().isDisplayed());
        assertTrue(adminGeoBoundsPage.getCloseBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getNameInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getAddressInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getCityInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getStateDropdown().isDisplayed());
        assertTrue(adminGeoBoundsPage.getZipInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getCountryDropdown().isDisplayed());
        assertTrue(adminGeoBoundsPage.getConvertGpsToAddress().isDisplayed());
        assertTrue(adminGeoBoundsPage.getConvertAddressToGps().isDisplayed());
        assertTrue(adminGeoBoundsPage.getLatitudeInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getLongitudeInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getRadiusInput().isDisplayed());
        assertTrue(adminGeoBoundsPage.getRectangleRadioBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getCircleRadioBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getHelpLink().isDisplayed());
        assertTrue(adminGeoBoundsPage.getSaveBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getCancelBtn().isDisplayed());

        //Validate modal title
        assertEquals(adminGeoBoundsPage.getModalTitle().getText(), "Create GeoFence");

        adminGeoBoundsPage.getSaveBtn().click();

        //Validate mandatory fields should show error messages if these fields are empty
        assertEquals(adminGeoBoundsPage.getNameErrorMessage().getText(), "Name is required");
        assertEquals(adminGeoBoundsPage.getAddressErrorMessage().getText(), "Address is required");
        assertEquals(adminGeoBoundsPage.getCityErrorMessage().getText(), "City is required");
        assertEquals(adminGeoBoundsPage.getStateErrorMessage().getText(), "State is required");
        assertEquals(adminGeoBoundsPage.getZipErrorMessage().getText(), "Invalid zip code");

        //Enter GeoZone name
        enterText(driver, adminGeoBoundsPage.getNameInput(), data.geoZone);

        //Enter GPS location
        enterText(driver, adminGeoBoundsPage.getLatitudeInput(), data.latitude);
        enterText(driver, adminGeoBoundsPage.getLongitudeInput(), data.longitude);

        //Click 'Convert GPS to address' and verify address
        adminGeoBoundsPage.clickConvertGpsToAddress();
        assertEquals(adminGeoBoundsPage.getAddressInput().getAttribute("value"), data.address);
        assertEquals(adminGeoBoundsPage.getCityInput().getAttribute("value"), data.city);
        assertEquals(adminGeoBoundsPage.getStateDropdown().getAttribute("value"), data.state);
        assertEquals(adminGeoBoundsPage.getZipInput().getAttribute("value"), data.zip);
        assertEquals(adminGeoBoundsPage.getCountryDropdown().getAttribute("value"), data.country);

        //Validate Shape Radio Button set to Rectangle by default
        assertTrue(adminGeoBoundsPage.getRectangleRadioBtn().isSelected());
        assertTrue(adminGeoBoundsPage.isMapDragMarkerRectangleVisible());
        assertFalse(adminGeoBoundsPage.getCircleRadioBtn().isSelected());
        assertFalse(adminGeoBoundsPage.isMapDragMarkerCircleVisible());

        //Switch the shape radio button and validate
        adminGeoBoundsPage.getCircleRadioBtn().click();
        assertFalse(adminGeoBoundsPage.getRectangleRadioBtn().isSelected());
        assertFalse(adminGeoBoundsPage.isMapDragMarkerRectangleVisible());
        assertTrue(adminGeoBoundsPage.getCircleRadioBtn().isSelected());
        assertTrue(adminGeoBoundsPage.isMapDragMarkerCircleVisible());

        //Validate Radius Value set to 0.1 by default
        assertEquals(adminGeoBoundsPage.getRadiusInput().getAttribute("value"), "0.1");

        // TODO open issue: https://jira.spireon.com/browse/VFM-4834
        //When entered values: 0.01, -1, and 0/null, should display an error message: Radius Value must be greater than 0.01
        //Now, radius with 0 is allowing to save. Once this ticket is addressed this step will be automated.

        adminGeoBoundsPage.getHelpLink().click();

        //Validate help link text
        assertEquals(adminGeoBoundsPage.getHelpLinkMessage().getText(),
                "GeoFences are user-created geographic boundaries that are manually sent to specific devices. "
                        + "When those devices enter or exit the boundary, alerts are instantly triggered.");

        adminGeoBoundsPage.clickOkBtn();

        //Validate Radius value
        adminGeoBoundsPage.enterRadiusInput("3001");
        adminGeoBoundsPage.getSaveBtn().click();

        //Validate error message displayed
        assertEquals(adminGeoBoundsPage.getRadiusErrorMessage().getText(), "Max Value: 3000");

        adminGeoBoundsPage.enterRadiusInput("3000");
        adminGeoBoundsPage.getSaveBtn().click();

        boolean radiusErrorMessageDisplayed;
        try {
            radiusErrorMessageDisplayed = adminGeoBoundsPage.getRadiusErrorMessage().isDisplayed();
        } catch (NoSuchElementException e) {
            radiusErrorMessageDisplayed = false;
        }

        //Validate error message not displayed
        assertFalse(radiusErrorMessageDisplayed);
    }

    @Test(description = "Admin Geozones - Verify Import Geozones page elements and Import csv file", groups = {"admin"})
    public void testAdminGeozonesImport() throws IOException {

        String firstParagraph = "Importing GeoZones requires a file to be in the CSV format. " +
                "This can be created by exporting from excel. The following column order should be used:";
        List<String> columnsList = Arrays.asList(
                "Name - Name of GeoZone",
                "Street Address",
                "City",
                "State - Two Letter Abbreviation",
                "Zip",
                "Country - US, Mexico or Canada",
                "Latitude - Not required if address is provided",
                "Longitude - Not required if address is provided",
                "Shape - Circle or Rectangle",
                "Radius - Radius in miles");
        String secondParagraph = "Example: ";
        String csvFile = new File("src").getAbsolutePath() + "/test/resources/testImportGeozones.csv";
        String pdfFile = new File("src").getAbsolutePath() + "/test/resources/testImportGeozones.pdf";
        List<String> importResultTableColumns = Arrays.asList("Row", "Name", "Error");

        logger.info("Absolute paths on machine where test are running: ");
        logger.info(csvFile);
        logger.info(pdfFile);

        //Depends on where the test are running set WebDriver
        if (!hub_url.isEmpty()) {
            logger.info("Cast WebDriver to RemoteWebDriver and set the file detector to load file to remote machine");
            ((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
        }
        else logger.info("Using WebDriver to load file to local machine");

        //Go to Geozones
        adminGeoBoundsPage = adminLeftBarPage.clickGeoZonesLink();
        adminGeoBoundsPage.clickImportBtn();

        //verify Import dialog
        assertTrue(adminGeoBoundsPage.isFormDisplayed());
        adminGeoBoundsPage.cancelForm();
        assertFalse(adminGeoBoundsPage.isFormDisplayed());
        adminGeoBoundsPage.clickImportBtn();

        //Verify Import button is disabled until select file
        assertTrue(adminGeoBoundsPage.getModalImportBtn().getAttribute("disabled").equals("true"));
        logger.info("SendKeys {} to node", csvFile);
        adminGeoBoundsPage.getChooseFileBtn().sendKeys(csvFile);
        assertNull(adminGeoBoundsPage.getModalImportBtn().getAttribute("disabled"));

        //Verify text
        assertTrue(adminGeoBoundsPage.isTextPresent(firstParagraph));
        assertEquals(adminGeoBoundsPage.getImportGeozonesExpectedColumns(), columnsList);
        assertTrue(adminGeoBoundsPage.isTextPresent(secondParagraph));

        //Verify import success popup
        adminGeoBoundsPage.clickModalImportBtn();
        logger.info("File loaded successful");
        assertTrue(adminGeoBoundsPage.getModalWindow().isDisplayed());

        // TODO: 9/11/18 App isuue on IE https://jira.spireon.com/browse/VFM-5096
        if(platform.toLowerCase().contains("win")) return;

        assertEquals(adminGeoBoundsPage.getModalWindow().getText(),
                "×\nImport Succeeded. Your file has been imported.\nOK");
        adminGeoBoundsPage.clickOkBtn();

        //Verify imported data presented in grid
        HashMap<String, String> csv = getCsvFirstRow(new File(csvFile));
        assertTrue(adminGeoBoundsPage.search(csv.get("Name")) > 0);
        HashMap<String, String> grid = adminGeoBoundsPage.getTableFirstRow();
        StringBuilder address = new StringBuilder()
                .append(csv.get("Street Address"))
                .append(" ")
                .append(csv.get("City"))
                .append(", ")
                .append(csv.get("State"))
                .append(" ")
                .append(csv.get("Zip"));
        assertEquals(grid.get("Address"), address.toString());
        assertEquals(grid.get("Shape"), csv.get("Shape"));

        //Delete imported Geozone and verify
        adminGeoBoundsPage.deleteRecord(csv.get("Name"));
        assertTrue(adminGeoBoundsPage.search(csv.get("Name")) == 0);

        //Verify import failture popup
        adminGeoBoundsPage.clickImportBtn();
        logger.info("SendKeys {} to node", pdfFile);
        adminGeoBoundsPage.getChooseFileBtn().sendKeys(pdfFile);
        adminGeoBoundsPage.clickModalImportBtn();
        logger.info("File loaded successful");
        assertTrue(adminGeoBoundsPage.getModalWindow().isDisplayed());

        //Verify text
        assertEquals(adminGeoBoundsPage.getImportResults().get("Success"), "Success Count: 0");
        assertEquals(adminGeoBoundsPage.getImportResults().get("Failure"), "Failure Count: 1");

        //Verify table
        assertEquals(adminGeoBoundsPage.getImportFailuresTableColumns(), importResultTableColumns);

        //Verify buttons
        assertTrue(adminGeoBoundsPage.getCloseModalBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getPrintBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getExportBtn().isDisplayed());
    }

    @Test(description = "Admin GeoZones - Verify page element", groups = {"admin"})
    public void testAdminGeoZonesPageElements() {
        final List<String> GRID_COLUMNS = Arrays.asList("Name", "Shape", "Address", "Latitude", "Longitude", "Created By", "Actions");

        //Navigate to Admin GeoZones Page
        adminGeoBoundsPage = adminLeftBarPage.clickGeoZonesLink();

        //Validate GeoZones title
        assertTrue(adminGeoBoundsPage.getPanelTitle().isDisplayed());
        assertEquals(adminGeoBoundsPage.getPanelTitle().getText(), "GeoZones");

        //Validate search input is displayed
        assertTrue(adminGeoBoundsPage.getSearchInput().isDisplayed());

        //Validate Grid Columns
        assertEquals(adminGeoBoundsPage.getGridColumns(), GRID_COLUMNS,
                "Column list does not match expected list for GeoZones grid");

        //Validate Add, Edit, Delete, Import buttons are visible
        waitUntilSpinnerVisibleThenInvisible(driver, 3, 5);
        assertTrue(adminGeoBoundsPage.getAddGeoZonesBtn().isDisplayed());
        assertTrue(adminGeoBoundsPage.getEditLink().isDisplayed());
        assertTrue(adminGeoBoundsPage.getDeleteLink().isDisplayed());

        //Validate Map All button
        assertTrue(adminGeoBoundsPage.getMapAllBtn().isDisplayed());
        assertEquals(adminGeoBoundsPage.getNumberOfMapPins(), adminGeoBoundsPage.getPageUpperBound());

        //Validate pagination
        adminGeoBoundsPage.verifyPagination();

    }
}

