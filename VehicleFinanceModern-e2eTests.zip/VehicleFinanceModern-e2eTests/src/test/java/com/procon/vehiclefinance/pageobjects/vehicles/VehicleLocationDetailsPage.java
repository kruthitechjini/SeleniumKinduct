package com.procon.vehiclefinance.pageobjects.vehicles;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.procon.vehiclefinance.pageobjects.CommonGrid;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class VehicleLocationDetailsPage extends CommonGrid {

    protected static final Logger logger = Logger
            .getLogger(VehicleLocationDetailsPage.class.getName());
        
    static final String panelTitle_css = "span.panel-title";
    @FindBy(css = panelTitle_css)
    private WebElement panelTitle;
    
    @FindBy(css = "div.trend-address button")
    private WebElement backButton;
    
    private static final String mapMarkerIcon_css = "img.leaflet-marker-icon";
    @FindBy(css = mapMarkerIcon_css)
    private WebElement mapMarkerIcon;
    
    @FindBy(css = "div.half")
    private WebElement eventsTable;
    
    private static final List<String> GRID_COLUMNS = Arrays.asList("Date", "Event", "Day");
    private static final List<String> WEEK_DAYS = Arrays.asList("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
    
    public VehicleLocationDetailsPage(WebDriver driver) {
        super(driver);
    }
    
    public void waitUntilPageDisplayed() {
    	new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(panelTitle));
    }
    
    public String getPanelTitle() {    	
    	return panelTitle.getText();
    }
    
    public VehicleLocationsPage clickBackButton(){
    	backButton.click();
    	return PageFactory.initElements(driver, VehicleLocationsPage.class);
    }
    
    public List<String> getExpectedColumns() {
    	return GRID_COLUMNS;
    }
    
    public Boolean isMapMarkerVisible(){
    	return isElementPresent(driver, By.cssSelector(mapMarkerIcon_css));
    }

    public HashMap<String, String> getLastEvent(){
    	return getTableFirstRow(eventsTable);
    }
    
    public List<String> getWeekDays() {
    	return WEEK_DAYS;
    }
}
