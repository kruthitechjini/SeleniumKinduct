package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.ScheduledCommand;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminScheduledCommandsPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.services.DeviceService.getDeviceCommands;
import static com.procon.vehiclefinance.services.DeviceService.getDevices;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminScheduledCommandsTest extends BaseTest {

    private static final Logger logger = Logger
            .getLogger(AdminScheduledCommandsTest.class.getName());
    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    AdminLeftBarPage adminLeftBarPage;
    AdminScheduledCommandsPage adminScheduledCommandsPage;


    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String serialNumber1;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickCommandPage(Method method) throws IOException {

        JsonNode dataNode = envNode.at("/" + method.getName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;
            serialNumber = data.serialNumber1;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            logger.info("Failed to process config values " + e);
            logger.info("Using system values");
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Click on scheduled command
        adminLeftBarPage = navbarHeaderPage.clickAdmin();
        adminScheduledCommandsPage = adminLeftBarPage.clickScheduledCommandsLink();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }


    @Test(description = "Add/Edit/Delete Scheduled commands", groups =
            {"admin"})
    public void testAddEditDeleteScheduledCommands() {

        // Open user modal form
        adminScheduledCommandsPage.clickAddBtn();

        //Form Data
        ScheduledCommand scheduledCommand = new ScheduledCommand.ScheduledCommandBuilder()
                .name("Test Name_" + System.currentTimeMillis())
                .command("Locate")
                .frequency("Daily")
                .startDate("08/20/2017")
                .startTime("12:00 AM")
                .build();

        //Array list of serial numbers to be used in scheduled command
        ArrayList<String> serialNumbersToSelect = new ArrayList<String>();
        serialNumbersToSelect.add(serialNumber);

        //add scheduled command
        adminScheduledCommandsPage.addEditScheduledCommand(scheduledCommand, serialNumbersToSelect);

        //Edit and modify scheduled command
        String scheduledCommandName = scheduledCommand.getName();
        adminScheduledCommandsPage.editScheduledCommand(scheduledCommandName);

        ArrayList<String> serialNumbersToUpdate = new ArrayList<String>();
        scheduledCommand = new ScheduledCommand.ScheduledCommandBuilder()
                .name("changed_" + scheduledCommandName)
                .build();

        adminScheduledCommandsPage.addEditScheduledCommand(scheduledCommand, serialNumbersToUpdate);

        //Cancel edit form
        adminScheduledCommandsPage.editScheduledCommand(scheduledCommand.getName());
        String toBeCancelledName = "toBeCancelled_" + scheduledCommand.getName();
        adminScheduledCommandsPage.addScheduledCommandName(toBeCancelledName);
        adminScheduledCommandsPage.clickCancelBtn();

        //Delete scheduled command.  This will also confirm that command name was not updated after cancel operation above
        adminScheduledCommandsPage.deleteScheduledCommand(scheduledCommand.getName());
    }

    @Test(description = "Admin Scheduled Commands - Verify Modal Page Elements", groups = {"admin"})
    public void testScheduledCommandsModalPageElements() throws UnirestException {

        List<String> frequencyDropdownOptions = Arrays.asList(
                "", " ",
                "Run Once",
                "Hourly (for 24 hours)",
                "Daily",
                "Weekly",
                "Biweekly",
                "Monthly",
                "Inactive");
        List<String> commandDropdownOptions = Arrays.asList(
                "", " ",
                "Locate",
                "Starter Disable",
                "Starter Enable",
                "Warning Off",
                "Warning On");

        adminScheduledCommandsPage.clickAddBtn();

        //Verify modal window
        assertTrue(adminScheduledCommandsPage.getModalDialog().isDisplayed());
        assertEquals(adminScheduledCommandsPage.getModalTitle(), "Create Scheduled Command");

        //Verify Name field
        assertEquals(adminScheduledCommandsPage.getScheduledCommandNameInput().getAttribute("placeholder"), "Name");

        //Verify Frequency drop down
        adminScheduledCommandsPage.getFrequencyDropdown().getOptions().
                forEach(o -> assertTrue(frequencyDropdownOptions.contains(o.getText()),
                        String.format("List frequencyDropdownOptions does not contain element '%s'", o.getText())));

        //Verify Command drop down
        adminScheduledCommandsPage.getCommandTypeDropdown().getOptions().
                forEach(o -> assertTrue(commandDropdownOptions.contains(o.getText()),
                        String.format("List commandDropdownOptions does not contain element '%s'", o.getText())));

        //Verify Date and Time dropdown
        adminScheduledCommandsPage.getStartDateInput().click();
        assertTrue(adminScheduledCommandsPage.isDatePickerDisplayed(), "There is no date picker");
        assertEquals(adminScheduledCommandsPage.getStartTimeInput().getAttribute("placeholder"), "12:00 AM");
        adminScheduledCommandsPage.getStartDateInput().click();
        assertTrue(adminScheduledCommandsPage.isTimePickerDisplayed());

        //Verify 'Device Transfer' buttons
        assertTrue(adminScheduledCommandsPage.getAddBtnToSelect().isDisplayed());
        assertTrue(adminScheduledCommandsPage.getRemoveBtnToSelect().isDisplayed());

        adminScheduledCommandsPage.clickCheckBoxRow(adminScheduledCommandsPage.getSourceGridBox(), 1);
        adminScheduledCommandsPage.clickAddToSelectionBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1,5 );
        adminScheduledCommandsPage.clickCheckBoxRow(adminScheduledCommandsPage.getDestinationGridBox(), 1);
        adminScheduledCommandsPage.getRemoveBtnToSelect().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 2,5 );

        //Verify pagination
        // TODO: 9/7/18 Uncomment next code since resolved https://jira.spireon.com/browse/VFM-5077
        //adminScheduledCommandsPage.verifyPagination(adminScheduledCommandsPage.getSourceGridBoxPanel());
        assertEquals(adminScheduledCommandsPage.getTotalRecordCount(
                adminScheduledCommandsPage.getPagingPositionDiv(
                        adminScheduledCommandsPage.getSourceGridBoxPanel())),
                getDevices(driver).total);
    }

    @Test(description = "Admin Scheduled Commands - Verify page element and Search", groups = {"admin"})
    public void testScheduledCommandsPageElementsSearch() throws UnirestException {

        List<String> columns = Arrays.asList(
                "Name",
                "Frequency",
                "LastRun",
                "NextRun",
                "Vehicles",
                "Command",
                "Scheduled By",
                "Actions");

        List<String> columnsSort = Arrays.asList(
                "Name",
                "Frequency",
                "LastRun",
                "NextRun",
                "Command",
                "Scheduled By");

        List<String> columnsSearch = Arrays.asList(
                "Name",
                "Frequency"
                //"LastRun",
                //"NextRun",
                //"Scheduled By"
        );


        String searchKey;

        //Verify page elements
        assertTrue(adminScheduledCommandsPage.getSearchInput().isDisplayed(),
                "Search box is not visible");
        assertTrue(adminScheduledCommandsPage.getAddBtn().isDisplayed(),
                "Add button is not visible");

        List<String> gridColumns = adminScheduledCommandsPage.getGridColumns();
        assertEquals(gridColumns, columns);

        columnsSort.forEach(c -> {
            assertTrue(adminScheduledCommandsPage.isColumnSortable(c),
                "Column " + c + " is not sortable");
            adminScheduledCommandsPage.verifyColumnSorting(c);
            });

        //Verify pagination
        adminScheduledCommandsPage.verifyPagination();

        //Verify total number of records
        assertEquals(adminScheduledCommandsPage.getTotalRecordCount(), getDeviceCommands(driver).total);

        //Verify search is case insensitive
        searchKey = adminScheduledCommandsPage.getTableFirstRow().get("Name");
        int count = adminScheduledCommandsPage.search(searchKey);
        List<HashMap<String, String>> table = adminScheduledCommandsPage.getFixedTable();

        assertEquals(adminScheduledCommandsPage.search(searchKey.toLowerCase()), count);
        assertEquals(adminScheduledCommandsPage.getFixedTable(), table);

        assertEquals(adminScheduledCommandsPage.search(searchKey.toUpperCase()), count);
        assertEquals(adminScheduledCommandsPage.getFixedTable(), table);

        //Verify 'X' icon
        assertTrue(adminScheduledCommandsPage.getSearchInputCancel().isDisplayed());
        adminScheduledCommandsPage.getSearchInputCancel().click();
        assertFalse(adminScheduledCommandsPage.getSearchInputCancel().isDisplayed());

        //Verify when no text is entered in the search box , the background says 'Search'
        assertEquals(adminScheduledCommandsPage.getSearchInput().getAttribute("placeholder"), "Search");

        //Verify "The user grid should update with the search input, does not require clicking a search icon or hitting enter"
        adminScheduledCommandsPage.getSearchInput().clear();
        new Actions(driver).sendKeys(adminScheduledCommandsPage.getSearchInput(),searchKey.substring(0,searchKey.length()/3)).perform();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertNotEquals(adminScheduledCommandsPage.getTotalRecordCount(),count);

        //Verify search by columns
        HashMap<String, String> firstRow = adminScheduledCommandsPage.getTableFirstRow();
        columnsSearch.forEach(c -> {
            assertTrue(adminScheduledCommandsPage.search(firstRow.get(c)) > 0,
                    "Search by column " + c + " doesn't work");
        });
    }
}
