package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;

public class AdminUsersPage extends CommonGrid {

    private static final Logger logger = Logger
            .getLogger(AdminUsersPage.class.getName());

    @FindBy(css = ".col-xs-6.device-filter-section > button:nth-of-type(1)")
    private WebElement addUserBtn;

    @FindBy(css = "input[name='firstName']")
    private WebElement firstNameInput;

    @FindBy(css = "input[name='lastName']")
    private WebElement lastNameInput;

    @FindBy(css = "input[name='username']")
    private WebElement usernameInput;

    @FindBy(css = "select.ember-view.ember-select.form-control")
    private WebElement userTypeDropdown;

    @FindBy(css = "input[name='newPassword']")
    private WebElement newPasswordInput;

    @FindBy(css = "input[name='confirmPassword']")
    private WebElement confirmPasswordInput;

    @FindBy(css = "input[name='email']")
    private WebElement emailInput;

    @FindBy(css = "input[name='phone']")
    private WebElement phoneInput;

    @FindBy(css = "div.panel-body.user_panel_body_small")
    private WebElement groupsBox;

    @FindBy(css = "input[name='groupAll']")
    private WebElement selectAllGroupsChkBox;

    @FindBy(css = "input[name='globalAccess']")
    private WebElement hasGlobalAccessCheckBox;

    @FindBy(css = "textarea[name='comments']")
    private WebElement commentsInput;

    @FindBy(css = "input[name='inactive']")
    private WebElement inactiveUserChkBox;

    private static final String CANCEL_BTN_CSS = "div.modal-footer > button" +
            ".btn-cancel";
    @FindBy(css = CANCEL_BTN_CSS)
    private WebElement cancelBtn;

    private static final String SAVE_BTN_CSS = "div.modal-footer > button" +
            ".btn-primary";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header h4.modal-title")
    private WebElement modalWindowTitle;

    @FindBy(css = "div.has-error span[for='firstName']")
    private WebElement firstNameErrorMessage;

    @FindBy(css = "div.has-error span[for='lastName']")
    private WebElement lastNameErrorMessage;

    @FindBy(css = "div.has-error span[for='username']")
    private WebElement usernameErrorMessage;

    @FindBy(css = "div.has-error span[for='rolesJSON']")
    private WebElement usertypeErrorMessage;

    @FindBy(css = "div.has-error span[for='newPassword']")
    private WebElement passwordErrorMessage;

    @FindBy(css = "div.has-error span[for='email']")
    private WebElement emailErrorMessage;

    @FindBy(css = "button[data-toggle='dropdown']")
    private WebElement exportBtn;

    @FindBy(css = "div.popover-content li:nth-child(1) > div > span")
    private WebElement exportCSVLink;

    @FindBy(css = "div.popover-content li:nth-child(2) > div > span")
    private WebElement exportPDFLink;

    @FindBy(css = "div.popover-content li:nth-child(3) > div > span")
    private WebElement exportXLSLink;

    public AdminUsersPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickAddUserBtn() {
        addUserBtn.click();
    }

    public void addEditUser(Person person, String password, String confirmPassword,
                            Boolean selectAllGroups, List<String> groupsToAdd, List<String> groupsToRemove) {
        addEditUser(person, password, confirmPassword, selectAllGroups,
                groupsToAdd, groupsToRemove, null, null, null);
    }

    public void addEditUser(Person person, String password, String confirmPassword,
                            Boolean selectAllGroups, List<String> groupsToAdd, List<String> groupsToRemove,
                            String comments, Boolean inactiveUser, Boolean hasGlobalAccess) {
        waitUntilSpinnerInvisible(driver, 40);
        enterPersonData(person);
        if (password != null) {
            newPasswordInput.clear();
            newPasswordInput.sendKeys(password);
        }
        if (confirmPassword != null) {
            confirmPasswordInput.clear();
            confirmPasswordInput.sendKeys(confirmPassword);
        }
        updateCheckBox(driver, selectAllGroupsChkBox, selectAllGroups);

        // completed STE-163
        addRemoveGroups(groupsToAdd, groupsToRemove);

        if (comments != null) {
            commentsInput.clear();
            commentsInput.sendKeys(comments);
        }
        updateCheckBox(driver, inactiveUserChkBox, inactiveUser);

        updateCheckBox(driver, hasGlobalAccessCheckBox, hasGlobalAccess);

        clickSave();

        //wait while user grid will be reloaded
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
    }

    public void addRemoveGroups(List<String> groupsToAdd,
                                List<String> groupsToRemove) {
        String format = "[name='%s']";
        if (groupsToRemove != null) {
            for (String group : groupsToRemove) {
                String css = String.format(format, group);
                updateCheckBox(driver, groupsBox.findElement(By.cssSelector(css)), false);
            }
        }
        if (groupsToAdd != null) {
            for (String group : groupsToAdd) {
                String css = String.format(format, group);
                updateCheckBox(driver, groupsBox.findElement(By.cssSelector(css)), true);
            }
        }
    }

    /**
     * Receives a list of groups and ensures that none of them are selected.  The first group found that is selected
     * will return false, exiting the method.
     *
     * @param groupsUnchecked
     * @return
     */
    public boolean ensureGroupsUnchecked(List<String> groupsUnchecked) {
        String format = "[name='%s']";
        if (groupsUnchecked != null) {
            // make sure the User dialog box completes displaying
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(firstNameInput)).clear();
            for (String group : groupsUnchecked) {
                String selector = String.format(format, group);
                WebElement checkBox = groupsBox.findElement(By.cssSelector(selector));
                if (checkBox.isSelected())
                    return false;
            }
        }

        return true;
    }

    /**
     * Receives a list of groups and ensures that none of them are enabled.  The first group found that is enabled
     * will return false, exiting the method.
     *
     * @param groupsUnchecked
     * @return
     */
    public boolean ensureGroupsDisabled(List<String> groupsUnchecked) {
        String format = "[name='%s']";
        if (groupsUnchecked != null) {
            // make sure the User dialog box completes displaying
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(firstNameInput)).clear();
            for (String group : groupsUnchecked) {
                String selector = String.format(format, group);
                WebElement checkBox = groupsBox.findElement(By.cssSelector(selector));
                if (checkBox.isEnabled())
                    return false;
            }
        }

        return true;
    }

    public void enterPersonData(Person person) {
        if (person.getFirstName() != null) {
            new WebDriverWait(driver, 10).until(ExpectedConditions
                    .elementToBeClickable(firstNameInput)).clear();
            firstNameInput.sendKeys(person.getFirstName());
        }
        if (person.getLastName() != null) {
            lastNameInput.clear();
            lastNameInput.sendKeys(person.getLastName());
        }
        if (person.getUsername() != null) {
            usernameInput.clear();
            usernameInput.sendKeys(person.getUsername());
        }
        if (person.getUserType() != null) {
            new Select(userTypeDropdown).selectByVisibleText(person
                    .getUserType());
        }
        if (person.getEmail() != null) {
            emailInput.clear();
            emailInput.sendKeys(person.getEmail());
        }
        if (person.getPhone() != null) {
            phoneInput.clear();
            phoneInput.sendKeys(person.getPhone());
        }
    }

    public void clickSave() {
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(saveBtn)).click();
    }

    public void clickCancel() {
        waitUntilSpinnerInvisible(driver, 10);
        clickElementAndWaitForInvisibility(driver, cancelBtn, By
                .cssSelector(CANCEL_BTN_CSS));
    }

    /**
     * Get header column names of grid.
     *
     * @return
     */
    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public HashMap<String, String> getTableFirstRow() {
        return getTableFirstRow(gridBody());
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }

    public WebElement getFirstNameErrorMessage() {
        return firstNameErrorMessage;
    }

    public WebElement getLastNameErrorMessage() {
        return lastNameErrorMessage;
    }

    public WebElement getUsernameErrorMessage() {
        return usernameErrorMessage;
    }

    public WebElement getUsertypeErrorMessage() {
        return usertypeErrorMessage;
    }

    public WebElement getPasswordErrorMessage() {
        return passwordErrorMessage;
    }

    public WebElement getEmailErrorMessage() {
        return emailErrorMessage;
    }

    public WebElement getExportBtn() {
        return exportBtn;
    }

    public WebElement getExportCSVLink() {
        return exportCSVLink;
    }

    public WebElement getExportPDFLink() {
        return exportPDFLink;
    }

    public WebElement getExportXLSLink() {
        return exportXLSLink;
    }
}
