package com.procon.vehiclefinance.tests.dashboard;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Dashboard;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AccountManagementPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.dashboard.DashboardPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.PlatformApiUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.*;

import static com.procon.vehiclefinance.services.DashboardService.*;
import static com.procon.vehiclefinance.services.DeviceService.getDevices;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class DashboardTest extends BaseTest {

    private static final Logger logger = LoggerFactory.getLogger(DashboardTest.class);
    private DashboardPage dashboardPage;
    private NavbarHeaderPage navbarHeaderPage;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String serialNumber;
    }

    @Test(description = "Renewals Dashboard", groups = {"bvt", "prodsmoke", "dashboard", "pipeline"})
    public void testDashboardRenewals() {
        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        // Validate renewal elements are present and clicking on "Renew Devices" takes user to Account Management
        DashboardPage dashboardPage = navbarHeaderPage.clickDashboard();
        assertTrue(dashboardPage.getRenewalsText().equals("Renewals"));
        assertTrue(dashboardPage.getRenewDevicesText().equals("Renew Devices"));

        String renewalsLegends = dashboardPage.getActiveDevicesText() + dashboardPage.getEligibleForRenewalText()
                + dashboardPage.getExpiredDevicesText();

        assertTrue(renewalsLegends.contains("Active Devices"));
        assertTrue(renewalsLegends.contains("Eligible for Renewal"));
        assertTrue(renewalsLegends.contains("Expired Devices"));

        assertTrue(dashboardPage.isActiveBarDisplayed());
        assertTrue(dashboardPage.isEligibleBarDisplayed());
        assertTrue(dashboardPage.isExpiredBarDisplayed());

        AdminLeftBarPage adminPage = dashboardPage.clickRenewDevices();

        assertTrue(adminPage.isAccountManagementLinkEnabled());

        AccountManagementPage acctManagementPage = PageFactory.initElements(driver, AccountManagementPage.class);
        assertTrue(acctManagementPage.isRenewalsLinkEnabled());

        navbarHeaderPage.logout();
    }

    @Test(description = "Devices Dashboard", groups = {"dashboard"})
    public void testBHPHDashboardDevices() {

        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        DashboardPage dashboardPage = navbarHeaderPage.clickDashboard();

        String devicesLegends = dashboardPage.getDevicesLegend1Text() + dashboardPage.getDevicesLegend2Text()
                + dashboardPage.getDevicesLegend3Text();

        assertTrue(dashboardPage.getDevicesText().equals("Devices"));
        assertTrue(dashboardPage.getTotalDevices() > 0);

        assertTrue(devicesLegends.contains("Installed"));
        assertTrue(devicesLegends.contains("Not Installed"));
        assertTrue(devicesLegends.contains("Out for Repossession"));

        assertTrue(dashboardPage.isDevicesPieSlice1Displayed());
        assertTrue(dashboardPage.isDevicesPieSlice2Displayed());
        assertTrue(dashboardPage.isDevicesPieSlice3Displayed());

        //click on the first pie slice to switch to vehicle page
        VehiclesPage vehiclesPage = dashboardPage.clickDevicesLegend1();

        //verify that vehicle page is displayed with Asset Groups Dropdown.
        assertTrue(vehiclesPage.isElementAvailable("Groups Dropdown"));
        assertTrue(vehiclesPage.isElementAvailable("Search"));

        navbarHeaderPage.logout();
    }

    @Test(description = "Devices GSE Dashboard", groups = {"gse", "dashboard", "pipeline"})
    public void testGSEDashboardDevices() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        DashboardTest.LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, DashboardTest.LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }
        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        DashboardPage dashboardPage = navbarHeaderPage.clickDashboard();

        assertTrue(dashboardPage.getDevicesText().equals("Devices"));

        String devicesLegends = dashboardPage.getDevicesLegend1Text() + dashboardPage.getDevicesLegend2Text();
        assertTrue(devicesLegends.contains("Active"));
        assertTrue(devicesLegends.contains("Inventory"));

        assertTrue(dashboardPage.isDevicesPieSlice1Displayed());
        assertTrue(dashboardPage.isDevicesPieSlice2Displayed());

        //click on the first pie slice to switch to vehicle page
        VehiclesPage vehiclesPage = dashboardPage.clickDevicesLegend1();
        waitUntilSpinnerInvisible(driver, 20);

        //verify that vehicle page is displayed with Asset Groups Dropdown.
        assertTrue(vehiclesPage.isElementAvailable("Groups Dropdown"));
        assertTrue(vehiclesPage.isElementAvailable("Search"));

        navbarHeaderPage.logout();
    }

    @Test(description = "Check Dashboard widgets -- BHPH", groups = {"dashboard"})
    public void testBHPHDashboardWidgets() throws UnirestException {

        verifyDashboardWidgets();

        //Verify Devices
        assertEquals(dashboardPage.getDevicesText(), "Devices");
        assertEquals(dashboardPage.getDevicesSubTitleText(), "View your installed devices");

        //Verify total devices match with API call
        assertEquals(dashboardPage.getTotalDevices(), getDevices(driver).total);
        assertEquals(dashboardPage.getTotalDevicesLabel(), "total devices");

        //Verify pie chart
        String devicesLegends = dashboardPage.getDevicesLegend1Text()
                + dashboardPage.getDevicesLegend2Text()
                + dashboardPage.getDevicesLegend3Text();
        assertTrue(devicesLegends.contains("Installed"), "Device Pie chart legend isn't correct");
        assertTrue(devicesLegends.contains("Not Installed"), "Device Pie chart legend isn't correct");
        assertTrue(devicesLegends.contains("Out for Repossession"), "Device Pie chart legend isn't correct");
        assertTrue(dashboardPage.isDevicesPieSlice1Displayed(), "Device Pie chart isn't correct");
        assertTrue(dashboardPage.isDevicesPieSlice2Displayed(), "Device Pie chart isn't correct");
        assertTrue(dashboardPage.isDevicesPieSlice3Displayed(), "Device Pie chart isn't correct");

        verifyRenewalsWidget();

        verifyUsageWidget();

        verifyRecentAlertsWidget();

        navbarHeaderPage.logout();

    }

    @Test(description = "Check Dashboard widgets -- GSE Lender", groups = {"dashboard", "gse"})
    public void testGSEDashboardWidgets() throws UnirestException {
        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }
        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        verifyDashboardWidgets();

        //Verify Devices
        assertEquals(dashboardPage.getDevicesText(), "Devices");
        assertEquals(dashboardPage.getDevicesSubTitleText(), "View your installed devices");

        //Verify total devices match with API call"
        assertEquals(dashboardPage.getTotalDevices(), getDevices(driver).total);
        assertEquals(dashboardPage.getTotalDevicesLabel(), "total devices");

        //Verify Device Pie chart
        String devicesLegends = dashboardPage.getDevicesLegend1Text()
                + dashboardPage.getDevicesLegend2Text();
        assertTrue(devicesLegends.contains("Active"), "Device Pie chart legend isn't correct");
        assertTrue(devicesLegends.contains("Inventory"), "Device Pie chart legend isn't correct");

        assertTrue(dashboardPage.isDevicesPieSlice1Displayed(), "Device Pie chart isn't correct");
        assertTrue(dashboardPage.isDevicesPieSlice2Displayed(), "Device Pie chart isn't correct");

        verifyRenewalsWidget();

        verifyUsageWidget();

        verifyRecentAlertsWidget();

        navbarHeaderPage.logout();

    }

    @Test(description = "Usage Widget Functionality -- BHPH Dealer", groups = {"dashboard"})
    public void testBHPHDashboardUsage() throws UnirestException {

        final String TIME_ZONE = "America/Los_Angeles";
        int[] dayRanges = {1, 7, 30};

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());
        DashboardTest.LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, DashboardTest.LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }
        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        verifyDashboardWidgets();

        // TODO: 9/20/18 Add report verification once resolved
        // step 1 http://testrail.spireon.com/index.php?/cases/view/88577&group_by=cases:section_id&group_id=519&group_order=asc

        //Verify default period
        assertEquals(dashboardPage.getActiveUsageReportPeriod(), 1);

        //Verify each day and match with API call
        for (int i = 0; i < dayRanges.length; i++) {
            dashboardPage.getUsageReportPeriod().get(i).click();
            //wait while data loads to UI
            new WebDriverWait(driver, 20).until(ExpectedConditions
                    .not(ExpectedConditions.textToBePresentInElement(
                            dashboardPage.getUsageDashboardElements().get(i).get("metric"),
                            "--")));

            //Sometimes a huge number of alerts are being generated. In this case skipping next assertion
            int temp = dashboardPage.getUsageTotalAlerts();

            //get data from API
            Dashboard.DashboardUsage v = getDashboardUsageReport(driver, dayRanges[i], TIME_ZONE);

            //verify API and UI data
            if (v.success && temp == v.data.totalAlerts) {
                assertEquals(dashboardPage.getUsageTotalAlerts(), v.data.totalAlerts);
                assertEquals(dashboardPage.getUsageUserLocates(), v.data.locateTotal);
                assertEquals(dashboardPage.getUsageStopDrive(), v.data.reportTotal);
                assertEquals(dashboardPage.getUsageStarter(), v.data.starterTotal);
            } else {
                logger.warn("Skipped API and UI data verification because a huge number of alerts are being generated");
                logger.warn("Before API call was " + temp + ". API call returned " + v.data.totalAlerts);
            }
        }
    }

    @DataProvider(name = "TestData")
    public Iterator<LoginData> bhphGseInformationProvider() {
        List<DashboardTest.LoginData> testData = new ArrayList<>();
        String[] nodes = {"testBHPHRecentAlerts",
                // TODO: 10/30/18 uncomment once tickets resolve inside testBhphGseRecentAlerts
                //"testGSERecentAlerts"
        };

        //load data from json
        for (int i = 0; i < nodes.length; i++) {
            JsonNode dataNode = envNode.at("/" + nodes[i]);
            try {
                testData.add(mapper.treeToValue(dataNode, DashboardTest.LoginData.class));
            } catch (JsonProcessingException e) {
                fail("Failed to process test data from " + TEST_DATA_FILE, e);
            }
        }
        return testData.iterator();
    }

    @Test(description = "Recent Alerts Widget Functionality -- BHPH and GSE", groups = {"dashboard"}, dataProvider = "TestData")
    public void testBhphGseRecentAlerts(DashboardTest.LoginData data) throws InterruptedException, UnirestException, IOException {

        // TODO: 10/30/18 https://jira.spireon.com/browse/VFM-5260

        ReportsPage reportsPage;
        String tripFile = "src/test/resources/trips/dashboard_events.csv";
        boolean failed = false;
        StringBuilder errors = new StringBuilder();

        //create hashmap key - events label on widget, value - events in reports
        HashMap<String, String> events = new HashMap<>();
        events.put("Power Up With Gps", "Power Up w/ GPS");
        events.put("Low Battery Voltage", "Low Internal Battery");
        events.put("Vehicle Abandonment", "Vehicle Abandonment");
        events.put("Battery Disconnect", "Battery Disconnect");

        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;
        if (data.serialNumber.isEmpty())
            fail("Serial number didn't find in " + TEST_DATA_FILE);

        //Generate events
        PlatformApiUtils.generateEvents(data.serialNumber, tripFile, 1000);

        login();

        //Go to dashboard
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        DashboardPage dbPage = navbarHeaderPage.clickDashboard();

        //wait for Recent Alerts widget
        dbPage.waitForRecentAlertsWidget();

        //click on 'View Today's Alerts' and verify report is generated
        reportsPage = dbPage.clickViewTodayAlerts();
        assertEquals(reportsPage.getReportTabText(), "Alert History");

        //return to widgets
        reportsPage.closeReportTab();
        navbarHeaderPage.clickDashboard();
        dbPage.waitForRecentAlertsWidget();

        //click on each bars and verify report is generated with the same number of events
        for (int i = 0; i < dbPage.getRecentAlertBarsValues().size(); i++) {

            String barLabel = events.get(dbPage.getRecentAlertBarsLabels().get(i).getText());

            int barValue = Integer.parseInt(dbPage.getRecentAlertBarsValues().get(i).getText());

            WebElement bar = dbPage.getRecentAlertBarsValues().get(i);
            bar.click();

            //wait while report page open and report is generated
            waitUntilSpinnerVisibleThenInvisible(driver, 3, 30);
            //verify the report open
            assertEquals(reportsPage.getReportTabText(), "Alert History", "Event " + barLabel);
            //verify right filter applied

            // TODO: 9/19/18 uncomment next line once resolved https://jira.spireon.com/browse/VFM-5117
            //assertEquals(reportsPage.getTableFirstRow().get("Event"), barLabel,
            //        "Event " + barLabel + ". 'Expected' from widget chart, 'Actual' in report: ");

            // TODO: 9/19/18  delete condition once resolved https://jira.spireon.com/browse/VFM-5116
            if (!barLabel.equals("Power Up w/ GPS")) {
                //verify numbers of events
                try {
                    assertEquals(reportsPage.getTotalRecordCount(reportsPage.getPagingPositionDiv()), barValue,
                            "Event " + barLabel + ". 'Expected' from widget chart, 'Actual' in report: ");
                } catch (AssertionError e) {
                    failed = true;
                    errors.append(e.getMessage());
                    errors.append(". ");
                }
            }
            //return to widgets
            reportsPage.closeReportTab();
            navbarHeaderPage.clickDashboard();
            dbPage.waitForRecentAlertsWidget();
        }

        if (failed) {
            // TODO: 9/19/18 replace logger to fail once resolved https://jira.spireon.com/browse/VFM-5117
            logger.error(String.valueOf(errors));
        }

        navbarHeaderPage.logout();
    }

    @DataProvider(name = "TestDataDashboardCounts")
    public Iterator<LoginData> dataBhphGseDashboardCounts() {
        List<DashboardTest.LoginData> testData = new ArrayList<>();
        String[] nodes = {
                "testBHPHDashboardCounts",
                "testGSEDashboardCounts"};

        //load data from json
        for (int i = 0; i < nodes.length; i++) {
            JsonNode dataNode = envNode.at("/" + nodes[i]);
            try {
                testData.add(mapper.treeToValue(dataNode, DashboardTest.LoginData.class));
            } catch (JsonProcessingException e) {
                fail("Failed to process test data from " + TEST_DATA_FILE, e);
            }
        }
        return testData.iterator();
    }

    @Test(description = "Verify Devices, Renewals and Alerts widgets with API calls -- BHPH and GSE", groups = {"dashboard"},
            dataProvider = "TestDataDashboardCounts")
    public void testBhphGseDashboardCounts(DashboardTest.LoginData data) throws UnirestException {
        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        login();

        //Go to dashboard
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        DashboardPage dbPage = navbarHeaderPage.clickDashboard();

        //wait for Recent Alerts widget because it the slowest widget
        dbPage.waitForRecentAlertsWidget();

        //Get data from API
        Dashboard.DashboardRecentAlerts apiAlerts = getDashboardRecentAlerts(driver);

        if (apiAlerts == null) fail("Recent Alerts API call return success:false");

        //Verify Recent Alerts match with API
        // TODO: 12/17/18 https://jira.spireon.com/browse/VFM-5142
        //assertEquals(dbPage.getRecentAlertBarsValues().get(0).getText(), Integer.toString(apiAlerts.totalPowerUpWithGps));
        //assertEquals(dbPage.getRecentAlertBarsValues().get(1).getText(), Integer.toString(apiAlerts.totalLowBattery));
        //assertEquals(dbPage.getRecentAlertBarsValues().get(2).getText(), Integer.toString(apiAlerts.totalVehicleAbandonment));
        //assertEquals(dbPage.getRecentAlertBarsValues().get(3).getText(), Integer.toString(apiAlerts.totalBatteryDisconnect));

        //Get data from API
        Dashboard.DashboardDevices apiDevices = getDashboardDevices(driver);

        if (apiDevices == null) fail("Devices API call return success:false");

        //Verify Devices match with API
        int totalDevices = apiDevices.total;

        assertEquals(dbPage.getTotalDevices(), totalDevices);
        List<Integer> values = new ArrayList<>();

        //calculate percent for each state
        //for BHPH account there are 4 elements, for GSE - 3 or 1
        if (apiDevices.data.size() == 4) {
            //not installed
            values.add(Math.round((float) 100 * (apiDevices.data.get(0).totalCount + apiDevices.data.get(1).totalCount) / totalDevices));
            //installed
            values.add(Math.round((float) 100 * apiDevices.data.get(2).totalCount / totalDevices));
            //out for repossession
            values.add(Math.round((float) 100 * apiDevices.data.get(3).totalCount / totalDevices));
        }
        //For GSE account
        else if (apiDevices.data.size() == 3) {
            //active
            values.add((int) Math.round((float) 100 * (apiDevices.data.get(1).totalCount + apiDevices.data.get(2).totalCount) / totalDevices));
            //inventory
            values.add((int) Math.round((float) 100 * (apiDevices.data.get(0).totalCount) / totalDevices));
        }
        //For GSE account with all active Devices
        else if (apiDevices.data.size() == 1) {
            //active
            values.add(100);
            //inventory
            values.add(0);
        }
        //verify data from UI match with API
        dbPage.getDevicesPieValues().forEach(e -> assertTrue(values.contains(e)));

        //Get data from API
        Dashboard.DashboardRenewals apiRenewals = getDashboardRenewals(driver);

        if (apiRenewals == null) fail("DevicesRenewals API call return success:false");

        //Verify Renewals match with API
        assertEquals(dbPage.getActiveDevicesValue(), apiRenewals.data.get(0).value);
        assertEquals(dbPage.getEligibleForRenewalValue(), apiRenewals.data.get(1).value);
        assertEquals(dbPage.getExpiredDevicesValue(), apiRenewals.data.get(2).value);

        //Logout
        navbarHeaderPage.logout();
    }

    @Test(description = "Dashboard - devices - functionality -- GSE Lender", groups = {"dashboard"})
    public void testGSEDashboardDevicesFunctionality() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());
        DashboardTest.LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, DashboardTest.LoginData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }
        userName = data.userName;
        password = data.password;
        renewalsPage = data.renewalsPage;

        login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        NavbarHeaderPage navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        DashboardPage dbPage = navbarHeaderPage.clickDashboard();

        //Get total devices from widget
        int totalDevicesWidget = dbPage.getTotalDevices();

        //Get groups list from Dashboard
        List<String> dashboardGroupsList = dbPage.getGroupsDropdownList();

        //Get devices info from API
        Dashboard.DashboardDevices api = getDashboardDevices(driver);

        //Verify Active and match with Vehicles page
        //Click on legend
        VehiclesPage vehiclesPage = dbPage.clickDevicesLegend1();

        verifyActiveDevices();

        navbarHeaderPage.clickDashboard();
        dbPage.waitForRecentAlertsWidget();

        // TODO: 11/6/18 uncomment below once resolve https://jira.spireon.com/browse/VFM-5294
/*
        //click on slice
        dbPage.clickDevicesPieSlice1();

        verifyActiveDevices();

        navbarHeaderPage.clickDashboard();
        dbPage.waitForRecentAlertsWidget();

       //Verify Active and match with Vehicles page
        int active = api.data.size() > 2 ? api.data.get(2).totalCount : 0;
        int inventoryDevicesDashboard = api.data.get(0).totalCount + active;

        dbPage.clickDevicesLegend1();
        assertEquals(vehiclesPage.getTotalRecordCount(), inventoryDevicesDashboard);

        navbarHeaderPage.clickDashboard();
        dbPage.waitForRecentAlertsWidget();

        dbPage.clickDevicesPieSlice1();
        assertEquals(vehiclesPage.getTotalRecordCount(), inventoryDevicesDashboard);

        //Verify groups lists
        assertEquals(vehiclesPage.getGroupsDropdownList(), dashboardGroupsList);*/

    }

    public void verifyDashboardWidgets() {
        List<String> widgets = Arrays.asList(
                "Devices Widget",
                "Renewals Widget",
                "Usage",
                "Recent Alerts");

        login();
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);
        dashboardPage = navbarHeaderPage.clickDashboard();

        //Verify widgets are available
        widgets.forEach(w -> assertTrue(dashboardPage.findIffeatureIsAccessible(w),
                w + " is not available"));

        //Verify the Dashboard page
        assertTrue(dashboardPage.isGroupsDropdownDisplayed());
        assertTrue(dashboardPage.isRefreshBtnDisplayed());
    }

    public void verifyRenewalsWidget() {
        //Verify Renewals
        assertEquals(dashboardPage.getRenewDevicesText(), "Renew Devices");
        assertEquals(dashboardPage.getActiveDevicesText(), "Active Devices");
        assertEquals(dashboardPage.getEligibleForRenewalText(), "Eligible for Renewal");
        assertEquals(dashboardPage.getExpiredDevicesText(), "Expired Devices");
        assertTrue(dashboardPage.isActiveBarDisplayed());
        assertTrue(dashboardPage.isEligibleBarDisplayed());
        assertTrue(dashboardPage.isExpiredBarDisplayed());
    }

    public void verifyUsageWidget() {

        List<String> viewUsageReportsPeriod = Arrays.asList("1 day", "7 days", "30 days");

        //Verify Usage"
        assertEquals(dashboardPage.getViewUsageReportText(), "View Reports");
        dashboardPage.getUsageReportPeriod().forEach(p ->
                assertTrue(viewUsageReportsPeriod.contains(p.getText()),
                        p.getText() + " isn't expected value."));
        assertTrue(dashboardPage.getUsageDashboardElements().get(0).get("icon").getAttribute("class").contains("dash-icon-total-alerts"));
        assertFalse(dashboardPage.getUsageDashboardElements().get(0).get("metric").getText().isEmpty());
        assertTrue(dashboardPage.getUsageEvents().get(0).getText().contains("Total Alerts"));
        assertTrue(dashboardPage.getUsageDashboardElements().get(1).get("icon").getAttribute("class").contains("dash-icon-locate"));
        assertFalse(dashboardPage.getUsageDashboardElements().get(1).get("metric").getText().isEmpty());
        assertTrue(dashboardPage.getUsageEvents().get(1).getText().contains("User Locates"));
        assertTrue(dashboardPage.getUsageDashboardElements().get(2).get("icon").getAttribute("class").contains("dash-icon-stop-report"));
        assertFalse(dashboardPage.getUsageDashboardElements().get(2).get("metric").getText().isEmpty());
        assertTrue(dashboardPage.getUsageEvents().get(2).getText().contains("Stop/Drive Reports"));
        assertTrue(dashboardPage.getUsageDashboardElements().get(3).get("icon").getAttribute("class").contains("dash-icon-enable"));
        assertFalse(dashboardPage.getUsageDashboardElements().get(3).get("metric").getText().isEmpty());
        assertTrue(dashboardPage.getUsageEvents().get(3).getText().contains("Starter Enable/Disable"));
    }

    public void verifyRecentAlertsWidget() {

        List<String> recentAlertsBars = Arrays.asList(
                "Power Up With Gps",
                "Low Battery Voltage",
                "Vehicle Abandonment",
                "Battery Disconnect");

        //Verify Recent Alerts
        assertEquals(dashboardPage.getViewTodayAlertsText(), "View Today's Alerts");
        dashboardPage.getRecentAlertBarsLabels().forEach(l -> assertTrue(recentAlertsBars.contains(l.getText()),
                l.getText() + " isn't expected value."));
        dashboardPage.getRecentAlertBarsValues().forEach(b -> assertFalse(b.getText().isEmpty()));
    }

    public void verifyActiveDevices() {
        // TODO: 9/26/18 Uncomment next lines once fixed https://jira.spireon.com/browse/VFM-5142
        /*assertEquals(vehiclesPage.getTotalRecordCount(), api.data.get(1).totalCount);
        vehiclesPage.clearFilter();
        waitUntilSpinnerVisibleThenInvisible(driver,2 ,10);
        assertEquals(vehiclesPage.getTotalRecordCount(), totalDevicesWidget);
        */
    }
}
