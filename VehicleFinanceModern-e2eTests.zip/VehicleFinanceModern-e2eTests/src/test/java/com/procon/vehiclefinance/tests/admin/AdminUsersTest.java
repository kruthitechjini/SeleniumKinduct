package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.ExportFormat;
import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminUsersPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.AccountService.*;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvFirstRow;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvNumberOfRecords;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminUsersTest extends BaseTest {

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminUsersPage adminUsersPage;

    protected List<Long> userIdList;

    private static final Logger logger = LoggerFactory.getLogger(AdminUsersTest.class);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String searchByName;
        public String searchByUsername;
        public String searchByEmail;
        public String firstName;
        public String lastName;
        public String phoneNumber;
        public String searchSubString;
    }

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class GroupsData {
        public List<String> addToGroup;
        public List<String> removeFromGroup;
        public List<String> knownGroups;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdminUsers(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin > Users Page
        adminUsersPage = navbarHeaderPage.clickAdmin().clickUserLink();

        userIdList = new ArrayList<>();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Delete created users
        if (!userIdList.isEmpty()) {
            for (Long userId : userIdList) {
                assertEquals(deleteUser(driver, userId).msg, "Account user deleted");
            }
        }

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //Reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Add/Edit/Delete an Admin User", groups = {"admin"})
    public void testAddEditDeleteUser() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        GroupsData data = null;
        try {
            data = mapper.treeToValue(dataNode, GroupsData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Open user modal form
        adminUsersPage.clickAddUserBtn();

        //Validate modal window
        assertTrue(adminUsersPage.getModalWindow().isDisplayed());
        assertEquals(adminUsersPage.getModalWindowTitle().getText(), "Create User");

        adminUsersPage.clickSave();

        //Validate mandatory fields should show error messages if these fields are empty
        assertEquals(adminUsersPage.getFirstNameErrorMessage().getText(), "First Name is required");
        assertEquals(adminUsersPage.getLastNameErrorMessage().getText(), "Last Name is required");
        assertEquals(adminUsersPage.getUsernameErrorMessage().getText(), "Username is required");
        assertEquals(adminUsersPage.getUsertypeErrorMessage().getText(), "Please select a user type");
        assertEquals(adminUsersPage.getPasswordErrorMessage().getText(), "Password is required");
        assertEquals(adminUsersPage.getEmailErrorMessage().getText(), "Email is required");

        //Form data
        String username = "autotest-" + System.currentTimeMillis();

        Person person = new Person.PersonBuilder()
                .firstName("Automated")
                .lastName("Test")
                .username(username)
                .userType(adminUserTypeData)
                .email("automationtests05@gmail.com")
                .phone("5555555555")
                .build();

        HashMap<String, String> userData = new HashMap<>();
        userData.put("Name", person.getFirstName() + " " + person.getLastName());
        userData.put("Username", person.getUsername());
        userData.put("User Type", person.getUserType());
        userData.put("Email", person.getEmail());
        userData.put("Phone", person.getPhone());

        //Create new user
        adminUsersPage.addEditUser(person, "password", "password", false,
                data.addToGroup, data.removeFromGroup, "Automated Test " +
                        "User", null, false);

        userIdList.add(getUsers(driver, username).data.get(0).id);

        //Search for newly added user
        assertEquals(adminUsersPage.search(username), 1);

        HashMap<String, String> firstRowData = getTableFirstRow();

        //Validate data is saved
        assertEquals(userData, firstRowData);

        //Edit data for newly created user
        adminUsersPage.editRecord(1);
        Person updatedUser = new Person.PersonBuilder()
                .firstName("Auto")
                .lastName("Test")
                .phone("4444444444")
                .build();

        userData.put("Name", updatedUser.getFirstName() + " " + updatedUser.getLastName());
        userData.put("Phone", updatedUser.getPhone());

        adminUsersPage.addEditUser(updatedUser, null, null, null, null,
                null);

        firstRowData = getTableFirstRow();

        //Validate data is updated
        assertEquals(userData, firstRowData);
    }

    @Test(description = "Add/Edit/Delete an Global Access User", groups = {"admin"})
    public void testGlobalAccessUser() {

        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        JsonNode dataNode = envNode.at("/" + methodName);

        AdminUsersTest.GroupsData data = null;
        try {
            data = mapper.treeToValue(dataNode, AdminUsersTest.GroupsData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        // Open user modal form
        adminUsersPage.clickAddUserBtn();

        // form data
        String username = "autotest" + System.currentTimeMillis();

        Person person = new Person.PersonBuilder()
                .firstName("Automated")
                .lastName("Test")
                .username(username)
                .userType(adminUserTypeData)
                .email("automationtests05@gmail.com")
                .phone("5555555555")
                .build();

        // create new user
        adminUsersPage.addEditUser(person, "password", "password", false,
                data.knownGroups, null, "Automated Test User", null, true);

        // search for the newly added user and edit first name
        waitUntilSpinnerInvisible(driver, 30);
        adminUsersPage.editSearchedRecord(username);

        // Since this user has global access, all individual groups should be unchecked.
        waitUntilSpinnerInvisible(driver, 30);
        assertTrue(adminUsersPage.ensureGroupsUnchecked(data.knownGroups));
        assertTrue(adminUsersPage.ensureGroupsDisabled(data.knownGroups));

        adminUsersPage.clickCancel();

        // Start cleanup.

        // delete user
        waitUntilSpinnerInvisible(driver, 30);
        adminUsersPage.deleteSearchedRecord(username);

        // confirm that the user was deleted
        waitUntilSpinnerInvisible(driver, 30);
        assertEquals(adminUsersPage.search(username), 0);
    }

    @Test(description = "Admin Users - Search, sort and Paginate", groups = {"admin"})
    public void testAdminUsersSearchSortPaginate() throws UnirestException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Validate search by name
        adminUsersPage.search(data.searchByName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(adminUsersPage.getTotalRecordCount(), getUsers(driver, data.searchByName).total);

        //Validate search by username
        adminUsersPage.search(data.searchByUsername);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(adminUsersPage.getTotalRecordCount(), getUsers(driver, data.searchByUsername).total);

        //Validate search by email
        adminUsersPage.search(data.searchByEmail);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(adminUsersPage.getTotalRecordCount(), getUsers(driver, data.searchByEmail).total);

        //Clear search
        adminUsersPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Get user count from API call
        int totalApiUsers = getUsers(driver).total;

        String paginationInfo = adminUsersPage.getPagingPositionDiv().getText();

        //Validate Sort on each column
        for (String column : adminUsersPage.getGridColumns()) {
            if (!column.equals("Actions")) {
                assertTrue(adminUsersPage.isColumnSortable(column));
            }
        }

        //Validate pagination display info
        if (totalApiUsers > adminUsersPage.getPageSizeSelection()) {

            assertEquals(paginationInfo, "1 - " + adminUsersPage.getPageSizeSelection()
                    + " of " + totalApiUsers);
        } else {
            assertEquals(paginationInfo, "1 - " + totalApiUsers + " of " + totalApiUsers);
        }

        //Validate select page size values
        assertEquals(adminUsersPage.getSelectPageSizeValues(), CommonGrid.SelectPageSizesEnum.getValues());

        //Validate default selected option should be 50
        assertEquals(adminUsersPage.getPageSizeSelection(), 50);

        //When the user changes the value in the Show dropdown, the # of users displayed in the grid
        //should automatically update to that number
        adminUsersPage.selectPageSizeValue(CommonGrid.SelectPageSizesEnum.TWENTY_FIVE.getName());

        if (adminUsersPage.getTotalRecordCount() >= 25) {
            assertEquals(adminUsersPage.getPageUpperBound(), 25);
        } else {
            assertEquals(adminUsersPage.getPageUpperBound(), adminUsersPage.getTotalRecordCount());
        }

        //Validate grid navigation control buttons
        adminUsersPage.verifyNavigationBtns();

        //Validate tooltip of navigation controls
        adminUsersPage.verifyNavigationBtnsTooptip();
    }

    @Test(description = "Add/Edit/Delete an Global Access User", groups = {"admin"})
    public void testEditMasterUserInfo() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Navigate to User Settings page by clicking on 'Account' drop down
        navbarHeaderPage.clickSettingsDropdownMenuItem();

        String firstName = navbarHeaderPage.getFirstNameInput().getAttribute("value");
        String lastName = navbarHeaderPage.getLastNameInput().getAttribute("value");
        String phoneNumber = navbarHeaderPage.getPhoneNumberInput().getAttribute("value");

        //Edit Fields(First Name, Last Name, Phone Number) and Save
        navbarHeaderPage.enterUserInfo(data.firstName, data.lastName, data.phoneNumber);

        HashMap<String, String> updatedData = new HashMap<>();
        updatedData.put("Name", data.firstName + " " + data.lastName);
        updatedData.put("Phone", data.phoneNumber);

        //Search by newly updated first name
        adminUsersPage.search(data.firstName);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        HashMap<String, String> firstRowData = getTableFirstRow();
        firstRowData.remove("Username");
        firstRowData.remove("User Type");
        firstRowData.remove("Email");

        //Validate data is updated
        assertEquals(firstRowData, updatedData);

        //Reset original data
        navbarHeaderPage.clickSettingsDropdownMenuItem();
        navbarHeaderPage.enterUserInfo(firstName, lastName, phoneNumber);
    }

    @Test(description = "User Export Button Functionality", groups = {"admin"})
    public void testUserExportBtn() throws IOException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Verify Export functionality is available
        assertTrue(adminUsersPage.getExportBtn().isEnabled(),
                "Export button is not enabled or visible for account " + userName);
        adminUsersPage.getExportBtn().click();
        assertTrue(adminUsersPage.getExportCSVLink().isEnabled());
        assertTrue(adminUsersPage.getExportPDFLink().isEnabled());
        assertTrue(adminUsersPage.getExportXLSLink().isEnabled());

        //Verify export for full list of records
        verifyExportedFile("");

        //Verify export fot searchSubString
        adminUsersPage.search(data.searchSubString);
        //TODO: 8/30/18 API call defect https://jira.spireon.com/browse/VFM-5055
        //verifyExportedFile(data.searchSubString);

    }

    @Test(description = "NavBar -> UserName - Verify Default 'map all' preference in User Settings",
            groups = {"admin"})
    public void testNavBarUserSettingMapAll() {

        //Check a 'Map All Devices On Login' state
        openUserSettings();
        String mapAllDeviceOnLogin = navbarHeaderPage.getMapAllDevicesOnLoginState();
        navbarHeaderPage.clickModalCancelBtn();

        //Get Vehicle - Map All Vehicles state
        VehiclesPage vehiclesPage = navbarHeaderPage.clickVehicles();

        //Verify MapAllDevices is in the same state
        if (mapAllDeviceOnLogin.equals("On")) {
            assertTrue(vehiclesPage.isMapAllActive(), "Map All is inactive");
            assertTrue(vehiclesPage.mapMarkersShow(), "There are no elements on the map");
        } else {
            assertFalse(vehiclesPage.isMapAllActive(), "Map All is active");
            assertFalse(vehiclesPage.mapMarkersShow(), "There are elements on the map");
        }

        //Toggle the status 'Map All Devices On Login'
        openUserSettings();
        mapAllDeviceOnLogin = mapAllDeviceOnLogin.equals("On") ? "Off" : "On";
        navbarHeaderPage.setMapAllDevicesOnLoginState(mapAllDeviceOnLogin);
        navbarHeaderPage.clickModalSaveBtn();

        //Go to different tab and then go to Vehicles
        navbarHeaderPage.clickAlerts();
        navbarHeaderPage.clickVehicles();

        //Verify MapAllDevices state isn't toggled
        if (mapAllDeviceOnLogin.equals("On")) {
            assertFalse(vehiclesPage.isMapAllActive(), "Map All is active");
            assertFalse(vehiclesPage.mapMarkersShow(), "There are elements on the map");
        } else {
            assertTrue(vehiclesPage.isMapAllActive(), "Map All is active");
            assertTrue(vehiclesPage.mapMarkersShow(), "There are no elements on the map");
        }

        //Re-login and verify the MapAllDevices was changed
        navbarHeaderPage.logout();
        login();

        if (mapAllDeviceOnLogin.equals("On")) {
            assertTrue(vehiclesPage.isMapAllActive(), "Map All is active");
            assertTrue(vehiclesPage.mapMarkersShow(), "There are no elements on the map");
        } else {
            assertFalse(vehiclesPage.isMapAllActive(), "Map All is active");
            assertFalse(vehiclesPage.mapMarkersShow(), "There are elements on the map");
        }

    }

    private void verifyExportedFile(String searchKey) throws IOException {

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));

        //Validate export users in CSV
        SimpleDateFormat currentDate = new SimpleDateFormat("yyyyMMddHHmm");
        String fileName = "UsersList_" + currentDate.format(new Date());
        File file = new File(String.format("./download/%s.%s", fileName, ExportFormat.CSV.getType()));

        try {
            InputStream is;
            if (searchKey.equals("")) {
                is = exportUsers(driver, fileName, ExportFormat.CSV.getType());
            } else {
                // TODO: 8/30/18 API call defect https://jira.spireon.com/browse/VFM-5055
                is = null; //exportUsers(driver, searchKey, fileName, ExportFormat.CSV.getType());
            }
            FileUtils.copyInputStreamToFile(is, file);
        } catch (UnirestException | IOException e) {
            e.printStackTrace();
            fail(e.getMessage());
        }

        //Validate file is downloaded
        assertTrue(file.exists());

        //Get first row data
        HashMap<String, String> usersTable = adminUsersPage.getTableFirstRow();

        //Prepare data in table
        usersTable.remove("Actions");
        usersTable.put("Phone", usersTable.get("Phone").replace(" ", ""));

        //Get CSV first record
        HashMap<String, String> usersCSV = getCsvFirstRow(file);

        //Prepare data in csv
        usersCSV.put("User Type", usersCSV.get("UserType").replace("Dealer", "")
                .replace(",", ""));
        usersCSV.remove("UserType");

        //Validate first row of csv file with first row of grid
        assertEquals(usersTable, usersCSV);

        //Validate total number of records in UI and csv file
        assertEquals(adminUsersPage.getTotalRecordCount(), getCsvNumberOfRecords(file, true));

        //Delete download folder
        FileUtils.deleteQuietly(new File("./download/"));
    }

    private void openUserSettings() {
        navbarHeaderPage.clickSettingsDropdownMenuItem();
        navbarHeaderPage.waitForUserSettingsWindow();
    }

    public HashMap<String, String> getTableFirstRow() {

        HashMap<String, String> firstRowData = adminUsersPage.getTableFirstRow();
        firstRowData.remove("Status");
        firstRowData.remove("Last Login");
        firstRowData.remove("Actions");
        firstRowData.put("Phone", firstRowData.get("Phone").replaceAll("[\\s\\-()]", ""));

        return firstRowData;
    }
}