package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions
        .elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

public class VehicleReferencesPage extends CommonGrid {

    protected static final Logger logger = LoggerFactory
            .getLogger(VehicleReferencesPage.class);

    @FindBy(css = "td:nth-child(2) > a")
    private WebElement addReferenceLink;

    @FindBy(css = "div.modal-content")
    private WebElement modelWindow;

    @FindBy(css = "input[name='name']")
    private WebElement nameInput;

    @FindBy(css = "input[name='address']")
    private WebElement addressInput;

    @FindBy(css = "input[name='city']")
    private WebElement cityInput;

    @FindBy(css = "select[name='country']")
    private WebElement countryDropdown;

    @FindBy(css = "select[name='state']")
    private WebElement stateDropdown;

    @FindBy(css = "input[name='zip']")
    private WebElement postalCodeInput;

    @FindBy(css = "input[name='visitThreshold']")
    private WebElement minimumVisitsInput;

    private static final String SAVE_BTN_CSS = "[name='modalSave']";
    @FindBy(css = SAVE_BTN_CSS)
    private WebElement saveBtn;

    @FindBy(css = "table.stip-table")
    private WebElement referencesTable;

    @FindBy(css = "button[title='Email References']")
    private WebElement emailBtn;

    @FindBy(css = "div.modal-body.clearfix select ")
    private WebElement exportTypeSelect;

    @FindBy(css = "div.modal-body.clearfix input")
    private WebElement emailInput;

    private final String emailSendBtn_css = "div.modal button.btn.btn-primary";
    @FindBy(css = emailSendBtn_css)
    private WebElement emailSendBtn;

    @FindBy(css = "div.vehicles-tab-buttons-container a.btn.btn-xs.btn-primary")
    private WebElement setStipReportLink;

    @FindBy(css = "div.trends-filter select")
    private WebElement setStipReportDropdown;

    @FindBy(css = "div.clearfix.text-right > button")
    private WebElement setStipReportBtn;

    @FindBy(css = "div.command-status div.container")
    private WebElement stipReportMap;

    public VehicleReferencesPage(WebDriver driver) {
        super(driver);
    }

    public WebElement getAddReferenceLink() {
        return addReferenceLink;
    }

    public WebElement getStipReportMap() {
        return stipReportMap;
    }

    public WebElement getModelWindow() {
        new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(modelWindow));
        return modelWindow;
    }

    public enum StipReportEnum {
        OFF("Off"),
        TWO_HOURS("2 Hours"),
        FOUR_HOURS("4 Hours"),
        SIX_HOURS("6 Hours"),
        EIGHT_HOURS("8 Hours");

        private String name;

        StipReportEnum(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    /**
     * Enter customer information
     *
     * @param name
     * @param address
     * @param minimumVisits
     */
    public void addReferenceDetails(String name, Address address, String
            minimumVisits) {

        //Enter details
        enterCustomerName(name);
        enterOperatorAddress(address);
        enterMinimumVisits(minimumVisits);

        clickSave();
    }

    /**
     * Enter customer name
     *
     * @param name
     */
    public void enterCustomerName(String name) {
        enterTextAndConfirmEntry(driver, nameInput, name);
    }

    /**
     * Enter customer address
     *
     * @param address
     */
    public void enterOperatorAddress(Address address) {
        if (address != null) {

            enterTextAndConfirmEntry(driver, addressInput, address.getStreet());

            enterTextAndConfirmEntry(driver, cityInput, address.getCity());

            new Select(countryDropdown).selectByVisibleText(address.getCountry());

            new Select(stateDropdown).selectByVisibleText(address.getState());

            enterTextAndConfirmEntry(driver, postalCodeInput, address.getPostalCode());
        }
    }

    /**
     * Enter minimum visits
     *
     * @param minimumVisits
     */
    public void enterMinimumVisits(String minimumVisits) {
        enterTextAndConfirmEntry(driver, minimumVisitsInput, minimumVisits);
    }

    /**
     * Click on save button
     */
    public void clickSave() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector
                (SAVE_BTN_CSS));
    }

    /**
     * Get data of the given row number
     *
     * @param rowNumber
     * @return
     */
    public HashMap<String, String> getTableRow(int rowNumber) {

        waitUntilSpinnerInvisible(driver, 30);
        new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(referencesTable));

        List<WebElement> headers = referencesTable.findElements(By
                .cssSelector("th"));

        //Retry policy to make sure header columns size and first row columns size is same in the grid
        RetryPolicy retryPolicy = new RetryPolicy()
                .retryIf((List<WebElement> r) -> r.size() != headers.size())
                .withDelay(2, TimeUnit.SECONDS)
                .withMaxRetries(5);

        //Run with retries
        List<WebElement> cells = Failsafe.with(retryPolicy)
                .onRetry((c, f, ctx) -> {
                    logger.warn("Headers size and first row cells size should be same.");
                })
                .onFailure(f -> {
                    throw new AssertionError("Failing because header columns size and first row cells size is not same...");
                })
                .get(() -> referencesTable.findElements(By.cssSelector
                        ("tr:nth-of-type(" + rowNumber + ") td")));

        HashMap<String, String> row = new HashMap<>();
        for (int i = 0; i < headers.size(); i++) {
            row.put(headers.get(i).getAttribute("innerText").trim(), cells.get(i)
                    .getAttribute("innerText").trim());
        }
        row.put("Address", row.get("Address").replaceAll(",", ""));
        row.remove("");
        row.remove("Action");
        return row;
    }

    /**
     * Send mail
     *
     * @param reportFormat
     * @param emailId
     */
    public void sendEmail(String reportFormat, String emailId) {
        clickEmailBtn();
        new WebDriverWait(driver, 30).until(visibilityOf(exportTypeSelect));
        new Select(exportTypeSelect).selectByVisibleText(reportFormat);
        enterText(driver, emailInput, emailId);
        clickElementAndWaitForInvisibility(driver, emailSendBtn, By.cssSelector(emailSendBtn_css), 10);
    }

    /**
     * Click on email button
     */
    public void clickEmailBtn() {
        new WebDriverWait(driver, 30).until(elementToBeClickable
                (emailBtn)).click();
    }

    /**
     * Click on set stip report link
     */
    public void clickSetStipReportLink() {
        new WebDriverWait(driver, 10).until(elementToBeClickable
                (setStipReportLink)).click();
    }

    /**
     * Set stip report
     */
    public void setStipReport() {
        new WebDriverWait(driver, 30).until(visibilityOf(setStipReportDropdown));
        new Select(setStipReportDropdown).selectByVisibleText
                (StipReportEnum.TWO_HOURS.getName());
        setStipReportBtn.click();
    }
}
