package com.procon.vehiclefinance.services;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.openqa.selenium.WebDriver;

public class O2cService extends ServiceCaller {
    private static String o2cBaseUrl;
    private static String renewalCheckEndpoint;

    static {
        o2cBaseUrl = System.getProperty("o2cUrl");
        renewalCheckEndpoint = o2cBaseUrl + "/in-app/v1/renewals";
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class RenewalData {
        public boolean success;
        public int total;
    }

    /**
     * Return boolean flag if a logged-in user is expecting to see renewals page or not
     *
     * @param driver
     * @param accountId
     * @return
     * @throws UnirestException
     */
    public static boolean expectRenewalPage(WebDriver driver, int accountId) throws UnirestException {
        HttpResponse<RenewalData> response = Unirest.get
                (renewalCheckEndpoint + "/{accountId}/devices")
                .routeParam("accountId", String.valueOf(accountId))
                .asObject(RenewalData.class);
        return response.getBody().success && (response.getBody().total > 0);
    }
}
