package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Dealer;
import com.procon.vehiclefinance.pageobjects.LoginPage;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminDealerManagementPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminOrderDevicesPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminRequestInstallationPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.services.DealerService;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.Email;
import com.spireon.automotive.cdm.v1.dto.CollectionResource;
import com.spireon.automotive.cdm.v1.dto.LenderDealerPartnershipDto;
import com.spireon.automotive.client.settings.ClientSettings;
import net.jodah.failsafe.RetryPolicy;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.search.AndTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.Email.markEmailsAsRead;
import static com.procon.vehiclefinance.util.WebElements.enterText;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static com.spireon.platform.utils.PlatformIdentityUtils.getJwtToken;
import static org.testng.Assert.*;

public class AdminDealerManagementTest extends BaseTest {
    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminDealerManagementPage adminDealerManagementPage;

    public String dealerID;

    protected static final Logger logger = Logger
            .getLogger(AdminDealerManagementTest.class.getName());

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String dealerID;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String searchText;
        public String apiUserName;
        public String apiPassword;
        public String appToken;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        loginWithLenderCredentials(dataNode);

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver,
                NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Dealer Management Link
        adminDealerManagementPage = adminLeftBarPage.clickDealerManagementLink();
    }

    private void loginWithLenderCredentials(JsonNode dataNode) {

        LoginData data;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;
            dealerID = data.dealerID;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Login
        mapPage = login();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName,password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(testName = "Dealer Management", groups = {"gse"})
    public void testDealerManagement() throws MessagingException {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        //Mark all "unread" mails with subject 'Welcome to Spireon Vehicle Finance - Goldstar Enterprise' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Welcome to Spireon Vehicle Finance - Goldstar Enterprise"));

        markEmailsAsRead(searchTerm, "INBOX");

        //Validate URL
        assertTrue(driver.getCurrentUrl().contains("admin/dealer-management"));

        //Validate header
        assertEquals(adminDealerManagementPage.getDealerTableHeader().getText(), "Dealer Management");

        adminDealerManagementPage.search("Lender");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertTrue(adminDealerManagementPage.getSectionText().getText().contains("Lender Dealer 1"));

        //Click add button
        adminDealerManagementPage.clickAddDealerButton();

        //Validate modal window
        assertTrue(adminDealerManagementPage.getModalWindow().isDisplayed());
        assertEquals(adminDealerManagementPage.getModalWindowTitle().getText(), "Create Dealer");

        //Validate mandatory fields should show error messages if these fields are empty
        adminDealerManagementPage.fillInvalidFormAndCancel();
        adminDealerManagementPage.clickAddDealerButton();

        //Populate address
        Address address = new Address.AddressBuilder()
                .street("123 Main")
                .city("Irvine")
                .state("CA - California")
                .postalCode("92606")
                .country("USA")
                .build();

        //Populate dealer details
        Dealer dealer = new Dealer.DealerBuilder()
                .dealerId(getRandomDealerId())
                .dealerName("New Dealer " + getRandomDealerId())
                .firstName("Automated")
                .lastName("Test")
                .email("automationtests05@gmail.com")
                .password("password")
                .confirmPassword("password")
                .address(address)
                .phone("1111111111")
                .phoneSecondary("3333333333")
                .fax("12222222222")
                .build();

        String dealerId = "LTS" + dealer.getDealerId();

        HashMap<String, String> userData = new HashMap<>();
        userData.put("Dealer ID", dealerId);
        userData.put("Dealer Name", dealer.getDealerName());
        userData.put("Dealer Contact", dealer.getFirstName() + " " + dealer.getLastName());
        userData.put("Dealer Phone", dealer.getPhone());
        userData.put("Dealer Email", dealer.getEmail());

        //Submit dealer form
        adminDealerManagementPage.fillAndSubmitFormWithDealerData(dealer);

        //Search for newly added dealer
        assertEquals(adminDealerManagementPage.search(dealerId), 1);

        HashMap<String, String> firstRowData = adminDealerManagementPage.getTableFirstRow();
        firstRowData.remove("Status");
        firstRowData.remove("Actions");

        //Validate data is saved
        assertEquals(userData, firstRowData);

        searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag
                .SEEN), false), new SubjectTerm("Welcome to Spireon Vehicle Finance - Goldstar Enterprise"));

        Email email = new Email();

        RetryPolicy retryPolicy = new RetryPolicy()
                .withDelay(10, TimeUnit.SECONDS)
                .withMaxRetries(3)
                .retryIf((Message[] messageList) -> messageList.length == 0);

        //Validate email received
        assertTrue(email.getMessages("INBOX", searchTerm,
                retryPolicy).size() > 0, "No mails found");

        //Edit data for newly created dealer
        adminDealerManagementPage.editRecord(1);

        //Validate edit modal title
        assertTrue(adminDealerManagementPage.getModalWindow().isDisplayed());
        assertEquals(adminDealerManagementPage.getModalWindowTitle().getText(), "Edit Dealer");

        Address updatedAddress = new Address.AddressBuilder()
                .street("456 Main")
                .build();

        Dealer updatedDealer = new Dealer.DealerBuilder()
                .address(updatedAddress)
                .firstName("NewAutomated")
                .lastName("NewTest")
                .enableRequestInstallation(true)
                .enableDeviceOrdering(true)
                .build();

        adminDealerManagementPage.fillAndSubmitFormWithDealerData(updatedDealer);

        userData.put("Dealer Contact", updatedDealer.getFirstName() + " " + updatedDealer.getLastName());

        firstRowData = adminDealerManagementPage.getTableFirstRow();

        //Validate dealer is Active
        assertEquals(firstRowData.get("Status"), "Active");

        firstRowData.remove("Status");
        firstRowData.remove("Actions");

        //Validate data is updated
        assertEquals(userData, firstRowData);

        String dealerLoginUserName = dealerId + "_master";

        //Logout lender and login with newly created dealer
        logoutLenderLoginDealer(dealerLoginUserName, dealer.getPassword());

        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(adminDealerManagementPage.getActiveDevicesLink()));

        //Validate Request Installation and Order Devices links are enabled
        assertTrue(adminDealerManagementPage.getRequestInstallationLink().isEnabled());
        assertTrue(adminDealerManagementPage.getOrderDevicesLink().isEnabled());

        //Logout Dealer and login with default lender
        logoutDealerLoginLender(dataNode);

        adminDealerManagementPage.search(dealerId);

        adminDealerManagementPage.editRecord(1);

        assertTrue(adminDealerManagementPage.getModalWindow().isDisplayed());

        //Validate updated address
        assertEquals(adminDealerManagementPage.getAddress().getAttribute("value"), updatedAddress.getStreet());

        //Disable Request Installation and Device Ordering
        updatedDealer = new Dealer.DealerBuilder()
                .enableRequestInstallation(false)
                .enableDeviceOrdering(false)
                .build();

        adminDealerManagementPage.fillAndSubmitFormWithDealerData(updatedDealer);

        //Logout lender and login with created dealer
        logoutLenderLoginDealer(dealerLoginUserName, dealer.getPassword());

        new WebDriverWait(driver, 10).until(ExpectedConditions
                .elementToBeClickable(adminDealerManagementPage.getActiveDevicesLink()));

        //Validate Request Installation, Order Devices tabs are not available
        boolean requestInstallationLinkDisplayed = true;
        try {
            if (adminDealerManagementPage.getRequestInstallationLink().isDisplayed()) {
                requestInstallationLinkDisplayed = true;
            }
        } catch (NoSuchElementException e) {
            requestInstallationLinkDisplayed = false;
        }

        assertFalse(requestInstallationLinkDisplayed);

        boolean orderDevicesLinkDisplayed = true;
        try {
            if (adminDealerManagementPage.getOrderDevicesLink().isDisplayed()) {
                orderDevicesLinkDisplayed = true;
            }
        } catch (NoSuchElementException e) {
            orderDevicesLinkDisplayed = false;
        }

        assertFalse(orderDevicesLinkDisplayed);

        //Logout Dealer and login with default lender
        logoutDealerLoginLender(dataNode);

        adminDealerManagementPage.search(dealerId);

        //Resend welcome email
        adminDealerManagementPage.resendRecord(1);

        adminDealerManagementPage.clickConfirmationOkBtn();

        //Validate email received
        assertTrue(email.getMessages("INBOX", searchTerm,
                retryPolicy).size() > 0, "No mails found");

        adminDealerManagementPage.editRecord(1);

        //Make Dealer In-Active and Save
        adminDealerManagementPage.makeDealerInactive();
        adminDealerManagementPage.submitForm();

        //Validate record shows up when filter by Inactive dealer status
        adminDealerManagementPage.selectDealerStatus("Inactive");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
        assertEquals(adminDealerManagementPage.getNumberOfRowsDisplayedInGrid(), 1);

        //Logout lender and login with created dealer
        logoutLenderLoginDealer(dealerLoginUserName, dealer.getPassword());

        //Validation of an inactive dealer should not be able to login.
        assertEquals(PageFactory.initElements(driver, LoginPage.class).getAlertText(), "Invalid login");

        navbarHeaderPage = null;

    }

    /**
     * Logout from Lender and Login with given dealer credentials
     *
     * @param dealerId
     */
    public void logoutLenderLoginDealer(String dealerId, String dealerPassword) {

        //Logout
        navbarHeaderPage.logout();

        //Login with the new user created
        userName = dealerId;
        password = dealerPassword;
        renewalsPage = "N";
        login();
    }

    /**
     * Logout from Dealer and Login with lender credentials
     *
     * @param dataNode
     */
    public void logoutDealerLoginLender(JsonNode dataNode) {

        //Logout
        navbarHeaderPage.logout();

        loginWithLenderCredentials(dataNode);

        //Navigate to Dealer Management Link
        navbarHeaderPage.clickAdmin().clickDealerManagementLink();
    }

    @Test(testName = "Verify Dealer Management grid Page elements, search and sort", groups = {"gse"})
    public void testDealerManagementUIElements() {

        ClientSettings clientSettings = new ClientSettings();

        clientSettings.setBaseUrl(String.format("%s/lenders/dealers", System.getProperty("automotiveSvcUrl")));

        DealerService client = new DealerService(clientSettings);

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Get the api user's token
        String apiToken = getJwtToken(data.apiUserName, data.apiPassword, data.appToken);

        final List<String> GRID_COLUMNS = Arrays.asList("Dealer ID", "Dealer Name",
                "Dealer Contact", "Dealer Phone", "Dealer Email", "Status", "Actions");

        final List<String> DEALER_STATUS_VALUES = Arrays.asList("All", "Active", "Inactive");

        //Validate grid and add button
        assertTrue(adminDealerManagementPage.gridBody().isDisplayed());
        assertTrue(adminDealerManagementPage.getAddDealerButton().isDisplayed());

        //Validate search
        assertTrue(adminDealerManagementPage.getSearchInput().isDisplayed());

        //Validate dealer status
        assertEquals(adminDealerManagementPage.getDealerStatusLabel().getText()
                        .replace(adminDealerManagementPage.getDealerStatusDropDown().getText(), "").trim(),
                "Dealer Status:");
        assertTrue(adminDealerManagementPage.getDealerStatusDropDown().isDisplayed());
        assertEquals(adminDealerManagementPage.getDealerStatusValues(), DEALER_STATUS_VALUES);

        //TODO Note: Once VFM-4768 this ticket is closed, default selection will be "Active" when the page loads
        assertEquals(new Select(adminDealerManagementPage.getDealerStatusDropDown())
                .getFirstSelectedOption().getText(), "All");

        //Validate Grid Columns.
        assertEquals(adminDealerManagementPage.getGridColumns(), GRID_COLUMNS,
                "Columns list is not matching");

        //Validate Grid Navigation control elements present
        adminDealerManagementPage.verifyNavigationElementsPresent();

        adminDealerManagementPage.search(data.searchText);
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate total record count in UI with API
        assertEquals(adminDealerManagementPage.getTotalRecordCount(), client.getDealer(apiToken, data.searchText).getTotal());

        //Clear search
        adminDealerManagementPage.getSearchInputCancel().click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate Sort on each column in list view
        for (String column : adminDealerManagementPage.getGridColumns()) {
            if (!(column.equals("Status") || column.equals("Actions"))) {
                assertTrue(adminDealerManagementPage.isColumnSortable(column));
            }
        }

        CollectionResource<LenderDealerPartnershipDto> dealerData = client.getDealer(apiToken);

        //Validate total record count in UI with API
        assertEquals(adminDealerManagementPage.getTotalRecordCount(), dealerData.getTotal());

        if (dealerData.getTotal() > 0) {

            //Validate first record in grid with data obtained using api call
            assertEquals(adminDealerManagementPage.getTableFirstRow(),
                    adminDealerManagementPage.getApiFirstRecord(dealerData.getContent()));
        }

        //Validate dealer status filter functions
        adminDealerManagementPage.selectDealerStatus("Active");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        int activeRecordCount = adminDealerManagementPage.getTotalRecordCount();
        CollectionResource<LenderDealerPartnershipDto> activeDealerData = client.getDealer(apiToken, true);

        //Validate total record count in UI with API
        assertEquals(activeRecordCount, activeDealerData.getTotal());

        HashMap<String, String> gridFirstRecord = adminDealerManagementPage.getTableFirstRow();

        //Validate first record in grid with data obtained using api call
        assertEquals(gridFirstRecord, adminDealerManagementPage.getApiFirstRecord(activeDealerData.getContent()));

        //Validate status of first record in grid is Active
        assertEquals(gridFirstRecord.get("Status"), "Active");

        adminDealerManagementPage.selectDealerStatus("Inactive");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        int inactiveRecordCount = adminDealerManagementPage.getTotalRecordCount();
        CollectionResource<LenderDealerPartnershipDto> inactiveDealerData = client.getDealer(apiToken, false);

        //Validate total record count in UI with API
        assertEquals(inactiveRecordCount, inactiveDealerData.getTotal());

        gridFirstRecord = adminDealerManagementPage.getTableFirstRow();

        //Validate first record in grid with data obtained using api call
        assertEquals(gridFirstRecord, adminDealerManagementPage.getApiFirstRecord(inactiveDealerData.getContent()));

        //Validate status of first record in grid is Inactive
        assertEquals(gridFirstRecord.get("Status"), "Inactive");

        adminDealerManagementPage.selectDealerStatus("All");
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

        //Validate Dealer status counts, All = Active+Inactive
        assertEquals(adminDealerManagementPage.getTotalRecordCount(), activeRecordCount + inactiveRecordCount);

        //Validate Grid Navigation control elements
        adminDealerManagementPage.verifyNavigationBtns();
    }

    @Test(description = "GSE - Admin, Dealer Management - Dealer Name shows in other forms.", groups = {"gse"})
    public void testEditedDealerNameRefreshed() {
        // TODO: 9/6/18 whitespace search bug https://jira.spireon.com/browse/VFM-5068
        //Looks like the search doesn't work with whitespace.
        //when issue will be fixed add the whitespace in Dealer name
        adminDealerManagementPage.search(dealerID);
        adminDealerManagementPage.editRecord(1);
        assertTrue(adminDealerManagementPage.getModalWindow().isDisplayed());
        assertTrue(Boolean.parseBoolean(adminDealerManagementPage.getDealerId().getAttribute("readonly")),
                "Edit Dealer popup window is shown with EDITABLE (not read-only) Dealer ID field");


        String dealerNameOld = adminDealerManagementPage.getDealerNameFromModal();
        String dealerNameNew = getRandomDealerId();

        enterText(driver, adminDealerManagementPage.setDealerName(), dealerNameNew);
        adminDealerManagementPage.submitForm();

        //Verify dealer was edited
        assertEquals(adminDealerManagementPage.search(dealerNameNew), 1);
        assertEquals(adminDealerManagementPage.search(dealerNameOld), 0);
        logger.info("Dealer name has been edited");

        //Verify that edited Dealer Name is shown in the drop down in the Request Installation
        AdminRequestInstallationPage adminRequestInstallPage = adminLeftBarPage.clickRequestInstallationLink();
        assertTrue(adminRequestInstallPage.selectDealerName(dealerNameNew));
        assertFalse(adminRequestInstallPage.selectDealerName(dealerNameOld));
        logger.info("Edited Dealer name shown in the Request Installation");

        //Verify that edited Dealer Name is shown in the drop down in the Order Devices
        // TODO: 10/19/18 https://jira.spireon.com/browse/VFMBL-146 Order Devices throw an error while open and redirect to Users page
        AdminOrderDevicesPage adminOrderDevice = adminLeftBarPage.clickOrderDevicesLink();
        assertTrue(adminOrderDevice.selectDealerName(dealerNameNew));
        assertFalse(adminOrderDevice.selectDealerName(dealerNameOld));
        logger.info("Edited Dealer name shown in Order Devices");

        //Verify that edited Dealer Name is shown in the drop down in the Vehicles page
        VehiclesPage vehiclesPage = navbarHeaderPage.clickVehicles();
        vehiclesPage.selectDealers(dealerNameNew);
        try {
            vehiclesPage.selectDealers(dealerNameOld);
            fail(String.format( "Dealer %s wasn't changed in the Vehicles page", dealerNameOld));
        }
        catch (NoSuchElementException e) {
            logger.info("Edited Dealer name shown in the Vehicles page");
        }
    }

    private String getRandomDealerId() {
        return Long.toString(System.currentTimeMillis()).substring(3, 13);
    }
}
