package com.procon.vehiclefinance.tests.sales;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.models.PlatformObject;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.pageobjects.sales.SalesPage;
import com.procon.vehiclefinance.tests.BaseTest;
import com.procon.vehiclefinance.util.Email;
import com.spireon.automotive.cdm.v1.dto.CollectionResource;
import com.spireon.automotive.cdm.v1.dto.SaleDto;
import com.spireon.automotive.cdm.v1.dto.SaleStatus;
import com.spireon.automotive.client.SaleServiceClient;
import com.spireon.automotive.client.SearchSalesCriteriaBuilder;
import com.spireon.automotive.client.settings.ClientSettings;
import com.spireon.platform.cdm.v1.dto.InvitationDto;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.jodah.failsafe.function.CheckedConsumer;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestNGException;
import org.testng.annotations.*;

import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.search.*;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.MobileSignUpService.activateAccount;
import static com.procon.vehiclefinance.services.MobileSignUpService.setUsernamePassword;
import static com.procon.vehiclefinance.util.DateTimeUtils.getCurrentBrowserDate;
import static com.procon.vehiclefinance.util.Email.markEmailsAsRead;
import static com.procon.vehiclefinance.util.PlatformApiUtils.createDeviceAndAsset;
import static com.procon.vehiclefinance.util.PlatformApiUtils.deleteDevice;
import static com.procon.vehiclefinance.util.PlatformApiUtils.deleteVehicle;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static com.spireon.platform.utils.PlatformIdentityUtils.getJwtToken;
import static org.testng.Assert.*;

public class SalesBase extends BaseTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(SalesBase.class);

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected SalesPage salesPage;

    private String serialNumber;
    private String vehicleName;
    private String vinNumber;
    private String deviceId;
    private String assetId;

    //generate unique email
    String emailId = "automationtests05+" + new Date().getTime() + "@gmail.com";

    private String dealerToken;

    private SaleServiceClient client;

    private ClientSettings clientSettings = new ClientSettings();

    RetryPolicy retryPolicy = new RetryPolicy()
            .withDelay(10, TimeUnit.SECONDS)
            .withMaxRetries(5)
            .retryIf((Message[] messageList) -> messageList.length == 0);

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
        public String apiUserName;
        public String apiPassword;
        public String appToken;
        public String vinNumber;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class TestData {
        public String vehicleYear;
        public String vehicleMake;
        public String vehicleModel;
        public String groupName;
        public String dealerName;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    @BeforeClass(alwaysRun = true)
    protected void setupDeviceAndVehicle() {

        JsonNode dataNode = envNode.at("/" + this.getClass().getSimpleName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            LOGGER.warn("Json data reading failure from test_data.json!");
        }

        vinNumber = data.vinNumber;

        //Get the api user's token
        dealerToken = getJwtToken(data.apiUserName, data.apiPassword, data.appToken);
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickSales(Method method) throws UnirestException {

        vehicleName = Long.toString(System.currentTimeMillis());

        //Create device & vehicle
        PlatformObject platformObject = createDeviceAndAsset(vehicleName, vinNumber, dealerToken);
        serialNumber = platformObject.deviceDto.getSerialNumber();

        deviceId = platformObject.deviceDto.getId();
        assetId = platformObject.assetDto.getId();

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Sales Page
        salesPage = navbarHeaderPage.clickSales();

        clientSettings.setBaseUrl(String.format("%s/sales", System.getProperty("automotiveSvcUrl")));

        client = new SaleServiceClient(clientSettings);
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException, UnirestException {

        takeScreenShotOnFailure(testResult, context);

        //Delete asset after sales case is completed
        if (assetId != null) {
            if (!deleteVehicle(assetId, dealerToken)) {
                LOGGER.warn("assetId -> {} could not be deleted ", assetId);
            } else {
                LOGGER.info("assetId -> {} deleted ", assetId);
            }
        }

        //Delete device after sales case is completed
        if (deviceId != null) {
            if (!deleteDevice(deviceId, dealerToken)) {
                LOGGER.warn("deviceId -> {} could not be deleted ", deviceId);
            } else {
                LOGGER.info("deviceId -> {} deleted ", deviceId);
            }
        }

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }
    }

    @AfterClass(alwaysRun = true)
    protected void resetLoginData() {

        //reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    /**
     * Create new sale, send emails, resend invitation and cancel sale
     *
     * @param data
     * @throws MessagingException
     * @throws ParseException
     */
    protected void verifySales(TestData data) throws MessagingException, ParseException {

        //Mark all "unread" mails with subject 'GoldStar Connect Order Confirmation'
        // and 'Welcome to GoldStar Connect: Get Your Mobile App' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new OrTerm(new SubjectTerm("GoldStar Connect Order Confirmation"),
                        new SubjectTerm("Welcome to GoldStar Connect: Get Your Mobile App")));

        markEmailsAsRead(searchTerm, "INBOX");

        final DateFormat UI_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

        final List<String> GRID_COLUMNS = Arrays.asList("Sale Date", "VIN", "Status", "Serial Number",
                "First Name", "Last Name", "Email", "Phone", "Term Length", "Actions");

        final List<String> saleComponentLabels = Arrays.asList("Sale Date:", "VIN:", "Email:", "First Name:",
                "Status:", "Last Name:", "Phone:");

        //Validate Connect form is opened
        assertEquals(salesPage.getActiveLink().getText(), "Connect");
        assertTrue(salesPage.getConnectForm().isDisplayed());

        //Enter vin number
        salesPage.enterAndDecodeVin(vinNumber);

        //Verify Make/Model/year
        assertTrue(salesPage.verifyVehicleMakeTxt(data.vehicleMake));
        assertTrue(salesPage.verifyVehicleModelTxt(data.vehicleModel));
        assertTrue(salesPage.verifyVehicleYearTxt(data.vehicleYear));

        //Create a sale
        String customerFirstName = createSale();

        String curDate = getCurrentBrowserDate(driver, UI_DATE_FORMAT)
                .replace("AM", "am").replace("PM", "pm");

        List<String> saleComponentValues = Arrays.asList(vinNumber, emailId,
                customerFirstName, "APPROVED", "Test", "5555555555");

        //Validate Complete Sale Button label and Sale completed message
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
        assertEquals(salesPage.getReloadFormBtn().getText(), "RESET FORM");
        assertEquals(salesPage.getSaleCompletedMessage().getText(), "Sale completed successfully");

        searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("GoldStar Connect Order Confirmation"));

        Email email = new Email();

        //Validate initial email
        assertTrue(email.getMessages("INBOX", searchTerm, retryPolicy).size() > 0,
                "No mails found");

        //Click Recent Sales tab
        salesPage.clickRecentSaleLink();

        //Validate Recent Sales grid is opened
        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(salesPage.getColumnHeader())).isDisplayed());

        //Validate Grid Columns.
        assertEquals(salesPage.getGridColumns(), GRID_COLUMNS,
                "Columns list should match for Recent Sales tab");

        //Create criteria to get the sales
        SearchSalesCriteriaBuilder criteriaBuilder = createSaleCriteria();

        //Retry until the created sale is APPROVED
        CollectionResource<SaleDto> sales = getSalesOnceApproved(customerFirstName, criteriaBuilder);

        searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Welcome to GoldStar Connect: Get Your Mobile App"));

        //Validate Second email sent when the status is APPROVED
        for (SaleDto saleDto : sales.getContent()) {
            if (saleDto.getCustomer().getFirstName().equals(customerFirstName)) {

                assertTrue(email.getMessages("INBOX", searchTerm, retryPolicy).size() > 0,
                        "No mails found");
                break;
            }
        }

        markEmailsAsRead(searchTerm, "INBOX");

        //Validate the sale record displayed on the grid
        assertEquals(salesPage.search(customerFirstName), 1);

        //Validate sale status on the grid is Approved and action (edit) icon is enabled
        assertEquals(salesPage.getGridSaleStatus().getText(), "Approved");
        assertTrue(salesPage.getEditLink().isEnabled());

        //Click on edit link
        salesPage.editRecord(1);

        //Validate GoldStar Connect Sell-Through Edit Form
        assertTrue(salesPage.getModalWindow().isDisplayed());
        assertEquals(salesPage.getModalWindowTitle().getText(), "GoldStar Connect Sell-Through Edit Form");

        Long maxDiff = 120000L; // max difference of 120 seconds

        List<String> saleComponentUIValues = salesPage.getSaleComponentValues();
        String saleCreatedDate = saleComponentUIValues.get(0);
        saleComponentUIValues.remove(0);

        //Validate sale components - Labels and Values
        assertEquals(salesPage.getSaleComponentLabels(), saleComponentLabels);
        assertEquals(saleComponentUIValues, saleComponentValues);

        long curDateMillis = UI_DATE_FORMAT.parse(curDate).getTime();
        long uiSaleCreatedDateMillis = UI_DATE_FORMAT.parse(saleCreatedDate)
                .getTime();

        //Validate sale created date
        assertTrue(Math.abs(uiSaleCreatedDateMillis - curDateMillis) <=
                maxDiff, String.format("Sale Created Date: %s doesn't match" +
                        " current date: %s within 2 minute.", uiSaleCreatedDateMillis,
                curDate));

        //Validate Cancel Sale, Resend Invitation, Revoke Consumer Access and Revoke Dealer Access tabs
        assertTrue(salesPage.getCancelSaleTab().isDisplayed());
        assertTrue(salesPage.getResendInvitationTab().isDisplayed());
        assertTrue(salesPage.getRevokeUserAccessTab().isDisplayed());
        assertTrue(salesPage.getRevokeDealerAccessTab().isDisplayed());

        //Resend Invitation for newly added sale
        salesPage.clickResendInvitationButton();

        //Validate resend invitation confirmation modal
        assertEquals(salesPage.getConfirmationTitle().getText(), "Resend");
        assertEquals(salesPage.getConfirmationMessage().getText(),
                "The GoldStar connect welcome email will be resent to " + emailId);

        salesPage.clickConfirmationOkBtn();

        //Validate email sent on click of resend button
        assertTrue(email.getMessages("INBOX", searchTerm, retryPolicy).size() > 0,
                "No mails found");

        //Click on edit link
        salesPage.editRecord(1);

        //Validate cancel sale
        salesPage.clickCancelSaleButton();

        //Validate cancel sale confirmation modal
        assertEquals(salesPage.getConfirmationTitle().getText(), "Cancel");
        assertEquals(salesPage.getConfirmationMessage().getText(),
                "Are you sure you want to cancel the sale?");

        salesPage.clickConfirmationOkBtn();

        //TODO open issue: https://jira.spireon.com/browse/VFM-4823
        //Retry until the sale is CANCELLED and validate the status updated in the grid
        // and Action button (Edit) is disabled
        validateSaleStatus(customerFirstName, criteriaBuilder, SaleStatus.CANCELLED, "Cancelled");

        //Close connection
        email.close();
    }

    /**
     * E2E: Repossession (Revoke Consumer Access)
     *
     * @throws MessagingException
     * @throws IOException
     * @throws UnirestException
     */
    protected void verifyRevokeConsumerAccess() throws MessagingException, IOException, UnirestException {

        //Mark all "unread" mails with subject 'Welcome to GoldStar Connect: Get Your Mobile App' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Welcome to GoldStar Connect: Get Your Mobile App"));

        markEmailsAsRead(searchTerm, "INBOX");

        //Create a sale
        String customerFirstName = createSale();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Create criteria to get the sales
        SearchSalesCriteriaBuilder criteriaBuilder = createSaleCriteria();

        //Retry until the created sale is APPROVED
        CollectionResource<SaleDto> sales = getSalesOnceApproved(customerFirstName, criteriaBuilder);

        String mobileSignUpStatus = mobileSignUpSimulate(customerFirstName, sales, searchTerm);

        //Validate mobile sign-up status is ACCEPTED
        assertEquals(mobileSignUpStatus, "ACCEPTED", "Mobile sign-up process failed");

        //Click Recent Sales tab
        salesPage.clickRecentSaleLink();

        //Validate Recent Sales grid is opened
        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(salesPage.getColumnHeader())).isDisplayed());

        //Validate the sale record displayed on the grid
        assertEquals(salesPage.search(customerFirstName), 1);

        //Click on edit link
        salesPage.editRecord(1);

        //Validate Revoke Consumer Access
        salesPage.clickRevokeUserAccessButton();

        //Validate Revoke Consumer Access confirmation modal
        assertEquals(salesPage.getConfirmationTitle().getText(), "Revoke");
        assertEquals(salesPage.getConfirmationMessage().getText(),
                "Are you sure you want to revoke consumer's access?");

        salesPage.clickConfirmationOkBtn();

        //Retry until the sale is CANCELLED and validate the status updated in the grid
        // and Action button (Edit) is disabled
        validateSaleStatus(customerFirstName, criteriaBuilder, SaleStatus.CANCELLED, "Consumer Revoked");

        //Click Connect tab
        salesPage.clickConnectLink();

        //Validate the device is still available on sales form > device drop down list.
        assertTrue(salesPage.validateSerialNumberInSalesPage(serialNumber));
    }

    /**
     * E2E: Consumer Freedom (Revoke Dealer Access)
     *
     * @throws MessagingException
     * @throws IOException
     * @throws UnirestException
     */
    protected void verifyRevokeDealerAccess() throws MessagingException, IOException, UnirestException {

        //Mark all "unread" mails with subject 'Welcome to GoldStar Connect: Get Your Mobile App' as read
        SearchTerm searchTerm = new AndTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false),
                new SubjectTerm("Welcome to GoldStar Connect: Get Your Mobile App"));

        markEmailsAsRead(searchTerm, "INBOX");

        //Create a sale
        String customerFirstName = createSale();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Create criteria to get the sales
        SearchSalesCriteriaBuilder criteriaBuilder = createSaleCriteria();

        //Retry until the created sale is APPROVED
        CollectionResource<SaleDto> sales = getSalesOnceApproved(customerFirstName, criteriaBuilder);

        String mobileSignUpStatus = mobileSignUpSimulate(customerFirstName, sales, searchTerm);

        //Validate mobile sign-up status is ACCEPTED
        assertEquals(mobileSignUpStatus, "ACCEPTED", "Mobile sign-up process failed");

        //Click Recent Sales tab
        salesPage.clickRecentSaleLink();

        //Validate Recent Sales grid is opened
        assertTrue(new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(salesPage.getColumnHeader())).isDisplayed());

        //Validate the sale record displayed on the grid
        assertEquals(salesPage.search(customerFirstName), 1);

        //Click on edit link
        salesPage.editRecord(1);

        //Validate Revoke Dealer Access
        salesPage.clickRevokeDealerAccessButton();

        //Validate Revoke Dealer Access confirmation modal
        assertEquals(salesPage.getConfirmationTitle().getText(), "Revoke");
        assertEquals(salesPage.getConfirmationMessage().getText(),
                "Are you sure you want to revoke your access?");

        salesPage.clickConfirmationOkBtn();

        //Retry until the sale is APPROVED and validate the status updated in the grid
        // and Action button (Edit) is disabled
        validateSaleStatus(customerFirstName, criteriaBuilder, SaleStatus.APPROVED, "Released");

        //Click Connect tab
        salesPage.clickConnectLink();

        //Validate the device is NOT available on sales form > device drop down list any more.
        // TODO: 10/9/18 issue https://jira.spireon.com/browse/VFM-5187
        //assertFalse(salesPage.validateSerialNumberInSalesPage(serialNumber));
    }

    /**
     * Create a sale using given data
     *
     * @return
     */
    private String createSale() {

        String customerFirstName = "Automated" + "_" + System.currentTimeMillis();

        Person customer = new Person.PersonBuilder()
                .firstName(customerFirstName)
                .lastName("Test")
                .email(emailId)
                .phone("5555555555")
                .build();

        Address address = new Address.AddressBuilder()
                .street("1429 W Royal Lane")
                .city("Juneau")
                .state("AK - Alaska")
                .postalCode("99801")
                .build();

        //Select Serial Number
        salesPage.enterSerialNumber(serialNumber);

        //Fill form data and complete sale
        salesPage.enterVehicleCustomerDetails(customer, address);

        //Click on Complete Sale
        salesPage.clickCompleteSale();

        //Verify sale proceed without issues
        assertFalse(salesPage.isErrorFields(), "Sale isn't created because of some fields have errors");

        LOGGER.info("Created Sale First Name - " + customerFirstName);
        return customerFirstName;
    }

    /**
     * Create search sales criteria to get last 1 day sales
     *
     * @return
     */
    private SearchSalesCriteriaBuilder createSaleCriteria() {

        Calendar cal = Calendar.getInstance();
        Date endDate = cal.getTime();

        //Get current date - 1 day
        cal.add(Calendar.DATE, -1);
        Date startDate = cal.getTime();

        //Get recent sales data
        SearchSalesCriteriaBuilder criteriaBuilder = client
                .searchSalesCriteriaBuilder(dealerToken)
                .withProductIds("goldstar.consumerMobile")
                .withStartDate(startDate)
                .withEndDate(endDate);

        return criteriaBuilder;
    }

    /**
     * Retry until the given sale is APPROVED
     *
     * @param customerFirstName
     * @param criteriaBuilder
     * @return
     */
    private CollectionResource<SaleDto> getSalesOnceApproved(String customerFirstName,
                                                             SearchSalesCriteriaBuilder criteriaBuilder) {

        RetryPolicy retryPolicy_sale = new RetryPolicy()
                .withDelay(5, TimeUnit.SECONDS)
                .withMaxRetries(20)
                .retryIf((CollectionResource<SaleDto> sales) -> {
                    if (sales.getTotal() > 50) {
                        criteriaBuilder.withPage(50, (sales.getTotal() / 50) * 50);
                    }
                    for (SaleDto saleDto : sales.getContent()) {
                        if (saleDto.getCustomer().getFirstName().equals
                                (customerFirstName) && saleDto.getStatus
                                ().equals(SaleStatus.APPROVED)) {
                            return false;
                        }
                    }
                    return true;
                });

        CollectionResource<SaleDto> sales = Failsafe.with(retryPolicy_sale)
                .onRetry((c, f, ctx) -> LOGGER.warn("Failure #{}. Retrying...", ctx.getExecutions()))
                .withFallback((CheckedConsumer<? extends Throwable>) failure -> {
                    throw new TestNGException("getSale failed with retry");
                })
                .get(() -> client.searchSales(criteriaBuilder));

        return sales;
    }

    /**
     * Retry until the sale created is with the given status and validate the status updated in the grid
     * and validate the Action button (Edit) status is disabled
     *
     * @param customerFirstName
     * @param criteriaBuilder
     * @param saleStatus
     * @param status
     */
    private void validateSaleStatus(String customerFirstName, SearchSalesCriteriaBuilder criteriaBuilder,
                                    SaleStatus saleStatus, String status) {

        RetryPolicy retryPolicy_sale = new RetryPolicy()
                .withDelay(5, TimeUnit.SECONDS)
                .withMaxRetries(2)
                .retryIf((CollectionResource<SaleDto> salesData) -> {
                    for (SaleDto saleDto : salesData.getContent()) {
                        if (saleDto.getCustomer().getFirstName().equals
                                (customerFirstName) && saleDto.getStatus
                                ().equals(saleStatus)) {
                            return false;
                        }
                    }
                    return true;
                });

        Failsafe.with(retryPolicy_sale)
                .onRetry((c, f, ctx) -> LOGGER.warn("Failure #{}. Retrying...", ctx.getExecutions()))
                .withFallback((CheckedConsumer<? extends Throwable>) failure -> {
                    throw new TestNGException("getSale failed with retry");
                })
                .get(() -> client.searchSales(criteriaBuilder));

        //Refresh page
        salesPage.clickRefreshBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate sale status on the grid is with the given status and action (edit) icon is disabled
        assertEquals(salesPage.getGridSaleStatus().getText(), status);

        assertTrue(salesPage.getEditLink().getAttribute("class").contains("disabled"));
    }

    /**
     * Get the value of PIN number in second email and simulate the mobile sign-up process
     *
     * @param customerFirstName
     * @param sales
     * @param searchTerm
     * @return
     * @throws MessagingException
     * @throws UnirestException
     * @throws IOException
     */
    private String mobileSignUpSimulate(String customerFirstName, CollectionResource<SaleDto> sales,
                                        SearchTerm searchTerm)
            throws MessagingException, UnirestException, IOException {

        String mobileSignUpStatus = "";

        //Get the pin in Second email sent when the status is APPROVED
        for (SaleDto saleDto : sales.getContent()) {

            if (saleDto.getCustomer().getFirstName().equals(customerFirstName)) {

                Email email = new Email();

                List<Message> messageList = email.getMessages("INBOX", searchTerm, retryPolicy);

                assertTrue(!messageList.isEmpty(), "No mails found");

                //Get the pin number in the second email
                String pin = email.getMailContent(messageList.get(0))
                        .split("Your activation PIN is ")[1].split(" ")[0];
                LOGGER.info("Pin number to activate account - " + pin);

                //Close connection
                email.close();

                //API call below to simulate the mobile sign-up process

                //Step 1 - Activate account using pin number and emailId
                InvitationDto dataDto = activateAccount(pin, emailId);
                LOGGER.info("Activate account ID - " + dataDto.getId());

                //Step 2 - Set username & password using id from step 1
                InvitationDto invitationDto = setUsernamePassword(dataDto.getId().toString(), dealerToken,
                        customerFirstName, "password");
                LOGGER.info("Set username & password API call status - " + invitationDto.getStatus());
                mobileSignUpStatus = invitationDto.getStatus();

                break;
            }
        }

        return mobileSignUpStatus;
    }
}
