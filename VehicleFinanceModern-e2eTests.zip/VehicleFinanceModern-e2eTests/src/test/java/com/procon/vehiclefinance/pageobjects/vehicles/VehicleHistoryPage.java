package com.procon.vehiclefinance.pageobjects.vehicles;

import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.reports.ReportsLeftBarPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements
        .waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements
        .waitUntilSpinnerVisibleThenInvisible;

public class VehicleHistoryPage extends CommonGrid {

    protected static final Logger logger = Logger
            .getLogger(VehicleHistoryPage.class.getName());

    @FindBy(css = "div.active div.panel-fill-height div.ember-table-tables-container")
    private WebElement activeReportTable;

    private static final String mapMarkerIcon_css = "img.leaflet-marker-icon";
    @FindBy(css = mapMarkerIcon_css)
    private WebElement mapMarkerIcon;

    @FindBy(css = "div.leaflet-popup dl.dl-horizontal > dt")
    private WebElement mapKeys;

    @FindBy(css = "div.history-paging-component li:nth-of-type(3)")
    private WebElement pagingDiv;

    @FindBy(css = "div.history-paging-component li:nth-of-type(5)")
    private WebElement nextBtn;

    @FindBy(css = "div.export-dropdown")
    private WebElement exportBtn;

    @FindBy(css = "div.open li:nth-of-type(1)")
    private WebElement csvLink;

    @FindBy(css = "button[title='More Reports']")
    private WebElement moreReportsBtn;

    public VehicleHistoryPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Get map bubble content
     *
     * @return
     */
    public HashMap<String, String> getMapMarkerPopUpContent() {

        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);

        HashMap<String, String> mapPopUpContent = new HashMap<>();

        List<WebElement> keyList = driver.findElements(By.cssSelector
                ("div.leaflet-popup dl.dl-horizontal > dt"));

        List<WebElement> valueList = driver.findElements(By.cssSelector
                ("div.leaflet-popup dl.dl-horizontal > dd"));

        String landmark = driver.findElement(By.cssSelector("div.leaflet-popup dl.dl-horizontal > dd > b")).getText();

        for (int i = 0; i < keyList.size(); i++) {
            if (keyList.get(i).getText().replaceAll(":", "").equals("Location")) {
                mapPopUpContent.put(keyList.get(i).getText().replaceAll(":", ""),
                        valueList.get(i).getText().replace("\n", ", ").replace(landmark + ",", "")
                                .trim());
            } else {
                mapPopUpContent.put(keyList.get(i).getText().replaceAll(":", ""),
                        valueList.get(i).getText().trim());
            }
        }
        return mapPopUpContent;
    }

    /**
     * Get the number of pages - ie, the "16" in "1 of 16".
     *
     * @return
     */
    public int getNumberOfPages() {
        waitUntilSpinnerInvisible(driver);

        String text = pagingDiv.getText();
        String[] values = text.split("of");

        return Integer.parseInt(values[1].trim());
    }

    /**
     * click on next button
     */
    public void clickNextBtn() {
        nextBtn.click();
    }

    /**
     * click on more reports button
     *
     * @return
     */
    public ReportsLeftBarPage clickMoreReportsBtn() {
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(moreReportsBtn)).click();
        return PageFactory.initElements(driver, ReportsLeftBarPage.class);
    }

    /**
     * Get data of the given row number
     *
     * @param rowNumber
     * @return
     */
    public HashMap<String, String> getTableRow(int rowNumber) {
        return getTableRow(activeReportTable, rowNumber);
    }
}
