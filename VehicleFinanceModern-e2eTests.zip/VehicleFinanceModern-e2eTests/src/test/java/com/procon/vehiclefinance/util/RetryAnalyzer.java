package com.procon.vehiclefinance.util;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import java.util.concurrent.atomic.AtomicInteger;

public class RetryAnalyzer implements IRetryAnalyzer {

    // default retry once, unless retryCount is specified
    private String countStr = System.getProperty("retryCount", "1");
    AtomicInteger count = new AtomicInteger(Integer.parseInt(countStr));

    /**
     * Returns true if the test method has to be retried, false otherwise.
     *
     * @param result The result of the test method that just ran.
     * @return true if the test method has to be retried, false otherwise.
     */
    @Override
    public boolean retry(ITestResult result) {
        if (count.getAndDecrement() > 0) {
            result.setStatus(ITestResult.SKIP);
            result.getThrowable().printStackTrace();
            return true;
        }
        return false;
    }
}
