package com.procon.vehiclefinance.pageobjects.admin;

import com.procon.vehiclefinance.models.ScheduledCommand;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.logging.Logger;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class AdminScheduledCommandsPage extends CommonGrid {
    private static final Logger logger = Logger
            .getLogger(AdminScheduledCommandsPage.class.getName());

    //Temp work around.
    //TODO: "del" should be replaced by "delete" in code so that inherited locator from CommonGrid can be used
    // ("button.btn-danger[data-bb-handler=del]" > "button.btn-danger[data-bb-handler=delete]")
    private static final String CONFIRM_DELETE_BTN_CSS = "div.modal-footer > " +
            "button.btn-danger[data-bb-handler=del]";
    @FindBy(css = CONFIRM_DELETE_BTN_CSS)
    private WebElement confirmDeleteBtn;

    //Add Button
    @FindBy(css = "button.btn-primary.gridButton")
    private WebElement addBtn;

    //Scheduled command name
    @FindBy(css = "[name='name']")
    private WebElement scheduledCommandNameInput;

    //command type
    @FindBy(css = "[name='deviceCommandTypeCode']")
    private WebElement CommandTypeDropdown;

    //search
    @FindBy(css = "div.col-xs-5 [type='search']")
    private WebElement searchInput;

    //Button Cancel
    @FindBy(css = "button.btn-cancel")
    private WebElement cancelBtn;

    //Button Save
    private final String saveBtn_css = "div.modal-footer button.btn-primary";
    @FindBy(css = saveBtn_css)
    private WebElement saveBtn;

    //Frequency
    @FindBy(css = "[name='frequencyName']")
    private WebElement frequencyDropdown;

    //start date
    @FindBy(css = "[propertyname='startDateOnly'] .form-control.input-sm")
    private WebElement startDateInput;

    //start time
    @FindBy(css = "[placeholder='12:00 AM']")
    private WebElement startTimeInput;

    //Source grid box
    private final String sourceGrid_css = "div.form > div:nth-of-type(2) > div:nth-of-type(1) .lazy-list-container";
    @FindBy(css = sourceGrid_css)
    private WebElement sourceGridBox;

    //Source grid box panel
    private final String sourceGridPanel_css = "div.form > div:nth-of-type(2) > div:nth-of-type(1)";
    @FindBy(css = sourceGridPanel_css)
    private WebElement sourceGridBoxPanel;

    //Destination grid box
    private final String destinationGrid_css = "div.form > div:nth-of-type(2) > div:nth-of-type(3) .lazy-list-container";
    @FindBy(css = destinationGrid_css)
    private WebElement destinationGridBox;

    //Destination grid box panel
    private final String destinationGridPanel_css = "div.form > div:nth-of-type(2) > div:nth-of-type(3)";
    @FindBy(css = destinationGrid_css)
    private WebElement destinationGridBoxPanel;

    //Source grid box rows
    private final String sourceGrid_rows_css = "div.form > div:nth-of-type(2) > div:nth-of-type(1) .lazy-list-container>div";
    @FindBy(css = sourceGrid_rows_css)
    private WebElement sourceGridBoxRows;

    //Add button to select
    @FindBy(css = "div.col-xs-2 > div:nth-of-type(2) > button")
    private WebElement addBtnToSelect;

    //Remove button to select
    @FindBy(css = "button.rem")
    private WebElement removeBtnToSelect;

    //Source grid box select all checkbox
    @FindBy(css = "div.form > div:nth-of-type(2) > div:nth-of-type(1) .ember-table-header-container input")
    private WebElement sourceGridCheckBoxAll;

    //Destination grid box select all checkbox
    @FindBy(css = "div.form > div:nth-of-type(2) > div:nth-of-type(3) .ember-table-header-container input")
    private WebElement destinationGridCheckBoxAll;

    @FindBy(css = ".modal-title")
    private WebElement modalTitle;

    @FindBy(css = ".modal-dialog")
    private WebElement modalDialog;

    public AdminScheduledCommandsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void addEditScheduledCommand(ScheduledCommand scheduledCommand, ArrayList<String> serialNumbers) {
        addScheduledCommandName(scheduledCommand.getName());
        selectCommand(scheduledCommand.getCommand());
        selectfrequency(scheduledCommand.getFrequency());
        selectStartDate(scheduledCommand.getStartDate());
        selectStartTime(scheduledCommand.getStartTime());
        selectSerialNumbers(serialNumbers);
        clickSaveBtn();
    }

    public void addScheduledCommandName(String name) {
        if (name != null) {
            waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
            enterText(driver, scheduledCommandNameInput, name, 5);
        }
    }

    public void selectStartDate(String startDateParam) {
        if (startDateParam != null) {
            enterText(driver, startDateInput, startDateParam, 5);
        }
    }

    public void selectStartTime(String startTimeParam) {
        if (startTimeParam != null) {
            startTimeInput.click();
            enterText(driver, startTimeInput, startTimeParam, 5);
            scheduledCommandNameInput.click();
        }
    }

    public void selectCommand(String commandTypeParam) {
        if (commandTypeParam != null) {
            new WebDriverWait(driver, 5).until(
                    elementToBeClickable(CommandTypeDropdown));
            Select select = new Select(CommandTypeDropdown);
            select.selectByVisibleText(commandTypeParam);
        }
    }

    public void selectfrequency(String frequencyParam) {
        if (frequencyParam != null) {
            new WebDriverWait(driver, 5).until(
                    elementToBeClickable(frequencyDropdown));
            Select select = new Select(frequencyDropdown);
            select.selectByVisibleText(frequencyParam);
        }
    }

    public void clickAddBtn() {
        addBtn.click();
        new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOf(modalDialog));
    }

    public void clickAddToSelectionBtn() {
        addBtnToSelect.click();
    }

    public void clickCancelBtn() {
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
        cancelBtn.click();
    }

    public void clickSaveBtn() {
        clickElementAndWaitForInvisibility(driver, saveBtn, By.cssSelector(saveBtn_css), 5);
    }

    public void selectSerialNumbers(ArrayList<String> serialNumbers) {
        if (!serialNumbers.isEmpty()) {
            String format = "//span[text()='%s']/parent::div/parent::div/descendant::input";
            new WebDriverWait(driver, 30).until(ExpectedConditions
                    .visibilityOfNestedElementsLocatedBy(sourceGridBox, By
                            .cssSelector("input.ember-view.ember-checkbox")));
            for (String serialNumber : serialNumbers) {
                searchInput.clear();
                searchInput.sendKeys(serialNumber);
                String xpath = String.format(format, serialNumber);
                new WebDriverWait(driver, 20).until(ExpectedConditions
                        .elementToBeClickable(By.xpath(xpath))).click();
                clickAddToSelectionBtn();
            }
        }
    }

    public MapPage deleteScheduledCommand(String strSearch) {
        deleteSearchedRecord(strSearch);
        return PageFactory.initElements(driver, MapPage.class);
    }

    public void deleteRecord() {
        WebElement element = driver.findElement(By.cssSelector(DELETE_LINK_CSS));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        new WebDriverWait(driver, 5).until(elementToBeClickable(deleteLink))
                .click();
        clickElementAndWaitForInvisibility(driver, confirmDeleteBtn, By
                .cssSelector(CONFIRM_DELETE_BTN_CSS), 10);
    }

    public void deleteSearchedRecord(String strSearch) {
        int rowCount = search(strSearch);
        if (rowCount == 1) {
            deleteRecord();
        } else {
            throw new RuntimeException("More than 1 record searched");

        }
    }

    public AdminScheduledCommandsPage editScheduledCommand(String strSearch) {
        super.editSearchedRecord(strSearch);
        return PageFactory.initElements(driver, AdminScheduledCommandsPage.class);
    }

    public String getModalTitle() {
        return modalTitle.getText();
    }

    public WebElement getModalDialog() {
        return modalDialog;
    }

    public WebElement getScheduledCommandNameInput() {
        return scheduledCommandNameInput;
    }

    public Select getFrequencyDropdown() {
        return new Select(frequencyDropdown);
    }

    public Select getCommandTypeDropdown() {
        return new Select(CommandTypeDropdown);
    }

    public WebElement getStartDateInput() {
        return startDateInput;
    }

    public WebElement getStartTimeInput() {
        return startTimeInput;
    }

    public WebElement getSourceGridBox() {
        return sourceGridBox;
    }

    public WebElement getDestinationGridBox() {
        return destinationGridBox;
    }

    public WebElement getAddBtnToSelect() {
        return addBtnToSelect;
    }

    public WebElement getRemoveBtnToSelect() {
        return removeBtnToSelect;
    }

    public boolean isDatePickerDisplayed()
    {
        return !driver.findElements(By.cssSelector(".datepicker")).isEmpty();
    }

    public boolean isTimePickerDisplayed()
    {
        return !driver.findElements(By.cssSelector("ul.list-unstyled")).isEmpty();
    }

    public WebElement getSourceGridBoxPanel() {
        return sourceGridBoxPanel;
    }

    public WebElement getAddBtn() {
        return addBtn;
    }
}