package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Account;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminAMOrdersPage;
import com.procon.vehiclefinance.pageobjects.admin.AdminLeftBarPage;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.services.AccountService.getOrders;
import static com.procon.vehiclefinance.services.ServiceCaller.getUserSettings;
import static com.procon.vehiclefinance.util.DateTimeUtils.formatDate;
import static org.testng.Assert.*;

public class AdminAMOrdersTest extends BaseTest {

    protected static final Logger logger = LoggerFactory.getLogger(AdminDealerManagementTest.class);

    protected MapPage mapPage;
    protected NavbarHeaderPage navbarHeaderPage;
    protected AdminLeftBarPage adminLeftBarPage;
    protected AdminAMOrdersPage adminAMOrdersPage;

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Account Management > Orders Page
        adminAMOrdersPage = adminLeftBarPage.clickAccountManagementLink().openOrdersTab();
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {

            //Press escape key to dismiss popup if present
            new Actions(driver).sendKeys(Keys.ESCAPE).build().perform();
            navbarHeaderPage.logout();
        }

        //reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "UI verification of Admin > Account Management > Orders tab", groups = {"admin"})
    public void testAdminAMOrdersUIElements() throws UnirestException, IOException, ParseException {

        final DateFormat UI_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy h:mm a");

        final DateFormat API_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ");

        final List<String> ORDER_GRID_COLUMNS = Arrays.asList("Order No.", "Date Submitted", "Item Count",
                "Order Total", "Order Status", "Actions");

        final List<String> ORDER_DETAILS_GRID_COLUMNS = Arrays.asList("Device Name", "Price", "Tax", "Expires On");

        //Validate Grid Columns.
        assertEquals(adminAMOrdersPage.getGridColumns(), ORDER_GRID_COLUMNS,
                "Columns list should match for Orders page");

        //Get first row data
        HashMap<String, String> ordersTableFirstRow = adminAMOrdersPage.getTableFirstRow();

        //Validate grid data format
        adminAMOrdersPage.validateDataFormat(ordersTableFirstRow, UI_DATE_FORMAT);

        Account.OrdersList ordersList = getOrders(driver);

        //Validate total record count in UI with API
        assertEquals(adminAMOrdersPage.getTotalRecordCount(), ordersList.total);

        ordersTableFirstRow.remove("Actions");

        HashMap<String, String> apiFirstRecord = adminAMOrdersPage.getApiFirstRecord(ordersList.data);

        apiFirstRecord.put("Date Submitted", formatDate(driver, apiFirstRecord.get("Date Submitted"),
                API_DATE_FORMAT, getUserSettings(driver).userTz, UI_DATE_FORMAT).toLowerCase());

        //Validate first record in grid with first record in api
        ordersTableFirstRow.forEach((k, v) ->
            {
                apiFirstRecord.containsKey(k);
                apiFirstRecord.containsValue(v);
            });

        //Validate Pagination Info
        adminAMOrdersPage.verifyPageSizeSelection(CommonGrid.SelectPageSizesEnum.HUNDRED);
        adminAMOrdersPage.verifyNavigationElementsPresent();
        adminAMOrdersPage.verifyNavigationBtns();
        adminAMOrdersPage.verifyNavigationBtnsTooptip();
        adminAMOrdersPage.verifyPaginationBoundsDisplay();

        //Click on view icon
        adminAMOrdersPage.getViewLink().click();

        //Validate modal window
        assertTrue(adminAMOrdersPage.getModalWindow().isDisplayed());
        assertEquals(adminAMOrdersPage.getModalWindowTitle().getText(),
                "Order on: " + ordersTableFirstRow.get("Date Submitted"));

        //Validate order details data with orders grid data
        adminAMOrdersPage.validateOrderDetailsData(ordersTableFirstRow);

        //Validate order details grid columns.
        assertEquals(adminAMOrdersPage.getModalWindowGridColumns(), ORDER_DETAILS_GRID_COLUMNS);

        //Validate first record in order details grid with first record in api
        adminAMOrdersPage.getTableFirstRow(adminAMOrdersPage.getOrderDetailsTable()).forEach((k, v) ->
        {
            adminAMOrdersPage.getApiFirstRecordOrderDetails(ordersList.data).containsKey(k);
            adminAMOrdersPage.getApiFirstRecordOrderDetails(ordersList.data).containsValue(v);
        });

        //Validate order total in order details grid and orders grid
        assertEquals(adminAMOrdersPage.getOrderTotalInOrderDetails(), ordersTableFirstRow.get("Order Total"));

        //Validate close button
        assertTrue(adminAMOrdersPage.getCloseBtn().isDisplayed());

        adminAMOrdersPage.clickCloseBtn();
    }
}
