package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Alert;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.admin.User;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.procon.vehiclefinance.models.Device.createDeviceAlertObject;
import static com.procon.vehiclefinance.util.MongoUtils.getDeviceDetail;
import static com.procon.vehiclefinance.util.MongoUtils.insertAlert;

public class AlertService extends ServiceCaller {

    // contact list
    private static String alertTypeEndpoint;
    private static String alertEndpoint;
    private static String alertSpecEndpoint;

    static {
        alertTypeEndpoint = baseUrl + "rest/json/alertType";
        alertEndpoint = baseUrl + "operation/json/deviceAlertRestService/get";
        alertSpecEndpoint = baseUrl + "rest/json/vehicleFinanceAlertSpecRest";
    }

    /**
     * Get the list of alert types.
     *
     * @param driver WebDriver object
     * @return Alert Type Result
     * @throws UnirestException
     */
    public static Alert.AlertTypeResults getAlertTypes(WebDriver driver) throws
            UnirestException {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("sort", "name");

        HttpResponse<Alert.AlertTypeResults> response = Unirest.get
                (alertTypeEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Alert.AlertTypeResults.class);
        return response.getBody();

    }

    /**
     * Get Alerts by calling the Alert Service
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return alert filter results
     * @throws UnirestException
     */
    public static Alert.AlertFilterResults
    getAlertFilterResults(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Alert.AlertFilterResults> response
                = Unirest.get(alertEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Alert.AlertFilterResults.class);

        return response.getBody();
    }

    /**
     * Get Outstanding alerts by calling the Alert Service. By default, the
     * outstanding alerts are returned for last 7 days
     *
     * @param driver WebDriver object
     * @return alert filter results
     * @throws UnirestException
     */
    public static Alert.AlertFilterResults getOutstandingAlerts(WebDriver driver,
                                                                List<Integer> alertTypeIds)
            throws UnirestException {

        // get current date - 7 days
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:sss'Z'");
        Calendar c = Calendar.getInstance();// convert date to calendar
        c.add(Calendar.DATE, -7); // manipulate date
        String dateStr = dateFormat.format(c.getTime());

        String filterStr = "[{\"property\":\"alertSpecId\"," +
                "\"operator\":\"exists\",\"value\":false," +
                "\"type\":\"Boolean\"},{\"property\":\"acknowledged\"," +
                "\"operator\":\"ne\",\"value\":true,\"type\":\"Boolean\"}," +
                "{\"property\":\"alertDate\",\"operator\":\"gte\"," +
                "\"value\":\"" + dateStr + "\",\"type\":\"Date\"}," +
                "{\"comparison\":\"in\",\"property\":\"alertTypeId\"," +
                "\"value\":" + alertTypeIds.toString() + "}]";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("filters", filterStr);
        queryParams.put("sorts", "[{\"property\":\"alertDate\"," +
                "\"direction\":\"DESC\"}]");
        queryParams.put("doCount", true);

        return getAlertFilterResults(driver, queryParams);
    }

    /**
     * Generate  alerts by directly inserting into Mongo
     *
     * @param driver
     * @param serialNumber
     * @param alertTypeIds
     * @return the device alerts that are generated
     */
    public static List<Device.DeviceAlert> generateAlerts(WebDriver driver, String
            serialNumber, List<Integer> alertTypeIds) throws IOException, UnirestException {
        User.UserSettings userSettings = getUserSettings(driver);
        List<Alert.AlertType> alertTypes = getAlertTypes(driver).data;
        List<Alert.AlertType> alertTypesToAdd = new ArrayList<Alert.AlertType>();
        for (Alert.AlertType a : alertTypes) {
            for (int alertTypeId : alertTypeIds) {
                if (a.id.equals(alertTypeId)) {
                    alertTypesToAdd.add(a);
                    break;
                }
            }
        }
        if (alertTypesToAdd.size() == 0) throw new AssertionError("Alert Type not " +
                "found");

        Device.DeviceDetail deviceDetail = getDeviceDetail(
                and(
                        eq("serialNumber", serialNumber),
                        eq("accountId", userSettings.accountId)
                )).first();

        List<Device.DeviceAlert> alerts = new ArrayList<>();
        for (Alert.AlertType a : alertTypesToAdd) {
            Device.DeviceAlert alert = createDeviceAlertObject(
                    userSettings, a, deviceDetail);
            alerts.add(alert);
        }

        insertAlert(alerts);
        return alerts;
    }

    /**
     * Get Saved Alerts by calling the Alert Service.
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return alert filter results
     * @throws UnirestException
     */
    public static Alert.AlertResults getSavedAlerts(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Alert.AlertResults> response
                = Unirest.get(alertSpecEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Alert.AlertResults.class);

        return response.getBody();
    }

    /**
     * Get Saved Alerts by calling the Alert Service using default parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Alert.AlertResults getSavedAlerts(WebDriver driver)
            throws UnirestException {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("filterOperator", "and");
        queryParams.put("filters", "[]");
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getSavedAlerts(driver, queryParams);
    }

    /**
     * Get Saved Alerts by calling the Alert Service using given search key.
     *
     * @param driver
     * @param searchKey
     * @return
     * @throws UnirestException
     */
    public static Alert.AlertResults getSavedAlerts(WebDriver driver, String searchKey)
            throws UnirestException {

        String filterStr = "[{\"property\":\"name\",\"comparison\":\"ilike\",\"value\":\"%s\"}]";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("filterOperator", "and");
        queryParams.put("filters", String.format(filterStr, searchKey));
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getSavedAlerts(driver, queryParams);
    }

    /**
     * Delete Saved Alert using given alert id.
     *
     * @param driver
     * @param id
     * @return
     * @throws UnirestException
     */
    public static Alert.AlertResponseData deleteSavedAlert(WebDriver driver, int id) throws UnirestException {
        HttpResponse<Alert.AlertResponseData> response = Unirest.delete
                (alertSpecEndpoint + "/{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", String.valueOf(id))
                .asObject(Alert.AlertResponseData.class);
        return response.getBody();
    }
}