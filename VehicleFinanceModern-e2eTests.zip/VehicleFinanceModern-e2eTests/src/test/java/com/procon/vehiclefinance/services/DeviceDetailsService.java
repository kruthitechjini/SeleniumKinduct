package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.vehicles.DeviceDetails;
import org.openqa.selenium.WebDriver;

import static com.procon.vehiclefinance.services.DeviceDetailsService.getDevices;

import java.util.HashMap;
import java.util.Map;

public class DeviceDetailsService extends ServiceCaller {

    // retrieve device details
    private static String deviceDetailsEndpoint;

    // retrieve device details
    private static String deviceCommandEndpoint;

    static {

        deviceDetailsEndpoint = baseUrl +
                "rest/json/vehicleFinanceDeviceLocationRest";
        deviceCommandEndpoint = baseUrl + "operation/deviceCommandService/executeCommand.json";
    }

    public static DeviceDetails.DeviceData getDevices(WebDriver driver, Map<String, Object> queryParams) throws
            UnirestException {
        HttpResponse<DeviceDetails.DeviceData> response = Unirest.get
                (deviceDetailsEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(DeviceDetails.DeviceData.class);
        return response.getBody();
    }

    public static DeviceDetails.Device getDevice(WebDriver driver, String searchText) throws
    	UnirestException {
        String filterStr = "[{\"property\":\"networkActive\",\"value\":true},"
        		+ "{\"property\":\"networkNetworkActive\",\"value\":true}]";
        String configStr = "{\"assetSearchText\":\"" + searchText + "\","
        		+ "\"queryFields\":[\"assetMake\",\"assetModel\",\"assetName\",\"assetVfColor\","
        		+ "\"assetVfStockNumber\",\"assetVin\",\"assetYear\",\"operatorFirstName\","
        		+ "\"operatorLastName\",\"serialNumber\"],"
        		+ "\"assetSearchFields\":[],\"landmarkSearchText\":null,\"assetSearchTags\":null,"
        		+ "\"landmarkSearchTags\":null,\"notInAssetGroup\":false,\"notInLandmarkGroup\":false,"
        		+ "\"selectedAssetFilters\":[],\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[],"
        		+ "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}";

        Map<String, Object> deviceQueryParams = new HashMap<>();
        deviceQueryParams.put("max", 50);
        deviceQueryParams.put("assetOnly", true);
        deviceQueryParams.put("filter", filterStr);
        deviceQueryParams.put("sorts", "[{\"property\":\"assetName\",\"direction\":\"ASC\"}]");
        deviceQueryParams.put("noSubgroups", true);
        deviceQueryParams.put("config", configStr);
        deviceQueryParams.put("_", System.currentTimeMillis());
        
        DeviceDetails.DeviceData devices = getDevices(driver, deviceQueryParams);
		return devices.data.get(0);
    }
    
    public static DeviceDetails.CommandResponse getCommandResponse(WebDriver driver, Map<String, Object> queryParams) throws
            UnirestException {
        HttpResponse<DeviceDetails.CommandResponse> response = Unirest.get
                (deviceCommandEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(DeviceDetails.CommandResponse.class);
        return response.getBody();
    }
}