package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.HttpRequest;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.DeviceStatusEnum;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage.ReportingEnum;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class DeviceService extends ServiceCaller {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceService.class);

    private static String getDevicesEndpoint;
    private static String transferAssetGroupEndpoint;
    private static String exportDeviceHistoryEndpoint;
    private static String getDeviceHistoryEndpoint;
    private static String exportDeviceReferencesEndpoint;
    private static String getDeviceReferencesEndpoint;
    private static String getGeoFenceEndpoint;
    private static String getDeviceDealerEndpoint;
    private static String exportDeviceDataEndpoint;
    private static String getDeviceCommandSpec;

    // map all report
    private static String mapAllEndpoint;

    private static String landmarksEndpoint;

    private static String getAssetApiEndPoint;

    private static String getDeviceNotesEndPoint;

    static {
        getDevicesEndpoint = baseUrl + "rest/json/vehicleFinanceDeviceLocationRest";
        transferAssetGroupEndpoint = baseUrl +
                "operation/json/vehicleFinanceOperatorAssetService/groupTransfer";
        mapAllEndpoint = baseUrl + "rest/json/deviceStateRest";
        exportDeviceHistoryEndpoint = baseUrl +
                "rest/{fileType}/vehicleFinanceDeviceHistoryRest";
        getDeviceHistoryEndpoint = baseUrl +
                "rest/json/vehicleFinanceDeviceHistoryRest";
        exportDeviceReferencesEndpoint = baseUrl +
                "rest/{fileType}/vfStipLandmark";
        getDeviceReferencesEndpoint = baseUrl +
                "rest/json/vfStipLandmark";
        landmarksEndpoint = System.getProperty("glSvcUrl") + "api/1.0.0/landmarks";
        getGeoFenceEndpoint = baseUrl + "rest/json/geofence/";
        getAssetApiEndPoint = baseUrl + "rest/json/assetApi";
        getDeviceDealerEndpoint = baseUrl + "rest/json/deviceDealerRest";
        exportDeviceDataEndpoint = baseUrl +
                "rest/{fileType}/vehicleFinanceDeviceVehicleRest/get";
        getDeviceNotesEndPoint = baseUrl + "rest/json/vehicleFinanceNotes";
        getDeviceCommandSpec = baseUrl + "rest/json/deviceCommandSpec";
    }

    /**
     * Get Devices belonging to the currently logged in account
     *
     * @param driver      WebDriver object
     * @param queryParams a Map of query parameters to use with the request
     * @return Device Data with a list of devices
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.DeviceData> response = Unirest.get
                (getDevicesEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceData.class);
        return response.getBody();
    }

    /**
     * Get Devices belonging to an asset group
     *
     * @param driver WebDriver object
     * @param id     asset group Id
     * @param name   asset group name
     * @return Device Data containing a list of devices in specified asset group
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, long id, String name, boolean filterToBeAdded)
            throws UnirestException {

        return getDevices(driver, id, name, filterToBeAdded, false);
    }

    /**
     * Get Devices belonging to an asset group
     *
     * @param driver          WebDriver object
     * @param id              asset group Id
     * @param name            asset group name
     * @param filterToBeAdded device filter
     * @param lenderFilter    filter to show only active devices in lender user
     * @return Device Data containing a list of devices in specified asset group
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, long id, String name, boolean filterToBeAdded,
                                               boolean lenderFilter) throws UnirestException {

        String configStr = "{\"queryFields\":[\"assetName\"," +
                "\"serialNumber\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null," +
                "\"landmarkSearchTags\":null,\"notInAssetGroup\":false," +
                "\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[]," +
                "\"selectedAssetGroups\":[{\"id\":%d,\"name\":\"%s\"}]," +
                "\"selectedLandmarkGroups\":[],\"assetSearchText\":null}";

        String filterStr = "[{\"property\":\"networkActive\"," +
                "\"value\":true},{\"property\":\"networkNetworkActive\"," +
                "\"value\":true}";

        if (lenderFilter) {
            filterStr = filterStr + ",{\"property\":\"active\",\"value\":true}]";
        } else {
            filterStr = filterStr + "]";
        }

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("offset", 0);
        queryParams.put("config", String.format(configStr, id, name.replace
                ("\"", "\\\"")));
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");
        if (filterToBeAdded) {
            queryParams.put("filter", filterStr);
        }
        queryParams.put("assetOnly", true);
        queryParams.put("noSubgroups", true);

        return getDevices(driver, queryParams);
    }

    /**
     * Get Device belonging to the currently logged in account and given
     * search key.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, String searchKey)
            throws UnirestException {

        String configStr = "{\"assetSearchText\":\"%s\"," +
                "\"queryFields\":[\"assetMake\",\"assetModel\",\"assetName\"," +
                "\"assetVfColor\",\"assetVfStockNumber\",\"assetVin\"," +
                "\"assetYear\",\"operatorFirstName\",\"operatorLastName\"," +
                "\"serialNumber\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null," +
                "\"landmarkSearchTags\":null,\"notInAssetGroup\":false," +
                "\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[]," +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("assetOnly", true);
        queryParams.put("filter", "[{\"property\":\"networkActive\"," +
                "\"value\":true},{\"property\":\"networkNetworkActive\"," +
                "\"value\":true}]");
        queryParams.put("sorts", "[{\"property\":\"assetName\",\"direction\":\"ASC\"}]");
        queryParams.put("noSubgroups", true);
        queryParams.put("config", String.format(configStr, searchKey));

        return getDevices(driver, queryParams);
    }

    /**
     * Get Device belonging to the currently logged in account with default
     * parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver) throws UnirestException {

        return getDevices(driver, false);
    }

    /**
     * Get Device belonging to the currently logged in account with default
     * parameters.
     *
     * @param driver
     * @param filterToBeAdded
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, boolean filterToBeAdded)
            throws UnirestException {

        String configStr = "{\"assetSearchText\":\"\"," +
                "\"queryFields\":[\"assetMake\",\"assetModel\",\"assetName\"," +
                "\"assetVfColor\",\"assetVfStockNumber\",\"assetVin\"," +
                "\"assetYear\",\"operatorFirstName\",\"operatorLastName\"," +
                "\"serialNumber\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null," +
                "\"landmarkSearchTags\":null,\"notInAssetGroup\":false," +
                "\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[]," +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}";

        String filterStr = "[{\"property\":\"networkActive\"," +
                "\"value\":true},{\"property\":\"networkNetworkActive\"," +
                "\"value\":true}";

        if (filterToBeAdded) {
            filterStr = filterStr + ",{\"property\":\"active\",\"value\":true}]";
        } else {
            filterStr = filterStr + "]";
        }

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("assetOnly", true);
        queryParams.put("filter", filterStr);
        queryParams.put("sorts", "[{\"property\":\"assetName\"," +
                "\"direction\":\"ASC\"}]");
        queryParams.put("noSubgroups", true);
        queryParams.put("config", configStr);

        return getDevices(driver, queryParams);
    }

    /**
     * Get Devices with filters
     * parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, DeviceStatusEnum deviceStatus)
            throws UnirestException {

        String configStr = "{\"assetSearchText\":null," +
                "\"queryFields\":[\"assetMake\",\"assetModel\",\"assetName\"," +
                "\"assetVfColor\",\"assetVfStockNumber\",\"assetVin\"," +
                "\"assetYear\",\"operatorFirstName\",\"operatorLastName\"," +
                "\"serialNumber\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null," +
                "\"landmarkSearchTags\":null,\"notInAssetGroup\":false," +
                "\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[]," +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}";

        String filterStr = "[{\"property\":\"assetVfDeviceStatus\"," +
                "\"value\":\"%s\"},{\"property\":\"networkActive\"," +
                "\"value\":true},{\"property\":\"networkNetworkActive\"," +
                "\"value\":true}]";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("assetOnly", true);
        queryParams.put("offset", 0);
        queryParams.put("filter", String.format(filterStr, deviceStatus.getDeviceStatus()));
        queryParams.put("sorts", "[{\"property\":\"assetName\"," +
                "\"direction\":\"ASC\"}]");
        queryParams.put("noSubgroups", true);
        queryParams.put("config", configStr);

        return getDevices(driver, queryParams);
    }

    /**
     * Get Devices with filters
     * parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDevices(WebDriver driver, DeviceStatusEnum deviceStatus,
                                               ReportingEnum reporting) throws UnirestException {

        String filterStr = "{\"property\":\"networkActive\",\"value\":true}," +
                "{\"property\":\"networkNetworkActive\",\"value\":true},{\"property\":\"active\",\"value\":true}";

        String deviceStr = "";
        if (deviceStatus != null) {
            if (deviceStatus.equals(DeviceStatusEnum.ACTIVE)) {
                deviceStr = "{\"property\":\"assetVflDeviceStatus\",\"value\":\"Active\"},";
            } else if (deviceStatus.equals(DeviceStatusEnum.INVENTORY)) {
                deviceStr = "{\"operator\":\"or\",\"value\":[{\"property\":\"assetVflDeviceStatus\"," +
                        "\"operator\":\"eq\",\"value\":\"Inventory\"},{\"property\":\"assetVflDeviceStatus\"," +
                        "\"operator\":\"eq\",\"value\":\"Pending\"},{\"property\":\"assetVflDeviceStatus\"," +
                        "\"operator\":\"eq\",\"value\":null}]},";
            }
        }

        String reportingStr = "";
        if (reporting != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE, -8);
            Long date = calendar.getTimeInMillis();
            if (reporting.equals(ReportingEnum.WITHIN_7_DAYS)) {
                reportingStr = "{\"property\":\"maxEventDate\"," +
                        "\"value\":%d,\"operator\":\"gte\"},";
            } else if (reporting.equals(ReportingEnum.NOT_WITHIN_7_DAYS)) {
                reportingStr = "{\"operator\":\"or\"," +
                        "\"value\":[{\"property\":\"maxEventDate\"," +
                        "\"value\":%d,\"operator\":\"lt\"}," +
                        "{\"property\":\"maxEventDate\"," +
                        "\"value\":false,\"operator\":\"exists\"}]},";
            }
            reportingStr = String.format(reportingStr, date);
        }

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("config", "{\"queryFields\":[\"assetMake\",\"assetModel\"," +
                "\"assetName\",\"assetVfColor\",\"assetVfStockNumber\",\"assetVflStockNumber\"," +
                "\"assetVin\",\"assetYear\",\"operatorFirstName\",\"operatorLastName\"," +
                "\"serialNumber\",\"assetVflActivationDate\",\"networkRenewalDate\"," +
                "\"starterOn\",\"warningOn\",\"assetVfDeviceStatus\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null,\"landmarkSearchTags\":null," +
                "\"notInAssetGroup\":false,\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[]," +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}\n");

        queryParams.put("filter", "[" + deviceStr + reportingStr + filterStr + "]");
        queryParams.put("assetOnly", true);
        queryParams.put("sorts", "[]");
        queryParams.put("offset", 0);
        queryParams.put("noSubgroups", true);
        queryParams.put("max", 50);

        return getDevices(driver, queryParams);
    }

    /**
     * Get All Devices belonging to the currently logged in account
     *
     * @param driver
     * @return all devices
     * @throws UnirestException
     */
    public static Device.DeviceData getDevicesAll(WebDriver driver) throws UnirestException {

        String configStr = "{\"queryFields\":[\"assetGroupName\",\"assetName\",\"assetVfDeviceStatus\"," +
                "\"assetVflDeviceStatus\",\"serialNumber\",\"vin\"],\"assetSearchFields\":[]," +
                "\"landmarkSearchText\":null,\"assetSearchTags\":null,\"landmarkSearchTags\":null," +
                "\"notInAssetGroup\":false,\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[],\"selectedLandmarkGroups\":[]}";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("assetOnly", true);
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("filter", "[]");
        queryParams.put("sorts", "[{\"property\":\"assetGroupName\"," +
                "\"direction\":\"ASC\"}]");
        queryParams.put("noSubgroups", true);
        queryParams.put("config", configStr);

        return getDevices(driver, queryParams);
    }

    /**
     * Transfer assets to the target asset group
     *
     * @param driver        WebDriver object
     * @param assetIds      List of asset Ids to be transferred
     * @param targetGroupId Target group Id to transfer the assets
     * @return Asset Transfer Response
     * @throws UnirestException
     */
    public static Device.AssetTransferResponse transferAssetGroup(WebDriver driver, List<Integer> assetIds,
                                                                  Long targetGroupId) throws UnirestException {

        HttpRequest httpRequest = Unirest.get(transferAssetGroupEndpoint)
                .queryString("targetGroupId", targetGroupId)
                .header("Cookie", getDriverCookies(driver));
        for (Integer assetId : assetIds) {
            httpRequest.queryString("assetId", assetId);
        }
        HttpResponse<Device.AssetTransferResponse> response = httpRequest
                .asObject(Device.AssetTransferResponse.class);
        return response.getBody();

    }

    /**
     * Get status of map all
     *
     * @param driver
     * @param deviceIds
     * @return
     * @throws UnirestException
     */
    public static int mapAllReport(WebDriver driver, List<String> deviceIds) throws UnirestException {

        HttpRequest httpRequest = Unirest.get(mapAllEndpoint)
                .header("Cookie", getDriverCookies(driver));
        for (String deviceId : deviceIds) {
            httpRequest.queryString("ids", deviceId);
        }
        HttpResponse<String> response = httpRequest.asString();
        return response.getStatus();
    }

    /**
     * Download vehicle finance device history data.
     * Accepted FileTypes = csv/pdf/excel
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static InputStream exportDeviceHistory(WebDriver driver, Map<String, Object> queryParams,
                                                  String fileType) throws UnirestException {

        HttpResponse<InputStream> response = Unirest.get
                (exportDeviceHistoryEndpoint)
                .routeParam("fileType", fileType)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Download vehicle finance device history data of 30 days for given
     * vehicle
     *
     * @param driver
     * @param deviceId
     * @return
     * @throws UnirestException
     */
    public static InputStream exportDeviceHistory(WebDriver driver, long deviceId, String fileType)
            throws UnirestException {

        DateFormat DATE_FORMAT = new SimpleDateFormat
                ("yyyy-MM-dd");

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -29);
        String startDate = DATE_FORMAT.format(calendar.getTime());

        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, 1);
        String endDate = DATE_FORMAT.format(calendar.getTime());

        String filterStrFormat = "[{\"operator\":\"and\"," +
                "\"value\":[{\"property\":\"eventTypeName\"," +
                "\"value\":\"Generic Event\",\"operator\":\"ne\"}," +
                "{\"operator\":\"or\"," +
                "\"value\":[{\"property\":\"eventTypeCode\"," +
                "\"value\":\"CFG_RESP\",\"operator\":\"ne\"}," +
                "{\"operator\":\"and\"," +
                "\"value\":[{\"property\":\"eventTypeCode\"," +
                "\"value\":\"CFG_RESP\",\"operator\":\"eq\"}," +
                "{\"property\":\"commandTypeCode\",\"value\":true," +
                "\"operator\":\"exists\"},{\"property\":\"commandTypeCode\"," +
                "\"value\":\"passthrough\",\"operator\":\"ne\"}]}]}]}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("fileName", "VehiclesHistory");
        queryParams.put("filters", filterStrFormat);
        queryParams.put("sort", "startDate");
        queryParams.put("order", "desc");
        queryParams.put("startDate", startDate);
        queryParams.put("endDate", endDate);
        queryParams.put("limitTotal", false);
        queryParams.put("id", deviceId);
        queryParams.put("fields", "[\"formattedStartDate\",\"event\"," +
                "\"fullAddress\",\"formattedTotalCost\",\"user\"]");

        return exportDeviceHistory(driver, queryParams, fileType);
    }

    /**
     * Get vehicle finance device history data.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDeviceHistory(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.DeviceData> response = Unirest.get
                (getDeviceHistoryEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceData.class);
        return response.getBody();
    }

    /**
     * Get vehicle finance device history data of 30 days for given
     * vehicle
     *
     * @param driver
     * @param deviceId
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDeviceHistory(WebDriver driver, long deviceId) throws UnirestException {

        DateFormat DATE_FORMAT = new SimpleDateFormat
                ("yyyy-MM-dd");

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -29);
        String startDate = DATE_FORMAT.format(calendar.getTime());

        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, 1);
        String endDate = DATE_FORMAT.format(calendar.getTime());

        String filterStrFormat = "[{\"operator\":\"and\"," +
                "\"value\":[{\"property\":\"eventTypeName\"," +
                "\"value\":\"Generic Event\",\"operator\":\"ne\"}," +
                "{\"operator\":\"or\"," +
                "\"value\":[{\"property\":\"eventTypeCode\"," +
                "\"value\":\"CFG_RESP\",\"operator\":\"ne\"}," +
                "{\"operator\":\"and\"," +
                "\"value\":[{\"property\":\"eventTypeCode\"," +
                "\"value\":\"CFG_RESP\",\"operator\":\"eq\"}," +
                "{\"property\":\"commandTypeCode\",\"value\":true," +
                "\"operator\":\"exists\"},{\"property\":\"commandTypeCode\"," +
                "\"value\":\"passthrough\",\"operator\":\"ne\"}]}]}]}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("filterOperator", "or");
        queryParams.put("range", "30");
        queryParams.put("id", deviceId);
        queryParams.put("filters", filterStrFormat);
        queryParams.put("order", "desc");
        queryParams.put("sort", "startDate");
        queryParams.put("limitTotal", false);
        queryParams.put("startDate", startDate);
        queryParams.put("endDate", endDate);

        return getDeviceHistory(driver, queryParams);
    }

    /**
     * Download References data for given vehicle.
     * Accepted FileTypes = csv/pdf/excel
     *
     * @param driver
     * @param fileName
     * @param deviceId
     * @param fileType
     * @return
     * @throws UnirestException
     */
    public static InputStream exportDeviceReferences(WebDriver driver, String fileName, long deviceId,
                                                     String fileType) throws UnirestException {

        HttpResponse<InputStream> response = Unirest.get
                (exportDeviceReferencesEndpoint)
                .routeParam("fileType", fileType)
                .queryString("fileName", fileName)
                .queryString("deviceId", deviceId)
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Get the References for given vehicle
     *
     * @param driver
     * @param deviceId
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceReferencesData getDeviceReferences(WebDriver driver, long deviceId)
            throws UnirestException {

        HttpResponse<Device.DeviceReferencesData> response = Unirest.get
                (getDeviceReferencesEndpoint)
                .queryString("deviceId", deviceId)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceReferencesData.class);
        return response.getBody();
    }

    /**
     * Delete Reference using reference id.
     *
     * @param driver
     * @param id
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceReferencesData deleteDeviceReferences(WebDriver driver, long id)
            throws UnirestException {

        HttpResponse<Device.DeviceReferencesData> response = Unirest.delete
                (getDeviceReferencesEndpoint + "/{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", String.valueOf(id))
                .asObject(Device.DeviceReferencesData.class);
        return response.getBody();
    }

    /**
     * Delete list of References using respective reference ids.
     *
     * @param driver
     * @param referenceIds
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceReferencesData deleteDeviceReferences(WebDriver driver, List<Long> referenceIds)
            throws UnirestException {

        Device.DeviceReferencesData data = null;
        for (Long id : referenceIds) {
            data = deleteDeviceReferences(driver, id);
            if (data.success != true) {
                break;
            }
        }
        return data;
    }

    /**
     * Get Impound Lots data.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Device.LandmarkData getImpoundLots(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.LandmarkData> response = Unirest.get
                (landmarksEndpoint)
                .queryString(queryParams)
                .header("X-Nspire-UserToken", getCookieValue(driver, "X-Nspire-UserToken"))
                .asObject(Device.LandmarkData.class);
        return response.getBody();
    }

    /**
     * Get Impound Lots data with filter.
     *
     * @param driver
     * @param searchText
     * @return
     * @throws UnirestException
     */
    public static Device.LandmarkData getImpoundLots(WebDriver driver, String searchText)
            throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", "50");
        queryParams.put("sortBy", "name:asc");
        queryParams.put("offset", 0);
        queryParams.put("filter", searchText);

        return getImpoundLots(driver, queryParams);
    }

    /**
     * Get GeoFences.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceGeoFencesData getGeoFences(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.DeviceGeoFencesData> response = Unirest.get
                (getGeoFenceEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceGeoFencesData.class);
        return response.getBody();
    }

    /**
     * Get GeoFences with default parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceGeoFencesData getGeoFences(WebDriver driver) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("filterOperator", "or");
        queryParams.put("filters", "[]");
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getGeoFences(driver, queryParams);
    }

    /**
     * Get all GeoFences set for given vehicle.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceGeoFencesData getGeoFences(WebDriver driver, long deviceId)
            throws UnirestException {

        String filterStr = "[{\"property\":\"device.id\",\"value\":\"%s\"," +
                "\"comparison\":\"eq\",\"type\":\"Long\"}]";

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("sort", "name");
        queryParams.put("filter", String.format(filterStr, deviceId));

        return getGeoFences(driver, queryParams);
    }

    /**
     * Get GeoFences with default parameters.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceGeoFencesData getGeoFences(WebDriver driver, String searchText)
            throws UnirestException {

        String filterStr = "[{\"property\":\"name\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"type\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"address\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"city\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"state\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}," +
                "{\"property\":\"zip\",\"comparison\":\"ilike\",\"value\":\"%1$s\"}]";

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("filterOperator", "or");
        queryParams.put("offset", 0);
        queryParams.put("filters", String.format(filterStr, searchText));
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getGeoFences(driver, queryParams);
    }

    /**
     * Delete GeoFence using GeoFence id.
     *
     * @param driver
     * @param id
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceGeoFencesData deleteGeoFences(WebDriver driver, String id)
            throws UnirestException {

        HttpResponse<Device.DeviceGeoFencesData> response = Unirest.delete
                (getGeoFenceEndpoint + "{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", id)
                .asObject(Device.DeviceGeoFencesData.class);
        return response.getBody();
    }

    /**
     * Get Map bubble data for given global ID of the vehicle
     *
     * @param driver
     * @param globalId
     * @return
     * @throws UnirestException
     */
    public static Device.AssetApiData getAssetApi(WebDriver driver, String globalId)
            throws UnirestException {

        HttpResponse<Device.AssetApiData> response = Unirest.get
                (getAssetApiEndPoint)
                .queryString("globalId", globalId)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.AssetApiData.class);
        return response.getBody();
    }

    /**
     * Download vehicle finance device data.
     * Accepted FileTypes = csv/pdf/excel
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static InputStream exportDeviceData(WebDriver driver, Map<String, Object> queryParams, String fileType)
            throws UnirestException {

        HttpResponse<InputStream> response = Unirest.get
                (exportDeviceDataEndpoint)
                .routeParam("fileType", fileType)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Download vehicle finance device data with given account id and file type
     *
     * @param driver
     * @param fileType
     * @return
     * @throws UnirestException
     */
    public static InputStream exportDeviceData(WebDriver driver, long accountUserId, String fileType)
            throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();
        queryParams.put("config", "{\"queryFields\":[\"assetMake\"," +
                "\"assetModel\",\"assetName\",\"assetVfColor\"," +
                "\"assetVfStockNumber\",\"assetVin\",\"assetYear\",\n" +
                "\"operatorFirstName\",\"operatorLastName\",\"serialNumber\"," +
                "\"assetVflActivationDate\",\"networkRenewalDate\"," +
                "\"starterOn\",\n" +
                "\"warningOn\",\"assetVfDeviceStatus\"],\n" +
                "\"assetSearchFields\":[],\"landmarkSearchText\":null," +
                "\"assetSearchTags\":null,\"landmarkSearchTags\":null," +
                "\"notInAssetGroup\":false,\n" +
                "\"notInLandmarkGroup\":false,\"selectedAssetFilters\":[]," +
                "\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[],\n" +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}");
        queryParams.put("filter", "[{\"property\":\"networkActive\"," +
                "\"value\":true},{\"property\":\"networkNetworkActive\"," +
                "\"value\":true}]");
        queryParams.put("limit", 25);
        queryParams.put("sorts", "[]");
        queryParams.put("noSubgroups", true);
        queryParams.put("fields", "[\"assetVfStockNumber\"," +
                "\"operatorFirstName\",\"operatorLastName\",\"assetVin\"," +
                "\"assetYear\",\"assetMake\",\"assetModel\",\n" +
                "\"serialNumber\",\"assetVflActivationDate\"," +
                "\"networkRenewalDate\",\"starterOn\",\"warningOn\"," +
                "\"assetVflDeviceStatus\"]");
        queryParams.put("labels", "{\"assetVfStockNumber\":\"Stock Number\"," +
                "\"operatorFirstName\":\"First Name\"," +
                "\"operatorLastName\":\"Last Name\",\n" +
                "\"assetVin\":\"VIN\",\"assetYear\":\"Year\"," +
                "\"assetMake\":\"Make\",\"assetModel\":\"Model\"," +
                "\"serialNumber\":\"Serial\",\n" +
                "\"assetVflActivationDate\":\"Date Activated\"," +
                "\"networkRenewalDate\":\"Renewal Date\"," +
                "\"starterOn\":\"Starter Status\",\n" +
                "\"warningOn\":\"Warning On\"," +
                "\"assetVflDeviceStatus\":\"Device Status\"}");
        queryParams.put("assetOnly", true);
        queryParams.put("offset", 0);
        queryParams.put("total", 1);
        queryParams.put("accountUserId", accountUserId);

        if (fileType.equals("xls")) {
            fileType = "excel";
        }
        return exportDeviceData(driver, queryParams, fileType);
    }

    /**
     * Get Devices belonging to the Dealer
     *
     * @param driver      WebDriver object
     * @param queryParams a Map of query parameters to use with the request
     * @return Device Data with a list of devices
     * @throws UnirestException
     */
    public static Device.DeviceData getDeviceDealers(WebDriver driver, Map<String,
            Object> queryParams) throws UnirestException {

        HttpResponse<Device.DeviceData> response = Unirest.get
                (getDeviceDealerEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceData.class);
        return response.getBody();
    }

    /**
     * Get Devices belonging to the Dealer using given dealer id and lender id.
     *
     * @param driver
     * @param dealerGlobalId
     * @param lenderId
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceData getDeviceDealers(WebDriver driver, String dealerGlobalId, long lenderId)
            throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();

        queryParams.put("noSubgroups", true);
        queryParams.put("filter", "[{\"property\":\"networkActive\",\"value\":true}," +
                "{\"property\":\"networkNetworkActive\",\"value\":true}]");
        queryParams.put("config", "{\"queryFields\":[\"assetMake\",\"assetModel\",\"assetName\"," +
                "\"assetVfColor\",\"assetVfStockNumber\",\"assetVflStockNumber\",\"assetVin\",\"assetYear\"," +
                "\"operatorFirstName\",\"operatorLastName\",\"serialNumber\",\"assetVflActivationDate\"," +
                "\"networkRenewalDate\",\"starterOn\",\"warningOn\",\"assetVfDeviceStatus\"]," +
                "\"assetSearchFields\":[],\"landmarkSearchText\":null,\"assetSearchTags\":null," +
                "\"landmarkSearchTags\":null,\"notInAssetGroup\":false,\"notInLandmarkGroup\":false," +
                "\"selectedAssetFilters\":[],\"selectedLandmarkFilters\":[],\"selectedAssetGroups\":[]," +
                "\"selectedLandmarkGroups\":[],\"defaultOperator\":\"AND\"}");
        queryParams.put("sorts", "[]");
        queryParams.put("max", "50");
        queryParams.put("assetOnly", true);
        queryParams.put("offset", "0");
        queryParams.put("dealerGlobalId", dealerGlobalId);
        queryParams.put("lenderId", lenderId);

        return getDeviceDealers(driver, queryParams);
    }

    /**
     * Get Notes Data.
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceNotesData getNotes(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.DeviceNotesData> response = Unirest.get
                (getDeviceNotesEndPoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceNotesData.class);
        return response.getBody();
    }

    /**
     * Get Notes Data for given device assetId.
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceNotesData getNotes(WebDriver driver, long refId) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();

        queryParams.put("max", "50");
        queryParams.put("offset", "0");
        queryParams.put("refType", "AssetNotes");
        queryParams.put("refId", refId);
        queryParams.put("sorts", "[{\"property\":\"timestamp\",\"direction\":\"DESC\"}]");

        return getNotes(driver, queryParams);
    }

    /**
     * Get scheduled commands for current user
     *
     * @param driver
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceCommands getDeviceCommands(WebDriver driver) throws UnirestException {

        HashMap<String, Object> queryParams = new HashMap<>();

        queryParams.put("max", "50");
        queryParams.put("filterOperator", "or");
        queryParams.put("active", "true");
        queryParams.put("sorts", "[{\"property\":\"name\",\"direction\":\"ASC\"}]");

        return getDeviceCommands(driver, queryParams);
    }

    /**
     * Get scheduled commands for current user
     *
     * @param driver
     * @param queryParams
     * @return
     * @throws UnirestException
     */
    public static Device.DeviceCommands getDeviceCommands(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {

        HttpResponse<Device.DeviceCommands> response = Unirest.get
                (getDeviceCommandSpec)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Device.DeviceCommands.class);

        return response.getBody();
    }
}
