package com.procon.vehiclefinance.pageobjects.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.procon.vehiclefinance.util.WebElements.clickElementAndWaitForInvisibility;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerInvisible;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.assertTrue;

import java.util.logging.Logger;

public class AdminAMReviewOrderPage {

    protected WebDriver driver;

    private static final Logger logger = Logger
            .getLogger(AdminAMReviewOrderPage.class.getName());

    @FindBy(css = "div.col-sm-12 button.btn-primary")
    protected WebElement renewDevicesButton;

    @FindBy(css = "div.col-sm-12 button:nth-of-type(2)")
    protected WebElement cancelRenewalButton;

    @FindBy(css = "div.bootbox[style='display: block;']")
    protected WebElement bootboxAlertWindow;

    @FindBy(css = "div.bootbox-body")
    protected WebElement bootboxBody;

    @FindBy(css = "div.modal-footer button.btn-primary")
    protected WebElement okButton;

    @FindBy(css = "div.modal-footer > button.btn-danger")
    protected WebElement cancelConfirmYesBtn;

    @FindBy(css = "div.modal-footer > button.btn-cancel")
    protected WebElement cancelConfirmNoBtn;

    @FindBy(css = "button.btn.btn-secondary:nth-of-type(1)")
    protected WebElement reviewBackButton;

    public void clickCancelRenewalButton() {
        cancelRenewalButton.click();
    }

    public AdminAMReviewOrderPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public AdminAccountManagementPage renewDevices() {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(renewDevicesButton)).click();

        return PageFactory.initElements(driver, AdminAccountManagementPage.class);
    }

    public AdminAccountManagementPage cancelRenewal() {
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(cancelRenewalButton)).click();
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 5);
        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(cancelConfirmYesBtn)).click();
        waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
        return PageFactory.initElements(driver, AdminAccountManagementPage.class);
    }

    public String getConfirmationText() {
        waitUntilSpinnerInvisible(driver, 300);

        // Wait for alert box, get alert message
        new WebDriverWait(driver, 600).until(ExpectedConditions.visibilityOf(bootboxAlertWindow));
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(bootboxBody));

        String alertMessage = bootboxBody.getText();

        new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(okButton)).click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div.bootbox")));
        waitUntilSpinnerInvisible(driver);

        return alertMessage;
    }

    public String getRemoveDevicesCancelConfirmationText() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(bootboxBody)).getText();
    }

    public void clickCancelConfirmYesBtn() {
        clickElementAndWaitForInvisibility(driver, cancelConfirmYesBtn, By.cssSelector("div.bootbox"));
    }

    public void validateReviewOrderButtons() {
        assertTrue(reviewBackButton.isDisplayed());
        assertTrue(cancelRenewalButton.isDisplayed());
        assertTrue(renewDevicesButton.isDisplayed());
    }
}