package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.HttpRequest;
import com.procon.vehiclefinance.models.ExportFormat;
import com.procon.vehiclefinance.pageobjects.admin.User;
import com.procon.vehiclefinance.pageobjects.reports.Report;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.RetryPolicy;
import net.jodah.failsafe.function.CheckedConsumer;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class ReportService extends ServiceCaller {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportService.class);

    // retrieve history of reports
    private static String reportHistoryEndpoint;

    // retrieve existing report
    private static String displayReportEndpoint;

    // new report
    private static String outputReportEndpoint;

    // saved reports
    private static String savedReportsEndpoint;

    // export report
    private static String exportReportEndpoint;

    static {
        reportHistoryEndpoint = baseUrl +
                                    "operation/json/reportHistoryService/get";
        displayReportEndpoint = baseUrl + "report/displayReport/{reportId}";
        outputReportEndpoint = baseUrl + "report/outputReport/{reportType}";
        savedReportsEndpoint = baseUrl + "rest/json/reportSpec";
        exportReportEndpoint = baseUrl + "report/exportReport/{reportId}";
    }

    /**
     * Download report. This mimics the functionality of "Export" in the
     * reports page
     *
     * @param driver   WebDriver object
     * @param reportId Id of the report to get
     * @param format
     * @return
     * @throws UnirestException
     */
    public static InputStream exportReport(WebDriver driver, String reportId, ExportFormat format)
            throws UnirestException {
        HttpResponse<InputStream> response = Unirest.get
                (exportReportEndpoint)
                .routeParam("reportId", reportId)
                .queryString("format", format.getType())
                .header("Cookie", getDriverCookies(driver))
                .asBinary();
        return response.getRawBody();
    }

    /**
     * Get Saved reports. The list of these scheduled or immediate reports is
     * shown at the bottom of left bar in Reports page, and can be edited,
     * deleted or run.
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return Saved Report Results
     * @throws UnirestException
     */
    public static Report.SavedReportResults getSavedReports(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Report.SavedReportResults> response = Unirest.get
                (savedReportsEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Report.SavedReportResults.class);
        return response.getBody();
    }

    /**
     * Get Saved reports with currently logged in user and default query
     * params. The list of these scheduled or immediate reports is
     * shown at the bottom of left bar in Reports page, and can be edited,
     * deleted or run.
     *
     * @param driver WebDriver object
     * @return Saved Report Results
     * @throws UnirestException
     */
    public static Report.SavedReportResults getSavedReports(WebDriver driver)
            throws UnirestException, IOException {
        User.UserSettings userSettings = getUserSettings(driver);
        int requestedByAccountUserId = userSettings.accountUserId;

        Map<String, Object> queryParams = new HashMap<>();
        String filters = "[{\"property\":\"userSaved\",\"value\":true}," +
                "{\"property\":\"requestedBy.id\",\"value\":%d," +
                "\"type\":\"Long\"}]";
        queryParams.put("filters", String.format(filters, requestedByAccountUserId));
        queryParams.put("sorts", "[{\"property\":\"userName\"," +
                "\"direction\":\"ASC\"}]");

        return getSavedReports(driver, queryParams);
    }

    /**
     * Return the output report. This is the service call that is made when a
     * new report is run. This returns a unique report id that can be used to
     * fetch the report using {@link #getDisplayReport(WebDriver, String, Map, Class)}
     *
     * @param driver      WebDriver object
     * @param reportType  type of report to run
     * @param queryParams query parameters to pass to get request
     * @return
     * @throws UnirestException
     */
    public static Report.ReportOutput outputReport(WebDriver driver, String reportType, Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Report.ReportOutput> response = Unirest.get
                (outputReportEndpoint)
                .routeParam("reportType", reportType)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Report.ReportOutput.class);
        return response.getBody();
    }

    /**
     * Get report data. This call retrieves the report identified by reportId
     *
     * @param driver        WebDriver object
     * @param reportId      Id of the report to get
     * @param queryParams   query parameters to pass to get request
     * @param responseClass type of ReportData
     * @param <T>
     * @return ReportData class of type T
     * @throws UnirestException
     */
    public static <T extends Report.ReportData> T getDisplayReport(WebDriver driver, String reportId,
                                                                   Map<String, Object> queryParams, Class<T> responseClass)
            throws UnirestException {
        HttpRequest request = Unirest.get
                (displayReportEndpoint)
                .routeParam("reportId", reportId)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .header("Content-Type", "application/json");

        RetryPolicy retryPolicy = new RetryPolicy()
                .withDelay(15, TimeUnit.SECONDS)
                .withMaxRetries(3)
                .retryOn(UnirestException.class);
        HttpResponse<T> response = Failsafe.with(retryPolicy)
                .onRetry((c, f, ctx) -> LOGGER.warn("Failure #{0}. {1}",
                        new Object[]{ctx.getExecutions(), f.getLocalizedMessage()}))
                .withFallback((CheckedConsumer<? extends Throwable>) failure
                        -> {
                    throw new AssertionError("Failed to get Report " +
                            "by reportId: " + reportId);
                })
                .get(() -> request.asObject(responseClass));
        return response.getBody();

    }

    /**
     * Get the reports history
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return report history results
     * @throws UnirestException
     */
    public static Report.ReportHistoryResults getReportHistoryResults(WebDriver driver, Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<Report.ReportHistoryResults> response = Unirest.get
                (reportHistoryEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Report.ReportHistoryResults.class);
        return response.getBody();
    }

    /**
     * Get the reports history of 30 days
     *
     * @param driver WebDriver object
     * @return report history results
     * @throws UnirestException
     * @throws IOException
     */
    public static Report.ReportHistoryResults getReportHistoryResults(WebDriver driver)
            throws UnirestException, IOException {

        User.UserSettings userSettings = getUserSettings(driver);
        int accountId = userSettings.accountId;
        int requestedByAccountUserId = userSettings.accountUserId;

        //Get current date - 30 days
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -30);
        String dateStr = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:sss'Z'")).format(c.getTime());

        String filterStrFormat = "[{\"property\":\"accountId\",\"value\":%d," +
                "\"type\":\"Long\"},{\"property\":\"executionStart\"," +
                "\"value\":\"%s\",\"type\":\"Date\"," +
                "\"operator\":\"gte\"}," +
                "{\"property\":\"requestedByAccountUserId\",\"value\":%d," +
                "\"type\":\"Long\"}]";
        String filterStr = String.format(filterStrFormat, accountId,
                dateStr, requestedByAccountUserId);

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("offset", 0);
        queryParams.put("filters", filterStr);
        queryParams.put("sorts", "[{\"property\":\"executionStart\"," +
                "\"direction\":\"DESC\"}]");

        return getReportHistoryResults(driver, queryParams);
    }
}