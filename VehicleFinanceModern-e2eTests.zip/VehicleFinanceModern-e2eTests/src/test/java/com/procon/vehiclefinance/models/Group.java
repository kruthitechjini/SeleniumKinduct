package com.procon.vehiclefinance.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * This class defines the objects needed to handle the various response
 * objects from Group service calls
 */
public class Group {

    public static class GroupItem {
        public boolean defaultGroup;
        public long groupId;
        public long id;
        public String name;
    }

    public static class GroupData {
        public List<GroupItem> data;
        public String msg;
        public boolean success;
        public int total;
    }
}
