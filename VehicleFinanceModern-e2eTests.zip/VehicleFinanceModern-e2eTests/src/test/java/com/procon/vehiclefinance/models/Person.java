package com.procon.vehiclefinance.models;

public class Person {
    private String firstName;
    private String lastName;
    private String username;
    private String userType;
    private String phone;
    private String email;

    private Person(String firstName, String lastName, String username,
                   String userType, String phone, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.userType = userType;
        this.phone = phone;
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getUserType() {
        return userType;
    }

    public static class PersonBuilder {
        private String firstName;
        private String lastName;
        private String username;
        private String userType;
        private String phone;
        private String email;

        public PersonBuilder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public PersonBuilder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public PersonBuilder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public PersonBuilder email(String email) {
            this.email = email;
            return this;
        }

        public PersonBuilder username(String username) {
            this.username = username;
            return this;
        }

        public PersonBuilder userType(String userType) {
            this.userType = userType;
            return this;
        }

        public Person build() {
            return new Person(firstName, lastName, username, userType, phone,
                    email);
        }
    }
}
