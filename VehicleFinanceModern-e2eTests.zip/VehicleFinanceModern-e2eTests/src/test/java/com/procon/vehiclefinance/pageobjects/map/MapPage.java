package com.procon.vehiclefinance.pageobjects.map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MapPage
{

    WebDriver driver;

    @FindBy(css = "div.search-bar")
    private WebElement searchInput;

    @FindBy(css = "div.segmented-control > button:nth-child(2)")
    private WebElement listViewButton;

    public MapPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getListViewButton() {
        return listViewButton;
    }

    public WebElement getSearchInput() {
        return searchInput;
    }

    public Boolean isSearchDislayed() {
        return searchInput.isDisplayed();
    }


}
