package com.procon.vehiclefinance.pageobjects.reports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;

public class AdvancedReportsPageGSE extends AdvancedReportsPage {

    protected static final Logger logger = LoggerFactory.getLogger(AdvancedReportsPage.class);

    // left panel elements
    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(2) select")
    private WebElement deviceStatusDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(3) input")
    private WebElement dealersDropdown;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(4) input")
    private WebElement groupsInput;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(4) label")
    private WebElement groupsLabel;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(5) input")
    private WebElement vehiclesInput;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(5) label")
    private WebElement vehiclesLabel;

    @FindBy(css = "div.modal-body div.selection-panel div.row:nth-of-type(6) select")
    private WebElement dateRangeDropdown;

    public AdvancedReportsPageGSE(WebDriver driver) {
        super(driver);
    }

    @Override
    public WebElement getGroupsInput() {
        return groupsInput;
    }

    @Override
    public WebElement getGroupsLabel() {
        return groupsLabel;
    }

    @Override
    public WebElement getVehiclesLabel() {
        return vehiclesLabel;
    }

    @Override
    public WebElement getVehiclesInput() {
        return vehiclesInput;
    }

    @Override
    public WebElement getDateRangeDropdown() {
        return dateRangeDropdown;
    }

    /**
     * Run advanced report for GSE user
     *
     * @param reportType
     * @param deviceStatus
     * @param dealers
     * @param groupNames
     * @param vehicleNames
     * @param dateRange
     * @param reportName
     * @param date
     * @param stockStatus
     * @param recipients
     * @param reportFormat
     */
    public void runAdvancedReport(ReportTypeEnum reportType, String deviceStatus, String dealers, String groupNames,
                                  String vehicleNames, DateRangeEnum dateRange, String reportName, String date,
                                  Boolean stockStatus, List<String> recipients, String reportFormat) {
        enterReportParams(reportType, groupNames, vehicleNames, dateRange);
        selectDeviceStatus(deviceStatus);
        selectDealers(dealers);
        selectCustomDate(date);
        checkStockNumberBox(stockStatus);
        clickSaveConfigTabLink();
        enterReportName(reportName);
        addRecipient(recipients, reportFormat);
        clickRunButton();
    }

    public void selectDeviceStatus(String deviceStatus) {
        if (deviceStatus != null) {
            new Select(deviceStatusDropdown).selectByVisibleText(deviceStatus);
        }
    }

    private void selectDealers(String dealerName) {
        if (dealerName != null) {
            enterText(driver, dealersDropdown, dealerName);
        }
    }
}