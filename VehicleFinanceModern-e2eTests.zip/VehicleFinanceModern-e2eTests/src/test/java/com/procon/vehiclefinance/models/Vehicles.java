package com.procon.vehiclefinance.models;

public class Vehicles {

    private String displayName;
    private String stockNumber;
    private String vin;
    private String vehicleMake;
    private String vehicleModel;
    private String vehicleYear;
    private String vehicleColor;
    private String vehicleInitialOdometer;
    private String vehicleLicencePlate;
    private String vehicleMileage;

    public Vehicles(String displayName, String stockNumber, String vin, String vehicleMake,
                    String vehicleModel, String vehicleYear, String vehicleColor,
                    String vehicleInitialOdometer, String vehicleLicencePlate,
                    String vehicleMileage) {

        this.displayName = displayName;
        this.stockNumber = stockNumber;
        this.vin = vin;
        this.vehicleMake = vehicleMake;
        this.vehicleModel = vehicleModel;
        this.vehicleYear = vehicleYear;
        this.vehicleColor = vehicleColor;
        this.vehicleInitialOdometer = vehicleInitialOdometer;
        this.vehicleLicencePlate = vehicleLicencePlate;
        this.vehicleMileage = vehicleMileage;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getStockNumber() {
        return stockNumber;
    }

    public String getVin() {
        return vin;
    }

    public String getVehicleMake() {
        return vehicleMake;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public String getVehicleYear() {
        return vehicleYear;
    }

    public String getVehicleColor() {
        return vehicleColor;
    }

    public String getVehicleInitialOdometer() {
        return vehicleInitialOdometer;
    }

    public String getVehicleLicencePlate() {
        return vehicleLicencePlate;
    }

    public String getVehicleMileage() {
        return vehicleMileage;
    }

    public void setStockNumber(long stockNumber) {
        this.stockNumber = String.valueOf(stockNumber);
    }

    public static class VehiclesBuilder {
        private String displayName;
        private String stockNumber;
        private String vin;
        private String vehicleMake;
        private String vehicleModel;
        private String vehicleYear;
        private String vehicleColor;
        private String vehicleInitialOdometer;
        private String vehicleLicencePlate;
        private String vehicleMileage;

        public VehiclesBuilder displayName(String displayName) {
            this.displayName = displayName;
            return this;
        }

        public VehiclesBuilder stockNumber(String stockNumber) {
            this.stockNumber = stockNumber;
            return this;
        }

        public VehiclesBuilder vin(String vin) {
            this.vin = vin;
            return this;
        }

        public VehiclesBuilder vehicleMake(String vehicleMake) {
            this.vehicleMake = vehicleMake;
            return this;
        }

        public VehiclesBuilder vehicleModel(String vehicleModel) {
            this.vehicleModel = vehicleModel;
            return this;
        }

        public VehiclesBuilder vehicleYear(String vehicleYear) {
            this.vehicleYear = vehicleYear;
            return this;
        }

        public VehiclesBuilder vehicleColor(String vehicleColor) {
            this.vehicleColor = vehicleColor;
            return this;
        }

        public VehiclesBuilder vehicleInitialOdometer(String vehicleInitialOdometer) {
            this.vehicleInitialOdometer = vehicleInitialOdometer;
            return this;
        }

        public VehiclesBuilder vehicleLicencePlate(String vehicleLicencePlate) {
            this.vehicleLicencePlate = vehicleLicencePlate;
            return this;
        }

        public VehiclesBuilder vehicleMileage(String vehicleMileage) {
            this.vehicleMileage = vehicleMileage;
            return this;
        }

        public Vehicles build() {
            return new Vehicles(displayName, stockNumber, vin, vehicleMake, vehicleModel,
                    vehicleYear, vehicleColor, vehicleInitialOdometer,
                    vehicleLicencePlate, vehicleMileage);
        }
    }

}
