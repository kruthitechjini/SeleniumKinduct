package com.procon.vehiclefinance.pageobjects.admin;

import com.google.common.collect.Maps;
import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Device;
import com.procon.vehiclefinance.models.GeoCoord;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.collections.Lists;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

public class AdminGeoBoundsPage extends CommonGrid {

    private static final Logger logger = LoggerFactory
            .getLogger(AdminGeoBoundsPage.class);

    @FindBy(css = "button.gridButton:nth-child(2)")
    protected WebElement addGeoFencesBtn;

    @FindBy(css = "button.gridButton:nth-child(3)")
    protected WebElement addGeoZonesBtn;

    @FindBy(css = "input[name='name']")
    protected WebElement nameInput;

    @FindBy(css = "input[name='address']")
    protected WebElement addressInput;

    @FindBy(css = "input[name='city']")
    protected WebElement cityInput;

    @FindBy(css = "select[name='state']")
    protected WebElement stateDropdown;

    @FindBy(css = "input[name='zip']")
    protected WebElement zipInput;

    @FindBy(css = "select[name='country']")
    protected WebElement countryDropdown;

    @FindBy(css = "input[name='lat']")
    protected WebElement latitudeInput;

    @FindBy(css = "input[name='lng']")
    protected WebElement longitudeInput;

    @FindBy(css = "input[name='radiusMiles']")
    protected WebElement radiusInput;

    @FindBy(css = "i.glyphicon-arrow-up")
    protected WebElement convertGpsToAddress;

    @FindBy(css = "i.glyphicon-arrow-down")
    protected WebElement convertAddressToGps;

    @FindBy(css = "input[value='rectangle']")
    protected WebElement rectangleRadioBtn;

    @FindBy(css = "input[value='circle']")
    protected WebElement circleRadioBtn;

    @FindBy(css = "input[value='polygon']")
    protected WebElement polygonRadioBtn;

    @FindBy(css = "div.modal-body > div.form-horizontal div" +
            ".geofence-map-wrapper div.leaflet-control-layers")
    private WebElement modalMapZoomInBtn;

    private static final String SAVE_BTN_XPATH = "//button[text()='Save']";
    @FindBy(xpath = SAVE_BTN_XPATH)
    protected WebElement saveBtn;

    private static final String CANCEL_BTN_XPATH = "//button[text()='Cancel']";
    @FindBy(xpath = CANCEL_BTN_XPATH)
    protected WebElement cancelBtn;

    private static final String CLOSE_BTN_CSS = "div.modal-header > button" +
            ".close";
    @FindBy(css = CLOSE_BTN_CSS)
    protected WebElement closeBtn;

    @FindBy(css = "span.panel-title")
    private WebElement panelTitle;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "button[title='Map All']")
    private WebElement mapAllBtn;

    private static final String MAP_PINS_CSS = "div.leaflet-marker-pane img";
    @FindBy(css = MAP_PINS_CSS)
    private WebElement mapPins;

    @FindBy(css = "img[src*='drag-marker-circle']")
    private WebElement mapDragMarkerCircle;

    @FindBy(css = "img[src*='drag-marker-square']")
    private WebElement mapDragMarkerRectangle;

    @FindBy(css = "div.modern-bubble-headline-title.ellipsis")
    private WebElement mapBubbleHeadline;

    @FindBy(css = "dd.formatted-address.map-bubble-location")
    private WebElement mapBubbleLocation;

    @FindBy(css = "div.modern-bubble-content dd:nth-of-type(2)")
    private WebElement mapBubblePosition;

    @FindBy(css = "div.modern-bubble-content dd:nth-of-type(3)")
    private WebElement mapBubbleShape;

    static final String MAP_ZOOM_IN_CSS = "[title='Zoom in']";
    @FindBy(css = MAP_ZOOM_IN_CSS)
    private WebElement mapZoomIn;

    static final String MAP_ZOOM_OUT_CSS = "[title='Zoom out']";
    @FindBy(css = MAP_ZOOM_OUT_CSS)
    private WebElement mapZoomOut;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header > h4.modal-title")
    private WebElement modalTitle;

    @FindBy(css = "a.help-icon-link")
    private WebElement helpLink;

    @FindBy(css = "div.bootbox-body.bootbox-wrap")
    private WebElement helpLinkMessage;

    private static final String OK_BTN_CSS = "button[data-bb-handler='ok']";
    @FindBy(css = OK_BTN_CSS)
    private WebElement okBtn;

    @FindBy(css = "div.has-error span[for='name']")
    private WebElement nameErrorMessage;

    @FindBy(css = "div.has-error span[for='address']")
    private WebElement addressErrorMessage;

    @FindBy(css = "div.has-error span[for='city']")
    private WebElement cityErrorMessage;

    @FindBy(css = "div.has-error span[for='state']")
    private WebElement stateErrorMessage;

    @FindBy(css = "div.has-error span[for='zip']")
    private WebElement zipErrorMessage;

    @FindBy(css = "div.has-error span[for='radiusMiles']")
    private WebElement radiusErrorMessage;

    @FindBy(xpath = "//button[text()='Import']")
    private WebElement importBtn;

    @FindBy(css = "div[id='modal'] button.btn-primary")
    private WebElement modalImportBtn;

    @FindBy(css = "input[name='csv']")
    private WebElement chooseFileBtn;

    @FindBy(css = "button.btn-cancel")
    private WebElement closeModalBtn;

    @FindBy(xpath = "//button[text()='Print']")
    private WebElement printBtn;

    @FindBy(xpath = "//button[text()='Export']")
    private WebElement exportBtn;

    @FindBy(css = "table.geozone-import-failures-table")
    private WebElement importFailuresTable;


    public AdminGeoBoundsPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void clickAddGeoFencesBtn() {
        addGeoFencesBtn.click();
    }

    public void clickAddGeoZonesBtn() {
        addGeoZonesBtn.click();
    }

    /**
     * Add a geofence/geozone by address
     *
     * @param name             name of geofence/geozone
     * @param address          address to enter
     * @param populateGeoCoord whether to click on button to populate lat/long
     * @param radius           radius
     * @param shapeType        type of shape ("Rectange", "Circle" or "Polygon")
     * @return geo-coords looked up based on address, if specified, null
     * otherwise
     */
    public GeoCoord addGeoBoundByAddress(String name, Address address,
                                         boolean populateGeoCoord, String
                                                 radius, String shapeType) {
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf
                (modalMapZoomInBtn));
        enterName(name);
        GeoCoord geoCoord = enterAddress(address, populateGeoCoord);
        enterRadius(radius);
        selectShapeType(shapeType);
        submitForm();
        return geoCoord;
    }

    /**
     * Add a geofence/geozone by latitude/longitude
     *
     * @param name            name of geofence/geozone
     * @param geoCoord        coordinates to enter (lat/long)
     * @param populateAddress whether to click on the button to populate address
     * @param radius          radius
     * @param shapeType       type of shape ("Rectange", "Circle" or "Polygon")
     * @return the address looked up based on lat/long, if specified. null
     * otherwise
     */
    public Address addGeoBoundByLatLong(String name, GeoCoord geoCoord,
                                        boolean populateAddress, String
                                                radius, String shapeType) {
        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf
                (modalMapZoomInBtn));
        enterName(name);
        Address address = enterGeoCoord(geoCoord, populateAddress);
        enterRadius(radius);
        selectShapeType(shapeType);
        submitForm();
        return address;
    }

    /**
     * Search for geofence/geozone by name and edit the address
     *
     * @param name             name of geofence/geozone
     * @param address          new address
     * @param populateGeoCoord whether to click on button to populate lat/long
     * @return geo-coords looked up based on address, if specified, null
     * otherwise
     */
    public GeoCoord editAddress(String name, Address address, boolean
            populateGeoCoord) {
        waitUntilSpinnerInvisible(driver, 5);
        super.editSearchedRecord(name);

        GeoCoord geoCoord = enterAddress(address, populateGeoCoord);
        submitForm();
        return geoCoord;

    }

    /**
     * Search for geofence/geozone by name and edit the lat/long
     *
     * @param name            name of geofence/geozone
     * @param geoCoord        new geo-coords
     * @param populateAddress whether to click on button to populate address
     * @param radius          radius
     * @param shapeType       type of shape ("Rectange", "Circle" or "Polygon")
     * @return the address looked up based on lat/long, if specified. null
     * otherwise
     */
    public Address editLatLong(String name, GeoCoord geoCoord, boolean
            populateAddress, String radius, String shapeType) {
        waitUntilSpinnerInvisible(driver, 5);
        super.editSearchedRecord(name);
        Address address = enterGeoCoord(geoCoord, populateAddress);
        enterRadius(radius);
        selectShapeType(shapeType);
        submitForm();
        return address;

    }

    public MapPage deleteGeoBound(String nameData) {
        super.deleteSearchedRecord(nameData);
        return PageFactory.initElements(driver, MapPage.class);
    }

    /**
     * Enter name of the geofence/geozone in name input field
     *
     * @param name name of geofence/geozone
     */
    public void enterName(String name) {
        // wait till page is ready
        waitUntilSpinnerInvisible(driver, 20);
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(nameInput));

        nameInput.clear();
        nameInput.sendKeys(name);
    }

    /**
     * Enter Geo-coordinates (lat/long)
     *
     * @param geoCoord        coordinates to enter (lat/long)
     * @param populateAddress whether to click on the button to populate address
     * @return the address looked up based on lat/long, if specified. null
     * otherwise
     */
    public Address enterGeoCoord(GeoCoord geoCoord, boolean populateAddress) {
        // wait till page is ready
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(latitudeInput));

        Address address = null;
        if (geoCoord.getLatitude() != null) {
            latitudeInput.clear();
            latitudeInput.sendKeys(geoCoord.getLatitude().toString());
        }
        if (geoCoord.getLongitude() != null) {
            longitudeInput.clear();
            longitudeInput.sendKeys(geoCoord.getLongitude().toString());
        }

        if (populateAddress) {
            convertGpsToAddress.click();

            // wait until the address is populated
            new WebDriverWait(driver, 5).until(d -> addressInput.getAttribute
                    ("value").length() != 0);

            // get the address values so they can be returned
            address = new Address.AddressBuilder()
                    .street(addressInput.getAttribute("value"))
                    .city(cityInput.getAttribute("value"))
                    .state(new Select(stateDropdown).getFirstSelectedOption().getText())
                    .postalCode(zipInput.getAttribute("value"))
                    .country(new Select(countryDropdown).getFirstSelectedOption()
                            .getText())
                    .build();
        }
        return address;
    }

    /**
     * Enter address
     *
     * @param address          address to enter
     * @param populateGeoCoord whether to click on button to populate lat/long
     * @return geo-coords looked up based on address, if specified, null
     * otherwise
     */
    public GeoCoord enterAddress(Address address, boolean populateGeoCoord) {
        // wait till page is ready
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(addressInput));

        GeoCoord geoCoord = null;
        if (address.getStreet() != null) {
            addressInput.clear();
            addressInput.sendKeys(address.getStreet());
        }
        if (address.getCity() != null) {
            cityInput.clear();
            cityInput.sendKeys(address.getCity());
        }
        if (address.getState() != null) {
            new Select(stateDropdown).selectByVisibleText(address.getState());
        }
        if (address.getPostalCode() != null) {
            zipInput.clear();
            zipInput.sendKeys(address.getPostalCode());
        }
        if (address.getCountry() != null) {
            new Select(countryDropdown).selectByVisibleText(address.getCountry());
        }

        if (populateGeoCoord) {
            convertAddressToGps.click();

            // wait until lat/long is populated
            new WebDriverWait(driver, 5).until(d -> latitudeInput.getAttribute
                    ("value").length() != 0);

            // get lat/long values so they can be returned
            geoCoord = new GeoCoord.GeoCoordBuilder()
                    .lat(Double.parseDouble(latitudeInput.getAttribute("value")))
                    .lng(Double.parseDouble(longitudeInput.getAttribute
                            ("value")))
                    .build();
        }
        return geoCoord;
    }

    public void enterRadius(String radius) {
        if (radius == null)
            return;
        // wait till page is ready
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(radiusInput));
        radiusInput.clear();
        radiusInput.sendKeys(radius);
    }

    public void selectShapeType(String shapeType) {
        if (shapeType == null)
            return;

        // wait till page is ready
        waitUntilSpinnerInvisible(driver, 10);
        new WebDriverWait(driver, 10).until(
                elementToBeClickable(rectangleRadioBtn));
        switch (shapeType.toLowerCase()) {
            case "rect":
            case "rectangle":
                rectangleRadioBtn.click();
                break;
            case "circle":
                circleRadioBtn.click();
                break;
            case "polygon":
                polygonRadioBtn.click();
                break;
            default:
                throw new WebDriverException("Invalid Shape Type");
        }

    }

    public void submitForm() {
        //make sure save button can be clicked
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(saveBtn)).click();

        // after save is clicked Save button should be invisible along with
        // the form
        new WebDriverWait(driver, 5).until(invisibilityOfElementLocated(By
                .xpath(SAVE_BTN_XPATH)));
    }

    public void cancelForm() {
        //make sure cancel button can be clicked
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(cancelBtn)).click();

        // after save is clicked cancle button should be invisible along with
        // the form
        new WebDriverWait(driver, 5).until(invisibilityOfElementLocated(By
                .xpath(CANCEL_BTN_XPATH)));
    }

    /**
     * Helper method to close the modal if it is not needed. This is useful
     * when test case needs to be retried
     */
    public void clickCloseBtn() {
        try {
            clickElementAndWaitForInvisibility(driver, closeBtn, By.cssSelector
                    (CLOSE_BTN_CSS));
        } catch (TimeoutException | ElementNotVisibleException |
                StaleElementReferenceException e) {
            // log warning and ignore exception
            logger.warn("Caught Exception while trying to " +
                    "close Geo modal: {0}", e.getLocalizedMessage());
        }
    }

    /**
     * Check if the add/edit form is displayed. This is done by checking the
     * existence of save button
     *
     * @return true if the Add/Edit modal form is displayed
     */
    public boolean isFormDisplayed() {
        waitUntilSpinnerInvisible(driver, 20);
        return isElementPresent(driver, By.xpath(CANCEL_BTN_XPATH));
    }

    public WebElement getPanelTitle() {
        return panelTitle;
    }

    /**
     * Get header column names of grid.
     *
     * @return
     */
    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getMapAllBtn() {
        return mapAllBtn;
    }

    public WebElement getAddGeoFencesBtn() {
        return addGeoFencesBtn;
    }

    /**
     * Get First Record from Grid
     *
     * @return
     */
    public HashMap<String, String> getTableFirstRow() {

        HashMap<String, String> gridFirstRecord = getTableFirstRow(gridBody);
        gridFirstRecord.remove("Actions");

        return gridFirstRecord;
    }

    /**
     * Get First Record from API
     *
     * @param geoFencesData
     * @return
     */
    public HashMap<String, String> getApiFirstRecord(List<Device.DeviceGeoFencesDetail> geoFencesData) {

        HashMap<String, String> apiFirstRecord = new HashMap<>();

        apiFirstRecord.put("Name", geoFencesData.get(0).name);
        apiFirstRecord.put("Shape", StringUtils.capitalize(geoFencesData.get(0).type));
        apiFirstRecord.put("Address", geoFencesData.get(0).address + " " + geoFencesData.get(0).city
                + ", " + geoFencesData.get(0).state + " " + geoFencesData.get(0).zip);
        apiFirstRecord.put("Latitude", geoFencesData.get(0).lat.toString());
        apiFirstRecord.put("Longitude", geoFencesData.get(0).lng.toString());
        apiFirstRecord.put("Assigned", geoFencesData.get(0).assignedDevicesCount.toString());

        return apiFirstRecord;
    }

    public WebElement getMapPins() {
        return mapPins;
    }

    public WebElement getMapBubbleHeadline() {
        return mapBubbleHeadline;
    }

    public WebElement getMapBubbleLocation() {
        return mapBubbleLocation;
    }

    public WebElement getMapBubblePosition() {
        return mapBubblePosition;
    }

    public WebElement getMapBubbleShape() {
        return mapBubbleShape;
    }

    public WebElement getMapZoomIn() {
        return mapZoomIn;
    }

    /**
     * Get number of map pins displayed.
     *
     * @return
     */
    public int getNumberOfMapPins() {
        return driver.findElements(By.cssSelector(MAP_PINS_CSS)).size();
    }

    /**
     * Click on the given map pin number
     *
     * @param pinNumber
     */
    public void clickMapPin(int pinNumber) {
        driver.findElement(By.cssSelector(MAP_PINS_CSS + ":nth-of-type(" +
                pinNumber + ")")).click();
    }

    /**
     * Click on the given row
     *
     * @param rowNumber
     */
    public void clickRow(int rowNumber) {
        clickRow(gridBody.findElement(By.cssSelector("div.ember-table-body-container")),
                rowNumber);
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    public WebElement getModalTitle() {
        return modalTitle;
    }

    public WebElement getNameInput() {
        return nameInput;
    }

    public WebElement getAddressInput() {
        return addressInput;
    }

    public WebElement getCityInput() {
        return cityInput;
    }

    public WebElement getStateDropdown() {
        return stateDropdown;
    }

    public WebElement getZipInput() {
        return zipInput;
    }

    public WebElement getCountryDropdown() {
        return countryDropdown;
    }

    public WebElement getConvertAddressToGps() {
        return convertAddressToGps;
    }

    public WebElement getConvertGpsToAddress() {
        return convertGpsToAddress;
    }

    public WebElement getLatitudeInput() {
        return latitudeInput;
    }

    public WebElement getLongitudeInput() {
        return longitudeInput;
    }

    public WebElement getRadiusInput() {
        return radiusInput;
    }

    public WebElement getRectangleRadioBtn() {
        return rectangleRadioBtn;
    }

    public WebElement getCircleRadioBtn() {
        return circleRadioBtn;
    }

    public WebElement getHelpLink() {
        return helpLink;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getCancelBtn() {
        return cancelBtn;
    }

    public WebElement getNameErrorMessage() {
        return nameErrorMessage;
    }

    public WebElement getAddressErrorMessage() {
        return addressErrorMessage;
    }

    public WebElement getCityErrorMessage() {
        return cityErrorMessage;
    }

    public WebElement getStateErrorMessage() {
        return stateErrorMessage;
    }

    public WebElement getZipErrorMessage() {
        return zipErrorMessage;
    }

    public WebElement getHelpLinkMessage() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(helpLinkMessage));
    }

    public void clickOkBtn() {
        clickElementAndWaitForInvisibility(driver, okBtn, By.cssSelector(OK_BTN_CSS));
    }

    public void enterRadiusInput(String radius) {
        radiusInput.clear();
        radiusInput.sendKeys(radius);
    }

    public WebElement getRadiusErrorMessage() {
        return radiusErrorMessage;
    }

    public void clickConvertGpsToAddress()
    {
        convertGpsToAddress.click();
        waitUntilSpinnerVisibleThenInvisible(driver,1 ,5 );
    }

    public void clickconvertAddressToGps()
    {
        convertAddressToGps.click();
        waitUntilSpinnerVisibleThenInvisible(driver,1 ,5 );
    }

    public boolean isMapDragMarkerCircleVisible() {
        try {
            return mapDragMarkerCircle.isDisplayed();
        }
        catch (NoSuchElementException e) {
            return false;
        }
    }

    public boolean isMapDragMarkerRectangleVisible() {
        try {
            return mapDragMarkerRectangle.isDisplayed();
        }
        catch (NoSuchElementException e) {
            return false;
        }
    }

    public void clickImportBtn()
    {
        importBtn.click();
        new WebDriverWait(driver,5 ).until(ExpectedConditions.visibilityOf(modalImportBtn));
    }

    public WebElement getModalImportBtn() {
        return modalImportBtn;
    }

    public WebElement getChooseFileBtn() {
        return chooseFileBtn;
    }

    public List<String> getImportGeozonesExpectedColumns()
    {
        List<String> list = new ArrayList<>();
        driver.findElements(By.cssSelector("div.col-md-12 > ul > li")).forEach(c -> list.add(c.getText()));

        return list;
    }

    public boolean isTextPresent(String text)
    {
        return driver.findElements(By.xpath("//*[text()='" + text + "']")).size() > 0 ? true : false;
    }

    public void clickModalImportBtn()
    {
        modalImportBtn.click();
        waitUntilSpinnerVisibleThenInvisible(driver,1 ,10 );
        new WebDriverWait(driver,20 ).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public HashMap<String, String> getImportResults()
    {
        HashMap<String, String> result = Maps.newHashMap();
        result.put("Success",
                driver.findElements(By.cssSelector("h5.form-control-static")).get(0).getText());
        result.put("Failure",
                driver.findElements(By.cssSelector("h5.form-control-static")).get(1).getText());
        return result;
    }

    public WebElement getCloseModalBtn() {
        return closeModalBtn;
    }

    public WebElement getPrintBtn() {
        return printBtn;
    }

    public WebElement getExportBtn() {
        return exportBtn;
    }

    public WebElement getImportFailuresTable() {
        return importFailuresTable;
    }

    public List<String> getImportFailuresTableColumns() {
        List<String> list = Lists.newArrayList();

        importFailuresTable.findElements(By.cssSelector("th")).forEach(
                c -> list.add(c.getText()));
        return list;

    }

    public WebElement getAddGeoZonesBtn() {
        return addGeoZonesBtn;
    }
}
