package com.procon.vehiclefinance.pageobjects.admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by SukjinderPurewal on 7/18/17.
 */
public class AccountManagementPage {
    WebDriver driver;

    @FindBy(linkText = "Renewals")
    private WebElement renewalsLink;

    public AccountManagementPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public Boolean isRenewalsLinkEnabled() {
           return renewalsLink.isEnabled();
    }
}
