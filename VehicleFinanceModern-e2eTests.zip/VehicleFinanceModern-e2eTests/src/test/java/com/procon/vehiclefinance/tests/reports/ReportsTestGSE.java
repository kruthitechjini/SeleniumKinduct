package com.procon.vehiclefinance.tests.reports;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Contacts;
import com.procon.vehiclefinance.pageobjects.reports.AdvancedReportsPageGSE;
import com.procon.vehiclefinance.pageobjects.reports.DateRangeEnum;
import com.procon.vehiclefinance.pageobjects.reports.ReportTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.ContactService.createContact;
import static org.testng.Assert.assertTrue;

public class ReportsTestGSE extends ReportsBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportsTestGSE.class);

    private static final DateFormat UI_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy hh:mm a");

    private static final DateFormat API_DATE_FORMAT = new SimpleDateFormat
            ("yyyy-MM-dd'T'HH:mm:ssZ");

    private static final DateFormat CELL_DATE_FORMAT = new SimpleDateFormat
            ("MM/dd/yyyy h:mm a");

    @Test(description = "Validate Daily Device History Report through " +
            "Advanced Report Link and Saved Report actions for GSE user", groups = {"reports"})
    public void testDailyDeviceHistoryAdvancedReportGSE() throws UnirestException, ParseException, IOException {

        //Create Recipient 1 using contact service call
        Contacts.Contact recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);
        List<String> addRecipientList = new ArrayList<>();
        addRecipientList.add(recipient.fullName);

        //Create Recipient 2 using contact service call
        recipient = createContact(driver).data;
        recipientIdList.add(recipient.id);
        List<String> changeRecipientList = new ArrayList<>();
        changeRecipientList.add(recipient.fullName);

        //Navigate to Advanced Reports page
        AdvancedReportsPageGSE advancedReportsPageGSE = reportsLeftBarPage.clickAdvancedReportLinkGSE();

        assertTrue(advancedReportsPageGSE.getModalWindow().isDisplayed());

        String reportName = ReportTypeEnum.DAILY_DEVICE_HISTORY.getName() + "_" +
                TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());

        //Create Daily Device History Report from Advanced Report Link
        advancedReportsPageGSE.runAdvancedReport(ReportTypeEnum.DAILY_DEVICE_HISTORY, "All",
                "-- All Dealers --", "-- All Groups --", "-- All Vehicles --",
                DateRangeEnum.CUSTOM, reportName, "09/17/2018", true, addRecipientList, "PDF");

        //Validate Daily Device History Report
        validateDailyDeviceHistory(advancedReportsPageGSE, reportName, addRecipientList, changeRecipientList,
                UI_DATE_FORMAT, API_DATE_FORMAT, CELL_DATE_FORMAT);
    }
}