package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.Contacts;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class ContactService extends ServiceCaller {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContactService.class);

    // contact list
    private static String contactEndpoint;

    static {
        contactEndpoint = baseUrl + "rest/json/contact";
    }

    /**
     * Get the list of contacts. This is currently a part of reports page but
     * can be generalized if this is common to other sections of app. When an
     * advanced reports is created/edited, the call is made to get a list of
     * recipients.
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return Contacts List
     * @throws UnirestException
     */
    public static Contacts.ContactList getContactList(WebDriver driver, Map<String, Object> queryParams) throws UnirestException {
        HttpResponse<Contacts.ContactList> response = Unirest.get(contactEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(Contacts.ContactList.class);
        return response.getBody();

    }

    public static Contacts.ContactList getContactList(WebDriver driver) throws UnirestException {

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 50);
        queryParams.put("filterOperator", "or");
        queryParams.put("countAlerts", 1);
        queryParams.put("filters", "[]");
        queryParams.put("sorts", "[{\"property\":\"firstName\",\"direction\":\"ASC\"}]");

        return getContactList(driver, queryParams);
    }

    public static Contacts.ContactList getContactList(WebDriver driver, String searchStr) throws UnirestException {

        String filter = String.format("[{\"property\":\"fullName\",\"comparison\":\"ilike\",\"value\":\"%s\"}," +
                "{\"property\":\"email\",\"comparison\":\"ilike\",\"value\":\"%s\"}," +
                "{\"property\":\"phoneNumber\",\"comparison\":\"ilike\",\"value\":\"%s\"}]", searchStr, searchStr, searchStr);

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("max", 200);
        queryParams.put("filterOperator", "or");
        queryParams.put("countAlerts", 1);
        queryParams.put("filters", filter);
        queryParams.put("sorts", "[{\"property\":\"firstName\",\"direction\":\"ASC\"}]");

        return getContactList(driver, queryParams);
    }

    public static Contacts.ContactResponseData createContact(WebDriver driver, Contacts.Contact recipients) throws
            UnirestException {
        HttpResponse<Contacts.ContactResponseData> response = Unirest.post
                (contactEndpoint)
                .header("accept", "application/json")
                .header("Content-Type", "application/json")
                .header("Cookie", getDriverCookies(driver))
                .body(recipients)
                .asObject(Contacts.ContactResponseData.class);
        return response.getBody();

    }

    /**
     * Create a new contact with default first, last name and email
     *
     * @param driver WebDriver object
     * @return Contact response
     * @throws UnirestException
     */
    public static Contacts.ContactResponseData createContact(WebDriver driver) throws
            UnirestException {

        Contacts.Contact contact = new Contacts.Contact();
        contact.firstName = "Automated" + System.currentTimeMillis();
        contact.lastName = "Recipient";
        contact.email = "automationtests05@gmail.com";

        return createContact(driver, contact);

    }

    public static Contacts.ContactResponseData deleteContact(WebDriver driver, int id) throws UnirestException {
        HttpResponse<Contacts.ContactResponseData> response = Unirest.delete
                (contactEndpoint + "/{id}")
                .header("Cookie", getDriverCookies(driver))
                .routeParam("id", String.valueOf(id))
                .asObject(Contacts.ContactResponseData.class);
        return response.getBody();
    }

    public static void deleteContact(WebDriver driver, String searchStr) throws UnirestException {

        if(searchStr.isEmpty() || searchStr == null) {
            return;
        }

        AtomicReference<Integer> counter = new AtomicReference<>(0);

        Contacts.ContactList contactToDelete = getContactList(driver, searchStr);

        contactToDelete.data.forEach(contact -> {
            try {
                Contacts.ContactResponseData res = deleteContact(driver, contact.id);
                if(res.success)
                {
                    LOGGER.info("Contact/Recipient: " + contact.fullName + " DELETED");
                    counter.getAndSet(counter.get() + 1);
                }
            } catch (UnirestException e) {
                e.printStackTrace();
            }
        });
        LOGGER.info("Total deleted " + counter);
    }



}
