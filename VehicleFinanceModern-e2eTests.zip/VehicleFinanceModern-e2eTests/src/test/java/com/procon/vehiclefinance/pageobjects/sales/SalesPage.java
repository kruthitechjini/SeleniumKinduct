package com.procon.vehiclefinance.pageobjects.sales;

import com.procon.vehiclefinance.models.Address;
import com.procon.vehiclefinance.models.Person;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.alerts.AlertManagementPage;
import com.procon.vehiclefinance.pageobjects.reports.ReportsLeftBarPage;
import com.procon.vehiclefinance.pageobjects.vehicles.VehiclesPage;
import com.procon.vehiclefinance.util.WebElements;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementValue;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

public class SalesPage extends CommonGrid {

    protected static final Logger logger = LoggerFactory.getLogger(SalesPage.class);

    // define elements in left bar for sales
    @FindBy(linkText = "New Sale")
    private WebElement newSaleLink;

    @FindBy(linkText = "Connect")
    private WebElement connectLink;

    @FindBy(linkText = "Recent Sales")
    private WebElement recentSalesLink;

    @FindBy(linkText = "Sales History")
    private WebElement salesHistoryLink;

    @FindBy(css = "[data-test-id ~= 'sales_type']")
    protected WebElement kahuSubscription;

    @FindBy(css = "[data-test-id ~= 'customer_first_name']")
    protected WebElement customerFirstName;

    @FindBy(css = "[data-test-id ~= 'customer_last_name']")
    protected WebElement customerLastName;

    @FindBy(css = "[data-test-id ~= 'customer_email']")
    protected WebElement customerEmail;

    @FindBy(css = "[data-test-id ~= 'customer_phone']")
    protected WebElement customerPhone;

    @FindBy(css = "[data-test-id ~= 'customer_address']")
    protected WebElement customerAddress;

    @FindBy(css = "[data-test-id ~= 'customer_city']")
    protected WebElement customerCity;

    @FindBy(css = "[data-test-id ~= 'customer_state']")
    protected WebElement customerState;

    @FindBy(css = "[data-test-id ~= 'customer_zip']")
    protected WebElement customerZip;

    @FindBy(css = "[data-test-id ~= 'vehicle_year']")
    protected WebElement vehicleYear;

    @FindBy(css = "[data-test-id ~= 'vehicle_make']")
    protected WebElement vehicleMake;

    @FindBy(css = "[data-test-id ~= 'vehicle_model']")
    protected WebElement vehicleModel;

    @FindBy(css = "[data-test-id ~= 'vehicle_mileage']")
    protected WebElement vehicleMileage;

    @FindBy(css = "button#completeSaleBtn")
    protected WebElement completeSaleBtn;

    @FindBy(css = "span[for='zip']")
    protected WebElement zipCodeErrorMesage;

    @FindBy(css = "section.west.sales-portal-nav-list li.active")
    private WebElement activeLink;

    @FindBy(css = "div.sales-form-space")
    private WebElement connectForm;

    @FindBy(css = "input[name='vin']")
    private WebElement vehicleVin;

    @FindBy(css = "input[name='deviceSerial']")
    private WebElement vehicleSerial;

    @FindBy(css = "button[title='Decode VIN']")
    private WebElement vehicleDecodeVinBtn;

    @FindBy(css = "button#reloadFormBtn")
    protected WebElement reloadFormBtn;

    @FindBy(css = "section.east.sales-portal-detail h5")
    private WebElement saleCompletedMessage;

    @FindBy(css = "div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeader;

    @FindBy(css = "div.ember-table-last-row div:nth-child(3)")
    private WebElement gridSaleStatus;

    @FindBy(css = "div.modal-content")
    private WebElement modalWindow;

    @FindBy(css = "div.modal-header h4.modal-title")
    private WebElement modalWindowTitle;

    @FindBy(css = "div.row div.col-md-2")
    private List<WebElement> saleComponentLabelElements;

    @FindBy(css = "div.row div.col-md-4")
    private List<WebElement> saleComponentValueElements;

    @FindBy(css = "a[href='#cancelSale']")
    private WebElement cancelSaleTab;

    @FindBy(css = "a[href='#resendInvite']")
    private WebElement resendInvitationTab;

    @FindBy(css = "a[href='#revokeUserAccess']")
    private WebElement revokeUserAccessTab;

    @FindBy(css = "a[href='#revokeDealerAccess']")
    private WebElement revokeDealerAccessTab;

    @FindBy(css = "div#cancelSale button[type='button']")
    private WebElement cancelSaleBtn;

    @FindBy(css = "div#resendInvite button[type='button']")
    private WebElement resendInvitationBtn;

    @FindBy(css = "div#revokeUserAccess button[type='button']")
    private WebElement revokeUserAccessBtn;

    @FindBy(css = "div#revokeDealerAccess button[type='button']")
    private WebElement revokeDealerAccessBtn;

    @FindBy(css = "div.bootbox.modal.fade.in div.modal-header h4.modal-title")
    private WebElement confirmationTitle;

    @FindBy(css = "div.modal-body div.bootbox-body.bootbox-wrap")
    private WebElement confirmationMessage;

    @FindBy(css = "div.modal-footer > button[type='button'].btn.btn-cancel")
    private WebElement confirmationBackBtn;

    @FindBy(css = "div.typeahead-input-wrapper ul > li:nth-of-type(1)")
    private WebElement firstVehicleInDeviceSerialList;

    public static final String CONFIRMATION_OK_BTN_CSS = "div.modal-footer > button[type='button'].btn.btn-primary";
    @FindBy(css = CONFIRMATION_OK_BTN_CSS)
    private WebElement confirmationOkBtn;

    @FindBy(css = "div.has-error")
    private List<WebElement> hasErrorFields;

    @FindBy(css = "input[name='assetName']")
    private WebElement vehicleName;

    public SalesPage(WebDriver driver) {
        super(driver);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public boolean isSalesFeaturePresent(String strSalesFeature) {
        return WebElements.isElementPresent(driver, By.partialLinkText(strSalesFeature));
    }

    public String getCurrentPanelTitle() {
        String text = driver.findElement(By.cssSelector("span[class=panel-title]")).getText();
        return text;
    }

    public ArrayList<String> getKahuSubscriptions() {

        ArrayList<String> subs = new ArrayList<>();
        Select kahuSub = new Select(kahuSubscription);
        for (WebElement option : kahuSub.getOptions()) {
            subs.add(option.getText());
        }
        return subs;
    }

    public void setCustomerZip(String zip) {
        customerZip.sendKeys(zip);
    }

    public Boolean areAllFieldsEmpty() {
        return customerLastName.getText().isEmpty() &&
                customerLastName.getText().isEmpty() &&
                customerEmail.getText().isEmpty() &&
                customerPhone.getText().isEmpty() &&
                customerAddress.getText().isEmpty() &&
                customerCity.getText().isEmpty() &&
                !customerState.isSelected() &&
                customerZip.getText().isEmpty() &&
                vehicleYear.getText().isEmpty() &&
                vehicleMake.getText().isEmpty() &&
                vehicleModel.getText().isEmpty() &&
                vehicleMileage.getText().isEmpty();

    }

    public void clickCompleteSale() {
        completeSaleBtn.click();
    }

    public String getZipErrorMessage() {
        return zipCodeErrorMesage.getText();
    }

    public Boolean isNewSaleLinkDisplayed() {
        return newSaleLink.isDisplayed();
    }

    public Boolean isRecentSaleLinkDisplayed() {
        return recentSalesLink.isDisplayed();
    }

    public Boolean isSalesHistoryLinkDisplayed() {
        return salesHistoryLink.isDisplayed();
    }

    public void clickSalesHistory() {
        salesHistoryLink.click();
    }

    public WebElement getActiveLink() {
        return activeLink;
    }

    public WebElement getConnectForm() {
        return connectForm;
    }

    public WebElement getDeviceSerialDropdown() {
        return vehicleSerial;
    }

    public WebElement getCompleteSaleBtn() {
        return completeSaleBtn;
    }

    public WebElement getColumnHeader() {
        return columnHeader;
    }

    public WebElement getSaleCompletedMessage() {
        return new WebDriverWait(driver, 10)
                .until(ExpectedConditions.visibilityOf(saleCompletedMessage));
    }

    public WebElement getReloadFormBtn() {
        return new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(reloadFormBtn));
    }

    public void enterSerialNumber(String serialNumber) {

        if (serialNumber != null) {

            enterText(driver, vehicleSerial, serialNumber);
            waitUntilAjaxSpinnerVisibleThenInvisible(driver, 2, 5);
            waitUntilSpinnerVisibleThenInvisible(driver, 3, 5);

            try {
                if (new WebDriverWait(driver, 10).until(ExpectedConditions
                        .visibilityOf(firstVehicleInDeviceSerialList)).getText()
                        .equals(serialNumber))
                    firstVehicleInDeviceSerialList.click();
            } catch (TimeoutException e) {
                fail("Serial number " + serialNumber + " not found in Device Serial dropdown");
            }
        }
    }

    public void enterAndDecodeVin(String vinNumber) {
        enterTextAndConfirmEntry(driver, vehicleVin, vinNumber);
        new WebDriverWait(driver, 5)
                .until(ExpectedConditions.elementToBeClickable(vehicleDecodeVinBtn)).click();
    }

    public Boolean verifyVehicleYearTxt(String year) {
        return new WebDriverWait(driver, 2)
                .until(textToBePresentInElementValue(vehicleYear, year));
    }

    public Boolean verifyVehicleMakeTxt(String make) {
        return new WebDriverWait(driver, 2)
                .until(textToBePresentInElementValue(vehicleMake, make));
    }

    public Boolean verifyVehicleModelTxt(String model) {
        return new WebDriverWait(driver, 2)
                .until(textToBePresentInElementValue(vehicleModel, model));
    }

    /**
     * Enter customer information
     *
     * @param customer
     * @param address
     */
    public void enterVehicleCustomerDetails(Person customer, Address address) {

        //Enter details in customer section
        enterCustomerInfo(customer);
        enterCustomerAddress(address);
    }

    /**
     * Enter customer information
     *
     * @param person
     */
    public void enterCustomerInfo(Person person) {

        if (person != null) {

            enterTextAndConfirmEntry(driver, customerFirstName, person.getFirstName());

            enterTextAndConfirmEntry(driver, customerLastName, person.getLastName());

            enterTextAndConfirmEntry(driver, customerEmail, person.getEmail());

            enterText(driver, customerPhone, person.getPhone());
        }
    }

    /**
     * Enter customer address
     *
     * @param address
     */
    public void enterCustomerAddress(Address address) {

        if (address != null) {

            enterTextAndConfirmEntry(driver, customerAddress, address.getStreet());

            enterTextAndConfirmEntry(driver, customerCity, address.getCity());

            new Select(customerState).selectByVisibleText(address.getState());

            enterTextAndConfirmEntry(driver, customerZip, address.getPostalCode());
        }
    }

    public void clickConnectLink() {
        connectLink.click();
    }

    public void clickRecentSaleLink() {
        recentSalesLink.click();
    }

    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements = columnHeader.findElements(By.cssSelector("span.ember-table-content"));
        for (WebElement column : elements) {
            columns.add(column.getText());
        }
        return columns;
    }

    public WebElement getCancelSaleTab() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(cancelSaleTab));
    }

    public WebElement getResendInvitationTab() {
        return resendInvitationTab;
    }

    public WebElement getRevokeUserAccessTab() {
        return revokeUserAccessTab;
    }

    public WebElement getRevokeDealerAccessTab() {
        return revokeDealerAccessTab;
    }

    public void clickCancelSaleTab() {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(cancelSaleTab)).click();
    }

    public void clickResendInvitationTab() {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(resendInvitationTab)).click();
    }

    public void clickRevokeUserAccessTab() {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(revokeUserAccessTab)).click();
    }

    public void clickRevokeDealerAccessTab() {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(revokeDealerAccessTab)).click();
    }

    public WebElement getCancelSaleBtn() {
        return cancelSaleBtn;
    }

    public WebElement getResendInvitationBtn() {
        return new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(resendInvitationBtn));
    }

    public WebElement getRevokeUserAccessBtn() {
        return new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(revokeUserAccessBtn));
    }

    public WebElement getRevokeDealerAccessBtn() {
        return new WebDriverWait(driver, 10)
                .until(ExpectedConditions.elementToBeClickable(revokeDealerAccessBtn));
    }

    public WebElement getConfirmationBackBtn() {
        return confirmationBackBtn;
    }

    public WebElement getConfirmationOkBtn() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(confirmationOkBtn));
    }

    public void clickConfirmationOkBtn() {
        clickElementAndWaitForInvisibility(driver, confirmationOkBtn, By.cssSelector(CONFIRMATION_OK_BTN_CSS));
    }

    public void clickResendInvitationButton() {
        clickResendInvitationTab();
        getResendInvitationBtn().click();
    }

    public void clickCancelSaleButton() {
        clickCancelSaleTab();
        getCancelSaleBtn().click();
    }

    public WebElement getModalWindow() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(modalWindow));
    }

    public WebElement getModalWindowTitle() {
        return modalWindowTitle;
    }

    public List<String> getSaleComponentLabels() {
        List<String> saleComponentLabelList = new ArrayList<>();

        for (WebElement saleComponent : saleComponentLabelElements) {
            saleComponentLabelList.add(saleComponent.getText());
        }

        return saleComponentLabelList;
    }

    public List<String> getSaleComponentValues() {
        List<String> saleComponentValueList = new ArrayList<>();

        for (WebElement saleComponent : saleComponentValueElements) {
            saleComponentValueList.add(saleComponent.getText());
        }

        return saleComponentValueList;
    }

    public WebElement getConfirmationTitle() {
        return new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(confirmationTitle));
    }

    public WebElement getConfirmationMessage() {
        return confirmationMessage;
    }

    public WebElement getGridSaleStatus() {
        return gridSaleStatus;
    }

    public WebElement getVehicleName() {
        return vehicleName;
    }

    public void clickRevokeUserAccessButton() {
        clickRevokeUserAccessTab();
        getRevokeUserAccessBtn().click();
    }

    public void clickRevokeDealerAccessButton() {
        clickRevokeDealerAccessTab();
        getRevokeDealerAccessBtn().click();
    }

    /**
     * Validate the device is available on sales form > device drop down list
     *
     * @param serialNumber
     * @return
     */
    public boolean validateSerialNumberInSalesPage(String serialNumber) {

        if (serialNumber != null) {
            enterText(driver, vehicleSerial, serialNumber);

            try {
                new WebDriverWait(driver, 5).until(ExpectedConditions
                        .visibilityOf(firstVehicleInDeviceSerialList));
                if (firstVehicleInDeviceSerialList.getText().equals(serialNumber))
                    return true;
            } catch (TimeoutException | NoSuchElementException e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Validate the device is available on vehicles page > vehicles list
     *
     * @param navbarHeaderPage
     * @param serialNumber
     * @return
     */
    public boolean validateSerialNumberInVehiclesPage(NavbarHeaderPage navbarHeaderPage, String serialNumber,
                                                      String vehicleName, boolean isGSEUser) {

        if (serialNumber != null && vehicleName != null) {

            VehiclesPage vehiclesPage = navbarHeaderPage.clickVehicles();
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

            if (isGSEUser) {

                //Clear filter
                vehiclesPage.clearFilter();
                waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
            }

            try {
                vehiclesPage.searchUniqueVehicle(serialNumber);

                if (vehiclesPage.getVehicleName().getText().equals(vehicleName))
                    return true;
            } catch (AssertionError e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Validate the device is available device on alerts page > create alert window > vehicle drop down list
     *
     * @param navbarHeaderPage
     * @param serialNumber
     * @param vehicleName
     * @param groupNameOrdealerName
     * @param isGSEUser
     * @return
     */
    public boolean validateSerialNumberInAlertsPage(NavbarHeaderPage navbarHeaderPage, String serialNumber,
                                                    String vehicleName, String groupNameOrdealerName,
                                                    boolean isGSEUser) {

        if (vehicleName != null && serialNumber != null) {

            //Click alerts menu
            AlertManagementPage alertManagementPage = navbarHeaderPage.clickAlerts().clickAlertManagement();

            //Open alert modal form
            alertManagementPage.clickAddAlertsBtn();

            assertTrue(getModalWindow().isDisplayed());

            alertManagementPage.selectScope("Vehicle");

            if (isGSEUser) {
                alertManagementPage.selectDealerName(groupNameOrdealerName);

                enterText(driver, alertManagementPage.getVehicleDropdown(), serialNumber);

            } else {
                alertManagementPage.selectGroup(groupNameOrdealerName);

                enterText(driver, alertManagementPage.getVehicleDropdown(), vehicleName);
            }

            waitUntilAjaxSpinnerVisibleThenInvisible(driver, 2, 5);

            try {
                String vehicleNameAlertsPage = new WebDriverWait(driver, 10).until(ExpectedConditions
                        .visibilityOf(alertManagementPage.getSecondVehicleInVehicleList())).getText();

                if (vehicleNameAlertsPage.equals(vehicleName))
                    return true;

            } catch (TimeoutException | NoSuchElementException e) {
                return false;
            } finally {

                alertManagementPage.getVehicleLabel().click();
                alertManagementPage.clickCancelBtn();
                waitUntilFadingDivInvisible(driver, 5);
            }
        }
        return false;
    }

    /**
     * Validate the device is available on reports page > vehicles drop down list
     *
     * @param navbarHeaderPage
     * @param serialNumber
     * @param vehicleName
     * @return
     */
    public boolean validateSerialNumberInReportsPage(NavbarHeaderPage navbarHeaderPage,
                                                     ReportsLeftBarPage reportsLeftBarPage, String serialNumber,
                                                     String vehicleName, boolean isGSEUser) {

        if (serialNumber != null && vehicleName != null) {

            navbarHeaderPage.clickReports();
            waitUntilSpinnerInvisible(driver, 10);

            if (isGSEUser)
                reportsLeftBarPage.selectDeviceStatus("All");

            WebElement vehiclesInput = new WebDriverWait(driver, 5).until(ExpectedConditions
                    .elementToBeClickable(reportsLeftBarPage.getVehiclesInput()));
            vehiclesInput.click();

            enterText(driver, vehiclesInput, serialNumber);
            waitUntilAjaxSpinnerVisibleThenInvisible(driver, 2, 5);

            try {
                if (new WebDriverWait(driver, 5).until(ExpectedConditions
                        .visibilityOf(reportsLeftBarPage.getSecondVehicleInVehiclesList())).getText()
                        .equals(vehicleName))
                    return true;

            } catch (TimeoutException | NoSuchElementException e) {
                return false;
            }
        }
        return false;
    }

    public boolean isErrorFields() {
        return !hasErrorFields.isEmpty();
    }
}
