package com.procon.vehiclefinance.pageobjects.gseDealer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class DevicesInstallationSupportPage {
    WebDriver driver;
    protected static final Logger logger = Logger
            .getLogger(DevicesInstallationSupportPage.class.getName());

    @FindBy(css = "span.panel-title")
    private WebElement panelTitle;

    @FindBy(css = "div.lender-installation-support-content h3")
    private List<WebElement> videosTitles;


    public DevicesInstallationSupportPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public String getPanelTitleText() {
        return panelTitle.getText();
    }

    public boolean isFileLinkShown(String linkName)
    {
        return !driver.findElements(By.linkText(linkName)).isEmpty();
    }

    public List<WebElement> getVideosTitles() {
        return videosTitles;
    }

    public List<String> getInnerVideosTitlesText() {
        List<String> titlesList = new ArrayList<>();

        new WebDriverWait(driver, 10).until(e -> e.findElements(By.cssSelector("iframe[src^='http']")).size() > 1);

        int totalVideos = driver.findElements(By.cssSelector("iframe[src^='http']")).size();

        for (int i = 0; i < totalVideos; i++) {
            driver.switchTo().frame(i);
            titlesList.add(driver.findElement(By.tagName("title")).getAttribute("innerHTML"));
            driver.switchTo().defaultContent();
        }

        return titlesList;
    }
}
