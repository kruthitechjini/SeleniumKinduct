package com.procon.vehiclefinance.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class TestsCounter implements ISuiteListener {
    protected static final Logger LOGGER = LoggerFactory.getLogger(TestsCounter.class);

    @Override
    public void onStart(ISuite suite) {
        LOGGER.info("Total amount of tests are: " + suite.getAllMethods().size());
    }

    @Override
    public void onFinish(ISuite suite) {

    }
}
