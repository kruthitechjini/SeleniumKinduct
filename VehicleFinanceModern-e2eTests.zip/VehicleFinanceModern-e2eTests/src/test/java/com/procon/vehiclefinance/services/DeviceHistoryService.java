package com.procon.vehiclefinance.services;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.pageobjects.reports.Report;
import com.procon.vehiclefinance.pageobjects.vehicles.DeviceHistory;
import org.openqa.selenium.WebDriver;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.Map;

public class DeviceHistoryService extends ServiceCaller {

    // retrieve history of device
	private static String deviceTopAddressEndpoint;
    private static String deviceHistoryEndpoint;

    static {
    	deviceTopAddressEndpoint = baseUrl + 
    			"operation/vfTrendsService/topAddresses.json";
    	deviceHistoryEndpoint = baseUrl +
                "operation/vehicleFinanceDeviceHistoryRestService/get.json";
    	
    }

    /**
     * Download device History.
     *
     * @param driver   WebDriver object
     * @param reportId Id of the report to get
     * @param format
     * @return
     * @throws UnirestException
     */
    public static DeviceHistory.DeviceHistoryResults getDeviceHistory(WebDriver driver, Map<String, Object> queryParams ) throws
            UnirestException {
        HttpResponse<DeviceHistory.DeviceHistoryResults> response = Unirest.post
                (deviceHistoryEndpoint)
                .header("Cookie", getDriverCookies(driver))
                .fields(queryParams)
                .asObject(DeviceHistory.DeviceHistoryResults.class);
                //.asBinary();
                //.asJson();
        return response.getBody();
    }
    
    /**
     * Return the device top addresses. This is the service call that is made when
     * user clicks on Vehicle Locations tab. This returns a unique state id's that can be used to
     * fetch the location details using {@link #getDeviceHistory(WebDriver, Map)}
     *
     * @param driver      WebDriver object
     * @param queryParams query parameters to pass to get request
     * @return
     * @throws UnirestException
     */
    public static DeviceHistory.DeviceTopAddressesResults getDeviceTopAddresses(WebDriver driver,
                                                   Map<String, Object> queryParams)
            throws UnirestException {
        HttpResponse<DeviceHistory.DeviceTopAddressesResults> response = Unirest.get
                (deviceTopAddressEndpoint)
                .queryString(queryParams)
                .header("Cookie", getDriverCookies(driver))
                .asObject(DeviceHistory.DeviceTopAddressesResults.class);
        return response.getBody();
    }
    
    // Returns UTC end of day in local time zone
    public static Date getEndOfDay(Date date) {
    	LocalDateTime localDateTime = dateToUTCDateTime(date);
    	LocalDateTime endOfDay = localDateTime.with(LocalTime.MAX);
    	return localDateTimeToDate(endOfDay);
    }

    // Returns UTC start of day in local time zone
    public static Date getStartOfDay(Date date) {
    	LocalDateTime localDateTime = dateToUTCDateTime(date);
    	LocalDateTime startOfDay = localDateTime.with(LocalTime.MIN);
    	return localDateTimeToDate(startOfDay);
    }

    private static Date localDateTimeToDate(LocalDateTime startOfDay) {
    	return Date.from(startOfDay.atZone(ZoneId.systemDefault()).toInstant());
    }

    //Returns UTC date time in local time zone
    private static LocalDateTime dateToUTCDateTime(Date date) {
    	return LocalDateTime.ofInstant(Instant.ofEpochMilli(date.getTime()), ZoneOffset.UTC);
    }
}
