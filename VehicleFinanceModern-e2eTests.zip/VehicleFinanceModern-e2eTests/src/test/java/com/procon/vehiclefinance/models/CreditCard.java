package com.procon.vehiclefinance.models;

public class CreditCard {
    private String number;
    private String month;
    private String year;
    private String cvv;

    private CreditCard(String number, String month, String year, String cvv) {
        this.number = number;
        this.month = month;
        this.year = year;
        this.cvv = cvv;
    }

    public String getNumber() {
        return number;
    }

    public String getMonth() {
        return month;
    }

    public String getYear() {
        return year;
    }

    public String getCvv() {
        return cvv;
    }

    public static class CreditCardBuilder {
        private String number;
        private String month;
        private String year;
        private String cvv;

        public CreditCardBuilder number(String number) {
            this.number = number;
            return this;
        }

        public CreditCardBuilder month(String month) {
            this.month = month;
            return this;
        }

        public CreditCardBuilder year(String year) {
            this.year = year;
            return this;
        }

        public CreditCardBuilder cvv(String cvv) {
            this.cvv = cvv;
            return this;
        }

        public CreditCard build() {
            return new CreditCard(number, month, year, cvv);
        }
    }
}
