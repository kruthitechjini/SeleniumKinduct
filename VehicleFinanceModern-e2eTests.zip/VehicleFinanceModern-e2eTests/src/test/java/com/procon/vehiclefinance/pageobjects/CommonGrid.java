package com.procon.vehiclefinance.pageobjects;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.procon.vehiclefinance.util.WebElements.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.testng.Assert.*;

public class CommonGrid {

    /**
     * This Regular Expression can be used to split the pagination text which is currently like:
     * 1 - 25 of 40.  This expression will split on both the hyphen and the word "of".
     */
    private static final String PAGINATION_FORMAT_REGEX = "(-|of)";

    // Constants representing the order in which pagination values appear on screen. (ex. 1 - 25 of 40)
    private final static int PAGE_LOWER_INDEX = 0;
    private final static int PAGE_UPPER_INDEX = 1;
    private final static int PAGE_TOTAL_INDEX = 2;

    protected WebDriver driver;

    protected static final Logger logger = LoggerFactory.getLogger(CommonGrid.class);

    protected String firstRowLocator = "div.ember-table-body-container div.ember-table-table-row:nth-child(1)";
    protected String cellLocator = "div.ember-table-cell";

    @FindBy(css = "div.panel.panel-default.panel-fill-height")
    private WebElement adminPanel;

    @FindBy(css = "div.active div.ember-view.ember-table-table-container.ember-table-fixed-table-container.ember-table-header-container")
    private WebElement columnHeaderActiveTab;

    @FindBy(css = "div.ember-table-header-container")
    private WebElement columnHeaderGeneral;

    @FindBy(css = "div.fixed-body")
    protected WebElement gridBody;

    @FindBy(css = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block")
    private WebElement resultGridRows;

    @FindBy(css = "div.paging-status.pull-right")
    private WebElement gridRecords;

    @FindBy(css = "ul.paging-controls")
    private WebElement pagingControls;

    private static final String FIRST_PAGE_BTN = "div.panel-footer [title='First Page']";
    @FindBy(css = FIRST_PAGE_BTN)
    private WebElement firstPageBtn;

    private static final String PREVIOUS_BTN = "div.panel-footer [title='Previous']";
    @FindBy(css = PREVIOUS_BTN)
    private WebElement previousBtn;

    private static final String NEXT_BTN = "div.panel-footer [title='Next']";
    @FindBy(css = NEXT_BTN)
    private WebElement nextBtn;

    private static final String LAST_PAGE_BTN = "div.panel-footer [title='Last Page']";
    @FindBy(css = LAST_PAGE_BTN)
    private WebElement lastPageBtn;

    private static final String REFRESH_BTN = "i.fa.fa-lg.fa-refresh";
    @FindBy(css = REFRESH_BTN)
    private WebElement refreshBtn;

    private static final String PAGE_SIZE_SELECT = "div.modern-select > select.ember-view.ember-select";
    @FindBy(css = PAGE_SIZE_SELECT)
    private WebElement pageSizeSelect;

    private static final String SEARCH_INPUT = "input.ember-view.ember-text-field.search.form-control.input-sm";
    @FindBy(css = SEARCH_INPUT)
    private WebElement searchInput;

    private static final String SEARCH_INPUT_CANCEL = "a.clear-btn";
    @FindBy(css = SEARCH_INPUT_CANCEL)
    private WebElement searchInputCancel;

    /**
     * Represents the div that contains the information of the current page and total number of records.
     */
    private static final String PAGING_POSITION_DIV = "div.paging-status.pull-right";
    @FindBy(css = PAGING_POSITION_DIV)
    private WebElement pagingPositionDiv;

    //used to get rows count
    protected String allRowsCssLocator = "div.ember-view.lazy-list-container > " +
            "div";

    @FindBy(css = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block > " +
            "div:first-child a:first-child")
    protected WebElement editLink;

    // TMP Workaround - VFM-2762
    // private static final String DELETE_LINK_CSS = "a.btn[title=Delete]";
    protected static final String DELETE_LINK_CSS = "a.btn > span.glyphicon-trash";
    @FindBy(css = DELETE_LINK_CSS)
    protected WebElement deleteLink;

    private static final String CONFIRM_DELETE_BTN_CSS = "div.modal-footer > " +
            "button.btn-danger[data-bb-handler=delete]";
    @FindBy(css = CONFIRM_DELETE_BTN_CSS)
    private WebElement confirmDeleteBtn;

    @FindBy(css = "div.active div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block")
    private WebElement activeGridData;

    protected static final String TEXT_ELEMENT_ACTION_LINK_XPATH = "//span[text()='%s']/../..//a[@title='%s']";
    protected static final String HEADER_COLUMN_SPAN_XPATH = "//div[contains(@class,'ember-table-header-container')]//span[text()='%s']";
    protected static final String HEADER_COLUMN_DIV_XPATH = HEADER_COLUMN_SPAN_XPATH + "/../..";

    private static final String SELECT_PAGE_SIZE = "div.paging-component select";
    @FindBy(css = SELECT_PAGE_SIZE)
    private WebElement selectPageSize;

    @FindBy(css = "div.ember-table-tables-container")
    private WebElement defaultTable;

    public CommonGrid(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public WebElement getDefaultTable() {
        return defaultTable;
    }

    public WebElement adminPanel() {
        return this.adminPanel;
    }

    public WebElement columnHeader() {
        return this.columnHeaderActiveTab;
    }

    public WebElement gridBody() {
        return this.gridBody;
    }

    public WebElement resultGridRows() {
        return this.resultGridRows;
    }

    public WebElement gridRecords() {
        return this.gridRecords;
    }

    public WebElement pagingControls() {
        return this.pagingControls;
    }

    public void clickFirstPageBtn() {
        this.firstPageBtn.click();
    }

    public void clickFirstPageBtn(WebElement firstPageBtn) {
        firstPageBtn.click();
    }

    public void clickPreviousBtn() {
        this.previousBtn.click();
    }

    public void clickPreviousBtn(WebElement previousBtn) {
        previousBtn.click();
    }

    public void clickNextBtn() {
        this.nextBtn.click();
    }

    public void clickNextBtn(WebElement nextBtn) {
        nextBtn.click();
    }

    public void clickLastPageBtn() {
        this.lastPageBtn.click();
    }

    public void clickLastPageBtn(WebElement lastPageBtn) {
        lastPageBtn.click();
    }

    public void clickRefreshBtn() {
        this.refreshBtn.click();
    }

    public void clickRefreshBtn(WebElement refreshBtn) {
        refreshBtn.click();
    }

    public WebElement pageSizeSelect() {
        return this.pageSizeSelect;
    }

    public int search(String strSearch) {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(
                elementToBeClickable(searchInput))
                .clear();

        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        new WebDriverWait(driver, 10).until(
                elementToBeClickable(searchInput))
                .sendKeys(strSearch);

        // seems like there is a slight delay when the type ahead search is
        // triggered. So wait for the spinner to be visible first to ensure
        // search was triggered and then wait for it to be invisible
        waitUntilSpinnerVisibleThenInvisible(driver, 5, 10);

        return getNumberOfRowsDisplayedInGrid();
    }

    public int getNumberOfRowsDisplayedInGrid() {
        int rowCount = driver.findElements(By.cssSelector(allRowsCssLocator)).size();
        return rowCount - 2;
    }

    /**
     * Search the given text and click on edit link
     *
     * @param strSearch
     */
    public void editSearchedRecord(String strSearch) {
        //searchUnique(strSearch);
        int rowCount = search(strSearch);
        if (rowCount == 1) {
            editLink.click();
        } else {
            throw new WebDriverException("More than 1 record returned");
        }
    }

    /**
     * Click on edit link for the given row
     */
    public void editRecord(int rowNumber) {
        WebElement e = driver.findElement(By.cssSelector("div.ember-view.lazy-list-container" +
                ".ember-table-table-block.ember-table-right-table-block > div:nth-child("
                + rowNumber + ") a:first-child"));
        scrollAndClick(driver, e);
    }

    public void editRecord(String text) {
        String deleteLink = String.format(TEXT_ELEMENT_ACTION_LINK_XPATH, text, "Edit");
        WebElement element = driver.findElement(By.xpath(deleteLink));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        new WebDriverWait(driver, 5).until(elementToBeClickable(element)).click();
    }

    public void deleteRecord() {
        WebElement element = driver.findElement(By.cssSelector(DELETE_LINK_CSS));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        new WebDriverWait(driver, 5).until(elementToBeClickable(deleteLink))
                .click();
        clickElementAndWaitForInvisibility(driver, confirmDeleteBtn, By
                .cssSelector(CONFIRM_DELETE_BTN_CSS), 10);
    }

    public void deleteRecord(String text) {
        String deleteLink = String.format(TEXT_ELEMENT_ACTION_LINK_XPATH, text, "Delete");
        WebElement element = driver.findElement(By.xpath(deleteLink));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        new WebDriverWait(driver, 5).until(elementToBeClickable(element))
                .click();
        clickElementAndWaitForInvisibility(driver, confirmDeleteBtn, By
                .cssSelector(CONFIRM_DELETE_BTN_CSS), 10);
    }

    public void viewRecord(int rowNumber) {
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 15);
        String format = "div.ember-view.lazy-list-container.ember-table-table-block.ember-table-right-table-block > div:nth-of-type(%s) a";
        String csspath = String.format(format, rowNumber);
        driver.findElement(By.cssSelector(csspath)).click();
    }

    public void deleteSearchedRecord(String strSearch) {
        int rowCount = search(strSearch);
        if (rowCount == 1) {
            deleteRecord();
        } else {
            throw new RuntimeException("More than 1 record searched");

        }
    }

    /**
     * Generic method to get table content
     *
     * @param table  table
     * @param header table header css locator
     * @param cell   table cell css locator
     * @return table content as list of maps
     */
    public List<HashMap<String, String>> getTable(WebElement table, String header, String cell) {

        List<HashMap<String, String>> content = new ArrayList<HashMap<String, String>>();

        List<WebElement> headers = table.findElements(By.cssSelector(header));
        List<WebElement> cells = table.findElements(By.cssSelector(cell));
        //logger.info("headers: " + headers.size() + " cells: " + cells.size());
        for (int c = 0; c < cells.size(); c += headers.size()) {
            HashMap<String, String> row = new HashMap<String, String>();
            for (int i = 0; i < headers.size(); i++) {
                row.put(headers.get(i).getAttribute("innerText").trim(), cells.get(c + i)
                        .getAttribute("innerText").trim());
            }
            content.add(row);
        }
        return content;
    }

    public List<HashMap<String, String>> getFixedTable(WebElement table) {
        waitForTable(table);
        return getTable(table, "div.ember-table-header-cell",
                "div.ember-table-body-container div.ember-table-cell");
    }

    public List<HashMap<String, String>> getFixedTable() {
        return getFixedTable(this.defaultTable);
    }

    public HashMap<String, String> getTableFirstRow(WebElement table) {
        waitForTable(table);
        return getTable(table, "div.ember-table-header-cell",
                "div.ember-table-body-container div.ember-table-table-row:nth-child(1) div.ember-table-cell").get(0);
    }

    public HashMap<String, String> getTableFirstRow() {
        return getTableFirstRow(this.defaultTable);
    }

    public void waitForTable(WebElement table) {
        //logger.info("Waiting for table");
        waitUntilSpinnerInvisible(driver, 30);
        WebDriverWait tableWait = new WebDriverWait(driver, 10);
        tableWait.until(ExpectedConditions.elementToBeClickable(table));
        String firstCellLocator = firstRowLocator + " " + cellLocator + ":nth-child(1)";
        WebElement firstCellElement = table.findElement(By.cssSelector(firstCellLocator));
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(firstCellElement));
        //logger.info("Waiting for table completed");
    }

    public void waitForTable() {
        waitForTable(this.defaultTable);
    }

    public void waitForNewTableRecord(WebElement table,
                                      HashMap<String, String> oldRecord, Integer timeout) {
        Integer sleepTime = 500;
        Integer timeSpent = 0;

        while (timeSpent < (timeout * 1000)) {
            //driver.navigate().refresh();
            refreshBtn.click();
            //waitForTable(table);
            if (!oldRecord.equals(getTableFirstRow(table))) {
                break;
            }
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException ie) {
            }
            timeSpent = timeSpent + sleepTime;
        }
    }

    public List<String> getGridColumns() {
        List<String> columns = new ArrayList<>();
        List<WebElement> elements;

        try {
            elements = columnHeaderActiveTab.findElements(By.cssSelector("span.ember-table-content"));
        } catch (NoSuchElementException e) {

            //If there are no any TABs then using general locator for table
            elements = columnHeaderGeneral.findElements(By.cssSelector("span.ember-table-content"));
        }

        for (WebElement column : elements) {
            new Actions(driver).moveToElement(column).perform();
            columns.add(column.getText());
        }
        return columns;
    }

    public String getTableHeaderColumnClassAttribute(String columnName) {
        return getTableHeaderColumnClassAttribute(this.HEADER_COLUMN_DIV_XPATH, columnName);
    }

    public String getTableHeaderColumnClassAttribute(String HEADER_COLUMN_DIV_XPATH, String columnName) {
        String locator = String.format(HEADER_COLUMN_DIV_XPATH, columnName);
        return driver.findElement(By.xpath(locator)).getAttribute("class");
    }

    public Boolean isColumnSortable(String column) {
        return getTableHeaderColumnClassAttribute(column).contains(" arrangeable ");
    }

    public Boolean isColumnSortable(String HEADER_COLUMN_DIV_XPATH, String column) {
        return getTableHeaderColumnClassAttribute(HEADER_COLUMN_DIV_XPATH, column).contains(" arrangeable ");
    }

    public Boolean isColumnSortedDescending(String column) {
        return getTableHeaderColumnClassAttribute(column).contains(" desc");
    }

    public Boolean isColumnSortedDescending(String HEADER_COLUMN_DIV_XPATH, String column) {
        return getTableHeaderColumnClassAttribute(HEADER_COLUMN_DIV_XPATH, column).contains(" desc");
    }

    public Boolean isColumnSortedAscending(String column) {
        return getTableHeaderColumnClassAttribute(column).contains(" asc");
    }

    public Boolean isColumnSortedAscending(String HEADER_COLUMN_DIV_XPATH, String column) {
        return getTableHeaderColumnClassAttribute(HEADER_COLUMN_DIV_XPATH, column).contains(" asc");
    }

    public void clickHeaderColumn(String columnName) {
        clickHeaderColumn(this.HEADER_COLUMN_DIV_XPATH, columnName);
    }

    public void clickHeaderColumn(String HEADER_COLUMN_DIV_XPATH, String columnName) {
        String locator = String.format(HEADER_COLUMN_DIV_XPATH, columnName);
        driver.findElement(By.xpath(locator)).click();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
    }

    /**
     * Get the record count from the element mapped to pagingPositionDiv.
     *
     * @return
     */
    public int getTotalRecordCount() {
        return getTotalRecordCount(this.pagingPositionDiv);
    }

    /**
     * Get the record count from the element mapped to pagingPositionDiv.
     *
     * @return
     */
    public int getTotalRecordCount(WebElement pagingPositionDiv) {
        waitUntilSpinnerInvisible(driver);

        List<String> pageInfo = getPageInfo(pagingPositionDiv);

        return Integer.parseInt(pageInfo.get(PAGE_TOTAL_INDEX));
    }


    /**
     * Get the current page lower bound - ie, the "25" in "1 - 25 of 40".
     *
     * @return
     */
    public int getPageLowerBound() {
        return getPageLowerBound(this.pagingPositionDiv);
    }

    /**
     * Get the current page lower bound - ie, the "25" in "1 - 25 of 40".
     *
     * @return
     */
    public int getPageLowerBound(WebElement pagingPositionDiv) {
        waitUntilSpinnerInvisible(driver);

        List<String> pageInfo = getPageInfo(pagingPositionDiv);

        return Integer.parseInt(pageInfo.get(PAGE_LOWER_INDEX));
    }

    /**
     * Get the current page upper bound - ie, the "25" in "1 - 25 of 40".
     *
     * @return
     */
    public int getPageUpperBound() {
        return getPageUpperBound(this.pagingPositionDiv);
    }

    /**
     * Get the current page upper bound - ie, the "25" in "1 - 25 of 40".
     *
     * @return
     */
    public int getPageUpperBound(WebElement pagingPositionDiv) {
        waitUntilSpinnerInvisible(driver);

        List<String> pageInfo = getPageInfo(pagingPositionDiv);

        return Integer.parseInt(pageInfo.get(PAGE_UPPER_INDEX));
    }

    /**
     * Scrapes the pagination info off the screen and splits the values into a list of strings.
     *
     * @return
     */
    private List<String> getPageInfo(WebElement pagingPositionDiv) {
        List<String> list = new ArrayList<>();

        // Need to remove text that could be at the end of counters like "ADD TO RENEWAL ORDER" button
        String text = pagingPositionDiv.getText().replaceAll("\\D*$", "");

        // Format is going to be like: "1 - 25 of 40.  Split values on both the "-" and the word "of".
        String[] values = text.split(PAGINATION_FORMAT_REGEX);

        list.add(values[0].trim());
        list.add(values[1].trim());
        list.add(values[2].trim());

        return list;
    }

    /**
     * Click on the given row
     *
     * @param rowNumber
     */
    public void clickRow(int rowNumber) {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(activeGridData.findElement(By.cssSelector("div" +
                        ".ember-table-table-row:nth-child(" + rowNumber + ")")))).click();
    }

    /**
     * Get data of the given row
     *
     * @param table
     * @param rowNumber
     * @return
     */
    public HashMap<String, String> getTableRow(WebElement table, int rowNumber) {
        waitForTable(table);
        return getTable(table, "div.ember-table-header-cell",
                "div.ember-table-body-container div" +
                        ".ember-table-table-row:nth-child(" + rowNumber + ") " +
                        "div.ember-table-cell").get(0);
    }

    /**
     * Click on the given row
     *
     * @param rowNumber
     */
    public void clickRow(WebElement table, int rowNumber) {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(table.findElement(By.cssSelector("div" +
                        ".ember-table-table-row:nth-child(" + rowNumber + ")")))).click();
    }

    /**
     * Toggle checkbox on the given row
     *
     * @param rowNumber
     */
    public void clickCheckBoxRow(WebElement table, int rowNumber) {
        waitUntilSpinnerInvisible(driver);
        new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(table.findElement(By.cssSelector("div" +
                        ".ember-table-table-row:nth-child(" + rowNumber + ") input")))).click();
    }

    public WebElement getPagingPositionDiv() {
        return pagingPositionDiv;
    }

    public WebElement getEditLink() {
        return editLink;
    }

    public WebElement getDeleteLink() {
        return deleteLink;
    }

    public WebElement getSearchInput() {
        return searchInput;
    }

    public WebElement getSearchInputCancel() {
        return searchInputCancel;
    }

    public enum SelectPageSizesEnum {
        TWENTY_FIVE("25"),
        FIFTY("50"),
        SEVENTY_FIVE("75"),
        HUNDRED("100");

        private String name;

        SelectPageSizesEnum(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public static List<String> getValues() {
            List<String> values = new ArrayList<>();
            for (SelectPageSizesEnum pageSize : SelectPageSizesEnum.values()) {
                values.add(pageSize.getName());
            }
            return values;
        }
    }

    /**
     * Verify Page Navigation bar and Show dropdown
     */
    public void verifyNavigationElementsPresent() {

        verifyNavigationElementsPresent(this.firstPageBtn, this.previousBtn,
                this.nextBtn, this.lastPageBtn, this.refreshBtn, this.selectPageSize, this.pagingPositionDiv);
    }

    /**
     * Verify Page Navigation bar and Show dropdown
     */
    public void verifyNavigationElementsPresent(WebElement selectPageSize) {

        verifyNavigationElementsPresent(this.firstPageBtn, this.previousBtn,
                this.nextBtn, this.lastPageBtn, this.refreshBtn, selectPageSize, this.pagingPositionDiv);
    }

    /**
     * Verify Page Navigation bar and Show dropdown
     */
    public void verifyNavigationElementsPresent(WebElement firstPageBtn, WebElement previousBtn, WebElement nextBtn,
                                                WebElement lastPageBtn) {

        verifyNavigationElementsPresent(firstPageBtn, previousBtn, nextBtn, lastPageBtn,
                this.refreshBtn, selectPageSize, this.pagingPositionDiv);
    }

    /**
     * Verify Page Navigation bar and Show dropdown
     */
    public void verifyNavigationElementsPresent(WebElement firstPageBtn, WebElement previousBtn, WebElement nextBtn,
                                                WebElement lastPageBtn, WebElement refreshBtn,
                                                WebElement selectPageSize, WebElement pagingPositionDiv) {

        assertTrue(firstPageBtn.isDisplayed());
        assertTrue(previousBtn.isDisplayed());
        assertTrue(nextBtn.isDisplayed());
        assertTrue(lastPageBtn.isDisplayed());
        assertTrue(refreshBtn.isDisplayed());

        //Validate Show dropdown to select page size
        assertTrue(selectPageSize.isDisplayed());

        //Validate record count is shown at the bottom right
        assertTrue(pagingPositionDiv.isDisplayed());
    }

    /**
     * Get all options of select page size drop down
     *
     * @return
     */
    public List<String> getSelectPageSizeValues() {

        return getSelectPageSizeValues(this.selectPageSize);
    }

    /**
     * Get all options of select page size drop down
     *
     * @return
     */
    public List<String> getSelectPageSizeValues(WebElement selectPageSize) {

        List<WebElement> showDropDownElementList = new Select(selectPageSize).getOptions();

        List<String> showDropDownValueList = new ArrayList<>();
        for (WebElement showDropDownElement : showDropDownElementList) {
            showDropDownValueList.add(showDropDownElement.getText());
        }

        return showDropDownValueList;
    }

    /**
     * Select given value in select page size drop down
     *
     * @param numberOfRows - number of rows typically 25, 50, 75, 100
     */
    public void selectPageSizeValue(String numberOfRows) {

        selectPageSizeValue(numberOfRows, this.selectPageSize);
    }

    /**
     * Select given value in select page size drop down
     *
     * @param numberOfRows - number of rows typically 25, 50, 75, 100
     * @param selectPageSize - WebElement selectPageSize
     */
    public void selectPageSizeValue(String numberOfRows, WebElement selectPageSize) {
        if (numberOfRows != null) {
            new Select(selectPageSize).selectByVisibleText(numberOfRows);
        }
    }

    /**
     * Get the page size selected option
     *
     * @return
     */
    public int getPageSizeSelection() {

        return getPageSizeSelection(this.selectPageSize);
    }

    /**
     * Get the page size selected option
     *
     * @param selectPageSize - WebElement selectPageSize
     */
    public int getPageSizeSelection(WebElement selectPageSize) {
        Select pageSizeSelect = new Select(selectPageSize);
        return Integer.parseInt(
                pageSizeSelect.getFirstSelectedOption().getText());
    }

    /**
     * Validate Grid Navigation control buttons
     */
    public void verifyNavigationBtns() {

        verifyNavigationBtns(this.firstPageBtn, this.previousBtn, this.nextBtn, this.lastPageBtn,
                this.selectPageSize, this.pagingPositionDiv);
    }

    /**
     * Validate Grid Navigation control buttons
     */
    public void verifyNavigationBtns(WebElement selectPageSize) {

        verifyNavigationBtns(this.firstPageBtn, this.previousBtn, this.nextBtn, this.lastPageBtn,
                selectPageSize, this.pagingPositionDiv);
    }

    /**
     * Validate Grid Navigation control buttons
     */
    public void verifyNavigationBtns(WebElement firstPageBtn, WebElement previousBtn, WebElement nextBtn,
                                     WebElement lastPageBtn) {

        verifyNavigationBtns(firstPageBtn, previousBtn, nextBtn, lastPageBtn, this.selectPageSize,
                this.pagingPositionDiv);
    }

    /**
     * Validate Grid Navigation control buttons
     */
    public void verifyNavigationBtns(WebElement firstPageBtn, WebElement previousBtn, WebElement nextBtn,
                                     WebElement lastPageBtn, WebElement selectPageSize, WebElement pagingPositionDiv) {

        if (getTotalRecordCount(pagingPositionDiv) > getPageSizeSelection(selectPageSize)) {

            verifyFooterNavBtns(false, false, true, true,
                    firstPageBtn, previousBtn, nextBtn, lastPageBtn);
            assertEquals(getPageSizeSelection(selectPageSize), getPageUpperBound(pagingPositionDiv));

            //Click next button and validate page upper bound and grid navigation control buttons
            clickNextBtn(nextBtn);
            if (getTotalRecordCount(pagingPositionDiv) == getPageUpperBound(pagingPositionDiv)) {
                verifyFooterNavBtns(true, true, false, false,
                        firstPageBtn, previousBtn, nextBtn, lastPageBtn);
            } else {
                assertEquals(getPageSizeSelection(selectPageSize) * 2, getPageUpperBound(pagingPositionDiv));
                verifyFooterNavBtns(true, true, true, true,
                        firstPageBtn, previousBtn, nextBtn, lastPageBtn);
            }

            //Click Previous button and validate page upper bound and grid navigation control buttons
            clickPreviousBtn(previousBtn);
            assertEquals(getPageSizeSelection(selectPageSize), getPageUpperBound(pagingPositionDiv));
            verifyFooterNavBtns(false, false, true, true,
                    firstPageBtn, previousBtn, nextBtn, lastPageBtn);

            //Click LastPage button and validate total record count and grid navigation control buttons
            // only if total records < 10000 because of too long wait upon loads all records and app rise a timeout
            if (getTotalRecordCount(pagingPositionDiv) < 10000) {
                clickLastPageBtn(lastPageBtn);
                assertEquals(getTotalRecordCount(pagingPositionDiv), getPageUpperBound(pagingPositionDiv));
                verifyFooterNavBtns(true, true, false, false,
                        firstPageBtn, previousBtn, nextBtn, lastPageBtn);
            }

            //Click First button and validate Page upper bound and grid navigation control buttons
            clickFirstPageBtn(firstPageBtn);
            assertEquals(getPageSizeSelection(selectPageSize), getPageUpperBound(pagingPositionDiv));
            verifyFooterNavBtns(false, false, true, true,
                    firstPageBtn, previousBtn, nextBtn, lastPageBtn);

        } else {
            verifyFooterNavBtns(false, false, false, false,
                    firstPageBtn, previousBtn, nextBtn, lastPageBtn);
            assertEquals(getTotalRecordCount(pagingPositionDiv), getPageUpperBound(pagingPositionDiv));
        }
    }

    /**
     * Validate grid navigation control buttons in panel footer
     *
     * @param previousBtnStatus
     * @param nextBtnStatus
     */
    protected void verifyFooterNavBtns(boolean firstPageBtnStatus, boolean previousBtnStatus, boolean nextBtnStatus,
                                       boolean lastPageBtnStatus) {

        verifyFooterNavBtns(firstPageBtnStatus, previousBtnStatus, nextBtnStatus, lastPageBtnStatus,
                this.firstPageBtn, this.previousBtn, this.nextBtn, this.lastPageBtn);
    }

    /**
     * Validate grid navigation control buttons in panel footer
     *
     * @param previousBtnStatus
     * @param nextBtnStatus
     */
    private void verifyFooterNavBtns(boolean firstPageBtnStatus, boolean previousBtnStatus, boolean nextBtnStatus,
                                     boolean lastPageBtnStatus, WebElement firstPageBtn, WebElement previousBtn,
                                     WebElement nextBtn, WebElement lastPageBtn) {
        assertEquals(getFirstPageBtnStatus(firstPageBtn), firstPageBtnStatus);
        assertEquals(getPreviousBtnStatus(previousBtn), previousBtnStatus);
        assertEquals(getNextBtnStatus(nextBtn), nextBtnStatus);
        assertEquals(getLastPageBtnStatus(lastPageBtn), lastPageBtnStatus);
    }

    /**
     * Get first page button status
     *
     * @return
     */
    private boolean getFirstPageBtnStatus(WebElement firstPageBtn) {
        return getGridNavigationBtnStatus(firstPageBtn);
    }

    /**
     * Get previous button status
     *
     * @return
     */
    private boolean getPreviousBtnStatus(WebElement previousBtn) {
        return getGridNavigationBtnStatus(previousBtn);
    }

    /**
     * Get next button status
     *
     * @return
     */
    private boolean getNextBtnStatus(WebElement nextBtn) {
        return getGridNavigationBtnStatus(nextBtn);
    }

    /**
     * Get last page button status
     *
     * @return
     */
    private boolean getLastPageBtnStatus(WebElement lastPageBtn) {
        return getGridNavigationBtnStatus(lastPageBtn);
    }

    /**
     * Get grid navigation control buttons status
     *
     * @param btnElement
     * @return
     */
    private boolean getGridNavigationBtnStatus(WebElement btnElement) {
        if (btnElement.getAttribute("class").equals("paging-btn disabled")) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Validate Grid Navigation control buttons tool tip
     */
    public void verifyNavigationBtnsTooptip() {

        verifyNavigationBtnsTooptip(this.firstPageBtn, this.previousBtn, this.nextBtn, this.lastPageBtn);
    }

    /**
     * Validate Grid Navigation control buttons tool tip
     */
    public void verifyNavigationBtnsTooptip(WebElement firstPageBtn, WebElement previousBtn,
                                            WebElement nextBtn, WebElement lastPageBtn) {

        assertEquals(firstPageBtn.getAttribute("title"), "First Page");
        assertEquals(previousBtn.getAttribute("title"), "Previous");
        assertEquals(nextBtn.getAttribute("title"), "Next");
        assertEquals(lastPageBtn.getAttribute("title"), "Last Page");
    }

    /**
     * Verify Page Size Selection
     */
    public void verifyPageSizeSelection(WebElement selectPageSize, WebElement pagingPositionDiv,
                                        Enum<SelectPageSizesEnum> pageSize) {

        //Verify default page size
        assertEquals(getPageSizeSelection(selectPageSize),
                Integer.parseInt(((SelectPageSizesEnum) pageSize).name));

        //Verify dropdown values
        List<String> dropdownValues = getSelectPageSizeValues(selectPageSize);
        assertEquals(dropdownValues, CommonGrid.SelectPageSizesEnum.getValues());

        //Verify change page size
        for (String dropdownValue : dropdownValues) {
            int pageUpperBound = getPageUpperBound(pagingPositionDiv);
            int value = Integer.parseInt(dropdownValue);

            if (getTotalRecordCount(pagingPositionDiv) > value) {
                selectPageSizeValue(dropdownValue, selectPageSize);
                waitUntilSpinnerVisibleThenInvisible(driver, 2, 10);
                assertNotEquals(getPageUpperBound(pagingPositionDiv), pageUpperBound);
                int pageUpperBoundNew =
                        (getTotalRecordCount(pagingPositionDiv) > value) ? value : getTotalRecordCount(pagingPositionDiv);
                assertEquals(getPageUpperBound(pagingPositionDiv), pageUpperBoundNew);
            } else {
                logger.info(String.format("Skipped verifying page size %s because total number of records %s",
                        value, getTotalRecordCount(pagingPositionDiv)));
            }
        }
    }

    /**
     * Verify Page Size Selection
     */
    public void verifyPageSizeSelection() {
        verifyPageSizeSelection(this.selectPageSize, this.pagingPositionDiv, SelectPageSizesEnum.FIFTY);
    }


    /**
     * Verify Page Size Selection
     * @param pageSize - default page size on a page
     */
    public void verifyPageSizeSelection(Enum<SelectPageSizesEnum> pageSize) {
        verifyPageSizeSelection(this.selectPageSize, this.pagingPositionDiv, pageSize);
    }

    /**
     * Verify pagination Display info "startIndex - showEntries of userCount"
     */
    public void verifyPaginationBoundsDisplay(WebElement pagingPositionDiv) {

        String text = String.format("%s - %s of %s",
                getPageLowerBound(pagingPositionDiv),
                getPageUpperBound(pagingPositionDiv),
                getTotalRecordCount(pagingPositionDiv));

        //Need to remove text that could be at the end of counters like "ADD TO RENEWAL ORDER" button
        String pagingPositionDivText = pagingPositionDiv.getText().replaceAll("\\D*$", "");

        assertEquals(pagingPositionDivText, text);
    }

    /**
     * Verify pagination Display info "startIndex - showEntries of userCount"
     */
    public void verifyPaginationBoundsDisplay() {
        verifyPaginationBoundsDisplay(this.pagingPositionDiv);
    }

    /**
     * Verify vertical scrollbar is present
     */
    public void verifyGridVerticalScrollbar() {
        verifyGridVerticalScrollbar("div.antiscroll-inner");
    }

    /**
     * Verify vertical scrollbar is present for given grid css
     *
     * @param gridCss - Grid CSS locator. Common scrolling div is 'div.antiscroll-inner'. Use locator to identify exactly the one
     */
    public void verifyGridVerticalScrollbar(String gridCss) {

        //common scrolling div is 'div.antiscroll-inner'. Use locator to identify exactly the one
        //For example div.active div.ember-table-body-container.antiscroll-wrap div.antiscroll-inner

        JavascriptExecutor javascript = (JavascriptExecutor) driver;

        String verticalScript = "var div = document.querySelector('" + gridCss + "');" +
                " return div.scrollHeight > div.clientHeight;";

        assertTrue((Boolean) javascript.executeScript(verticalScript));
    }

    /**
     * Verify vertical scrollbar is present
     */
    public void verifyGridHorizontalScrollbar() {
        verifyGridVerticalScrollbar("div.antiscroll-inner");
    }

    /**
     * Verify horizontal scrollbar is present for given grid css
     *
     * @param gridCss - Grid CSS locator. Common scrolling div is 'div.antiscroll-inner'. Use locator to identify exactly the one
     */
    public void verifyGridHorizontalScrollbar(String gridCss) {

        JavascriptExecutor javascript = (JavascriptExecutor) driver;

        String horizontalScript = "var div = document.querySelector" + "('" + gridCss + "');" +
                " return div.scrollWidth > div.clientWidth;";

        assertTrue((Boolean) javascript.executeScript(horizontalScript));
    }

    /**
     * Method to do full validation of paging includes:
     * - Verify Page Size Selection
     * - Verify navigation buttons
     * - Verify pagination display info "startIndex - showEntries of userCount"
     */
    public void verifyPagination() {

        //Verify Page Size Selection
        verifyPageSizeSelection();

        //Verify navigation buttons
        verifyNavigationElementsPresent();
        verifyNavigationBtns();
        verifyNavigationBtnsTooptip();

        //Verify pagination display info "startIndex - showEntries of userCount"
        verifyPaginationBoundsDisplay();
    }

    /**
     * Method to do full validation of paging includes:
     * - Verify Page Size Selection
     * - Verify navigation buttons
     * - Verify pagination display info "startIndex - showEntries of userCount"
     * @param table table - Grid locator
     */
    public void verifyPagination(WebElement table) {

        //Verify Page Size Selection
        verifyPageSizeSelection(
                table.findElement(By.cssSelector(SELECT_PAGE_SIZE)),
                table.findElement(By.cssSelector(PAGING_POSITION_DIV)),
                SelectPageSizesEnum.FIFTY);

        //Verify navigation buttons
        verifyNavigationElementsPresent(
                table.findElement(By.cssSelector(FIRST_PAGE_BTN)),
                table.findElement(By.cssSelector(PREVIOUS_BTN)),
                table.findElement(By.cssSelector(NEXT_BTN)),
                table.findElement(By.cssSelector(LAST_PAGE_BTN)),
                table.findElement(By.cssSelector(REFRESH_BTN)),
                table.findElement(By.cssSelector(SELECT_PAGE_SIZE)),
                table.findElement(By.cssSelector(PAGING_POSITION_DIV)));

        verifyNavigationBtns(
                table.findElement(By.cssSelector(FIRST_PAGE_BTN)),
                table.findElement(By.cssSelector(PREVIOUS_BTN)),
                table.findElement(By.cssSelector(NEXT_BTN)),
                table.findElement(By.cssSelector(LAST_PAGE_BTN)),
                table.findElement(By.cssSelector(SELECT_PAGE_SIZE)),
                table.findElement(By.cssSelector(PAGING_POSITION_DIV)));

        verifyNavigationBtnsTooptip(
                table.findElement(By.cssSelector(FIRST_PAGE_BTN)),
                table.findElement(By.cssSelector(PREVIOUS_BTN)),
                table.findElement(By.cssSelector(NEXT_BTN)),
                table.findElement(By.cssSelector(LAST_PAGE_BTN)));

        //Verify pagination display info "startIndex - showEntries of userCount"
        verifyPaginationBoundsDisplay(table.findElement(By.cssSelector(PAGING_POSITION_DIV)));
    }

    /**
     * Method to do full validation of paging includes:
     * - Verify Page Size Selection
     * - Verify navigation buttons
     * - Verify pagination display info "startIndex - showEntries of userCount"
     */
    public void verifyPagination(Enum<SelectPageSizesEnum> pageSize, WebElement firstPageBtn, WebElement previousBtn,
                                    WebElement nextBtn, WebElement lastPageBtn) {

        //Verify Page Size Selection
        verifyPageSizeSelection(pageSize);

        //Verify navigation buttons
        verifyNavigationElementsPresent(firstPageBtn, previousBtn, nextBtn, lastPageBtn);

        verifyNavigationBtns(firstPageBtn, previousBtn, nextBtn, lastPageBtn);

        verifyNavigationBtnsTooptip(firstPageBtn, previousBtn, nextBtn, lastPageBtn);

        //Verify pagination display info "startIndex - showEntries of userCount"
        verifyPaginationBoundsDisplay();
    }


    /**
     * Verify Ability to sort in ascending & descending when click on column
     *
     * @param columnName
     */
    public void verifyColumnSorting(String columnName) {

        verifyColumnSorting(this.HEADER_COLUMN_DIV_XPATH, columnName);
    }

    /**
     * Verify Ability to sort in ascending & descending when click on column
     *
     * @param columnName
     */
    public void verifyColumnSorting(String HEADER_COLUMN_DIV_XPATH, String columnName) {

        //Check if column not active sorting then click to activate sorting
        if (!isColumnSortedAscending(HEADER_COLUMN_DIV_XPATH, columnName))
            clickHeaderColumn(HEADER_COLUMN_DIV_XPATH, columnName);
        assertTrue(isColumnSortedAscending(HEADER_COLUMN_DIV_XPATH, columnName));
        clickHeaderColumn(HEADER_COLUMN_DIV_XPATH, columnName);
        assertTrue(isColumnSortedDescending(HEADER_COLUMN_DIV_XPATH, columnName));
    }

    public WebElement getPagingPositionDiv(WebElement table) {
        return table.findElement(By.cssSelector(PAGING_POSITION_DIV));
    }

    public String getRefreshBtnCSS() {
        return REFRESH_BTN;
    }
}
