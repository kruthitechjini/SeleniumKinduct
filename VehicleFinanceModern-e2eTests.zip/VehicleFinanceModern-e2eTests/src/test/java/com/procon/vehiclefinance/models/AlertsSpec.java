package com.procon.vehiclefinance.models;

import java.util.ArrayList;

public class AlertsSpec {
    private String alertName;
    private String scope;
    private String group;
    private String vehicle;
    private boolean selectAllAlerts;
    private ArrayList<AlertType> includeAlerts;
    private ArrayList<AlertType> removeAlerts;
    private boolean validAllDays;
    private boolean validMonToFri;
    private ArrayList<String> validWeekDays;
    private boolean validAnyTime;
    private String validStartTime;
    private String validEndTime;
    private Double distanceInterval;

    private AlertsSpec(String alertName, Double distanceInterval, String scope, String group, String vehicle,
                       Boolean selectAllAlerts, ArrayList<AlertType> includeAlerts, ArrayList<AlertType> removeAlerts,
                       boolean validAllDays, boolean validMonToFri, ArrayList<String> validWeekDays,
                       boolean validAnyTime, String validStartTime, String validEndTime ) {
        this.alertName = alertName;
        this.distanceInterval = distanceInterval;
        this.scope = scope;
        this.group = group;
        this.vehicle = vehicle;
        this.selectAllAlerts = selectAllAlerts;
        this.includeAlerts = includeAlerts;
        this.removeAlerts = removeAlerts;
        this.validAllDays = validAllDays;
        this.validMonToFri = validMonToFri;
        this.validWeekDays = validWeekDays;
        this.validAnyTime = validAnyTime;
        this.validStartTime = validStartTime;
        this.validEndTime = validEndTime;
    }

    private AlertsSpec(String alertName,  Double distanceInterval){
        this.alertName = alertName;
        this.distanceInterval = distanceInterval;
    }
    public String getAlertName() {
        return alertName;
    }

    public String getScope() {
        return scope;
    }

    public String getGroup() {
        return group;
    }

    public String getVehicle() {
        return vehicle;
    }

    public Boolean getSelectAllAlerts() {
        return selectAllAlerts;
    }

    public ArrayList<AlertType> getIncludeAlerts() {
        return includeAlerts;
    }

    public ArrayList<AlertType> getRemoveAlerts() {
        return removeAlerts;
    }

    public Boolean getValidAllDays() {
        return validAllDays;
    }

    public Boolean getValidMonToFri() {
        return validMonToFri;
    }

    public ArrayList<String> getValidWeekDays() {
        return validWeekDays;
    }

    public Boolean getValidAnyTime() {
        return validAnyTime;
    }

    public String getValidStartTime() {
        return validStartTime;
    }

    public String getValidEndTime() {
        return validEndTime;
    }

    public Double getDistanceInterval() { return distanceInterval; }


    public static class AlertsSpecBuilder {
        private String alertName;
        private String scope;
        private String group;
        private String vehicle;
        private boolean selectAllAlerts;
        private ArrayList<AlertType> includeAlerts;
        private ArrayList<AlertType> removeAlerts;
        private boolean validAllDays;
        private boolean validMonToFri;
        private ArrayList<String> validWeekDays;
        private boolean validAnyTime;
        private String validStartTime;
        private String validEndTime;
        private Double distanceInterval;

        public AlertsSpecBuilder distanceInterval(Double distanceInterval) {
            this.distanceInterval = distanceInterval;
            return this;
        }

        public AlertsSpecBuilder alertName(String alertName) {
            this.alertName = alertName;
            return this;
        }

        public AlertsSpecBuilder scope(String scope) {
            this.scope = scope;
            return this;
        }

        public AlertsSpecBuilder group(String group) {
            this.group = group;
            return this;
        }

        public AlertsSpecBuilder vehicle(String vehicle) {
            this.vehicle = vehicle;
            return this;
        }

        public AlertsSpecBuilder selectAllAlerts(Boolean selectAllAlerts) {
            this.selectAllAlerts = selectAllAlerts;
            return this;
        }

        public AlertsSpecBuilder includeAlerts(ArrayList<AlertType> includeAlerts) {
            this.includeAlerts = includeAlerts;
            return this;
        }

        public AlertsSpecBuilder removeAlerts(ArrayList<AlertType> removeAlerts) {
            this.removeAlerts = removeAlerts;
            return this;
        }

        public AlertsSpecBuilder validAllDays(Boolean validAllDays) {
            this.validAllDays = validAllDays;
            return this;
        }

        public AlertsSpecBuilder validMonToFri(Boolean validMonToFri) {
            this.validMonToFri = validMonToFri;
            return this;
        }

        public AlertsSpecBuilder validWeekDays(ArrayList<String> validWeekDays) {
            this.validWeekDays = validWeekDays;
            return this;
        }

        public AlertsSpecBuilder validAnyTime(Boolean validAnyTime) {
            this.validAnyTime = validAnyTime;
            return this;
        }

        public AlertsSpecBuilder validStartTime(String validStartTime) {
            this.validStartTime = validStartTime;
            return this;
        }

        public AlertsSpecBuilder validEndTime(String validEndTime) {
            this.validEndTime = validEndTime;
            return this;
        }

        public AlertsSpec build() {
            return new AlertsSpec(alertName,distanceInterval, scope, group, vehicle, selectAllAlerts, includeAlerts, removeAlerts, validAllDays,
                    validMonToFri, validWeekDays, validAnyTime, validStartTime, validEndTime);
        }
    }
}
