package com.procon.vehiclefinance.tests.admin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.procon.vehiclefinance.models.*;
import com.procon.vehiclefinance.pageobjects.CommonGrid;
import com.procon.vehiclefinance.pageobjects.NavbarHeaderPage;
import com.procon.vehiclefinance.pageobjects.admin.*;
import com.procon.vehiclefinance.pageobjects.map.MapPage;
import com.procon.vehiclefinance.tests.BaseTest;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.procon.vehiclefinance.services.AccountService.exportRenewals;
import static com.procon.vehiclefinance.services.AccountService.getRenewals;
import static com.procon.vehiclefinance.util.CSVUtils.getCsvFirstRow;
import static com.procon.vehiclefinance.util.WebElements.waitUntilSpinnerVisibleThenInvisible;
import static org.testng.Assert.*;

public class AdminAMRenewalsTest extends BaseTest {

    protected static final Logger logger = LoggerFactory.getLogger(AdminAMRenewalsTest.class);

    protected MapPage mapPage;
    private AdminLeftBarPage adminLeftBarPage;
    private NavbarHeaderPage navbarHeaderPage;
    private AdminAccountManagementPage adminAMPage;

    Address reynolds_address = new Address.AddressBuilder()
            .street("1721 Reynolds Ave")
            .city("Irvine")
            .state("CA - California")
            .postalCode("92614")
            .country("United States")
            .build();

    CreditCard visaTestCard = new CreditCard.CreditCardBuilder()
            .number("4111111111111111")
            .month("01")
            .year(Integer.toString(Calendar.getInstance().get(Calendar.YEAR) + 3))
            .cvv("1234")
            .build();

    Person cardHolder = new Person.PersonBuilder()
            .firstName("John")
            .lastName("Doe")
            .phone("5555555555")
            .email("a@b.com")
            .build();

    // this class needs to be static for Jackson to be able to databind to it
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class LoginData {
        public String userName;
        public String password;
        public String renewalsPage;
    }

    static class AccountData {
        public boolean isAccountTaxed;
    }

    static class TestData {
        public String serialNumber;
        public String description;
        public String vinNumber;
    }

    @BeforeMethod(alwaysRun = true)
    protected void loginAndClickAdmin(Method method) {

        JsonNode dataNode = envNode.at("/" + method.getName());

        LoginData data = null;
        try {
            data = mapper.treeToValue(dataNode, LoginData.class);
            userName = data.userName;
            password = data.password;
            renewalsPage = data.renewalsPage;

            if (userName == null) {
                userName = System.getProperty("userName");
                password = System.getProperty("password");
                renewalsPage = System.getProperty("renewalsPage");
            }

        } catch (JsonProcessingException e) {
        }

        //Login
        mapPage = login();

        //Create instance of NavbarHeaderPage class to handle top nav bar
        navbarHeaderPage = PageFactory.initElements(driver, NavbarHeaderPage.class);

        //Navigate to Admin Page
        adminLeftBarPage = navbarHeaderPage.clickAdmin();

        //Navigate to Account Management Page
        adminAMPage = adminLeftBarPage.clickAccountManagementLink();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);
    }

    @AfterMethod(alwaysRun = true)
    protected void logout(ITestResult testResult, ITestContext context) throws IOException {

        takeScreenShotOnFailure(testResult, context);

        //Logout
        if (navbarHeaderPage != null) {
            navbarHeaderPage.logout();
        }

        //reset to default userName, password and renewalsPage
        userName = System.getProperty("userName");
        password = System.getProperty("password");
        renewalsPage = System.getProperty("renewalsPage");
    }

    @Test(description = "Renew single device", groups = {"o2c"})
    public void testDeviceRenewal() {

        // 06/21/2018 12:00 am
        final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy K:h a");

        // Open Account Management Orders Tab, get last processed order
        AdminAMOrdersPage adminAMOrdersPage = adminAMPage.openOrdersTab();
        HashMap<String, String> lastOrder = adminAMOrdersPage.getLastOrder();
        logger.info("Last Processed Order: " + lastOrder);

        // Renew first device from the list
        adminAMPage = adminAMOrdersPage.openRenewTab();
        adminAMPage.waitWhileLoading();
        String deviceSerial = adminAMPage.getFirstSerial();
        logger.info("First device serial: " + deviceSerial);
        AdminAMBillingPage billingPage = adminAMPage.addFirstDeviceToRenewOrder(reynolds_address);
        AdminAMReviewOrderPage reviewOrderPage = billingPage.payWithCreditCard(
                reynolds_address, visaTestCard, cardHolder);
        reviewOrderPage.renewDevices();

        String message = reviewOrderPage.getConfirmationText();

        assertTrue(message.contains("Your order is being processed"),
                "Device renewal order was not processed.\n" + message + "\n");
        adminAMOrdersPage = adminAMPage.openOrdersTab();

        adminAMOrdersPage.waitForNewOrder(lastOrder, 1000); // 1000 16+ minutes
        HashMap<String, String> newOrder = adminAMOrdersPage.getLastOrder();
        assertNotEquals(lastOrder, newOrder, "New device renewal order was not created");
        logger.info("Current Order: " + newOrder);

        adminAMOrdersPage.waitForOrderComplete(1000); // 1000 16+ minutes
        newOrder = adminAMOrdersPage.getLastOrder();
        assertEquals(newOrder.get("Order Status"), "COMPLETED", "New device renewal order was not completed");

        HashMap<String, String> newOrderDetails = adminAMOrdersPage.getLastOrderDetails();
        logger.info("Order details: " + newOrderDetails);
        assertEquals(newOrderDetails.get("Device Name"), deviceSerial,
                "Device Name in order details does not match first device serial");
        // Adding 1 year to current date to get expected deviceRenewal date
        Calendar expectedRenewalDate = Calendar.getInstance();
        expectedRenewalDate.add(Calendar.YEAR, 1);
        String deviceRenewalString = newOrderDetails.get("Expires On");
        Date deviceRenewal = null;
        try {
            deviceRenewal = DATE_FORMAT.parse(deviceRenewalString);
        } catch (java.text.ParseException pe) {
            logger.info("Cannot parse the date: " + deviceRenewalString);
        }

        Long millis = Math.abs(deviceRenewal.getTime() - expectedRenewalDate.getTime().getTime());
        Long difference = TimeUnit.DAYS.convert(millis, TimeUnit.MILLISECONDS);
        logger.info("Renewal date difference: " + difference + " day(s)");
        assertTrue(difference.longValue() < 3,
                "Incorrect Device renewal date: "
                        + DATE_FORMAT.format(deviceRenewal) + " for 1 year has "
                        + difference + " day(s) difference");
    }

    @Test(description = "Renew single device - cancel", groups = {"prodsmoke", "admin"})
    public void testDeviceRenewalCancel() {

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        AccountData data = null;

        //set default value in case it is not defined in test_data.json
        boolean isAccountTaxed = false;

        try {
            data = mapper.treeToValue(dataNode, AccountData.class);
            isAccountTaxed = data.isAccountTaxed;
        } catch (JsonProcessingException e) {
        }

        //get first serial number
        String deviceSerial = adminAMPage.getFirstSerial();
        logger.info("First device serial: " + deviceSerial);

        //Select device and fill order and payment info
        adminAMPage.selectFirstDevice();
        adminAMPage.clickAddToRenewalOrderBtn();

        AdminAMBillingPage billingPage = null;
        if (isAccountTaxed) {
            Address address = new Address.AddressBuilder()
                    .street("16802 Aston St")
                    .city("Irvine")
                    .state("CA - California")
                    .postalCode("92606")
                    .country("United States")
                    .build();

            adminAMPage.clickContinueBtn();
            adminAMPage.calculateTax(address);
            billingPage = adminAMPage.clickContinueBtn();
        } else {
            billingPage = adminAMPage.clickContinueBtn();
        }

        AdminAMReviewOrderPage reviewOrderPage = billingPage.payWithCreditCard(
                reynolds_address, visaTestCard, cardHolder);

        //Cancel order (do not save it)
        reviewOrderPage.cancelRenewal();

    }

    @Test(description = "Search for device to renew", groups = {"admin"})
    public void testDeviceRenewalSearch() {

        String deviceSerial = adminAMPage.getFirstSerial();
        adminAMPage.searchDevice(deviceSerial);
        assertEquals(adminAMPage.getTotalRecordCount(), 1, "Only one device should be displayed: " + deviceSerial);
    }

    @Test(description = "UI verification of Admin > Account Management > Renewals tab", groups = {"admin"})
    public void testAdminAMRenewalsUIElements() {

        final List<String> DEVICE_LIST_GRID_COLUMNS = Arrays.asList("Serial", "Description", "Group", "VIN",
                "Expiration", "Renewable Until", "Last Event", "Date & Time");

        final List<String> RENEWAL_ORDER_GRID_COLUMNS = Arrays.asList("Serial", "Description", "Service Until",
                "Price", "Remove");

        //Validate Grid Columns.
        assertEquals(adminAMPage.getGridColumns(), DEVICE_LIST_GRID_COLUMNS);

        //Validate Pagination Info
        adminAMPage.verifyPagination(CommonGrid.SelectPageSizesEnum.HUNDRED, adminAMPage.getFirstPageBtn(),
                adminAMPage.getPreviousBtn(), adminAMPage.getNextBtn(), adminAMPage.getLastPageBtn());

        //Validate 'ADD TO RENEWAL ORDER' command button is displayed
        assertTrue(adminAMPage.getAddToRenewalOrderCmdBtn().isDisplayed());

        //Validate renewal order grid columns.
        assertEquals(adminAMPage.getRenewalOrderGridColumns(), RENEWAL_ORDER_GRID_COLUMNS);

        //Validate 'Remove All' link is displayed
        assertTrue(adminAMPage.getRemoveAllLink().isDisplayed());

        //Validate 'Subtotal: $0' is displayed
        assertTrue(adminAMPage.getSubTotal().isDisplayed());
        assertEquals(adminAMPage.getSubTotal().getText(), "Subtotal: $0");

        //Validate 'Total: $0.00' is displayed
        assertTrue(adminAMPage.getTotal().isDisplayed());
        assertEquals(adminAMPage.getTotal().getText(), "Total: $0.00");

        //Validate 'CONTINUE' button is displayed
        assertTrue(adminAMPage.getContinueBtn().isDisplayed());

        //validate text in footer
        assertEquals(adminAMPage.getNoticeText().getText(), "Suspended devices can be renewed within 90 days" +
                " of the expiration date\nDevices are normally reactivated within 2-3 hours" +
                "\nPlease allow 3-5 business days for devices that have been expired more than a week.");
    }

    @Test(description = "UI verification of Admin > Account Management : Confirm and Submit Payment",
            groups = {"admin"})
    public void testAdminAMRenewalsBillingUIElements() {

        final List<String> REVIEW_ORDER_GRID_COLUMNS = Arrays.asList("Serial", "Description", "Service Until",
                "Price", "Remove");

        //Select Devices to Renew and click Continue
        AdminAMBillingPage adminAMBillingPage = adminAMPage.addFirstDeviceToRenewOrder(reynolds_address);

        //Validate Credit Card and Billing Information Fields displayed
        adminAMBillingPage.validateCreditCardBillingInformationUIElements();

        //verify country dropdown defaults to United States
        assertEquals(adminAMBillingPage.getCountryDropdownValue(), "United States");

        //Enter Payment Information and click REVIEW ORDER button
        AdminAMReviewOrderPage adminAMReviewOrderPage = adminAMBillingPage.payWithCreditCard(reynolds_address,
                visaTestCard, cardHolder);

        //Click Cancel button
        adminAMReviewOrderPage.clickCancelRenewalButton();

        //Validate Confirmation text
        assertEquals(adminAMReviewOrderPage.getRemoveDevicesCancelConfirmationText(),
                "Are you sure you want to cancel this order?");

        //Confirm Cancel
        adminAMReviewOrderPage.clickCancelConfirmYesBtn();
        waitUntilSpinnerVisibleThenInvisible(driver, 1, 10);

        //Validate UI is navigated back to renewals grid
        assertTrue(adminAMPage.getRenewalOrderTable().isDisplayed());

        //Select Devices to Renew and click Continue
        adminAMPage.addFirstDeviceToRenewOrder(reynolds_address);

        //Enter Payment Information and click REVIEW ORDER button
        adminAMBillingPage.payWithCreditCard(reynolds_address, visaTestCard, cardHolder);

        //Validate review order grid columns
        assertEquals(adminAMPage.getRenewalOrderGridColumns(), REVIEW_ORDER_GRID_COLUMNS);

        //Validate Review Order buttons
        adminAMReviewOrderPage.validateReviewOrderButtons();

        //TODO open issue: https://jira.spireon.com/browse/VFM-5148
        // Renew Devices confirmation message shows and Order History tab with most recent order at the top shows
    }

    @Test(description = "Admin > Account Management > Renew Devices - Verify Search/Sort/Paginate Functionality",
            groups = {"admin"})
    public void testRenewalsSearchSortPaginate() throws UnirestException {

        final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");

        JsonNode dataNode = envNode.at("/" + Thread.currentThread().getStackTrace()[1].getMethodName());

        TestData data = null;
        try {
            data = mapper.treeToValue(dataNode, TestData.class);
        } catch (JsonProcessingException e) {
            fail("Failed to process data values", e);
        }

        //Validate search when there are no devices in the list
        if (adminAMPage.getTotalRecordCount() == 0) {

            adminAMPage.search(data.serialNumber);
            assertEquals(adminAMPage.getTotalRecordCount(), 0);
            assertEquals(getRenewals(driver, data.serialNumber).total, 0);

        } else {

            //Validate search by serial number
            searchAndValidateData(data.serialNumber, DATE_FORMAT);

            //Validate search by description
            searchAndValidateData(data.description, DATE_FORMAT);

            //Validate search by VIN number
            searchAndValidateData(data.vinNumber, DATE_FORMAT);

            //Validate search by non-existing device with alpha-numerics and search returns nothing
            String deviceNotExists = "Automated Test-" + System.currentTimeMillis();
            adminAMPage.search(deviceNotExists);
            assertEquals(adminAMPage.getTotalRecordCount(), 0);
            assertEquals(getRenewals(driver, deviceNotExists).total, 0);

            //Clear search
            adminAMPage.getSearchInputCancel().click();
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

            //Validate renewal status filter functions - Suspended
            adminAMPage.selectRenewalStatus("Suspended");
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
            int suspendedRecordCount = adminAMPage.getTotalRecordCount();
            validateRenewalStatusData(false, DATE_FORMAT);

            //Renewal status - Expiring
            adminAMPage.selectRenewalStatus("Expiring");
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);
            int expiringRecordCount = adminAMPage.getTotalRecordCount();
            validateRenewalStatusData(true, DATE_FORMAT);

            //Renewal status - All
            adminAMPage.selectRenewalStatus("All");
            waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

            //Validate Renewal status counts, All = Suspended + Expiring
            assertEquals(adminAMPage.getTotalRecordCount(), suspendedRecordCount + expiringRecordCount);

            //Add two devices to renewal order grid
            adminAMPage.clickCheckbox(1);
            //adminAMPage.clickAddToRenewalOrderBtn();
            adminAMPage.clickCheckbox(2);
            adminAMPage.clickAddToRenewalOrderBtn();

            //Validate sum of price matches to total
            assertTrue(validateRenewalOrderTotal());

            //waitUntilSpinnerVisibleThenInvisible(driver, 1, 5);

            //Validate export links CSV, PDF and XLS
            assertTrue(adminAMPage.getExportBtn().isEnabled(), "Export button is not enabled or visible");
            adminAMPage.getExportBtn().click();
            assertTrue(adminAMPage.getExportCSVLink().isEnabled());
            assertTrue(adminAMPage.getExportPDFLink().isEnabled());
            assertTrue(adminAMPage.getExportXLSLink().isEnabled());

            //Validate export devices in CSV, PDF and XLS
            String exportFileName = "renewalDevices_" + System.currentTimeMillis();
            for (ExportFormat format : ExportFormat.values()) {
                File file = new File(String.format("./download/%s.%s", exportFileName,
                        format.getType()));
                try {
                    InputStream is = exportRenewals(driver, format.getType());
                    FileUtils.copyInputStreamToFile(is, file);
                } catch (UnirestException | IOException e) {
                    e.printStackTrace();
                    fail(e.getMessage());
                }

                //Validate file is downloaded
                assertTrue(file.exists());

                //Validate downloaded file size is greater than 0 bytes
                assertTrue(file.length() > 0);
            }

            //TODO open issue: https://jira.spireon.com/browse/VFM-5145
            //Validate csv first row and grid first row are matching
            /*File file = new File("./download/" + "exportFileName.csv");
            assertEquals(adminAMPage.getTableFirstRow(), getCsvFirstRow(file));*/

            //Delete download folder
            FileUtils.deleteQuietly(new File("./download/"));

            //Verify columns

            List<String> columnList = adminAMPage.getGridColumns();

            //Validate Sort on each column
            columnList.forEach(column -> {
                if (!column.equals("Serial") && !column.equals("Description") && !column.equals("VIN") &&
                        !column.equals("Expiration"))
                    assertTrue(adminAMPage.isColumnSortable(column));
            });

            //Verify Ability to sort in ascending & descending when click on 'Group', 'Renewable Until',
            // 'Last Event' and 'Date & Time' columns
            columnList.forEach(column -> {
                if (!column.equals("Serial") && !column.equals("Description") && !column.equals("VIN") &&
                        !column.equals("Expiration"))
                    adminAMPage.verifyColumnSorting(column);
            });
        }
    }

    /**
     * Search and validate data.
     *
     * @param searchKey
     * @throws UnirestException
     */
    public void searchAndValidateData(String searchKey, DateFormat DATE_FORMAT) throws UnirestException {


        adminAMPage.search(searchKey);

            Account.RenewalDevices renewalDevices = getRenewals(driver, searchKey);

            HashMap<String, String> gridFirstRecord = adminAMPage.getTableFirstRow();
            gridFirstRecord.put("Expiration", gridFirstRecord.get("Expiration").split(" \\(")[0]);

            //Validate total record count in UI with API
            assertEquals(adminAMPage.getTotalRecordCount(), renewalDevices.total);

            //Validate first record in grid with data obtained using api call
            assertEquals(gridFirstRecord, adminAMPage.getApiFirstRecord(renewalDevices.data, DATE_FORMAT));

    }

    /**
     * Validate renewal status data after filtering
     *
     * @param renewalStatus Accepted value : Suspended = false and Expiring = true
     * @return
     * @throws UnirestException
     */
    public void validateRenewalStatusData(boolean renewalStatus, DateFormat DATE_FORMAT)
            throws UnirestException {

        Account.RenewalDevices renewalDevicesData = getRenewals(driver, renewalStatus);

        //Validate total record count in UI with API
        assertEquals(adminAMPage.getTotalRecordCount(), renewalDevicesData.total);

        if (adminAMPage.getTotalRecordCount() > 0) {

            HashMap<String, String> gridFirstRecord = adminAMPage.getTableFirstRow();

            if (!renewalStatus) {

                //Validate expiration shows expired date
                assertTrue(adminAMPage.getTableFirstRow().get("Expiration").contains("ago"));
            } else {

                //Validate expiration shows expiration date
                assertTrue(adminAMPage.getTableFirstRow().get("Expiration").contains("in"));
            }

            gridFirstRecord.put("Expiration", gridFirstRecord.get("Expiration").split(" \\(")[0]);

            //Validate first record in grid with data obtained using api call
            assertEquals(gridFirstRecord, adminAMPage.getApiFirstRecord(renewalDevicesData.data, DATE_FORMAT));

            //Validate by adding some devices to renewal order grid
            adminAMPage.selectFirstDevice();
            adminAMPage.clickAddToRenewalOrderBtn();

            //Validate Renewal Order grid data
            HashMap<String, String> renewalOrderTableFirstRow = adminAMPage.getRenewalOrderTableFirstRow();
            renewalOrderTableFirstRow.remove("Remove");

            gridFirstRecord.remove("Group");
            gridFirstRecord.remove("VIN");
            gridFirstRecord.remove("Expiration");
            gridFirstRecord.remove("Renewable Until");
            gridFirstRecord.remove("Last Event");
            gridFirstRecord.remove("Date & Time");

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.YEAR, 1);

            gridFirstRecord.put("Service Until", DATE_FORMAT.format(calendar.getTime()));

            gridFirstRecord.put("Price", "$" + renewalDevicesData.data.get(0).renewalOptions.get(0).price);

            //Validate first record in Renewal Order grid with Renew Devices grid
            assertEquals(renewalOrderTableFirstRow, gridFirstRecord);
            if(renewalOrderTableFirstRow.size() > 0) {
                adminAMPage.removeAllDevices();
            }
        }
    }

    /**
     * Validate renewal order total
     *
     * @return
     */
    public boolean validateRenewalOrderTotal() {

        final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.#");
        DECIMAL_FORMAT.setMinimumFractionDigits(2);

        Double priceSum = 0.00;
        List<HashMap<String, String>> tableContent = adminAMPage.getRenewalOrderTableContent();

        for (HashMap<String, String> row : tableContent) {
            String price = row.get("Price").replace("$", "");
            priceSum = priceSum + Double.parseDouble(price);
        }

        //Validate sum of price matches to total
        assertEquals("$" + DECIMAL_FORMAT.format(priceSum),
                adminAMPage.getTotal().getText().replace("Total: ", ""));
        return true;
    }
}
